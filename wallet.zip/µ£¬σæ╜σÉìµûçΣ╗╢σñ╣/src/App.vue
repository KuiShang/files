<template>
  <div id="app">
    <CommonHeader
      v-if="!isJDAPP"
      :title="title"
      :color="titleBlack? 'white': 'black'"
      :bgcolor="titleBlack? 'black': 'white'"
    >
      <CommonIcon
        slot="left"
        :color="titleBlack? 'white': 'black'"
        name="back"
        size=".4rem"
        @click="$router.go(-1)"
      />
    </CommonHeader>
    <router-view/>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import * as types from '@/store/mutation-types'

export default {
  name: 'App',
  data() {
    return {
    }
  },
  computed: {
    ...mapGetters([
      'title',
      'titleBlack'
    ]),
    isJDAPP() {
      return this.$utils.getSysType('isJdApp')
    }
  },
  async created() {
    this.$store.commit(types.SAVE_IS_APP, false)
    this.$store.commit(types.SET_TiTLE, 'Wallet')
    this.setLanguage('EN')
    if (this.isJDAPP) {
      if (this.$DeviceInfo.language === 'th_TH') {
        this.setLanguage('TH')
      }
    }

    // setTimeout(() => {
    //   this.$store.commit(types.SAVE_IS_APP, false)
    //   this.$store.commit(types.SET_TiTLE, 'Wallet')
    //   this.setLanguage('EN')
    //   if (this.isJDAPP) {
    //       this.setLanguage('TH')
    //     }
    //   }
    // }, 10)
    // this.setTitle()
    // this.$messagebox('提示', '操作成功');
  },
  methods: {
    setTitle() {
      this.$SDK.setTitle({
        title: 'wallet'
      })
    },
    ...mapMutations({
      setLanguage: 'SET_LANGUAGE'
    })
  }
}
</script>

<style lang="scss">
#app {
  height: 100%;
}
// ---------------收银台cdcp cvvinfo弹窗专用样式-------------start
.message-box-cashier-cdcp-cardinfo {
  text-align: center;
  padding-bottom: .4rem;
  .title {
    font-size: .48rem;
    color: #4F577C;
    padding-bottom: .4rem;
    margin-top: -10px;
  }
  .img {
    width: 4.9rem;
    padding-bottom: .48rem;
  }
  .txt {
    font-size: .36rem;
    color: #4F577C;
    padding-left: .8rem;
    padding-right: .8rem;
    line-height: .5rem;
    .bold {
      font-family: The1Official_bold;
    }
  }
}

.cdcp {
  .el-form-item__error {
      font-size: .28rem;
  }
}
.van-password-input {
.van-password-input__security {
  justify-content: center;
  li {
    border: 1px solid #A1A5B9;
    width: .96rem;
    height: .96rem;
    box-sizing: border-box;
    border-radius: 4px;
    flex: none;
  }
}
}


// ---------------收银台cdcp专用样式-------------end
</style>
