/*eslint-disable*/
export default function billpayment(mock) {
    // billpayment
    mock.onGet('/th/wallet/billpayment/queryPaymentType').reply(200, {
        "code": "000000", //返回code
        "msg": "success", //处理结果描述
        "resultData": [{
            "typeNo": "01",
            "name": "Mobile top-up",
            "typeImg": "Entertainment"
        },
        {
            "typeNo": "02",
            "name": "utility",
            "typeImg": "leasing"
        },
        {
            "typeNo": "03",
            "name": "Card Repay",
            "typeImg": "leasing"
        },
        {
            "typeNo": "04",
            "name": "Telco",
            "typeImg": "leasing"
        },
        {
            "typeNo": "05",
            "name": "Leasing",
            "typeImg": "Entertainment"
        },
        {
            "typeNo": "06",
            "name": "Credit Card/ Loan",
            "typeImg": "Entertainment"
        },
        {
            "typeNo": "07",
            "name": "Insurance",
            "typeImg": "leasing"
        },
        {
            "typeNo": "08",
            "name": "Education",
            "typeImg": "Entertainment"
        },
        {
            "typeNo": "09",
            "name": "Entertainment",
            "typeImg": "leasing"
        },
        {
            "typeNo": "10",
            "name": "Estate",
            "typeImg": "leasing"
        },
        {
            "typeNo": "11",
            "name": "Transport",
            "typeImg": "leasing"
        },
        {
            "typeNo": "12",
            "name": "ETC",
            "typeImg": "leasing"
        }
        ]
    })
    
    // billpayment  company
    mock.onGet('/th/wallet/billpayment/getCompanyByPayType').reply(200, {
        "code": "000000", //返回code
        "msg": "success", //处理结果描述
        "resultData": [{
        "id": 1,
        "name": "Universal Utility Co., Ltd.",
        "type": "02",
        "imgUrl": "Entertainment",
        "billType": {
            "keyin": 0,
            "scan": 1
        }
        }, {
        "id": 2,
        "name": "TOT - TRUE",
        "type": "02",
        "imgUrl": "leasing",
        "billType": {
            "keyin": 1,
            "scan": 0
        }
        }]
    })
    // billpayment  根据keyin获取最近5次历史记录
    mock.onGet('/th/wallet/billpayment/queryKeyInHistory').reply(200, {
        "code": "000000", //返回code
        "msg": "success", //处理结果描述
        "resultData": [{
        "id": 1,
        "name": "Universal Utility Co., Ltd.",
        "type": "02",
        "imgUrl": "Entertainment",
        "billType": {
            "keyin": 0,
            "scan": 1
        }
        }, {
        "id": 2,
        "name": "TOT - TRUE",
        "type": "02",
        "imgUrl": "leasing",
        "billType": {
            "keyin": 1,
            "scan": 0
        }
        }]
    })
    
    // billpayment  查询缴费结果
    mock.onGet('/th/wallet/billpayment/queryBillResult').reply(200, {
        "code": "000000", //返回code
        "msg": "success", //处理结果描述
        "resultData": {
        "amount": 40,
        "serviceFee": 3,
        "saleCompany": 'KFC',
        "bonous": 10, // 服务费补贴
        "date": "2018-3-18",
        "CA": "299999",
        "name": "jack"
        }
    })
}
