/*eslint-disable*/
export default function promotion(mock) {
  // 支付成功后返营销
  mock.onPost('/th/promo/queryHitInfo').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      "status": true,
      "maxCashback": 999,
      "promoInfo": {
          "action": "testAction",
          "needCheck": false,
          "needPwd": true,
          "riskId": null,
          "transactionNo": "12345456456456",
          "transactionStatus": null
      }
    }
  })

   // 支付成功后返营销命中
   mock.onPost('/th/promo/queryRewardInfo').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      "cashback": 44,
      "randomCash": [100, 20, 10]
    }
  })

}
