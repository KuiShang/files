/*eslint-disable*/
var axios = require('axios')
import billpayment from './billpayment'
import topup from './topup'
import cashier from './cashier'
import transfer from './transfer'
import withdraw from './withdraw'
import p2p from './p2p'
import promotion from './promotion'
import transDetail from './transDetail'
import coupon from './coupon'
import h5Config from './h5Config'
import invite from './invite'
import mission from './mission'
var MockAdapter = require('axios-mock-adapter')
var mock = new MockAdapter(axios, {
  delayResponse: 1000
})

billpayment(mock)
topup(mock)
cashier(mock)
transfer(mock)
withdraw(mock)
p2p(mock)
promotion(mock)
transDetail(mock)
coupon(mock)
h5Config(mock)
invite(mock)
mission(mock)

export default mock
