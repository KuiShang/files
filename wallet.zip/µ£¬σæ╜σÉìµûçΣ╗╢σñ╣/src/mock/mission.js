/*eslint-disable*/
export default function mission(mock) {
  mock.onPost('/scallop/meetTheScallop').reply(200, {
    "resultCode": 1, //返回code
    "msg": 'success', //处理结果描述
      'resultData': {
        'part1': {
          'missiondId': 'missiondIdString',
          'complete': 2,
          'times': 5,
        },
        'part2': {
          'missiondId': 'missiondIdString',
          'complete': 3,
          'reward': {
           
          }
        },
        'part3': {
          'missiondId': 'missiondIdString',
          'complete': 3,
          'payment': 1,
          'card': 1,
          'invite': 1,
          'reward': {
            'coupon': 'win'
          }
        }
    }
  })
  // mock.onPost('/scallop/meetTheScallop').reply(200, {
  //   "resultCode": 0, //返回code
  //   "msg": 'success', //处理结果描述
  //   "errorData": {
  //     'errorCode': 'kyc-too-low',
  //     'kycJump': 'http://www/baidu/com',
  //     'actionData': {
  //         'abc': '11',
  //         'bbb': '222'
  //     }
  //   }
  // })
  mock.onPost('/scallop/openScallop').reply(200, {
    'resultCode': 1,
    'resultData': {
      'number': 1
    }
  })
}
