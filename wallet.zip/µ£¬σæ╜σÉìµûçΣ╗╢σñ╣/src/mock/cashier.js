/*eslint-disable*/
export default function topup(mock) {
  // 收銀台初始化信息2
  mock.onPost('/th/cashier/query/method/list3').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      kycCheckResultModel: {
        kycCheckFlag: 1,
        kycPromptJsonMsg: {
          en: "Unable to proceed. Please contact Customer Service for assistance",
          th: "ไม่สามารถทำรายการได้ กรุณาติดต่อe",
          actionData: "{\"address\":\"/kyc/completeMsg\",\"params\":{},\"type\":\"native\"}"
        }
      },
      "cashierStyle": {
        "code": "half_screen"
      },
      "payOrderModel": {
        "amount": 23.00,
        "currency": "THB",
        "bizCode": "WLT_TRANSFER_BLE"
      },
      "payMethodModelList": [{
        "displayName": "BALA",
        "payMethodCodeFirst": "BALA",
        "payMethodCodeSecond": null,
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": 87935.58,
        "priority": 11000000,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "ODD.KBANK",
        "payMethodCodeFirst": "ODD",
        "payMethodCodeSecond": "KBANK",
        "payMethodCodeThird": null,
        "bizId": "7E8CB665EC867FEE4E619FADBE66AEEF",
        "accountNo": "4052507747",
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
        "availableAmount": null,
        "priority": 13000100,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "CCP.Visa",
        "payMethodCodeFirst": "CCP",
        "payMethodCodeSecond": "Visa",
        "payMethodCodeThird": null,
        "bizId": "283485453912494080",
        "accountNo": "454628******8110",
        "defaultFlag": true,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 14000100,
        "bankAccBindDate": 1540818597000,
        "cardOrgCode": "Visa",
        "payOrgModelList": null
      },
      {
        "displayName": "CCP.SPECIAL",
        "payMethodCodeFirst": "CCP",
        "payMethodCodeSecond": "SPECIAL",
        "payMethodCodeThird": null,
        "bizId": "",
        "accountNo": "",
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 14000200,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "OFLN.CENPAY",
        "payMethodCodeFirst": "OFLN",
        "payMethodCodeSecond": "CENPAY",
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541073404426.png",
        "availableAmount": null,
        "priority": 14000100,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": [{
          "orgCode": "KBANK",
          "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "h5LogoUrl": "http://storage.cjdfintech.com/images/h5/20181108_cenpay_supported_stores.png?Expires=3689148038&amp;AccessKey=mzvGcdr2erjPc5qe&amp;Signature=jW2UUmhrGsL%2Bp4ogfrAoyV4XJg8%3D",
          "priority": 14000100
        },
        {
          "orgCode": "BBL",
          "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "priority": 14000200
        }
        ]
      }
      ],
      "availablePayMethodCodeFirstList": [
        "CCP",
        "BALA",
        "ODD"
      ],
      "creditCardOrgModelList": [{
        "orgCode": "Visa",
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
      }]
    }
  })
  // 收銀台初始化信息
  mock.onPost('/th/cashier/query/method/list3').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      kycCheckResultModel: {
        kycCheckFlag: 1,
        kycPromptJsonMsg: {
          en: "Unable to proceed. Please contact Customer Service for assistance",
          th: "ไม่สามารถทำรายการได้ กรุณาติดต่อe",
          actionData: "{\"address\":\"/kyc/completeMsg\",\"params\":{},\"type\":\"native\"}"
        }
      },
      "cashierStyle": {
        "code": "half_screen"
      },
      "payOrderModel": {
        "amount": 1.00,
        "currency": "THB",
        "bizCode": "WLT_CHARGE"
      },
      "payMethodModelList": [{
        "displayName": "ODD.KBANK",
        "payMethodCodeFirst": "ODD",
        "payMethodCodeSecond": "KBANK",
        "payMethodCodeThird": null,
        "bizId": "C27A7EEAD0E4A613619259B9BB176CFF",
        "accountNo": "0012151782",
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
        "availableAmount": null,
        "priority": 23000100,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "CCP.SPECIAL",
        "payMethodCodeFirst": "CCP",
        "payMethodCodeSecond": "SPECIAL",
        "payMethodCodeThird": null,
        "bizId": "",
        "accountNo": "",
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 13500000,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "DELI.KBANK",
        "payMethodCodeFirst": "DELI",
        "payMethodCodeSecond": "KBANK",
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 14000100,
        "bankAccBindDate": null,
        "cardOrgCode": null
      },

      {
        "displayName": "CCP.VISA",
        "payMethodCodeFirst": "CCP",
        "payMethodCodeSecond": "VISA",
        "payMethodCodeThird": null,
        "bizId": "",
        "accountNo": "",
        "defaultFlag": false,
        "status": 0,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 500300,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "BALA",
        "payMethodCodeFirst": "BALA",
        "payMethodCodeSecond": null,
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 0,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": 111579.99,
        "priority": 11000000,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "OFLN.CENPAY",
        "payMethodCodeFirst": "OFLN",
        "payMethodCodeSecond": "CENPAY",
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": true,
        "status": 0,
        "pcLogoUrl": null,
        "h5LogoUrl": null,
        "availableAmount": null,
        "priority": 15000100,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": [{
          "orgCode": "CENPAY",
          "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "h5LogoUrl": "http://storage.cjdfintech.com/images/h5/20181108_cenpay_supported_stores.png?Expires=3689148038&AccessKey=mzvGcdr2erjPc5qe&Signature=jW2UUmhrGsL%2Bp4ogfrAoyV4XJg8%3D",
          "priority": 15000100
        }]
      }
      ],
      "availablePayMethodCodeFirstList": [
        "OFLN",
        "ODD"
      ],
      "creditCardOrgModelList": [{
        "orgCode": "VISA",
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
      },
      {
        "orgCode": "Master",
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
      },
      {
        "orgCode": "JCB",
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
      },
      {
        "orgCode": "UPOP",
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
      }

      ]
    }
  })
  // 收銀台初始化信息3
  mock.onPost('/th/cashier/query/method/list3').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      kycCheckResultModel: {
        kycCheckFlag: 1,
        kycPromptJsonMsg: {
          en: "Unable to proceed. Please contact Customer Service for assistance",
          th: "ไม่สามารถทำรายการได้ กรุณาติดต่อe",
          actionData: "{\"address\":\"/kyc/completeMsg\",\"params\":{},\"type\":\"native\"}"
        }
      },
      "cashierStyle": {
        "code": "half_screen"
      },
      "payOrderModel": {
        "amount": 1.00,
        "currency": "THB",
        "bizCode": "WLT_TRANSFER_BLE"
      },
      "payMethodModelList": [{
        "displayName": "BALA",
        "payMethodCodeFirst": "BALA",
        "payMethodCodeSecond": null,
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": 46.98,
        "priority": 11000000,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      }, {
        "displayName": "CCP.SPECIAL",
        "payMethodCodeFirst": "CCP",
        "payMethodCodeSecond": "SPECIAL",
        "payMethodCodeThird": null,
        "bizId": "",
        "accountNo": "",
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037726107.png",
        "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037726129.png",
        "availableAmount": null,
        "priority": 14000400,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": null
      },
      {
        "displayName": "OFLN.CENPAY",
        "payMethodCodeFirst": "OFLN",
        "payMethodCodeSecond": "CENPAY",
        "payMethodCodeThird": null,
        "bizId": null,
        "accountNo": null,
        "defaultFlag": false,
        "status": 1,
        "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
        "availableAmount": null,
        "priority": 15000100,
        "bankAccBindDate": null,
        "cardOrgCode": null,
        "payOrgModelList": [{
          "orgCode": "CENPAY",
          "pcLogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "h5LogoUrl": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
          "priority": 15000100
        }]
      }
      ],
      "availablePayMethodCodeFirstList": ["CCP", "BALA", "ODD"],
      "creditCardOrgModelList": [{
        "orgCode": "Visa",
        "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037764242.png",
        "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037764266.png"
      }, {
        "orgCode": "MasterCard",
        "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037794692.png",
        "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037794711.png"
      }, {
        "orgCode": "JCB",
        "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037777357.png",
        "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1541037777398.png"
      }]
    }
  })
  // 收銀台初始化信息3
  mock.onPost('/th/cashier/query/method/list').reply(200, {
    "resultData": {
     "payOrderModel": {
      "amount": 2.00,
      "bizCode": "WLT_TRANSFER_BLE",
      "currency": "THB"
     },
     "payMethodModelList": [{
      "defaultFlag": true,
      "displayName": "BALA",
      "priority": 11000000,
      "availableAmount": 51174.20,
      "pcLogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "h5LogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "payMethodCodeFirst": "BALA",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "ODD.KBANK",
      "bankAccBindDate": 1542189670000,
      "priority": 13000100,
      "pcLogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "accountNo": "4052507747",
      "payMethodCodeSecond": "KBANK",
      "bizId": "7E8CB665EC867FEE4E619FADBE66AEEF",
      "h5LogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "payMethodCodeFirst": "ODD",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "ODD.BBL",
      "bankAccBindDate": 1542708094000,
      "priority": 13000200,
      "pcLogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "accountNo": "3903009961",
      "payMethodCodeSecond": "BBL",
      "bizId": "03004569577A2A2DE8D4D7BA2F7F6CFF",
      "h5LogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "payMethodCodeFirst": "ODD",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "ODD.BAY",
      "bankAccBindDate": 1550647339000,
      "priority": 13000300,
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556172390632.png",
      "accountNo": "0121557307",
      "payMethodCodeSecond": "BAY",
      "bizId": "780F9CB0A92802A336D19832008D4027",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556172390669.png",
      "payMethodCodeFirst": "ODD",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "ODD.SCB",
      "bankAccBindDate": 1551693752000,
      "priority": 13000400,
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556172381991.png",
      "accountNo": "0013261116",
      "payMethodCodeSecond": "SCB",
      "bizId": "B6961F51D668F095313DD1DB3AF22E44",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556172382013.png",
      "payMethodCodeFirst": "ODD",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "CCP.MasterCard",
      "bankAccBindDate": 1568199607000,
      "priority": 14000200,
      "cardOrgCode": "MasterCard",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990832.png",
      "accountNo": "544485******5118",
      "payMethodCodeSecond": "MasterCard",
      "bizId": "326904658142855168",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990988.png",
      "payMethodCodeFirst": "CCP",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "CCP.JCB",
      "bankAccBindDate": 1567682697000,
      "priority": 14000200,
      "cardOrgCode": "JCB",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977218.png",
      "accountNo": "356999******8938",
      "payMethodCodeSecond": "JCB",
      "bizId": "326903558161465344",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977245.png",
      "payMethodCodeFirst": "CCP",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "DELI.KBANK",
      "priority": 15000100,
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556420111554.png",
      "payMethodCodeSecond": "KBANK",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556420112545.png",
      "payMethodCodeFirst": "DELI",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "DELI.BBL",
      "priority": 15000200,
      "pcLogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "payMethodCodeSecond": "BBL",
      "h5LogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&amp;AccessKey=1ievRXlPgvbYfXzh&amp;Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "payMethodCodeFirst": "DELI",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "OFLN.CENPAY",
      "payOrgModelList": [{
       "orgCode": "CENPAY",
       "pcLogoUrl": "http://storage.cjdfintech.com/images/h5/20181108_cenpay_supported_stores.png?Expires=3689148038&amp;AccessKey=mzvGcdr2erjPc5qe&amp;Signature=jW2UUmhrGsL%2Bp4ogfrAoyV4XJg8%3D",
       "h5LogoUrl": "http://storage.cjdfintech.com/images/h5/20181108_cenpay_supported_stores.png?Expires=3689148038&amp;AccessKey=mzvGcdr2erjPc5qe&amp;Signature=jW2UUmhrGsL%2Bp4ogfrAoyV4XJg8%3D",
       "priority": 16000100
      }],
      "priority": 16000100,
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163827248.png",
      "payMethodCodeSecond": "CENPAY",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163827302.png",
      "payMethodCodeFirst": "OFLN",
      "status": 1
     }, {
      "defaultFlag": false,
      "displayName": "CCP.SPECIAL",
      "priority": 16000400,
      "pcLogoUrl": "https://test.storage.jd.com/thadminpayment-images/1539334127483.png",
      "accountNo": "",
      "payMethodCodeSecond": "SPECIAL",
      "bizId": "",
      "h5LogoUrl": "https://test.storage.jd.com/thadminpayment-images/1539334127483.png",
      "payMethodCodeFirst": "CCP",
      "status": 1
     }],
     "creditCardOrgModelList": [{
      "orgCode": "Visa",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163962258.png",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163962280.png"
     }, {
      "orgCode": "MasterCard",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990832.png",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990988.png"
     }, {
      "orgCode": "JCB",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977218.png",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977245.png"
     }, {
      "orgCode": "UnionPay",
      "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163942907.png",
      "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163943019.png"
     }],
     "kycCheckResultModel": {
      "kycCheckFlag": 1
     },
     "cashierStyle": {
      "code": "half_screen"
     },
     "availablePayMethodCodeFirstList": ["CCP", "DELI", "BALA", "OFLN", "ODD"]
    },
    "resultCode": 1,
    "errorData": {
     "msg": "success",
     "code": "CSR9900001"
    },
    "resultMsg": "succ"
   })

  // 收銀台初始化信息3
  mock.onPost('/th/cashier/query/method/list3').reply(200, { "resultCode": 1, "resultMsg": "succ", "errorData": null, "actionData": null, "resultData": { "cashierStyle": { "code": "half_screen" }, "payOrderModel": { "amount": 1.00, "currency": "THB", "bizCode": "QRC_NEG_PAYMENT" }, "payMethodModelList": null, "availablePayMethodCodeFirstList": ["CCP", "DELI", "BALA", "ODD"], "creditCardOrgModelList": null, "kycCheckResultModel": { "kycCheckFlag": 0, "kycPromptJsonMsg": { "en": "Unable to proceed. Please contact Customer Service for assistance.", "th": "ไม่สามารถทำรายการได้ กรุณาติดต่อ Customer Service", "actionData": "{\"address\":\"/kyc/main\",\"params\":{\"businessName\":\"PAYMENT\"},\"type\":\"native\"}" } } } })

    // 收銀台初始化信息3
    mock.onPost('/th/cashier/query/method/list3').reply(200, {
      "resultCode": 1,
      "resultMsg": "succ",
      "errorData": null,
      "actionData": null,
      "resultData": {
          "cashierStyle": {
              "code": "half_screen"
          },
          "payOrderModel": {
              "amount": 78.00,
              "currency": "THB",
              "bizCode": "APP_PAY_PHYSICAL_GOODS",
              "merchantShortName": "",
              "orderSubject": null
          },
          "payMethodModelList": [{
              "displayName": "CCP.SPECIAL",
              "payMethodCodeFirst": "CCP",
              "payMethodCodeSecond": "SPECIAL",
              "payMethodCodeThird": null,
              "bizId": "",
              "accountNo": "",
              "defaultFlag": false,
              "status": 1,
              "pcLogoUrl": "https://test.storage.jd.com/thadminpayment-images/1539334127483.png",
              "h5LogoUrl": "https://test.storage.jd.com/thadminpayment-images/1539334127483.png",
              "availableAmount": null,
              "priority": 9,
              "bankAccBindDate": null,
              "cardOrgCode": null,
              "payOrgModelList": null
          }, {
              "displayName": "BALA",
              "payMethodCodeFirst": "BALA",
              "payMethodCodeSecond": null,
              "payMethodCodeThird": null,
              "bizId": null,
              "accountNo": null,
              "defaultFlag": false,
              "status": 0,
              "pcLogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
              "h5LogoUrl": "https://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
              "availableAmount": 0.00,
              "priority": 15,
              "bankAccBindDate": null,
              "cardOrgCode": null,
              "payOrgModelList": null
          }],
          "availablePayMethodCodeFirstList": ["CCP", "BALA", "ODD"],
          "creditCardOrgModelList": [{
              "orgCode": "UnionPay",
              "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163942907.png",
              "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163943019.png"
          }, {
              "orgCode": "Visa",
              "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163962258.png",
              "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163962280.png"
          }, {
              "orgCode": "JCB",
              "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977218.png",
              "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163977245.png"
          }, {
              "orgCode": "MasterCard",
              "pcLogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990832.png",
              "h5LogoUrl": "http://test.storage.jd.com/thadminpayment-images/1556163990988.png"
          }],
          "kycCheckResultModel": {
              "kycCheckFlag": 1,
              "kycPromptJsonMsg": null
          }
      }
  })
  // 收銀台卡支付
  mock.onPost('/th/cashier/pay/odd').reply(200, {
    "resultCode": 0,
    "resultMsg": "succ",
    "errorData": {
      code: 'CSR4400005'
    },
    "actionData": null,
    "resultData": {}
  })
  // 收銀台余额支付
  mock.onPost('/th/cashier/pay/balance').reply(200, {
    "resultCode": 0,
    "resultMsg": "succ",
    "errorData": {
      code: 'CSR4400005'
    },
    "actionData": null,
    "resultData": {
      transactionStatus: 'SUCC'
    }
  })

  // 收银台卡支付
  mock.onPost('/th/cashier/pay/ccp').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": {
      code: 'CSR4400005'
    },
    "actionData": null,
    "resultData": {
      "action": "{\"actionData\":{\"address\":\"/safecenter/main\",\"params\":{\"WHETHERCROSSRISK\":\"1\",\"actionType\":0,\"bffOpenRecordId\":\"\",\"businessNo\":\"20181119113521102234323434884728\",\"businessType\":\"\",\"email\":\"\",\"jrPin\":\"0066002000006802\",\"mobile\":\"0156785678\",\"riskId\":\"20181119113521657jvXUj9O\",\"sc_no\":\"d3dad6ac-e56d-41c2-bdbd-ab9acba5e3c3\",\"scene\":\"09900101\",\"snNumber\":\"d3dad6ac-e56d-41c2-bdbd-ab9acba5e3c3\",\"tmMobile\":\"******5678\",\"validateSubType\":null,\"validateType\":\"OTP\"},\"type\":\"native\"},\"errorData\":null,\"resultCode\":\"1\",\"resultData\":{\"WHETHERCROSSRISK\":\"1\",\"actionType\":0,\"bffOpenRecordId\":\"\",\"businessNo\":\"20181119113521102234323434884728\",\"businessType\":\"\",\"email\":\"\",\"jrPin\":\"0066002000006802\",\"mobile\":\"0156785678\",\"riskId\":\"20181119113521657jvXUj9O\",\"sc_no\":\"d3dad6ac-e56d-41c2-bdbd-ab9acba5e3c3\",\"scene\":\"09900101\",\"snNumber\":\"d3dad6ac-e56d-41c2-bdbd-ab9acba5e3c3\",\"tmMobile\":\"******5678\",\"validateSubType\":null,\"validateType\":\"OTP\"},\"resultMsg\":\"\"}",
      "appGuideNeedDataMap": {
        "canOpenBFF": true,
        "guideUrl": {
          "actionData": {
            "address": "/safecenter/guideEnableBiometric",
            "params": {
              "openBFFType": "FIGER",
              "token": "6b876664-db14-4f3b-b225-e29179888cef",
              "openType": "1,1,0,0"
            },
            "type": "native"
          },
          "resultCode": "1"
        },
        "openBFFType": "FIGER",
        "token": "6b876664-db14-4f3b-b225-e29179888cef",
        "openType": "1,1,0,0"
      },
      "additionalData": "{\"action\":\"https://psipay.bangkokbank.com/b2c/eng/dPayment/payComp.jsp\",\"fields\":{\"securityCode\":\"10000\",\"amount\":\"10000\",\"currCode\":\"764\",\"epYear\":\"2021\",\"cardHolder\":\"tombejanmin\",\"successUrl\":\"TODO\",\"failUrl\":\"TODO\",\"orderRef1\":\"20180919175917t000001497124531\",\"cardNo\":\"4546289950108110\",\"epMonth\":\"12\",\"errorUrl\":\"TODO\",\"payType\":\"N\",\"orderRef\":\"20180919180109781830429994215164\",\"merchantId\":\"3911\",\"pMethod\":\"VISA\",\"lang\":\"T\"},\"method\":\"post\",\"target\":\"_self\",\"type\":\"form\"}",
      "checkType": "C000011",
      "needCheck": true,
      "riskId": "20181119113521657jvXUj9O",
      "transactionNo": "201811191134597444FR111148731284"
    }
  })
  // 收银台卡支付
  mock.onPost('/th/cashier/pay/ccp').reply(200, {
     "resultData": {
      "checkType": "C000011",
      "transactionStatus": "PEND",
      "transactionNo": "20190809175605662680985676285264",
      "needCheck": true,
      "additionalData": "{\"action\":\"https://psipay.bangkokbank.com/b2c/eng/dPayment/payComp.jsp\",\"fields\":{\"secureHash\":\"0eb973fb5c0ec88fb5354b1c97cc0935d1ea61ebe53f6d3162b971e0665502d88471b4fcafb84b4c28d88a4d4fa89ab7413060179a692b47b42d4dd823ca0d4e\",\"amount\":\"1\",\"currCode\":\"764\",\"epYear\":\"2021\",\"cardHolder\":\"The\",\"successUrl\":\"https://channel.cjdfintech.com/paymentGateWay/BBL/payResultFront/success\",\"failUrl\":\"https://channel.cjdfintech.com/paymentGateWay/BBL/payResultFront/fail\",\"orderRef1\":\"20190809175605662680985676285264\",\"cardNo\":\"5444289950005118\",\"epMonth\":\"12\",\"errorUrl\":\"https://channel.cjdfintech.com/paymentGateWay/BBL/payResultFront/error\",\"payType\":\"N\",\"orderRef\":\"20190809175624161434436514977291\",\"merchantId\":\"3911\",\"pMethod\":\"Master\",\"orderRef5\":\"DOLFIN\",\"lang\":\"E\"},\"method\":\"post\",\"target\":\"_self\",\"type\":\"form\"}"
     },
     "resultCode": 1,
     "errorData": {
      "msg": "success",
      "code": "CSR4400005"
     },
     "resultMsg": "succ"
    })



    // 收銀台余额支付
    mock.onPost('/th/cashier/pay/balance2').reply(200, { 
      "resultCode": 1, 
      "resultMsg": "succ",
       "errorData": null, 
       "resultData": {
        needCheck: true
      },
       "actionData": '{ "type": "native", address:"/kyc/main" }',
        "resultData": { "transactionNo": "20190428173033AN7722824851692604", "transactionStatus": null, "needCheck": false, "riskId": null, "needPwd": true, "action": "{\"actionData\":{\"address\":\"/safecenter/main\",\"params\":{\"WHETHERCROSSRISK\":\"0\",\"actionType\":0,\"bffOpenRecordId\":\"\",\"businessNo\":\"th_cashier_20190428173033AN7722824851692604\",\"businessType\":\"\",\"email\":\"\",\"jrPin\":\"0066002000201661\",\"mobile\":\"\",\"riskId\":\"\",\"sc_no\":\"16475a72-561f-45ea-94dd-3b3b8c535a8a\",\"scene\":\"01300100\",\"snNumber\":\"16475a72-561f-45ea-94dd-3b3b8c535a8a\",\"tmMobile\":\"\",\"validateSubType\":\"NORMAL\",\"validateType\":\"ZM_HALF\"},\"type\":\"native\"},\"errorData\":null,\"resultCode\":\"\",\"resultData\":null,\"resultMsg\":\"\"}", "checkType": null, "additionalData": null, "paymentCodeUrl": null, "expireTime": null, "payGatewayOrderNo": null, "appGuideNeedDataMap": null } 
    })


  // 收銀台余额支付
  mock.onPost('/th/cashier/pay/csp').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {}
  })
  // 收銀台deeplink支付
  mock.onPost('/th/cashier/pay/deeplink').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": {
      code: 'CSR4400005'
    },
    "actionData": null,
    "resultData": {
      "additionalData": "{\"tokenId\":\"KMBJDC000000000D4944FFDB0BC40FEA95E721030A0CFD7PMT\",\"callBackAppUrl\":\"kbank.kplus://cjd.payment?tokenId=KMBJDC000000000D4944FFDB0BC40FEA95E721030A0CFD7PMT\"}"
    }
  })
  // 收银台结果页查询支付结果信息;
  mock.onPost('/th/cashier/card/org/query').reply(200, {
    "success": true,
    "resultCode": 1,
    errorData: null,
    "resultData": {
      "orgCode": "Visa"
    }
  })

  // 收银台结果页查询支付结果信息;
  mock.onPost('/th/cashier/result/query').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      "transactionNo": "20181108174324110817431449359059",
      "orderAmount": 5.60,
      merchantShortName: 'Lucking Coffee',
      orderSubject: 'Who doesn\'t love this cup?',
      "transactionStatus": "SUCC",
      "orderCurrency": "THB",
      "merchantName": "oversea",
      "orderType": "QRC_NEG_PAYMENT",
      "payResultModel": {
        "displayName": "ODD.KBANK",
        "payMethodCodeFirst": "ODD",
        "payMethodCodeSecond": "KBANK",
        "payMethodCodeThird": null,
        "cardCenterId": "7E8CB665EC867FEE4E619FADBE66AEEF",
        "maskedNo": "******7747"
      }
    }
  })

  // 收银台gateway 参数;
  mock.onPost('/open_api/gateway').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      "cashierH5Url": "https://cashier.jd.co.th/payment?transactionNo=20190402205817040220575488160123",
      "cashierPcUrl": "https://cashier.jd.co.th/payment?transactionNo=20190402205817040220575488160123",
      "merchantNo": "360087641000000252",
      "merchantOrderNo": "20190402205754",
      "transactionNo": "20190402205817040220575488160123"
    }
  })

  // 收银台跳转到商户APP的参数签名
  mock.onPost('/th/cashier/result/transaction/sign/query').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
      "resultCode": "000000",
      "resultInfo": "SUCCESSFUL",
      "transactionNo": "20190403162236AN3984797478539856",
      "merchantOrderNo": "201904031608222121",
      "totalAmount": "1000.00",
      "appId": "th.joy.jd",
      "attach": "泰国电商",
      "transactionFinishTime": "20190403180601",
      "sign": "afljfdasjfdals12893792131l2jjfalfja"
    }
  })
  // 收银台跳转到商户APP的参数签名
  mock.onPost('/th/check/login').reply(200, {
    "resultCode": 1,
    "resultMsg": "succ",
    "errorData": null,
    "actionData": null,
    "resultData": {
    }
  })

}
