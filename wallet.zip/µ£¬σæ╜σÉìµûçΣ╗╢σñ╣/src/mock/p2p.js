/*eslint-disable*/
export default function p2p(mock) {
  // 收銀台卡支付
  mock.onPost('/th/wallet/collect/parseCode').reply(200, {
    "resultCode": "1",
    "resultData": {
        "amount": 100,
        "codeType": "2",
        "customerId": "0066002000017093",
        "customerName": "fdrxc",
        "promptAccountNo": "1230008888888708888",
        "iconUrl": "http://test.storage.jd.com/bluewhale/0066002000017093.jpg?Expires=1851043398&AccessKey=V0plYwuLkX1Zk9iv&Signature=lwDlobNxrp11DSDyZ8PgiXrvG1w%3D",
        "modifiedDate": null,
        "remark": "收款理由RequestToPayNo1539747096951RequestToPayNo1539747096951RequestToPayNo1539747096951RequestToPayNo1539747096951",
        "requestToPayNo": "RequestToPayNo1539747096951"
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
})
  

  mock.onPost('/th/wallet/collect/cancelTransfer').reply(200, {
    "resultCode": "1",
    "resultData": {
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })
  
}
