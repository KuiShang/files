/*eslint-disable*/
export default function transDetail(mock) {
  // 充值
  //   mock.onPost('/th/trade_center/detail').reply(200, {
  //     "resultCode": "1",
  //     "resultData": {
  //       "amount": 100000.00,
  //       "displayName": "ODD.KBANK",
  //       "remark": "充值",
  //       "payBankName": "KBANK",
  //       "logoUrl": "http://storage.cjdfintech.com/th-wallet-server/transfer/TopUp.png?Expires=3687155298&AccessKey=duB7kf1nPEsvNizS&Signature=tGEYi1OcrudevqaDlfDIMkfGy/k=",
  //       "paymentMethod2": "KBANK",
  //       "paymentMethod1": "ODD",
  //       "serviceCharge": 0.00,
  //       "createdDate": 1538190245000,
  //       "busiScenarios": "1",
  //       "receiverAccountNo": "4369",
  //       "transOrderNo": "20180929110405TRAN43177639",
  //       "inOutFlag": "+",
  //       "status": 3,
  //       "payAccountNo": "12345",
  //       },
  //     "errorData": null,
  //     "actionData": null,
  //     "resultMsg": "success"
  // })

  // 转账  到银行账户
  mock.onPost('/th/trade_center/detail3').reply(200, {
    "resultCode": "1",
    "resultData": {
      "amount": 3000.00,
      "busiScenarios": "3",
      "createdDate": 1538200632000,
      "displayName": "BALA",
      "inOutFlag": "-",
      "logoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6/G0USE0MVOkiI=",
      "paymentMethod1": "BALA",
      "receiverAccountName": "JDPAYER",
      "receiverAccountNo": "4369",
      "remark": "",
      "serviceCharge": 4.00,
      "status": 3,
      "transOrderNo": "20180929135711TRAN72003781",
      "transferChannel": "2",
      "payAccountNo": "12345",
      receiverBankName: "kbank"
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  // request to pay
  mock.onPost('/th/trade_center/detail2').reply(200, {
    "resultCode": "1",
    "resultData": {
      "logoName": "RequestToPay",
      "amount": 0.00,
      "createdDate": 1546914034000,
      "busiScenarios": "7",
      "transOrderNo": "20190108102034RTP13546356",
      "actionData": {
        "params": {
          "serviceOddNo": "20190108102034RTP13546356"
        },
        "address": "/qr/rtp"
      },
      "currency": "THB",
      "statusDes": "{\"TH\":\"Collecting\",\"EN\":\"Collecting\"}",
      "remark": "活生生斤斤计较设计技术",
      "logoUrl": "http://storage.cjdfintech.com/th-wallet-server/requestToPay/RTP.png?Expires=3687163833&AccessKey=duB7kf1nPEsvNizS&Signature=beNcFgY49arP88JmALK6WHVZGK4%3D",
      "inOutFlag": "+"
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  // 转账  到银行账户
  mock.onPost('/th/trade_center/detail').reply(200, {
    "resultCode": "1",
    "resultData": {
      "amount": 3000.00,
      "busiScenarios": "6",
      "createdDate": 1538200632000,
      "displayName": "BALA",
      "inOutFlag": "-",
      "logoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6/G0USE0MVOkiI=",
      "paymentMethod1": "BALA",
      "receiverAccountName": "JDPAYER",
      "receiverAccountNo": "4369",
      "remark": "",
      "serviceCharge": 4.00,
      "status": 3,
      "transOrderNo": "20180929135711TRAN72003781",
      "transferChannel": "1",
      "payAccountNo": "12345",
      receiverBankName: "kbank"
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  // request to pay
  mock.onPost('/th/trade_center/detail2').reply(200, {
    "resultCode": "1",
    "resultData": {
      "amount": 5.00,
      "bankAccount": "",
      "bankName": "",
      "busiScenarios": "33",
      "createdDate": 1548039452000,
      "currency": "THB",
      "customerId": "0066002000031660",
      "displayName": "BALA",
      "modifiedDate": 1548039461000,
      "payeeReason": "",
      "paymentMethod1": "BALA",
      "paymentMethod2": "",
      "promptAccountNo": "",
      "receiverName": "ชุติกาญจน์",
      "receiverWalletAccount": "0888888851",
      "remark": "",
      "serviceCharge": 0.00,
      "status": 3,
      "successTime": 1548039461000,
      "transOrderNo": "20190121105731TRAN10075035",
      "transferChannel": "1"
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  mock.onPost('/th/trade_center/detail4').reply(200, {
    "resultCode": "1",
    "resultData": {
      "amount": 26.45,
      "statusDesc": "{\"EN\":\"Success\",\"TH\":\"สำเร็จ\"}",
      "payAccountNo": null,
      "displayName": "BALA",
      "receiverBankName": null,
      "remark": "",
      "transferChannel": "1",
      "payBankName": null,
      "logoUrl": "http://test.storage.jd.com/bluewhale/00660020001948351550458157091.jpg?Expires=1865818157&AccessKey=V0plYwuLkX1Zk9iv&Signature=hLMrhLwW9LnSEVlUlhFFTsrhSJ0%3D",
      "paymentMethod2": null,
      "receiverAccountName": null,
      "paymentMethod1": "BALA",
      "serviceCharge": 0.00,
      "createdDate": 1550556714000,
      "busiScenarios": "3",
      "receiverAccountNo": null,
      "transOrderNo": "20190219141202TRAN78608951",
      "currency": null,
      "payAccountName": "ศศพินทุ์",
      "inOutFlag": "+",
      "status": 3
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  // tag30 消费
  mock.onPost('/th/trade_center/detail').reply(200, {
    "resultCode": "1",
    "resultData": {
      "amount": 3000.00,
      "busiScenarios": "4",
      "createdDate": 1538200632000,
      "displayName": "BALA",
      "inOutFlag": "-",
      "logoUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6/G0USE0MVOkiI=",
      "paymentMethod1": "BALA",
      "receiverAccountName": "JDPAYER",
      "receiverAccountNo": "4369",
      "remark": "",
      "serviceCharge": 4.00,
      "status": 3,
      "transOrderNo": "20180929135711TRAN72003781",
      "transferChannel": "1",
      "payAccountNo": "12345",
      receiverBankName: "kbank",
      associationRecord: '{"tranNo":"20180619155506TRAN59578655","tranType":3,"bizSystem":1}',
      coupon: {
        name: "{\"EN\":\"kkkk\",\"TH\":\"สำเร็จ  สำเร็สำเร็สำเร็  สำเร็สำเร็สำเร็สำเร็  สำเร็สำเร็สำเร็ สำเร็ สำเร็  สำเร็สำเร็\"}",
        orderAmount: 1,
        couponAmount: 12

      }
    },
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })
  // tag30 消费
  mock.onPost('/th/trade_center/detail1').reply(200, {
    "resultCode":"1","resultData":{"logoName":"SUPERCHEAP CO.,LTD.","displayName":"BALA","remark":"","receiverAccountName":"SUPERCHEAP CO.,LTD.","paymentMethod1":"BALA","serviceCharge":0.00,"transOrderNo":"20190712111011TRAN26576878","mechantrOrderNo":"R000005","amount":1.00,"statusDesc":"{\"TH\":\"สำเร็จ\",\"EN\":\"Success\"}","logoUrl":"https://uat-storage.cjdfintech.com/transfer/prompttag30.png","createdDate":1562904612000,"busiScenarios":"8","inOutFlag":"-","status":3},"resultMsg":"success"})



    // 赔付 退款
  mock.onPost('/th/trade_center/detail').reply(200,{"resultCode":"1","resultData":{"logoName":"{\"EN\":\"Refund to Dolfin balance\",\"TH\":\"เงินคืนเข้าบัญชีดอลฟิน\"}","amount":2.01,"createdDate":1564392310000,"busiScenarios":"11","transOrderNo":"20190729172509CUCO25326522","currency":"THB","statusDes":"{\"EN\":\"Refund Successfully\",\"TH\":\"ได้รับเงินคืนเรียบร้อยแล้ว\"}","logoUrl":"https://test.storage.jd.com/compensation/refund_3x.png","inOutFlag":"+"},"resultMsg":"SUCCESS"})


}

