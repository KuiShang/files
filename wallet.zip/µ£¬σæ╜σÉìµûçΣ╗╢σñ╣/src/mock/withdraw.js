
/*eslint-disable*/
export default function topup(mock) {
// blance  withdraw 初始化
mock.onGet('/th/wallet/withdraw/withdrawPage').reply(200, {
    "code": "000000",
    "msg": "success",
    "resultData": {
      "balanceAmount": 1000,
      "bankAccountInfoList": [{
          "accountName": "tom",
          "accountNo": "12345",
          "bankIconUrl": "success",
          "bankName": "icbc",
          "cardId": "1"
        },
        {
          "accountName": "jack",
          "accountNo": "1235",
          "bankIconUrl": "success",
          "bankName": "ABC",
          "cardId": "2"
        }
      ],
      "fee": "4" //每笔4泰铢
    }
  })
  
  // blance  withdraw 创建提现业务单
  mock.onPost('/th/wallet/topup/withdrawBegin').reply(200, {
    "code": "000000",
    "msg": "success",
    "resultData": {
      "amount": 1000,
      "beyondLimitFlag": false,
      "currency": "th",
      "payUrl": "http://thwallet/payUrl",
      "transOrderNo": "20180515112229TRAN15404954",
      "transactionNo": "tranNo21",
      "withdrawSuccUrl": "/th/wallet/withdraw/withdrawResult?transOrderNo={0}"
    }
  })
  
  // blance  withdraw 提现结果页
  mock.onGet('/th/wallet/topup/withdrawResult').reply(200, {
    "code": "000000",
    "msg": "success",
    "resultData": {
      "amount": 1000,
      "createdDate": 1526354550000,
      "currency": "th",
      "modifiedDate": 1526354549000,
      "payeeAccount": "PayeeAccount",
      "payeeName": "PayeeName",
      "status": 2, //处理中:2  成功：3   失败：4
      "transOrderNo": "20180515112229TRAN15404954"
    }
  })
}

