/*eslint-disable*/
export default function topup(mock) {
  mock.onPost('/th/app_config/getH5CfgData').reply(200, {
    "resultCode": 1,
    "resultData": {
      "h5PageConfigContainer": {
        "hasJump": 0,
        "pageComponentContainers": [{
          "componentId": 2,
          "componentInfos": [{
            "componentId": 2,
            "activityId": 111111111,
            "configurable": true,
            "content": "content",
            "id": 39,
            "imageUrl": "//img1.360buyimg.com/da/jfs/t1/25469/40/5576/75855/5c3e95e0Eb188b24b/a6f7dbf54b60160b.jpg",
            "jumpDataTemplate": "",
            "jumpType": 0,
            "jumpUrl": "jumpUrl",
            "label": "label",
            "labelBgColor": "label",
            "labelColor": "label",
            "onOffLineStatus": false,
            "ordinal": 1,
            "pageId": 35,
            "title1": "werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr",
            "title1Color": "",
            "title2": "title2 title2 title2 title2 title2 title2 title2 title2 title2 title2 title2  title2 title2 title2 title2",
            "title2Color": "",
            "title3": "title3 title3 title3 title3 title3 title3",
            "title3Color": "",
            "title4": "title4",
            "title4Color": "",
            "tracePoint": "35_60_39",
            "businessData": {
              "resultCode":"1",
              "resultData": {
                  "debugInfo":"{}",
                  "engineIp":"172.24.8.154",
                  "message":"SUCCESS",
                  "status": -1,
                  "point": 1000000000,
                  "pending": 123,
                  "firstName": 'name name name name name name', 
                  "t1Card": 123123123123123123,
                  "promos": [
                       {
                          "detailLink":"/discoveryCouponDetail?activityId=4QNMi4DEjHas7MIpW0K3K4UZwP6JtQBm3OxPskEprwU&batchId=ISpdRdWroivnizAyOSKqTasfalfQ4H_Jsj28FI7DCvP3tjCebShyclqCw6NiRtYN",
                          "gotPrizeFlag":1,
                          "prize": {
                              "batchId":"d236e2ee255d418ba519b316f295824a",
                              "type":0
                          },
                          "promoId":"123795037752602624",
                          "activityStatus": 1
                      }
                  ],
                  "resTime":1547108950941,
                  "resultCode":"00000000",
                  "resultFlag":true
              },
              "resultMsg":"success"
          },
          }, {
            "componentId": 2,
            "activityId": 222222222,
            "configurable": true,
            "content": "content",
            "id": 39,
            "imageUrl": "//m.360buyimg.com/babel/jfs/t1/21900/8/4577/82699/5c34450fE281ba944/475b08f9457bc574.jpg",
            "jumpDataTemplate": "",
            "jumpType": 0,
            "jumpUrl": "jumpUrl",
            "label": "label",
            "labelBgColor": "label",
            "labelColor": "label",
            "onOffLineStatus": false,
            "ordinal": 1,
            "pageId": 35,
            "title1": "werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr",
            "title1Color": "",
            "title2": "title2 title2 title2 title2 title2 title2 title2 title2 title2 title2 title2  title2 title2 title2 title2",
            "title2Color": "",
            "title3": "title3 title3 title3 title3 title3 title3",
            "title3Color": "",
            "title4": "title4",
            "title4Color": "",
            "tracePoint": "35_60_39",
            "businessData": {
              "resultCode":"1",
              "resultData": {
                  "debugInfo":"{}",
                  "engineIp":"172.24.8.154",
                  "message":"SUCCESS",
                  "promos": [
                       {
                          "detailLink":"/discoveryCouponDetail?activityId=4QNMi4DEjHas7MIpW0K3K4UZwP6JtQBm3OxPskEprwU&batchId=ISpdRdWroivnizAyOSKqTasfalfQ4H_Jsj28FI7DCvP3tjCebShyclqCw6NiRtYN",
                          "gotPrizeFlag":1,
                          "prize": {
                              "batchId":"d236e2ee255d418ba519b316f295824a",
                              "type":0
                          },
                          "promoId":"123795037752602624",
                          "activityStatus": 3
                      }
                  ],
                  "resTime":1547108950941,
                  "resultCode":"00000000",
                  "resultFlag":true
              },
              "resultMsg":"success"
          },
          }, {
            "componentId": 2,
            "activityId": 333333333,
            "configurable": true,
            "content": "content",
            "id": 39,
            "imageUrl": "//img1.360buyimg.com/pop/jfs/t1/22397/6/5090/132740/5c384a77E79489d56/eef4722f654bed7e.jpg",
            "jumpDataTemplate": "",
            "jumpType": 0,
            "jumpUrl": "jumpUrl",
            "label": "label",
            "labelBgColor": "label",
            "labelColor": "label",
            "onOffLineStatus": false,
            "ordinal": 1,
            "pageId": 35,
            "title1": "werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr",
            "title1Color": "",
            "title2": "title2 title2 title2 title2 title2 title2 title2 title2 title2 title2 title2  title2 title2 title2 title2",
            "title2Color": "",
            "title3": "title3 title3 title3 title3 title3 title3",
            "title3Color": "",
            "title4": "title4",
            "title4Color": "",
            "tracePoint": "35_60_39",
            "businessData": {
              "resultCode":"1",
              "resultData": {
                  "debugInfo":"{}",
                  "engineIp":"172.24.8.154",
                  "message":"SUCCESS",
                  "promos": [
                       {
                          "detailLink":"/discoveryCouponDetail?activityId=4QNMi4DEjHas7MIpW0K3K4UZwP6JtQBm3OxPskEprwU&batchId=ISpdRdWroivnizAyOSKqTasfalfQ4H_Jsj28FI7DCvP3tjCebShyclqCw6NiRtYN",
                          "gotPrizeFlag":1,
                          "prize": {
                              "batchId":"d236e2ee255d418ba519b316f295824a",
                              "type":0
                          },
                          "promoId":"123795037752602624",
                          "activityStatus": 3
                      }
                  ],
                  "resTime":1547108950941,
                  "resultCode":"00000000",
                  "resultFlag":true
              },
              "resultMsg":"success"
          },
          }, {
            "componentId": 2,
            "activityId": 444444444,
            "configurable": true,
            "content": "content",
            "id": 39,
            "imageUrl": "//m.360buyimg.com/babel/jfs/t1/12104/14/5583/35044/5c3da73bE8bddc1c2/1e2aac67102e2803.jpg",
            "jumpDataTemplate": "",
            "jumpType": 0,
            "jumpUrl": "jumpUrl",
            "label": "label",
            "labelBgColor": "label",
            "labelColor": "label",
            "onOffLineStatus": false,
            "ordinal": 1,
            "pageId": 35,
            "title1": "werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr werqr",
            "title1Color": "",
            "title2": "title2 title2 title2 title2 title2 title2 title2 title2 title2 title2 title2  title2 title2 title2 title2",
            "title2Color": "",
            "title3": "title3 title3 title3 title3 title3 title3",
            "title3Color": "",
            "title4": "title4",
            "title4Color": "",
            "tracePoint": "35_60_39",
            "businessData": {
              "resultCode":"1",
              "resultData": {
                  "debugInfo":"{}",
                  "engineIp":"172.24.8.154",
                  "message":"SUCCESS",
                  "promos": [
                       {
                          "detailLink":"/discoveryCouponDetail?activityId=4QNMi4DEjHas7MIpW0K3K4UZwP6JtQBm3OxPskEprwU&batchId=ISpdRdWroivnizAyOSKqTasfalfQ4H_Jsj28FI7DCvP3tjCebShyclqCw6NiRtYN",
                          "gotPrizeFlag":1,
                          "prize": {
                              "batchId":"d236e2ee255d418ba519b316f295824a",
                              "type":0
                          },
                          "promoId":"123795037752602624",
                          "activityStatus": 3
                      }
                  ],
                  "resTime":1547108950941,
                  "resultCode":"00000000",
                  "resultFlag":true
              },
              "resultMsg":"success"
          },
          }],
          "componentName": "The 1 info banner",
          "couponGroupId": 123123123123,
          "layoutTitle1":"Best Deal Coupon",
          "layoutTitle2":"See All",
          "layoutTitle3":"",
          "id": 60,
          "ordinal": 1,
          "title": "wer",
          "total": 15
        }],
        "pageId": 33,
        "pageName": "erqwrq",
        "pageTitle": "{\"EN\":\"wrqr\",\"TH\":\"THwrqr\"}",
        "remark": "wrwqrqwe",
        "subTitle": "{\"EN\": \"history\",\"TH\": \"history\"}",
        "subTitleType": 1,
        "tracePoint": "H5CONFIG_35_NEXT"
      },
      "loginDowngrade": false,
      "loginStatus": true,
      "scence": 0
    },
    "resultMsg": "success"
  })

}
