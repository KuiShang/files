/*eslint-disable*/
export default function topup(mock) {
  // blance  topup 校验充值金额（单次上下限）
  // mock.onPost('/th/wallet/topup/queryOnceLimit').reply(200, {
  //     "resultCode": 1,
  //     "resultData": [{
  //       "availableAmount": 24890,
  //       "customerId": "0066002000017051",
  //       "dayAmountUpper": 24889.29,
  //       onceAmountLover: 1,
  //       "onceAmountUpper": 24889.29,
  //       "totalAmount": 0
  //     }],
  //     "errorData": null,
  //     "actionData": null,
  //     "resultMsg": "success"
  //   })

  mock.onPost('/th/wallet/topup/queryOnceLimit').reply(200, {
    "resultCode": 1,
    "resultData": [{
      customerId: '0066002000000783',
      totalAmount: 75110.71,
      availableAmount: 24889.29,
      onceAmountLower: 0.01,
      onceAmountUpper: 100000.00,
      dayAmountUpper: 100000.00,
      monthAmountUpper: 200000.00,
      monthTimeUpper: '100'
    }
    ],
    "errorData": null,
    "actionData": null,
    "resultMsg": "success"
  })

  // blance  topup 点击充值，创建充值业务单
  mock.onPost('/th/wallet/topup/topUpBegin').reply(200, { "resultCode": "1", "resultData": { "actionData": "", "amount": 123, "currency": "THB", "operateAmount": 0, "payUrl": "https://cashier.jd.co.th/payment?transactionNo=20180913143912AN8777171551465521", "topupSuccUrl": "", "transOrderNo": "20180913143912TRAN87771715", "transactionNo": "20180913143912AN8777171551465521", "transferResultUrl": "", "withdrawSuccUrl": "" }, "errorData": null, "actionData": null, "resultMsg": "success" })

  // blance  topup 充值成功页
  mock.onPost('/th/wallet/topup/topUpSucc3').reply(200, {
    "resultCode": 1,
    "msg": "success",
    "resultData": {
      "amount": 100000,
      "bankAccount": "4369",
      "bankName": "KBANK",
      "createdDate": 1538190245000,
      "currency": "THB",
      "customerId": "0066002000020022",
      "displayName": "ODD.KBANK",
      "modifiedDate": 1539071740000,
      "paymentMethod1": "ODD",
      "paymentMethod2": "KBANK",
      "status": 2,
      "successTime": 1538191203000,
      "transOrderNo": "20180929110405TRAN43177639"
    }
  })

  mock.onPost('/th/wallet/topup/topUpSucc').reply(200, { "resultCode": "1", "resultData": { "amount": 1.00, "bankAccount": "8064", "bankName": "KBANK", "createdDate": 1551854255000, "currency": "THB", "customerId": "0066002000194394", "displayName": "ODD.KBANK", "modifiedDate": 1551854278000, "paymentMethod1": "ODD", "paymentMethod2": "KBANK", "status": 4, "successTime": null, "transOrderNo": "20190306143734TRAN35616142" }, "errorData": null, "actionData": null, "resultMsg": "success" })
}
