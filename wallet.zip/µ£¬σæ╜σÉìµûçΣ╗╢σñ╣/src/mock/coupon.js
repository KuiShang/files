/*eslint-disable*/
export default function coupon(mock) {

  // 用券
  mock.onPost('/th/coupon/detailByCouponId2').reply(200, {

    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      "couponId": "JFuw9Pyl3JgfwgrfSg8BTQ",
      "merchantId": "300100000301",
      expSoon: 1,
      "multilingual": {
        "en_US": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem  ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition": "1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. \n 2.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        },
        "th_TH": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem ipsum dolor sit amet, \\n co@@nsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut en@@im ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition2": `โบางสเต็ปสามแยกแพตเทิร์น  \\n ดีพาร์ตเมนต์มอลล์ วานิลลาเอ็นทร@@านซ์ เรตไวอา@กร้ากลาสป๋อหลอ นายแบบ เลคเชอร์เยอร์บีราเจ๊าะแจ๊ะมลภาวะไรเฟิล ซิลเวอร์ วิภัชภา@@ค พรีเมียมฟลอร์ชีสจีดีพีเคลื่อนย้าย โปรดักชั่นเกย์โฮสเตสป๋อหลอแอปพริคอท ออดิชั่นมินท์บ๋อยตังค์
          <br/>
          <br/> ไอซ์ซิตี้ละอ่อน อัตลักษณ์สตรอเบอร์รีแคชเชียร์สต๊อคคาปูชิโน ไฮเทคโพลล์มาร์ชวีเจเฝอ ไฮไลต์วัจนะแทกติคพาสตาโปรเจกเตอร์ ปาสกาลเยนบลอนด์สตาร์ สโตนเกสต์เฮาส์แกงค์เพลย์บอย สะเด่ามาร์ช ดราม่าฮ็อตด็อกวานิลาก๋ากั่น ปิโตรเคมีมาราธอนสโตร์บุญคุณบอมบ์ ช็อปดีพาร์ทเมนต์เอาต์ช็อปปิ้งออร์แกน เพลย์บอยโปรเจกต์ก่อนหน้าหลวงปู่ ฮันนีมูนสตรอเบ@@อรีเบบี้ เห่ย หลินจือ ชิฟฟอนรีไซเคิลสเตชันแรงดูดคอมเพล็กซ์ นิวตรวจสอบ﻿กรรมาชนไงติ่มซำ`,
          condition: '12'
        }
      },
      "expDate": "2018-03-01",
      "couponStatus": 0,
      timeLeft: 6000,
      countdownTime: 6000,
      validDate: '2018-03-01',
      validStatus: 0,
      "logo": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "background": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D"
    }
  })

  // 用券
  mock.onPost('/th/coupon/detailByCouponId').reply(200, {

    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      "couponId": "LcuLef9KNUqDnGTKazqgnNrYJzKlbZpq_69rs0-CtLM",
      "merchantId": "300900100042",
      "couponType": "2",//券类型 (1:商家兑换券/2:支付券)
      "multilingual": {
        "en_US": {
          "merchant": "test122",
          "title": "title-en",
          "desc": "description-ende\\nscription-e\\nndescription-endescription-endescription-endescription-endescription-endescription-endescription-endescription-endescriptio",
          "condition": "condition-enhsjadklfhjskldfh\\nshfjksdahfjkl\\nsafhjskdahg"
        },
        "th_TH": {
          "merchant": "test122",
          "title": "title-th",
          "desc": "description-e\\nndescription-ende\\nscription-endescription-endescription-endescription-endescription-endescription-endescription-endescription-endescriptio",
          "condition": "condition-enhsjadklfhjskldfh\\nshfjksdahfjkl\\nsafhon-enhsjadklfhjskldfh\\nshfjksdahfjkl\\nsaon-enhsjadklfhjskldfh\\nshfjksdahfjkl\\nsaon-enhsjadklfhjskldfh\\nshfjksdahfjkl\\nsajskdahg"
        }
      },
      "expDate": "2019-01-26",
      "validDate": "2019-01-25",
      "validStatus": 1,
      "expSoon": 0,
      "couponStatus": 2,
      "logo": "http://test.storage.jd.com/tha.business.man/20181225112421132173.png?Expires=3695975785&AccessKey=P3HpX2xJ5l8iZqLA&Signature=QW0sRe9z3fJ6VlniL08ISP6YsT0%3D",
      "background": "http://test.storage.jd.com/th.wallet.coupon.doc/130349709205811200.jpg?Expires=2548492192&AccessKey=rerNzraul9V6GShy&Signature=7qF%2Fe0T%2BXY5QUSq6GIHbdjC9dxg%3D",
      "countdownTime": 18,
      "timeLeft": 0
    }

  })

  // 领取券详情
  mock.onPost('/th/coupon/withoutLogin/detailByBatchId').reply(502, {

    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      "merchantId": "300100000301",
      "multilingual": {
        "en_US": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition": "1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        },
        "th_TH": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition": "1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        }
      },
      "logo": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "background": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      activityStatus: 2
    }
  })

  // group 领取券详情
  mock.onPost('/th/coupon//withoutLogin/groupBatchDetail').reply(200, {

    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      "merchantId": "300100000301",
      "multilingual": {
        "en_US": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition": "1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labor1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore ma1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore mae et dolore magna aliqua."
        },
        "th_TH": {
          "merchant": "magor cineplex",
          "title": "free 1 movie ticket",
          "desc": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          "condition": "1.	Lorem ipsum dolor sit amet, consectetur adipi1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit,1.	Lorem ipsum dolor sit amet, consectetur adipisicing elit,sicing elit,1.	Lorem ipsum dolor sit amet, consectetur adipisicing el1.	Lorem ipsum dolor sit amet, consectetur adipisicing el sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        }
      },
      "logo": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      "background": "http://storage.jd.com/thimage/balance.png?Expires=3682512391&AccessKey=1ievRXlPgvbYfXzh&Signature=zFnrMUDLN3LabOGecs7qm8TcbpE%3D",
      activityStatus: 2,
      groupLeftCount: 10,
      batchLeftCount: 12,
      validStartTime: '2018-03-01',
      validEndTime: '2019-07-05'
    }
  })


  // coupon group列表状态
  mock.onPost('/th/coupon/withoutLogin/groupStatus').reply(200, {
    "resultCode": 1,
    "resultData": {
      "groupLeftCount": 1,
      "batches": [
        {
          "batchId": "0m-ihpvS6UsxVcNqDfNmjMfYgxYPG4qXEalCOF9yLpE",
          "groupId": "12323",
          "activityId": "S1iFgKEIAqvnp--IF-3NXA",
          "activityStatus": 3,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },
        {
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 2,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },
        {
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 2,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },{
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 2,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        }
      ]
    }
  });

  // 领取券

  mock.onPost('/th/coupon/got').reply(200, {
    "resultCode": 1,
    "resultData": {
      "gotSuccess":0,
      "errorCode":"100000037",
      "activityStatus":2
    }
  });

  // 领取券

  mock.onPost('/th/coupon/groupGot').reply(200, {
    "resultCode": 1,
    "resultData": {
      "gotSuccess": 1,
      "groupLeftCount": 0,
      "batches": [
        {
          "batchId": "0m-ihpvS6UsxVcNqDfNmjMfYgxYPG4qXEalCOF9yLpE",
          "groupId": "12323",
          "activityId": "S1iFgKEIAqvnp--IF-3NXA",
          "activityStatus": 3,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },
        {
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 1,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },
        {
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 2,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        },{
          "batchId": "cRuPv7joo9ssACbNW1PaWBVnp2fsH160elh6r2mG0pA",
          "groupId": "123214",
          "activityId": "WBvJmhdCJJ3xtmOEiwm_LbbUkNaA0-PwjpDEhdpDTD0",
          "activityStatus": 2,
          "detailLink": "/th/coupon/withoutLogin/groupBatchDetail?xxx=123",
        }

      ]
    }
  });

  // 优惠券领券上报信息

  mock.onPost('/th/coupon/mark').reply(200, {
    "resultData": {
    "actionData": {
      "type": "native",
      "address": "/qr/scan"
      }
    },
    "resultCode": 1,
    "resultMsg": "success"
    });
}
