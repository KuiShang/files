/*eslint-disable*/
export default function invite(mock) {
    // 进入邀请页面初始化数据
    mock.onPost('/invitation/getLandingPage').reply(200, {
        "resultCode": 1, //返回code
        "msg": "success", //处理结果描述
        "resultData": {
            "responseCode":1,
            "response": {
                "imageUrl": "http://test.storage.jd.com/th.wallet.invitation/images/208646235199528960_big_209628342537314304.jpg?Expires=3714877339&AccessKey=iCgOJscM0K44WuDc&Signature=El9evCJhTBJKY1knHjZWA6xZ7ac%3D",
                "subjectId": "123456677"
            }
        }
    })
    // 邀请历史条数
    mock.onPost('/invitation/getFriends').reply(200, {
        "resultCode": 1, //返回code
        "msg": "success", //处理结果描述
        "resultData": {
            "responseCode": 1,
            "response":{
                "count": 30,
                "friendList":[
                {
                firstName: 'Hendry',
                state: 'Completed',
                time: '2019.08.01 19:20'
                },
                {
                firstName: 'Lisa',
                state: 'Completed',
                time: '2019.08.01 19:20'
                },
                {
                firstName: 'Dave',
                state: 'Completed',
                time: '2019.08.01 19:20'
                }
            ]
             }
        }
    })
    //邀请历史数据
    mock.onPost('/invitation/historyData').reply(200, {
        "resultCode": 1, //返回code
        "msg": "success", //处理结果描述
        "resultData": {
            "responseCode": 1,
            "count": 30,
            "friendList":[
                {
                firstName: 'Hendry',
                state: 'Completed',
                time: '2019.08.01 19:20'
                },
                {
                firstName: 'Lisa',
                state: 'Completed',
                time: '2019.08.01 19:20'
                },
                {
                firstName: 'Dave',
                state: 'Completed',
                time: '2019.08.01 19:20'
                }
            ]
        }
    })
    //邀请用户方式
    mock.onPost('/invitation/getSharing').reply(200, {
        "resultCode": 1,
        "resultMsg": "success",
        "resultData": {
            "responseCode":1,
            "link": "http://jdd.cn/b5c107e8",
            "copyWritting": {
                "title": "Title(English)",
                "content": "Content(English)",
                "smallImageLink": "http://test.storage.jd.com/th.wallet.invitation/images/208646235199528960_small_209628342537314304.jpg?Expires=3714877338&AccessKey=iCgOJscM0K44WuDc&Signature=tqvI1xCiLm3d7BQL2jbA5s1Lh1Y%3D",
                "bigImageLink": "http://test.storage.jd.com/th.wallet.invitation/images/208646235199528960_big_209628342537314304.jpg?Expires=3714877339&AccessKey=iCgOJscM0K44WuDc&Signature=El9evCJhTBJKY1knHjZWA6xZ7ac%3D"
            }
        }
    })
    mock.onPost('/invitation/join').reply(200, {
        "resultCode": 1,
        "resultMsg": "success",
        "resultData": {
            "responseCode":1,
            "response": {
                'dynamicLink': "http://www.baidu.com"
            },
            "link": "http://jdd.cn/b5c107e8",
            "copyWritting": {
                "title": "Title(English)",
                "content": "Content(English)",
                "smallImageLink": "http://test.storage.jd.com/th.wallet.invitation/images/208646235199528960_small_209628342537314304.jpg?Expires=3714877338&AccessKey=iCgOJscM0K44WuDc&Signature=tqvI1xCiLm3d7BQL2jbA5s1Lh1Y%3D",
                "bigImageLink": "http://test.storage.jd.com/th.wallet.invitation/images/208646235199528960_big_209628342537314304.jpg?Expires=3714877339&AccessKey=iCgOJscM0K44WuDc&Signature=El9evCJhTBJKY1knHjZWA6xZ7ac%3D"
            }
        }
    })
}
