/*eslint-disable*/
export default function topup(mock) {

	/**
	 * 转账到prompt tag 30 相关的3个新增接口
	 */
	// 1. prompt tag30 扫描后跳转H5页面后 获取页面数据接口
	mock.onPost('/th/wallet/collect/getPromptTag30Info').reply(200, {
		"resultCode": "1",
		"resultData": {
			"amount": 0,
			"billerId": "099400016520000",
			"reference1": "015286961",
			"reference2": "",
			"reference3": ""
		},
		"errorData": null,
		"actionData": null,
		"resultMsg": "success"
	})

	// 2.  promptTag30查询详情页面
	mock.onPost('/th/wallet/promptTag30/promptTag30ReviewDetail').reply(200, {
		"resultCode": "1",
		"resultData": {
			"receiverName": 'zhang san',
			"promptLoolupRef": "123456",
			"fee": "015281236961"
		},
		"errorData": null,
		"actionData": null,
		"resultMsg": "success"
	})
	// 3.  promptTag30 点击转账，创建转账业务单
	mock.onPost('/th/wallet/promptTag30/promptTag30CreateOrder').reply(200, {
		"resultCode": "1",
		"resultData": {
			"actionData": "",
			"amount": 111,
			"currency": "THB",
			"operateAmount": 0,
			"payUrl": "https://cashier.jd.co.th/payment?transactionNo=20180929195939AN7147997935332160",
			"topupSuccUrl": "",
			"transOrderNo": "20180929195931TRAN71479979",
			"transactionNo": "20180929195939AN7147997935332160",
			"transferResultUrl": "",
			"withdrawSuccUrl": ""
		},
		"errorData": null,
		"actionData": null,
		"resultMsg": "success"
	})

	// transfer    转账 查询历史记录
	mock.onPost('/th/wallet/transfer/transferRecord').reply(200,
		{
			"resultCode": "1",
			"resultData": {
				"productStyle": "",
				"transRecordResList": [{
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000202604",
					"customerName": "สุธยาน",
					"iconUrl": "http://test.storage.jd.com/bluewhale/00660020002026041557143318478.jpg?Expires=1872503318&AccessKey=V0plYwuLkX1Zk9iv&Signature=sQoSmAsTmEzJy93tB0GWJFYMW0c%3D",
					"phone": "0113692580",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190821154043TRAN58706450",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "",
					"customerName": "",
					"iconUrl": "",
					"phone": "",
					"promptAccountNo": "0988352881",
					"promptAccountType": "MSISDN",
					"promptIconUrl": "https://storage.cjdfintech.com/th-wallet-server/transfer/promptpay.png?Expires=3687155232&AccessKey=duB7kf1nPEsvNizS&Signature=EWvPrauZn4BLcn%2BOw6xiTOPP%2BzY%3D",
					"promptReciverName": "MR TEST_P0229824 P0229824",
					"transOrderNo": "20190820164306TRAN17337998",
					"transferChannel": "3"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "",
					"customerName": "",
					"iconUrl": "",
					"phone": "",
					"promptAccountNo": "0861234502",
					"promptAccountType": "MSISDN",
					"promptIconUrl": "https://storage.cjdfintech.com/th-wallet-server/transfer/promptpay.png?Expires=3687155232&AccessKey=duB7kf1nPEsvNizS&Signature=EWvPrauZn4BLcn%2BOw6xiTOPP%2BzY%3D",
					"promptReciverName": "จ่าสิบเอกหญิงชณิสร สิทธิปัญญา",
					"transOrderNo": "20190816152517TRAN69630327",
					"transferChannel": "3"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000202727",
					"customerName": "สร้อยสรินทร์",
					"iconUrl": "http://test.storage.jd.com/bluewhale/09464353331556183825687.png?Expires=1871543826&AccessKey=V0plYwuLkX1Zk9iv&Signature=l6LgNnl12IoazXcp3l4GPYynp1g%3D",
					"phone": "0866666668",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190815101626TRAN59088332",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000214577",
					"customerName": "ปาริชาติ",
					"iconUrl": "http://test.storage.jd.com/bluewhale/05677899871565348211469.png?Expires=1880708211&AccessKey=V0plYwuLkX1Zk9iv&Signature=WNYuxXBq%2BRYTOxo%2FdoSPhQWjB%2Bo%3D",
					"phone": "0567789987",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190812103551TRAN90386961",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000208833",
					"customerName": "อุทัย",
					"iconUrl": "http://test.storage.jd.com/bluewhale/08764664991560916516427.png?Expires=1876276516&AccessKey=V0plYwuLkX1Zk9iv&Signature=raXUwj0zDDUof4X%2BJeRAiaoGKrs%3D",
					"phone": "0876466499",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190812104514TRAN74789597",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "7307",
					"bankIconUrl": "http://test.storage.jd.com/thadminpayment-images/1556171824092.png",
					"bankName": "BAY",
					"cardId": "780F9CB0A92802A336D19832008D4027",
					"customerId": "",
					"customerName": "",
					"iconUrl": "",
					"phone": "",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190702153914TRAN50706717",
					"transferChannel": "2"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000201685",
					"customerName": "สร้อยสรินทร์",
					"iconUrl": "http://test.storage.jd.com/bluewhale/00660020002016851556001353843.jpg?Expires=1871361353&AccessKey=V0plYwuLkX1Zk9iv&Signature=RYoXraMD47RpGwFP9fRZ9Basiuk%3D",
					"phone": "0753693690",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190729175019TRAN17826669",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000192976",
					"customerName": "ติยาภรณ์",
					"iconUrl": "http://test.storage.jd.com/bluewhale/04444400111546510646215.png?Expires=1861870646&AccessKey=V0plYwuLkX1Zk9iv&Signature=VIHRjWA1vLRoDqQGdmYkEAQMT%2Bc%3D",
					"phone": "0444440011",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190723145703TRAN21671922",
					"transferChannel": "1"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "",
					"customerName": "",
					"iconUrl": "",
					"phone": "",
					"promptAccountNo": "0896920809",
					"promptAccountType": "MSISDN",
					"promptIconUrl": "https://storage.cjdfintech.com/th-wallet-server/transfer/promptpay.png?Expires=3687155232&AccessKey=duB7kf1nPEsvNizS&Signature=EWvPrauZn4BLcn%2BOw6xiTOPP%2BzY%3D",
					"promptReciverName": "บิลสุลต่าน เปรมชาดา",
					"transOrderNo": "20190626170041TRAN12064477",
					"transferChannel": "3"
				}, {
					"accountName": "",
					"accountNo": "",
					"bankIconUrl": "",
					"bankName": "",
					"cardId": "",
					"customerId": "0066002000201357",
					"customerName": "วัฒนา",
					"iconUrl": "http://test.storage.jd.com/bluewhale/08666666661555312437619.png?Expires=1870672437&AccessKey=V0plYwuLkX1Zk9iv&Signature=UzMAP38TYwqY85kVtMfyqobCTAs%3D",
					"phone": "0866666666",
					"promptAccountNo": "",
					"promptAccountType": "",
					"promptIconUrl": "",
					"promptReciverName": "",
					"transOrderNo": "20190624175834TRAN38583129",
					"transferChannel": "1"
				}],
				"whiteListSwitch": "off"
			},
			"errorData": null,
			"actionData": null,
			"resultMsg": "success"
		}
	)

	// transfer    转账 查询转账到bankacount 初始化数据
	mock.onPost('/th/wallet/transfer/transferPage').reply(200, {
		"resultCode": "1",
		"resultData": {
			"balanceAmount": 97892,
			"bankAccountInfoList": [
				{
					"accountName": "JDPAYER",
					"accountNo": "1787",
					"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
					"bankName": "KBANK",
					"cardId": "C27A7EEAD0E4A613619259B9BB176CF2"
				},
				{
					"accountName": "JDPAYER",
					"accountNo": "8068",
					"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
					"bankName": "KBANK",
					"cardId": "A6BC30B3F3079C910BC93B38A65331C3"
				},
				{
					"accountName": "JDPAYER",
					"accountNo": "4369",
					"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
					"bankName": "KBANK",
					"cardId": "CB01377D2A8060D51590BD1B28F38244"
				}
			],
			"fee": "4",
			"limitAmountl": {
				"availableAmount": 95700,
				"customerId": "0066002000020022",
				"dayAmountUpper": 100000,
				"onceAmountLower": 0.01,
				"onceAmountUpper": 100000,
				"totalAmount": 4300
			}
		},
		"errorData": null,
		"actionData": null,
		"resultMsg": "success"
	})

	// transfer    转账 查询转账到bankacount 初始化数据
	mock.onPost('/th/wallet/transfer/createTransfer').reply(200, { "resultCode": "1", "resultData": { "actionData": "", "amount": 12, "currency": "THB", "operateAmount": 0, "payUrl": "https://cashier.jd.co.th/payment?transactionNo=20180913144404AN4563324237527948", "topupSuccUrl": "", "transOrderNo": "20180913144404TRAN45633242", "transactionNo": "20180913144404AN4563324237527948", "transferResultUrl": "", "withdrawSuccUrl": "" }, "errorData": null, "actionData": null, "resultMsg": "success" })

	// transfer    转账 通过手机号查询用户信息
	mock.onPost('/th/wallet/transfer/queryByPhone').reply(200,
		{
			"resultCode": "1", "resultData":
			{
				"customerId": "0066002000017051",
				"customerName": "first",
				"iconUrl": "http://test.storage.jd.com/bluewhale/0066002000017051.jpg?Expires=1851042477&AccessKey=V0plYwuLkX1Zk9iv&Signature=PSx5YpFckae%2FP0%2FTYJ2vBawur%2BM%3D",
				"phone": "0888888870"
			},
			"errorData": null, "actionData": null, "resultMsg": "success"
		})

	// transfer    转账 通过手机号查询用户信息
	mock.onPost('/th/wallet/balancemain/mainPage').reply(200, { "resultCode": "1", "msg": "success", "resultData": { "balanceAmount": 2000, "currency": "THB" } })

	// transfer    转账 通过手机号查询用户信息
	mock.onPost('/th/wallet/record/queryDetail').reply(200, {
		"code": "000000",
		"msg": "success",
		"resultData": {
			"amount": 2000,
			"balanceAmount": 0,
			"busiScenarios": "5", //业务场景 1消费、2消费退款、3充值、4提现、5转账
			"inOutFlag": "1", //出入款标识 (1:in 2:out)
			"serviceCharge": 0,
			"serviceOddNo": "20180512145350BAL92292433",
			"successTime": 1527069754000
		}
	})

	// transfer    转账 通过银行列表
	mock.onPost('/th/wallet/transfer/queryBankList').reply(200,
		{
			"resultCode": "1",
			"resultData": [
				{
					"bankCode": "156485",
					"bankName": "中国银行",
					"createdDate": 1528786057000,
					"h5Logo": "http://icb.jpg",
					"id": 1,
					"modifiedDate": 1528786059000,
					"pcLogo": "http://icb.jpg",
					"status": 1 //状态（1、正常  2、弃用）
				},
				{
					"bankCode": "874641",
					"bankName": "农业银行",
					"createdDate": 1528790469000,
					"h5Logo": "http://h5.jpg",
					"id": 2,
					"modifiedDate": 1528790472000,
					"pcLogo": "http://pc.jpg",
					"status": 1
				}
			],
			"errorData": null,
			"actionData": null,
			"resultMsg": "success"
		})


	// transfer     转到银行账户 查询可转银行账户列表
	mock.onPost('/th/wallet/transfer/transBankAccountList').reply(200,
		{
			"resultCode": "1",
			"resultData": {
				"bindBankAccountList": [
					{
						"accountName": "JDPAYER",
						"accountNo": "1787",
						"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
						"bankName": "KBANK",
						"cardId": "C27A7EEAD0E4A613619259B9BB176CF2"
					},
					{
						"accountName": "JDPAYER",
						"accountNo": "8068",
						"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
						"bankName": "KBANK",
						"cardId": "A6BC30B3F3079C910BC93B38A65331C3"
					},
					{
						"accountName": "JDPAYER",
						"accountNo": "4369",
						"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
						"bankName": "KBANK",
						"cardId": "CB01377D2A8060D51590BD1B28F38244"
					}
				],
				"transBankAccountRecordList": [
					{
						"accountName": "JDPAYER",
						"accountNo": "4369",
						"bankIconUrl": "http://storage.jd.com/thimage/kbank.png?Expires=3682512055&AccessKey=1ievRXlPgvbYfXzh&Signature=Rg61V6oOyhIHe6%2FG0USE0MVOkiI%3D",
						"bankName": "KBANK",
						"cardId": "CB01377D2A8060D51590BD1B28F38244"
					}
				]
			},
			"errorData": null,
			"actionData": null,
			"resultMsg": "success"
		})


	// transfer     转到银行账户 查看prompt详情
	mock.onPost('/th/wallet/transfer/promptReviewDetail').reply(200,
		{
			"resultCode": "1",
			"resultData": {
				"promptLookupId": "12",
				"promptLookupRef": "dsddddfafaff",
				"receiverName": "jack"
			},
			"errorData": null,
			"actionData": null,
			"resultMsg": "success"
		})
	// transfer     转账结果页
	mock.onPost('/th/wallet/transfer/transferResult').reply(200,
		{
			"resultCode": "1",
			"resultData": {
				"amount": 1.00,
				"busiScenarios": "32",
				"createdDate": 1562930652000,
				"currency": "THB",
				"customerId": "0066002000000471",
				"displayName": "BALA",
				"modifiedDate": 1562930667000,
				"paymentMethod1": "BALA",
				"receiverName": "เบญจพร",
				"promptAccountNo": "0898891415",
				"remark": "",
				"serviceCharge": 0.00,
				"status": 3,
				"successTime": 1562930667000,
				"transOrderNo": "20190712182412TRAN76760962",
				"transferChannel": "1"
			},
			"errorData": null,
			"actionData": null,
			"resultMsg": "success"
		}
		// {
		// 	"resultCode": "1",
		// 	"resultData": {
		// 			"amount": 2000,
		// 			"bankAccount": "1892554369",
		// 			"bankName": "KBANK",
		// 			"createdDate": 1538200632000,
		// 			"currency": "THB",
		// 			"customerId": "0066002000020022",
		// 			"displayName": "BALA",
		// 			"modifiedDate": 1538200632000,
		// 			"paymentMethod1": "BALA",
		// 			"paymentMethod2": "",
		// 			"promptAccountNo": "",
		// 			"receiverName": "JDPAYER",
		// 			"receiverWalletAccount": "",
		// 			"remark": "转账（余额到银行账户）",
		// 			"status": 3,
		// 			"successTime": 1538201225000,
		// 			"transOrderNo": "20180929135711TRAN72003781"
		// 	},
		// 	"errorData": null,
		// 	"actionData": null,
		// 	"resultMsg": "success"
		// }
		// {	
		// 	"resultCode": "1",
		// 	"resultData": {
		// 			"amount": 2000,
		// 			"bankAccount": "",
		// 			"bankName": "",
		// 			"createdDate": 1538202585000,
		// 			"currency": "THB",
		// 			"customerId": "0066002000020022",
		// 			"displayName": "BALA",
		// 			"modifiedDate": 1538202610000,
		// 			"paymentMethod1": "BALA",
		// 			"paymentMethod2": "",
		// 			"promptAccountNo": "123456789",
		// 			"receiverName": "jack",
		// 			"receiverWalletAccount": "",
		// 			"remark": "转账（余额到promptPay）",
		// 			"status": 3,
		// 			"successTime": 1538203133000,
		// 			"transOrderNo": "20180929142944TRAN10959218"
		// 	},
		// 	"errorData": null,
		// 	"actionData": null,
		// 	"resultMsg": "success"
		// }
)
// transfer     结果页优惠券查询
mock.onPost('/setting/queryOrderDetail').reply(200,{
	"resultCode": 1,
	"resultMsg": null,
	"resultData": {
	"orderAmount": 100.00,
	"orderCurrency": "THB",
	"promoBean": {
	"couponName": "test晓翠0916-1",
	"discountAmount": 20.00,
	"shortDesicriptionMap": {
	"en_US": "test晓翠0916-1",
	"th_TH": "test晓翠0916-1"
	},
	"titleMap": {
	"en_US": "test晓翠0916-1",
	"th_TH": "test晓翠0916-1"
	},
	"prizeRuleValue": "20.00",
	"extAttribute": {},
	"conditionMap": {
	"en_US": "test晓翠0916-1",
	"th_TH": "test晓翠0916-1"
	},
	"orderAmount": 100.00,
	"actualPaymentAmount": 80.00,
	"background": "https://test.storage.jd.com/th.wallet.coupon.doc/214714274267533312.png?Expires=2568606272&AccessKey=rerNzraul9V6GShy&Signature=sjAbypwNx6JZY%2FY1cO9rhuCcLBI%3D",
	"couponType": 0,
	"logo": "https://test.storage.jd.com/th.wallet.coupon.doc/214714259671355392.jpg?Expires=2568606268&AccessKey=rerNzraul9V6GShy&Signature=qZgjxHz0szC5vku7ol3qPAc0Nog%3D",
	"prizeRuleType": 5
	},
	"remark": "",
	"payResultModel": {
	"maskedNo": null,
	"displayName": "BALA",
	"payMethodCodeSecond": null,
	"payMethodCodeThird": "",
	"payMethodCodeFirst": "BALA"
	},
	"merchantName": "oversea252"
	},
	"errorData": null,
	"actionData": null
   }
   )
}


