import * as types from './mutation-types'

const mutations = {
  [types.SET_TiTLE](state, str) {
    state.titleTxt = str
  },
  [types.SAVE_IS_APP](state, flag) {
    state.isApp = flag
  },
  [types.SET_TITLE_BLACK](state, flag) {
    state.titleBlack = flag
  },
  [types.SET_LANGUAGE](state, flag) {
    state.language = flag;
  },
  setCdcpPendingBox(state, flag) {
    state.cdcpPendingBox = flag
  },
  payLooping(state, flag) {
    state.payLooping = flag
  }
}
export default mutations
