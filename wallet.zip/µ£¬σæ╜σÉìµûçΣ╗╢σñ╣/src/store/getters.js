export const isApp = state => state.isApp
export const title = state => state.titleTxt
export const titleBlack = state => state.titleBlack
export const language = state => state.language
