import * as types from './mutation-types';

// 设置标题文字
export const setTitle = ({ commit }, data) => {
  commit(types.SET_TiTLE, data);
}
// 保存是否app状态
export const saveIsApp = ({ commit }, data) => {
  commit(types.SAVE_IS_APP, data);
}
// 设置标题栏颜色
export const saveTitleBlack = ({ commit }, data) => {
  commit(types.SET_TITLE_BLACK, data);
}
