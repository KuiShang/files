/*eslint-disable*/
/*-------------------------全局状态---------------------*/
// 设置标题
export const SET_TiTLE = 'SET_TiTLE'
// 保存是否app状态
export const SAVE_IS_APP = 'CHANGE_INSTRUCTION'
// 更改标题栏颜色
export const SET_TITLE_BLACK = 'SET_TITLE_BLACK'

export const SET_LANGUAGE = 'SET_LANGUAGE'
