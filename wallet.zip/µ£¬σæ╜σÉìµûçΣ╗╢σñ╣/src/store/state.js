const state = {
  isApp: false,
  titleTxt: '',
  titleBlack: false,
  language: 'EN',
  cdcpPendingBox: false,
  payLooping: false
}
export default state
