import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger'
import * as actions from './actions'
import * as getters from './getters'
import mutations from './mutations'
import state from './state'
import billPayment from './modules/billPayment'
import transferBankAccount from './modules/transferBankAccount'
import h5Config from './modules/h5Config'

Vue.use(Vuex)
const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
  state,
  actions,
  mutations,
  getters,
  modules: {
    billPayment,
    transferBankAccount,
    h5Config
  },
  strict: debug,
  plugins: debug ? [createLogger()] : []
})
