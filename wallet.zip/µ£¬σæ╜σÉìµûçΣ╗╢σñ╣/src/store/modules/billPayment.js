import * as types from '../mutation-types';
/*eslint-disable*/
const state = {
  showSelectPeople: false
}

const mutations = {
  [types.SET_TiTLE](state, id) {
    state.title = id;
  }
}
const getters = {
  showSelectPeople: state => state.showSelectPeople
};

export default {
  state,
  mutations,
  getters
}
