/*eslint-disable*/
const state = {
  selectBankInfo: {},
  bankAccountInfoList: []
}

const mutations = {
  'SET_SELECTBANKINFO'(state, data) {
    state.selectBankInfo = data
  },
  'SET_BANKINFOLIST'(state, data) {
    state.bankAccountInfoList = data
  }
}

const getters = {
  bankAccountInfoList: state => state.bankAccountInfoList,
  selectBankInfo: state => state.selectBankInfo
}

export default {
  state,
  mutations,
  getters
}
