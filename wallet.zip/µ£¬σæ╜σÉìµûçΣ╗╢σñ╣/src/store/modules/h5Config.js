/*eslint-disable*/
const state = {
  promotionTracePoint: '',
  pageId: -1,
  promotionScrollY: 0
}

const mutations = {
  'SET_PROMOTION_TRACE_POINT'(state, data) {
    state.promotionTracePoint = data
  },
  'SET_PROMOTION_PAGE_ID'(state, data) {
    state.pageId = data;
  },
  'SET_PROMOTION_SCROLL_Y'(state, data) {
    state.promotionScrollY = data;
  }
}

const getters = {
  promotionTracePoint: state => state.promotionTracePoint,
  pageId: state => state.pageId,
  promotionScrollY: state => state.promotionScrollY
}

export default {
  state,
  mutations,
  getters
}
