import { balancePay, oddPay, cspPay, ccpPay, deliPay, scanedResultQuery } from '@/api'
import { enumPayMethodCodeFirst, ENUM_ERRORCODE, CASHIER_CHECKTYPE, CASHIER_TRANSATION_STATUS } from '@/utils/const'
import * as CASHIER_BURRY from '@/pages/burry/cashier'
// import axios from 'axios'

let currentPayTiming = -1 // 支付开始计时
const maxPayTiming = 40 // 最大计时时间
let lastPayTime = 0 // 上一次支付时间
let cashierPaytimer = '' // 收银台支付轮训定时器
export default {
  data() {
    return {
      // 第一次发起支付的时候， 记录原始数据，后端未返回actionData时，用第一次的原始数据
      firstReqData: '',
      showRetrydialog: false
    }
  },
  methods: {
    /**
     * @param {一级付款方式} payMethodCodeFirst
     * @param {请求数据} reqData
     * @param {请求回调,如果不是通过收银台成功动画完成后通知外层组建去处理后续事件，可以通过cb去做自定义处理} cb
     * @param {调用这个方法的页面来源 目前有三处 'simpleCashier（半屏收银台）', 'cdcp（半屏收银台新卡支付）' ‘cashierCdcp（绑卡并支付）’} callFrom
     */
    async switchPay(payMethodCodeFirst, reqData, cb = () => {}, callFrom = 'simpleCashier') {
      let res
      if (payMethodCodeFirst === enumPayMethodCodeFirst.ODD) {
        res = await oddPay(reqData)
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.BALA) {
        res = await balancePay(reqData)
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.OFLN) {
        res = await cspPay(reqData)
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
        res = await ccpPay(reqData)
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.DELI) {
        res = await deliPay(reqData)
      }
      // 调用失败  或者 调用成功 但是支付时返回状态失败
      function transtionFailed() {
        if (callFrom === 'simpleCashier') {
          this.paymentFailed = true
        } else if (callFrom === 'cashierCdcp') {
          this.$router.replace({ name: 'addBankAccountResult', query: { result: 0, type: 'CARD' } })
        } else if (callFrom === 'cdcp') {
          // TODO: 带讨论
          // this.$parent.$parent.$parent.goLeave()
          // 针对 CSR2200004 跳转失败，此处没有判断错误码，因为此处失败跳转处理超成通用失败界面
          this.$router.replace({ name: 'cardPayFail' })
        } else {
          this.$toast({
            message: this.$t('TWL9900001'),
            position: 'middle',
            duration: 3000
          })
        }
      }
      // 成功不需要加验证
      async function successNoNeedCheck() {
        console.log('enumPayMethodCodeFirst.OFLN', enumPayMethodCodeFirst.OFLN)
        // 保存 安全中心返回的 是否需要引导用户开通指纹\人脸识别数据，再结果页会据此判断
        if (res && res.data && res.data.resultData && res.data.resultData.appGuideNeedDataMap) {
          await this.$SDK.putCache({
            key: 'appGuideNeedDataMap',
            value: JSON.stringify(res.data.resultData.appGuideNeedDataMap),
            cacheMode: 2
          })
        }
        // 线下充值成功
        if (payMethodCodeFirst === enumPayMethodCodeFirst.OFLN) {
          cb(res)
          return res
        }
        // deeplink成功
        if (payMethodCodeFirst === enumPayMethodCodeFirst.DELI) {
          cb(res)
          return res
        }
        // 返回pend状态半屏收银台显示支付超时  卡支付界面显示dialog
        if (res && res.data && res.data.resultData && res.data.resultData.transactionStatus === CASHIER_TRANSATION_STATUS.PEND) {
          if (callFrom === 'simpleCashier') {
            console.log('当前：收银台返回pending')
            this.networkError = true
          } else if (callFrom === 'cashierCdcp') {
            console.log('绑卡并支付返回pending')
            this.$indicator.close()
            this.pendingBox = true
          } else if (callFrom === 'cdcp') {
            console.log('当前：收银台使用新卡返回pending')
            this.$store.commit('setCdcpPendingBox', true)
          } else {
            console.error('不能识别的类型，请检查传参')
          }
          return res
        }
        // 卡支付成功（正常支付，不需要3ds跳转到三方页面）区分卡支付来源
        if (payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
          CASHIER_BURRY.CREDIT_CARD_ONLINE_LEAVE()
          console.log('卡支付成功')
          // 当前如果是 半屏收银台页面 则直接emit外层
          // 当前如果是 cdcp卡支付页面 则需要this.$parent.$parent.$parent.$emit 能相当于在半屏收银台emit
          // 此处通过调用这个方法的来源（callFrom）区分，当前是哪个页面
          // 也可以通过payMethodCodeSecond 是否是special 来区分 当前是旧卡支付还是新卡支付 来区分当前是哪个组建在调用这个方法
          if (callFrom === 'simpleCashier') {
            console.log('当前：收银台使用旧卡支付成功')
            const txt = this.$t('Success')
            this.cashierAnimateStatusTxt = `${txt}!`
            this.$emit('paynow', this.dataObj)
          } else if (callFrom === 'cashierCdcp') {
            console.log('绑卡并支付成功，跳转至原声，目前这种情况都会通过3ds调走，')
            this.$SDK.closeWebViewAndSendResult()
          } else if (callFrom === 'cdcp') {
            console.log('当前：收银台使用新卡支付成功')
            cb(res)
            this.$parent.$parent.$parent.$emit('paynow', this.currentBank)
          } else {
            console.error('不能识别的类型，请检查传参')
          }
          return res
        }
        // 普通业务流程 充值 转账 等 成功 emit外层成功
        this.$refs.animateSuccess.complete(() => {
          const txt = this.$t('Success')
          this.cashierAnimateStatusTxt = `${txt}!`
          CASHIER_BURRY.SUCCESS_COUNTER_LEAVE()
          this.$nextTick(() => {
            this.$emit('paynow', this.dataObj)
            return res
          })
        })
        return res
      }

      function retryAjaxEnd() {
        clearInterval(cashierPaytimer)
        currentPayTiming = -1
        this.showRetrydialog = true
        this.$store.commit('payLooping', false)
        this.$indicator.close()
      }
      function retryAjax() {
        async function queryResult(transactionNo) {
          const payRet = await scanedResultQuery({
            transactionNo
          })
          if (payRet && payRet.data && payRet.data.resultCode === 1) {
            const status = payRet.data.resultData.transactionStatus
            if (status === CASHIER_TRANSATION_STATUS.SUCC) {
              successNoNeedCheck.call(this)
            } else if (status === CASHIER_TRANSATION_STATUS.PEND) {
              transtionFailed.call(this)
            } else if (status === CASHIER_TRANSATION_STATUS.INIT) {
              transtionFailed.call(this)
            } else if (status === CASHIER_TRANSATION_STATUS.CLOSE) {
              transtionFailed.call(this)
            }
          } else {
            retryAjax.call(this)
          }
        }
        lastPayTime = Date.now()
        this.startPayTiming()
        if (currentPayTiming < maxPayTiming) {
          const millis = Date.now() - lastPayTime
          if (Math.floor(millis / 1000) < 2) {
            setTimeout(async () => {
              console.log('查询收银台支付结果请求，间隔：', Math.floor((Date.now() - lastPayTime) / 1000))
              console.log('查询收银台支付结果请求，当前时间：', currentPayTiming)
              queryResult.call(this, reqData.transactionNo)
            }, 2000)
          } else {
            console.log('查询收银台支付结果请求，间隔：', Math.floor((Date.now() - lastPayTime) / 1000))
            console.log('查询收银台支付结果请求，当前时间：', currentPayTiming)
            queryResult.call(this, reqData.transactionNo)
          }
        } else {
          setTimeout(() => {
            retryAjaxEnd.call(this)
          }, 0);
        }
      }

      // 成功但是需要加验证
      async function successAndNeedCheck() {
        // 加验场景为3DS时候跳转第三方连接
        if (res.data.resultData.needCheck && res.data.resultData.checkType === CASHIER_CHECKTYPE['3DS']) {
          this.go3ds(res.data.resultData.additionalData)
          return
        }
        if (res.data.actionData) {
          const pwdret = await this.$SDK.goNativeAction(res.data.actionData)
          if (pwdret.status === 1) {
            // 每次重新获取 deviceInfo，客户端会更新这个值
            const deviceInfoObj = await this.$SDK.getCommonInfo()
            console.log('输入密码后结果：', pwdret)
            const reqDataAfter = Object.assign({}, reqData, {
              riskId: pwdret.outData.riskId,
              pwdBizId: pwdret.outData.sc_no || '',
              deviceInfo: escape(JSON.stringify(deviceInfoObj))
            })
            await this.switchPay(payMethodCodeFirst, reqDataAfter, cb, callFrom)
          } else {
            this.showLoading = false
            this.$indicator.close()
          }
        } else {
          // 登录超时 但是并没有返回actionData 则重新调用
          this.switchPay(payMethodCodeFirst, this.firstReqData, cb, callFrom)
        }
      }

      // 调用失败
      async function returnfailed() {
        if (res.data.errorData.code === ENUM_ERRORCODE.RPC_NETWORK_TIMEOUT) {
          this.$indicator.close()
          if (callFrom === 'simpleCashier') {
            console.log('当前：收银台返回pending')
            this.networkError = true
          } else if (callFrom === 'cashierCdcp') {
            console.log('绑卡并支付返回pending')
            this.$indicator.close()
            this.pendingBox = true
          } else if (callFrom === 'cdcp') {
            console.log('当前：收银台使用新卡返回pending')
            this.$store.commit('setCdcpPendingBox', true)
          } else {
            console.error('不能识别的类型，请检查传参')
          }
        } else if (res.data.errorData.code === ENUM_ERRORCODE.CASHIER_NOT_LOGIN) {
          const ret = await this.$SDK.goNativeAction(res.data.actionData)
          console.log('登录后结果ret', ret)
        } else {
          transtionFailed.call(this)
          console.error('收银台支付报错：', `code: ${res.data.errorData.code} ,msg: ${res.data.errorData.msg}`)
        }
        CASHIER_BURRY.cashierError(callFrom, res.data.errorData.code)
      }

      console.log('------1.3-----', res)
      if (!res.data) {
        retryAjax.call(this)
        return
      }
      if (res.data.resultCode === 1) {
        if (res.data.resultData.needCheck) {
          successAndNeedCheck.call(this)
        } else if (res.data.resultData.transactionStatus === CASHIER_TRANSATION_STATUS.CLOSE) {
          transtionFailed.call(this)
        } else if (res.data.resultData.transactionStatus === CASHIER_TRANSATION_STATUS.PEND || res.data.resultData.transactionStatus === CASHIER_TRANSATION_STATUS.SUCC) {
          successNoNeedCheck.call(this)
        }
      } else if (res.data.resultCode === 0) {
        returnfailed.call(this)
      }
    },
    async go3ds(additionalData) {
      const dataObj = JSON.parse(additionalData)
      console.log(dataObj)
      if (!(dataObj.fields && dataObj.fields.securityCode)) {
        dataObj.fields.securityCode = await this.goLocalcvv()
      }
      this.saveInfoToStorageIf3ds()
      this.formPost(dataObj.action, dataObj.fields)
    },
    // 采集cvv 打开新webview 采集cvv
    async goLocalcvv() {
      const url = `${window.location.origin}/#/collectCVV`
      const ret = await this.$SDK.goNativeWebview(url)
      console.log(ret)
      if (ret.status === 1) {
        return ret.outData.value
      }
      console.log('没有输入cvv直接返回l', ret)
      this.$toast({
        message: this.$t('TWL9900001'),
        position: 'middle',
        duration: 3000
      })
      return ''
    },
    // 卡支付如果需要3ds验证 会刷新当前页面，再次提前保存当前业务场景
    async saveInfoToStorageIf3ds() {
      await this.$SDK.putCache({
        key: 'busi_type_before_cashier_leave',
        value: this.currentBusiType,
        cacheMode: 2
      })
      await this.$SDK.putCache({
        key: 'transOrderNo_before_cashier_leave',
        value: this.transOrderNo,
        cacheMode: 2
      })
      console.log('存储3ds跳转前的信息， currentBusiType：', this.currentBusiType)
      console.log('存储3ds跳转前的信息， transOrderNo: ', this.transOrderNo)
    },
    formPost(url, args = {}) {
      CASHIER_BURRY.CREDIT_CARD_ONLINE_LEAVE()
      const form = document.createElement('form')
      form.action = url
      form.style.display = 'none'
      form.method = 'POST'
      let input
      Object.keys(args).forEach((key) => {
        input = document.createElement('input')
        input.setAttribute('type', 'hidden')
        input.setAttribute('name', key)
        input.setAttribute('value', args[key])
        form.appendChild(input)
      })
      // iframe.appendChild(form)
      document.body.appendChild(form)
      this.$SDK.cancleOnBackPress()
      form.submit()
    },
    // 开启计时器 最大40s，一旦生效 再次调用也不会重复计时
    startPayTiming() {
      if (currentPayTiming !== -1) {
        return
      }
      this.$store.commit('payLooping', true)
      currentPayTiming += 1
      console.log('开始计时了～～～～～')
      cashierPaytimer = setInterval(() => {
        if (currentPayTiming >= 40) {
          this.$store.commit('payLooping', false)
          clearInterval(cashierPaytimer)
          return
        }
        console.log('收银台支付计时器:', currentPayTiming)
        currentPayTiming += 4
      }, 4000);
    }
  }
}
