/* eslint-disable  */
const busi = {
  scaned: 'scaned', // 被扫
  APP_PAY_VIRTUAL_GOODS: 'APP_PAY_VIRTUAL_GOODS' // gateway deeplink
}
export default busi
