<template>
  <div>please waiting...</div>
</template>
<script>
import { ALL_BUSI_TYPE } from '@/utils/const'

export default {
  name: 'RDT',
  async created() {
    const currentType = await this.$SDK.getCache({
      key: 'busi_type_before_cashier_leave',
      cacheMode: 2
    })
    const transOrderNo = await this.$SDK.getCache({
      key: 'transOrderNo_before_cashier_leave',
      cacheMode: 2
    })
    console.log('currentType：', currentType)
    console.log('transOrderNo：', transOrderNo)
    if (!currentType) {
      return
    }
    if (ALL_BUSI_TYPE.TOPUP === currentType) {
      if (window.location.hash.search('success') !== -1) {
        this.$router.replace({ name: 'topupResult', query: { transOrderNo } })
      } else {
        this.$router.replace({ name: 'topupResult' })
      }
    } else if (ALL_BUSI_TYPE.TRANSFER_TH1 === currentType || ALL_BUSI_TYPE.TRANSFER_BANKACCOUNT === currentType || ALL_BUSI_TYPE.TRANSFER_PROMOPY === currentType || ALL_BUSI_TYPE.P2P === currentType) {
      if (window.location.hash.search('success') !== -1) {
        this.$router.replace({ name: 'transferTh1Result', query: { transOrderNo } })
      } else {
        this.$router.replace({ name: 'transferTh1Result' })
      }
    } else if (ALL_BUSI_TYPE.SCANDED === currentType) {
      if (window.location.hash.search('success') !== -1) {
        this.$router.replace({ name: 'scanedResult', query: { transactionNo: this.$utils.getQueryString('transactionNo'), from: 'cashier' } })
      } else {
        this.$router.replace({ name: 'scanedResult' })
      }
    } else if (ALL_BUSI_TYPE.BIND_AND_PAY === currentType) {
      if (window.location.hash.search('success') !== -1) {
        this.$SDK.closeWebViewAndSendResult({ resultCode: 1 });
      } else {
        this.$router.replace({ name: 'addBankAccountResult', query: { result: 0, type: 'CARD' } })
      }
    } else if (ALL_BUSI_TYPE.APP_PAY_VIRTUAL_GOODS === currentType) {
      if (window.location.hash.search('success') !== -1) {
        this.$SDK.closeWebViewAndSendResult({ resultCode: 1 });
      } else {
        this.$router.replace({ name: 'gatewayResult', query: { transactionNo: this.$utils.getQueryString('transactionNo') } })
      }
    } else {
      console.error('没有匹配到正确类型', currentType)
    }
  }
}
</script>
