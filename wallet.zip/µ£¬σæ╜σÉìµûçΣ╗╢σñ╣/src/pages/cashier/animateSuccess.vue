<template>
  <div class="cashier-animate-status-container">
    <div class="cashier-success-txt-container">
      <div class="cashier-success-container" />
      <span
        v-show = "cutdownTime"
        class="seconed">{{ cutdownTime }}s</span>
    </div>
    <div class="cashier-animate-status-txt">{{ statusTxt }}</div>
  </div>
</template>
<script>
/*eslint-disable*/
import $ from 'zepto'

var tools = {
  browserInfo: null,
  getBrowserInfo: function () {
    if (this.browserInfo) {
      return this.browserInfo;
    }
    var ua = navigator.userAgent.toLowerCase();
    var isIos = ua.indexOf('ipad') > -1 || ua.indexOf('iphone') > -1 || false;
    var inWx = ua.indexOf('micromessenger') > -1 || false;
    var inJdApp = ua.indexOf('t1w') > -1 || false;
    var inJrApp = ua.indexOf('jdjr') > -1 || ua.indexOf('android-async-http') > -1 || false;
    var inWyApp = ua.indexOf('WalletClient') > -1 || false;
    var inApp = (tools.getUrlString('source') == "app" ? true : false);
    var resultObj = {
      isIos: isIos,
      inWx: inWx,
      inApp: inApp,
      inJdApp: inJdApp,
      inJrApp: inJrApp,
      inWyApp: inWyApp
    };
    this.browserInfo = resultObj;
    return resultObj
  },
  getUrlString: function (name) {
    var url = location.search;
    var pattern = /(\w+)=(\w+)/ig;
    var parames = {};
    url.replace(pattern, function (a, b, c) {
      parames[b] = c;
    });
    return parames[name];
  },
  format: function (str) {
    var pattern = /\{([\w\-_]+)\}/gm;
    var arr = Array.prototype.slice.call(arguments, 1);
    var args = /\{(\d+)\}/.test(str) ? arr : arr[0];
    var formatStr = str.replace(pattern, function () {
      return args[arguments[1]];
    });
    return formatStr;
  }
};
var h = "hidden";
var ua = navigator.userAgent;
var verArr = ua.toUpperCase().match(/CPU\s+IPHONE\s+OS\s+(\d+)/);
var iosVer = verArr && verArr.length == 2 ? verArr[1] : 0;

var aniEndStr = "animationend webkitAnimationEnd";
var tranEndStr = "transitionend webkitTransitionEnd";

var info = tools.getBrowserInfo();
var SuccessLoading
var loading
var completeFn
if (true) {
  console.log('dayu 7')
 var html =
    `<div class="success-loading abs-mm {statusClass} {visible}" style="zoom:{zoom};"> 
        
        <svg id="svg">
            <defs>
              <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%"  class="red"  />
                <stop offset="100%" class="yellow" />
              </linearGradient>
            </defs>
            
            <!-- 底色 --> 
            <circle r="27" cx="30" cy="30" fill="none"></circle>
            <!-- 遮罩 --> <circle  class="circle-mask" r="28" cx="30" cy="30" fill="{bgColor}"></circle>
            <!-- 圆轨 --> <path d="M3 30 A25 25 0 1 1 57 30 A25 25 0 0 1 3 30 A25 25 0 1 1 57 30 A25 25 0 0 1 3 30 A25 25 0 1 1 57 30 A25 25 0 0 1 3 30 A25 25 0 1 1 57 30" fill="none"  stroke="url(#grad1)"; stroke-width="3" class="path-rotate"></path>
            <!-- 对号 --> <path  stroke-linecap="round" stroke="url(#grad1)"; stroke-linejoin="round" class="path-correct hide" d="M17 30 L26 38 L43 21" fill="none" ß stroke-width="3"></path> 
        
        
            </svg> 
            <div class="circle-maskUp" style="background-color:{bgColor}"> </div>
     </div>`;

  
  var arr = ["rotate", "full", "scale", "complete", "scaleUp"];

  SuccessLoading = function SuccessLoading(options) {
    this.opts = options;
    this.init();
  }

  SuccessLoading.prototype = {
    constructor: SuccessLoading,

    init: function () {
      var self = this;
      var zoom = 1;
      var statusClass = "fullLayer"; // 有父元素(传进来)时，添加的样式
      var $box = $(this.opts.box);
      self.opts.color = self.opts.color || "#00c752";
      self.opts.bgColor = self.opts.bgColor || "#fff";
      self.opts.visible = self.opts.visible || "";
      if ($box.length == 0) {
        $box = $("body");
        statusClass = "single";
      } else {
        var w = $box.width();
        zoom = w / 60;
        self.zoom = zoom;
      }
      $box.find(".success-loading").remove();
      var obj = $.extend(self.opts, {
        statusClass: statusClass,
        zoom: zoom
      });
      $box.append(tools.format(html, obj));
      self.$box = $box;

      var $loading = $box.find(".success-loading");
      var $pathRotate = $loading.find(".path-rotate");
      var $circleMask = $loading.find(".circle-mask");
      var $pathCorrect = $loading.find(".path-correct");
      var $maskUp = $loading.find(".circle-maskUp");
      self.$pathRotate = $pathRotate;
      self.$loading = $loading;

      if (self.opts.type == "button") { //ios按钮loading，transform-origin不能是50%了
        $circleMask.addClass("zoom");
      }

      $pathRotate.off().on(aniEndStr, function (e) {
        if ($pathRotate.hasClass(arr[0]) && !self.isComplete) { // 未完成-继续转 - rotate
          self.start();
        } else if ($pathRotate.hasClass(arr[0]) && self.isComplete) { // 完成-切换到第二个状态 - full
          self.opts.rotateEnd && self.opts.rotateEnd();
          $pathRotate.removeClass(arr[0]).addClass(arr[1]);
        } else if ($pathRotate.hasClass(arr[1])) { //完成，切换到scale状态 - scale
          $pathCorrect.removeClass('hide')
          self.opts.fullEnd && self.opts.fullEnd();
          $circleMask.addClass(arr[2]);
        }
      });
      $circleMask.off().on(aniEndStr, function (e) { //缩放完成 ，切换到下一个状态 complete
        self.opts.scaleEnd && self.opts.scaleEnd();
        $loading.addClass(arr[3]);
      });
      $pathCorrect.off().on(tranEndStr, function () { // 对号完成，切换到scaleUp
        self.opts.correctEnd && self.opts.correctEnd();
        self.correctEnd && self.correctEnd();
        //$maskUp.addClass(arr[4]);
      });
      $maskUp.off().on(aniEndStr, function (e) { // scaleUp完成，切换到下一个页面
        //self.opts.scaleUpEnd && self.opts.scaleUpEnd();
      });
    },
    complete: function (fn) {
      this.isComplete = true;
      this.correctEnd = fn;
    },
    close: function () {
      var self = this;
      self.$loading.addClass(h);
    },
    start: function () {
      var self = this;
      self.$pathRotate.removeClass(arr[0]);
      setTimeout(function () {
        self.$pathRotate.addClass(arr[0]);
      }, 10);
    },
    show: function () {
      var self = this;
      var $box = $(self.opts.box);
      var zoom = self.zoom;
      if (!zoom) {
        if ($box.length > 0) {
          var w = $box.width();
          zoom = w / 60;
        }
        $box.find(".success-loading").css("zoom", zoom);
      }
      setTimeout(function () {
        self.start();
      }, 10);
      self.$loading.removeClass(h);
    }
  };
} else {
  console.log('xiaoyu 7')
  var html =
    '<div class="success-loading {androidClass}"><div class="circle-maskUp hidden" style="background-color:{color}"></div></div>';
  var splits = [35, 45, 63, 70, 72]; // 0-旋转、1、旋转完成-开始full一圈-rotateEnd；2、一圈完成-fullEnd；3、缩放完成-scaleEnd，4、对号完成-correctEnd
  var arrIndex = [0, splits[0], splits[1]];

  SuccessLoading = function SuccessLoading(options) {
    this.opts = options;
    this.init();
  }

  SuccessLoading.prototype = {
    constructor: SuccessLoading,

    init: function () {
      var self = this;
      var statusClass = "fullLayer"; // 有父元素(传进来)时，添加的样式
      var $box = $(self.opts.box);
      var color = self.opts.color || "#fff";
      var androidClass = "android";
      if (self.opts.type == "button") {
        androidClass = "android-btn";
        splits = [28, 29, 39, 45, 58];
        arrIndex = [0, splits[0], splits[1]];
      }
      if ($box.length == 0) {
        $box = $("body");
        statusClass = "single";
      }
      var $loading = $box.find(".success-loading");
      $loading.remove();
      $box.append(tools.format(html, {
        statusClass: statusClass,
        color: color,
        androidClass: androidClass
      }));
      $loading = $box.find(".success-loading");
      self.$box = $box;
      self.$loading = $loading;

      self.status = 0;
    },
    complete: function (fn) {
      this.status = 1;
      this.correctEnd = fn;
    },
    close: function () {
      var self = this;
      self.$loading.addClass(h);
    },
    start: function () {
      var self = this;
      var index = 0;
      var $box = self.$box;
      var box = $box.get(0);
      var $loading = $box.find(".success-loading");
      var $maskUp = $box.find(".circle-maskUp");
      // var h = $loading.height();
      // console.log('loading :', $loading)
      // console.log('loading hieght:', h)
      // $loading.height(h).width(h);
      var h = $('.cashier-success-container').height() || 60 ;
      console.log('loading hieght:', h)
      $loading.height(h).width(h);
      clearInterval(box.timer);
      box.timer = setInterval(function () {
        index++;
        if (index == splits[0] && self.status == 0) {
          index = arrIndex[0];
        } else if (index == splits[0] && self.status == 1) { // rotateEnd
          index = arrIndex[1];
          self.opts.rotateEnd && self.opts.rotateEnd();
        } else if (index == splits[2]) {
          self.opts.fullEnd && self.opts.fullEnd();
        } else if (index == splits[3]) {
          self.opts.scaleEnd && self.opts.scaleEnd();
        } else if (index == splits[4]) {
          self.opts.correctEnd && self.opts.correctEnd();
          self.correctEnd && self.correctEnd();
          clearInterval(box.timer);
          //$maskUp.addClass("scaleUp");
          return;
        }
        $loading.css({
          "background-position": "0 " + -index * h + "px"
        });
      }, 60);

      $maskUp.off().on(aniEndStr, function (e) { // 放大完成，切换到另一个页面
        //self.opts.scaleUpEnd && self.opts.scaleUpEnd();
      });
    },
    show: function () {
      var self = this;
      setTimeout(function () {
        self.start();
      }, 10);
      self.$loading.removeClass(h);
    }
  };
}

export default {
  name: 'AnimateSuccess',
  props: {
    show: {
      type: Boolean,
      default: false
    },
    statusTxt: {
      type: String,
      default: 'Processing'
    },
    cutdownTime: {
      type: Number,
      default: 0
    }
  },
  watch: {
    show(flag) {
      console.log('flag', flag)
      if (flag) {
        this.$nextTick(() => {
          this.initData()
        })
      }
    }
  },
  methods: {
    initData() {
      console.log('init')
        loading = new SuccessLoading({
        box: $(".cashier-success-container"),
        rotateEnd: function () {
          console.log('rotate end')
        },
        fullEnd: function () {
          console.log('full end')
        },
        scaleEnd: function () {
          console.log('scaleEnd ')
        },
        correctEnd: function () {
          console.log('correctEnd ')
          completeFn()
        },
        color: 'blue'
      });
      loading.show();
      console.log('end', SuccessLoading)
      // setTimeout(function () {
      //   loading.complete();
      // }, 4000);
    },
    complete(fn) {
      loading.complete();
      completeFn = fn
    }
  }
}
</script>
<style lang="scss" >
.cashier-success-txt-container {
  position: relative;
  .cashier-success-container {
    // width: 1.2rem;
    margin-left: 50%;
    transform: translateX(-30px);
    height: 1.5rem;
  }
  .seconed {
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -0.17rem;
    font-size: 0.36rem;
    margin-left: -0.26rem;
    color: #4F577C;
  }
  .hide {
    display: none;
  }
}
 
/**
 * css3lib
 * thanks: 
 * //bourbon.io/
 * https://github.com/thomas-mcdonald/bootstrap-sass/blob/master/vendor/assets/stylesheets/bootstrap/_mixins.scss
 * https://github.com/marvin1023/sassCore/blob/master/core/_css3.scss
 */
/**================================================================
成功页的loading
=================================================================*/
.success-loading {
  width: 100%;
  height: 100%;
  /**================================================================
   ⬆原始状态；⬇动画状态；infinite
  =================================================================*/
  /*    .scaleUp { @include animation(loading-scaleUp .4s .6s cubic-bezier(.23, .55, .81, .45) 1 forwards); }*/
  /**============================
  android 版
  ==============================*/ }
  .success-loading svg {
    width: 1.5rem;
    height: 1.5rem; 
    }
  .success-loading .path-rotate {
    stroke-dashoffset: -340;
    stroke-dasharray: 0, 340, 0, 340; }
  .success-loading .path-correct {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 140;
    -webkit-transition: all 0.2s ease-in;
    -moz-transition: all 0.2s ease-in;
    -ms-transition: all 0.2s ease-in;
    transition: all 0.2s ease-in; }
  .success-loading .circle-mask {
    -webkit-transform-origin: 50% 50%;
    -moz-transform-origin: 50% 50%;
    -ms-transform-origin: 50% 50%;
    transform-origin: 50% 50%; }
  .success-loading .circle-mask.zoom {
    -webkit-transform-origin: 25% 25%;
    -moz-transform-origin: 25% 25%;
    -ms-transform-origin: 25% 25%;
    transform-origin: 25% 25%; }
  .success-loading .circle-maskUp {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    margin: auto;
    -webkit-transform-origin: center center;
    -moz-transform-origin: center center;
    -ms-transform-origin: center center;
    transform-origin: center center;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0); }
  .success-loading .rotate {
    -webkit-animation: loading-rotate 1.5s cubic-bezier(0.77, 0.54, 0.55, 0.78) 1 forwards;
    -moz-animation: loading-rotate 1.5s cubic-bezier(0.77, 0.54, 0.55, 0.78) 1 forwards;
    -ms-animation: loading-rotate 1.5s cubic-bezier(0.77, 0.54, 0.55, 0.78) 1 forwards;
    animation: loading-rotate 1.5s cubic-bezier(0.77, 0.54, 0.55, 0.78) 1 forwards; }
  .success-loading .full {
    -webkit-animation: loading-full 0.7s ease-out 1 forwards;
    -moz-animation: loading-full 0.7s ease-out 1 forwards;
    -ms-animation: loading-full 0.7s ease-out 1 forwards;
    animation: loading-full 0.7s ease-out 1 forwards; }
  .success-loading .scale {
    -webkit-animation: loading-scale 0.2s cubic-bezier(0.23, 0.55, 0.81, 0.45) 1 forwards;
    -moz-animation: loading-scale 0.2s cubic-bezier(0.23, 0.55, 0.81, 0.45) 1 forwards;
    -ms-animation: loading-scale 0.2s cubic-bezier(0.23, 0.55, 0.81, 0.45) 1 forwards;
    animation: loading-scale 0.2s cubic-bezier(0.23, 0.55, 0.81, 0.45) 1 forwards; }
  .success-loading.complete .path-correct {
    stroke-dasharray: 140, 140; }
  .success-loading.single {
    width: 60px;
    height: 60px; }
  .success-loading.android {
    background-image: url("../../assets/images/cashier/the1/loading-series.png");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: 0 0; }
  .success-loading.android-btn {
    background-image: url("../../assets/images/cashier/the1/loading-series.png");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: 0 0; }

/**
 * css3lib
 * thanks: 
 * //bourbon.io/
 * https://github.com/thomas-mcdonald/bootstrap-sass/blob/master/vendor/assets/stylesheets/bootstrap/_mixins.scss
 * https://github.com/marvin1023/sassCore/blob/master/core/_css3.scss
 */
/**================================================================
页面切换动画
=================================================================*/
.slideRight {
  -webkit-transform: translateX(100%) !important;
  -moz-transform: translateX(100%) !important;
  -ms-transform: translateX(100%) !important;
  transform: translateX(100%) !important; }

.slideLeft {
  -webkit-transform: translateX(-100%) !important;
  -moz-transform: translateX(-100%) !important;
  -ms-transform: translateX(-100%) !important;
  transform: translateX(-100%) !important; }

/**============================
loading Rotate
==============================*/
@-webkit-keyframes rotate {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg); } }
@-moz-keyframes rotate {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg); } }
@-ms-keyframes rotate {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg); } }
@keyframes rotate {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    transform: rotate(360deg); } }
/**============================
fade
==============================*/
@-webkit-keyframes fadeOut {
  0% {
    opacity: 1; }
  100% {
    opacity: 0; } }
@-moz-keyframes fadeOut {
  0% {
    opacity: 1; }
  100% {
    opacity: 0; } }
@-ms-keyframes fadeOut {
  0% {
    opacity: 1; }
  100% {
    opacity: 0; } }
@keyframes fadeOut {
  0% {
    opacity: 1; }
  100% {
    opacity: 0; } }
@-webkit-keyframes fadeIn {
  0% {
    opacity: 0; }
  100% {
    opacity: 1; } }
@-moz-keyframes fadeIn {
  0% {
    opacity: 0; }
  100% {
    opacity: 1; } }
@-ms-keyframes fadeIn {
  0% {
    opacity: 0; }
  100% {
    opacity: 1; } }
@keyframes fadeIn {
  0% {
    opacity: 0; }
  100% {
    opacity: 1; } }
/**============================
slide
==============================*/
@-webkit-keyframes slideRight {
  0% {
    -webkit-transform: translateX(100%);
    -moz-transform: translateX(100%);
    -ms-transform: translateX(100%);
    transform: translateX(100%); }
  100% {
    -webkit-transform: translateX(0);
    -moz-transform: translateX(0);
    -ms-transform: translateX(0);
    transform: translateX(0); } }
@-moz-keyframes slideRight {
  0% {
    -webkit-transform: translateX(100%);
    -moz-transform: translateX(100%);
    -ms-transform: translateX(100%);
    transform: translateX(100%); }
  100% {
    -webkit-transform: translateX(0);
    -moz-transform: translateX(0);
    -ms-transform: translateX(0);
    transform: translateX(0); } }
@-ms-keyframes slideRight {
  0% {
    -webkit-transform: translateX(100%);
    -moz-transform: translateX(100%);
    -ms-transform: translateX(100%);
    transform: translateX(100%); }
  100% {
    -webkit-transform: translateX(0);
    -moz-transform: translateX(0);
    -ms-transform: translateX(0);
    transform: translateX(0); } }
@keyframes slideRight {
  0% {
    -webkit-transform: translateX(100%);
    -moz-transform: translateX(100%);
    -ms-transform: translateX(100%);
    transform: translateX(100%); }
  100% {
    -webkit-transform: translateX(0);
    -moz-transform: translateX(0);
    -ms-transform: translateX(0);
    transform: translateX(0); } }
@-webkit-keyframes slideUp {
  0% {
    -webkit-transform: translateY(100%);
    -moz-transform: translateY(100%);
    -ms-transform: translateY(100%);
    transform: translateY(100%); }
  100% {
    -webkit-transform: translateY(0);
    -moz-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0); } }
@-moz-keyframes slideUp {
  0% {
    -webkit-transform: translateY(100%);
    -moz-transform: translateY(100%);
    -ms-transform: translateY(100%);
    transform: translateY(100%); }
  100% {
    -webkit-transform: translateY(0);
    -moz-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0); } }
@-ms-keyframes slideUp {
  0% {
    -webkit-transform: translateY(100%);
    -moz-transform: translateY(100%);
    -ms-transform: translateY(100%);
    transform: translateY(100%); }
  100% {
    -webkit-transform: translateY(0);
    -moz-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0); } }
@keyframes slideUp {
  0% {
    -webkit-transform: translateY(100%);
    -moz-transform: translateY(100%);
    -ms-transform: translateY(100%);
    transform: translateY(100%); }
  100% {
    -webkit-transform: translateY(0);
    -moz-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0); } }
/**============================
信息滚动提示
==============================*/
@-webkit-keyframes tipsScroll {
  0% {
    -webkit-transform: translate(100%, -50%);
    -moz-transform: translate(100%, -50%);
    -ms-transform: translate(100%, -50%);
    transform: translate(100%, -50%); }
  100% {
    -webkit-transform: translate(-100%, -50%);
    -moz-transform: translate(-100%, -50%);
    -ms-transform: translate(-100%, -50%);
    transform: translate(-100%, -50%); } }
@-moz-keyframes tipsScroll {
  0% {
    -webkit-transform: translate(100%, -50%);
    -moz-transform: translate(100%, -50%);
    -ms-transform: translate(100%, -50%);
    transform: translate(100%, -50%); }
  100% {
    -webkit-transform: translate(-100%, -50%);
    -moz-transform: translate(-100%, -50%);
    -ms-transform: translate(-100%, -50%);
    transform: translate(-100%, -50%); } }
@-ms-keyframes tipsScroll {
  0% {
    -webkit-transform: translate(100%, -50%);
    -moz-transform: translate(100%, -50%);
    -ms-transform: translate(100%, -50%);
    transform: translate(100%, -50%); }
  100% {
    -webkit-transform: translate(-100%, -50%);
    -moz-transform: translate(-100%, -50%);
    -ms-transform: translate(-100%, -50%);
    transform: translate(-100%, -50%); } }
@keyframes tipsScroll {
  0% {
    -webkit-transform: translate(100%, -50%);
    -moz-transform: translate(100%, -50%);
    -ms-transform: translate(100%, -50%);
    transform: translate(100%, -50%); }
  100% {
    -webkit-transform: translate(-100%, -50%);
    -moz-transform: translate(-100%, -50%);
    -ms-transform: translate(-100%, -50%);
    transform: translate(-100%, -50%); } }
/**============================
zoom
==============================*/
@-webkit-keyframes zoomIn {
  0% {
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -moz-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3); }
  100% {
    opacity: 1; } }
@-moz-keyframes zoomIn {
  0% {
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -moz-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3); }
  100% {
    opacity: 1; } }
@-ms-keyframes zoomIn {
  0% {
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -moz-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3); }
  100% {
    opacity: 1; } }
@keyframes zoomIn {
  0% {
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -moz-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
    transform: scale3d(0.3, 0.3, 0.3); }
  100% {
    opacity: 1; } }
/**============================
 success-loading
==============================*/
@-webkit-keyframes loading-rotate {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  50% {
    stroke-dashoffset: -51;
    stroke-dasharray: 119, 600; }
  100% {
    stroke-dashoffset: -340;
    stroke-dasharray: 0, 340, 0, 340; } }
@-moz-keyframes loading-rotate {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  50% {
    stroke-dashoffset: -51;
    stroke-dasharray: 119, 600; }
  100% {
    stroke-dashoffset: -340;
    stroke-dasharray: 0, 340, 0, 340; } }
@-ms-keyframes loading-rotate {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  50% {
    stroke-dashoffset: -51;
    stroke-dasharray: 119, 600; }
  100% {
    stroke-dashoffset: -340;
    stroke-dasharray: 0, 340, 0, 340; } }
@keyframes loading-rotate {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  50% {
    stroke-dashoffset: -51;
    stroke-dasharray: 119, 600; }
  100% {
    stroke-dashoffset: -340;
    stroke-dasharray: 0, 340, 0, 340; } }
@-webkit-keyframes loading-full {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  100% {
    stroke-dashoffset: -85;
    stroke-dasharray: 170, 600; } }
@-moz-keyframes loading-full {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  100% {
    stroke-dashoffset: -85;
    stroke-dasharray: 170, 600; } }
@-ms-keyframes loading-full {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  100% {
    stroke-dashoffset: -85;
    stroke-dasharray: 170, 600; } }
@keyframes loading-full {
  0% {
    stroke-dashoffset: 0;
    stroke-dasharray: 0, 600; }
  100% {
    stroke-dashoffset: -85;
    stroke-dasharray: 170, 600; } }
@-webkit-keyframes loading-scale {
  100% {
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0); } }
@-moz-keyframes loading-scale {
  100% {
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0); } }
@-ms-keyframes loading-scale {
  100% {
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0); } }
@keyframes loading-scale {
  100% {
    -webkit-transform: scale(0);
    -moz-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0); } }
/*@include keyframes(loading-scaleUp, webkit moz ms spec) {
    0% { transform: scale(0); }
    100% { transform: scale(4); }
    }*/
    .cashier-animate-status-container {
      display: flex;
      flex-direction: column;
      align-items: center;
       .red {
         stop-color:#FFAA8A
      }
      .yellow {
         stop-color:#FF557F
      }
    }
.cashier-animate-status-txt {
  padding-top: .52rem;
  font-size: .36rem;
  color: #141E50;
  font-family: The1Official_Bold;
 
}
</style>


