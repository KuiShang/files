<template>
  <div class="item">
    <div
      v-if="computedBankName"
      class="bank"
      @click="$emit('setBankAccountVisible')">
      <span class="card-container">
        <img
          :src="currentBank.h5LogoUrl"
          class="img"
        >
        <p class="value">
          <span>{{ computedBankName }}</span>
          <img
            v-if="currentBank.payOrgModelList"
            :src="currentBank.payOrgModelList[0].h5LogoUrl"
            class="ofln-img"
          >
        </p>
      </span>
      <common-icon
        class="custom-ico"
        name="more"
        size=".4rem"
        @click="selectPay"
      />
    </div>
    <!-- <div
      v-else-if="showAddBtn"
      class="no-bank-container"
      @click="$emit('addCard')"
    >
      <div>
        <p class="no-applica">{{ $t('Setuppaymentmethod') }}</p>
        <p class="please-top">{{ $t('Pleaseaddabankaccountorbankcard') }}</p>
      </div>
      <common-icon
        class="custom-ico"
        name="more"
        size=".4rem"
      />
    </div> -->
    <div
      v-else
      class="no-bank-container"
      @click="$emit('setBankAccountVisible')"
    >
      <div>
        <p class="no-applica">{{ $t('No Available Payment Method') }}</p>
        <p class="please-top">{{ $t('Click here to view or add new account/card') }}</p>
      </div>
      <common-icon
        class="custom-ico"
        name="more"
        size=".4rem"
      />
    </div>
    <div class="name hide">
      <span class="key">Account name</span>
      <span class="value">lucy **</span>
    </div>
  </div>
</template>
<script>
import { enumPayMethodCodeFirst, enumPayMethodCodeSecond, CASHIER_PAYMENT_METHODS } from '@/utils/const'
import * as CASHIER_BURRY from '@/pages/burry/cashier'

export default {
  name: 'MethodsItem',
  props: {
    currentBank: {
      type: Object,
      default: () => {}
    },
    availableCodeFirst: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
    }
  },
  computed: {
    computedBankName() {
      if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.ODD && this.currentBank.status !== 0) {
        const last4Num = this.currentBank.accountNo.slice(-4)
        // return `${this.currentBank.payMethodCodeSecond} (${last4Num})`
        return `${this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])} (${last4Num})`
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.BALA && this.currentBank.status !== 0) {
        // return this.currentBank.payMethodCodeFirst
        // return 'Balance'
        return this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.OFLN && this.currentBank.status !== 0) {
        return this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.DELI && this.currentBank.status !== 0) {
        return this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.CCP && this.currentBank.status !== 0) {
        if (this.currentBank.payMethodCodeSecond === enumPayMethodCodeSecond.SPECIAL) {
          // return this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])
          return ''
        }
        const last4Num = this.currentBank.accountNo.slice(-4)
        return `${this.$t(CASHIER_PAYMENT_METHODS[this.currentBank.displayName])}  (${last4Num})`
      }
      console.log('没有找到可用的支付方式，当前支付方式为', this.currentBank.payMethodCodeFirst)
      return ''
    },
    showAddBtn() {
      const availableArr = this.availableCodeFirst ? this.availableCodeFirst : []
      return availableArr.includes(enumPayMethodCodeFirst.ODD) || availableArr.includes(enumPayMethodCodeFirst.CCP)
    }
  },
  methods: {
    // lnwang 收银台弹窗选择支付方式
    selectPay() {
      CASHIER_BURRY.PAY_METHOD();
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.item {
  border-top: .5px solid $color-gray-e;
}
.bank {
  box-sizing: border-box;
  height: 1.4rem;
  line-height: 1.4rem;
  border-bottom: .5px solid $color-gray-e;
  display: flex;
  justify-content: space-between;
  .custom-ico {
    font-weight: bold;
    color: $color-gray-f;
  }
  .card-container {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .img{
    width: .6rem;
    height: .6rem;
  }
  .ofln-img {
    height: .32rem;
  }
  .value {
    font-size: .36rem;
    color: $color-gray-g;
    text-align: left;
    padding-left: .2rem;
    display: flex;
    flex-direction: column;
    line-height: initial;
  }
}

.no-bank-container {
  .custom-ico {
    font-weight: bold;
    color: $color-gray-f;
  }
  height: 1.4rem;
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid $color-gray-e;
  align-items: center;
  .no-applica {
    font-size: .36rem;
    color: $color-gray-g;
  }
  .please-top {
    padding-top: .1rem;
    font-size: .28rem;
    color: $color-gray-f;
  }
}
</style>
