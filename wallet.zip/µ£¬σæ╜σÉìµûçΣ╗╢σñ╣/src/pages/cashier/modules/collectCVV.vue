<template>
  <div class="collect-cvv-wraper">
    <img
      class="card-img"
      src="./credit card@3x.png">
    <p class="txt-cvv">{{ $t('CVV / CVC') }}</p>
    <p class="general-txt">{{ $t('is a') }}&nbsp;<span class="txt-bold">{{ $t('3 digit number') }}&nbsp;</span>{{ $t('at the back of your card next to signature label') }}</p>
    <!-- 密码输入框 -->
    <van-password-input
      :value="value"
      :length="3"
      gutter="50"
      @focus="showKeyboard = true"
    />
    <!-- 数字键盘 -->
    <van-number-keyboard
      :show="showKeyboard"
      :maxlength="3"
      :delete-button-text="$t('DEL')"
      @blur="show = false"
      @input="onInput"
      @delete="onDelete"
    >
      <template v-slot:delete>
        <img
          src="./Delete Icon@3x.png"
          class="card-del">
      </template>
    </van-number-keyboard>
  </div>
</template>
<script>
import Vue from 'vue'
import { PasswordInput, NumberKeyboard } from 'vant'
import 'vant/lib/password-input/style';
import 'vant/lib/number-keyboard/style';

Vue.use(NumberKeyboard).use(PasswordInput)

export default {
  name: 'CollectCVV',
  data() {
    return {
      value: '',
      showKeyboard: true
    }
  },
  created() {
    this.setTitle()
  },
  methods: {
    onInput(key) {
      this.value = (this.value + key).slice(0, 3);
      if (this.value.length === 3) {
        this.$SDK.closeNativeWebview({ value: this.value })
      }
    },
    onDelete() {
      this.value = this.value.slice(0, this.value.length - 1);
    },
    setTitle() {
      this.$SDK.setTitle({
        title: this.$t('Enter CVV/CVC'),
        mHeaderTitle: {
          showEnd: 0,
          showBack: 1
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.collect-cvv-wraper {
  padding-top: 1rem;
  text-align: center;
  .card-img {
    width: 2.4rem;
  }
  .txt-cvv {
    font-family: The1Official_Bold;
    font-size: .36rem;
    color: $color-gray-g;
  }
  .general-txt {
    padding-left: 1rem;
    padding-right: 1rem;
    padding-bottom: .3rem;
    padding-top: .2rem;
    font-size: .28rem;
    line-height: .4rem;
    color: $color-gray-h;
    .txt-bold {
      font-family: The1Official_Bold;
    }
  }
  .card-del {
    width: .56rem;
    vertical-align: middle;
  }
}
</style>

