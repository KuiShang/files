<template>
  <div class="result">
    <div
      class="result-fail">
      <div class="head">
        <img
          class="img"
          src="@/assets/images/blance/the1/error@3x.png">
        <p class="txt-title"> {{ $t('Paymentfailed') }}</p>
        <p class="txt-des">{{ $t('PleaseTryitlatter') }}</p>
      </div>
      <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">{{ $t('OK ') }}</common-button>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  name: 'CardPayFail',
  created() {
    this.$SDK.setTitle({
      title: this.$t('payment'),
      mHeaderTitle: {
        showEnd: 1,
        showBack: 0
      }
    })
  },
  methods: {
    handleClick() {
      this.$SDK.closeWebView()
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: $color-white;
    box-sizing: border-box;
    text-align: center;
    padding-top: .8rem;
    padding-bottom: .6rem;
    .img {
      width: 1.2rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
      margin-top: .4rem;
    }
  }
  .txt-des {
  padding-top: .3rem;
  font-size: .32rem;
  color: $color-gray-h;
  text-align: center;
  }
  .btn-wraper {
    margin-top: .5rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
