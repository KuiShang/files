<template>
  <div>
    <common-popup
      v-model="show"
      :close-on-click-modal="false"
      position="bottom"
      style="width:100%"
    >
      <!-- 没有券 -->
      <div
        v-if="!useCouponBol"
        class="simple-cashier">
        <div class="title">
          <span>{{ $t('PaymentDetail') }}</span>
          <common-icon
            class="custom-ico"
            name="close"
            size=".4rem"
            @click="close()"
          />
        </div>
        <div class="amount">
          <span class="des">{{ getbizCode(dataObj.payOrderModel.bizCode) }}</span>
          <p
            :class="{'little-txt-money': littleTxt}"
            class="money"
          >
            <span
              :class="{'little-txt-money': littleTxt}"
              class="txt-b"
            >฿ </span>
            <span>{{ actualTxt | tofloat | thousandBitSeparator }}</span>
          </p>
        </div>
        <div
          v-if="(dataObj.payOrderModel.orderSubject || dataObj.payOrderModel.merchantShortName)"
          class="hei9">
          <div
            v-if="dataObj.payOrderModel.merchantShortName"
            class="item gateway">
            <div class="payment-method">{{ $t('Receiver') }}</div>
            <div class="pay-value">{{ dataObj.payOrderModel.merchantShortName }}</div>
          </div>
          <div
            v-if="dataObj.payOrderModel.orderSubject"
            class="item gateway">
            <div class="payment-method">{{ $t('Order Subject') }}</div>
            <div class="pay-value">{{ dataObj.payOrderModel.orderSubject }}</div>
          </div>
        </div>
        <div
          v-else
          class="item">
          <div class="payment-method">{{ $t('Payment Method') }}</div>
        </div>
        <methodsItem
          :current-bank = "currentBank"
          :available-code-first ="dataObj.availablePayMethodCodeFirstList"
          :class="{opcatify: !kycCheckFlag}"
          @setBankAccountVisible="methodsItemClick" />
        <p
          v-if="!kycCheckFlag"
          class="kycCheckFlagWrong"
        >{{ getkycCheckStr() }}</p>
        <div class="btn-wrapper">
          <common-button
            :disabled="!btnok"
            type="danger"
            @click.native="handleClick">{{ $t('CONFIRM') }}</common-button>
        </div>
        <div
          v-show="showLoading"
          class="cashier-success-container-bg"
          style="z-index:1001;"
        >
          <animateSuccess
            ref="animateSuccess"
            :cutdown-time = "animateCutdownTime"
            :status-txt="cashierAnimateStatusTxt" />
        </div>
        <div
          v-if="networkError"
          class="result-network-error">
          <img
            class="width12"
            src="@/assets/images/cashier/netError.png" >
          <p class="txt">{{ $t('Network error') }}</p>
          <p class="txt">{{ $t('Please check the results and try again later.') }}</p>
        </div>
        <div
          v-if="paymentFailed"
          class="result-network-error">
          <img
            class="img"
            src="@/assets/images/blance/the1/error@3x.png" >
          <p class="txt">{{ $t('Paymentfailed') }}</p>
        </div>
      </div>
      <!-- 有券 -->
      <div
        v-if="useCouponBol"
        class="simple-cashier">
        <div class="titleY">
          <span>{{ $t('PaymentDetail') }}</span>
          <common-icon
            class="custom-ico"
            name="close"
            size=".4rem"
            @click="close()"
          />
        </div>
        <div class="amountY">
          <div
            v-if="useCouponBol">
            <span
              v-if="me_checked"
              class="desY">฿{{ amount | tofloat | thousandBitSeparator }}</span>
            <span
              v-if="!me_checked"
              class="desNO">{{ $t('tag30_txt_payamount') }}</span>
          </div>
          <!-- <span class="des">{{ getbizCode(dataObj.payOrderModel.bizCode) }}</span> -->
          <p
            :class="{'little-txt-money': littleTxt}"
            class="moneyY"
          >
            <span
              :class="{'little-txt-money': littleTxt}"
              class="txt-b"
            >฿ </span>
            <span>{{ actualTxt | tofloat | thousandBitSeparator }}</span>
          </p>
          <p
            v-if="!me_checked"
            class="no-user-tip">{{ $t('Use coupon to get discount') }}</p>
        </div>
        <div
          v-if="useCouponBol"
          class="has-coupon">
          <div
            v-if="me_checked"
            class="use-coupon">
            <div class="use-coupon-box">
              <div class="coupon-top">
                <div class="save-amount">{{ $t('Save') }}฿{{ discountAmount | tofloat | thousandBitSeparator }}
                  <span v-if="coupons.hitPrizeInfoList[0].prizeRuleType === '6'">
                    ({{ coupons.hitPrizeInfoList[0].prizeRuleValue }})
                  </span>
                </div>
                <div class="save-info">
                  <div class="left-img">
                    <img
                      src="../../assets/images/cashier/E-coupon@2x.png"
                      alt="">
                  </div>
                  <div
                    class="right-txt"
                  >{{ name }}</div>
                </div>
              </div>
              <div class="valid-and-use">
                <div class="valid-left">{{ $t('Valid until') }}
                  <span
                    v-text="yearMonthDay(expireTime)"/>
                </div>
                <span
                  :class="{'weui-switch-on' : me_checked}"
                  class="weui-switch"
                  @click="toggle"/>
                <span class="txt">{{ $t('Use now') }}</span>
              </div>
            </div>
          </div>
          <div
            v-if="!me_checked"
            class="no-use-coupon">
            <div class="use-coupon-box">
              <div>
                <div class="save-info">
                  <div class="left-img">
                    <img
                      src="../../assets/images/cashier/E-coupon@2x.png"
                      alt="">
                  </div>
                  <div class="right-txt">{{ name }}</div>
                </div>
              </div>
              <div
                class="valid-and-use"
                style="float:left;">
                <div class="valid-left2">{{ $t('Valid until') }}
                  <span
                    v-text="yearMonthDay(expireTime)"/>
                </div>
                <span
                  :class="{'weui-switch-on' : me_checked}"
                  class="weui-switch"
                  @click="toggle"/>
                <span class="txt">{{ $t('Use now') }}</span>
              </div>
            </div>
          </div>
        </div>
        <div
          v-if="(dataObj.payOrderModel.orderSubject || dataObj.payOrderModel.merchantShortName)"
          class="hei9">
          <!-- <div
            v-if="dataObj.payOrderModel.merchantShortName"
            class="item gateway">
            <div class="payment-method">{{ $t('Receiver') }}</div>
            <div class="pay-value">{{ dataObj.payOrderModel.merchantShortName }}</div>
          </div> -->
          <!-- <div
            v-if="dataObj.payOrderModel.orderSubject"
            class="item gateway">
            <div class="payment-method">{{ $t('Order Subject') }}</div>
            <div class="pay-value">{{ dataObj.payOrderModel.orderSubject }}</div>
          </div> -->
        </div>
        <div
          v-else
          class="item">
          <div class="payment-method">{{ $t('Payment Method') }}</div>
        </div>
        <methodsItem
          :current-bank = "currentBank"
          :available-code-first ="dataObj.availablePayMethodCodeFirstList"
          :class="{opcatify: !kycCheckFlag}"
          @setBankAccountVisible="methodsItemClick" />
        <p
          v-if="!kycCheckFlag"
          class="kycCheckFlagWrong"
        >{{ getkycCheckStr() }}</p>
        <div class="btn-wrapper">
          <common-button
            v-if="kycCheckFlag"
            :disabled="!btnok"
            type="danger"
            @click.native="handleClick">{{ $t('CONFIRM') }}</common-button>
          <common-button
            v-else
            :disabled="!hasKycActionData"
            type="danger"
            @click.native="goVerify">{{ $t('Verify now') }}</common-button>
        </div>
        <div
          v-show="showLoading"
          class="cashier-success-container-bg"
          style="z-index:1001;"
        >
          <animateSuccess
            ref="animateSuccess"
            :cutdown-time = "animateCutdownTime"
            :status-txt="cashierAnimateStatusTxt" />
        </div>
        <div
          v-if="networkError"
          class="result-network-error">
          <img
            class="width12"
            src="@/assets/images/cashier/netError.png" >
          <p class="txt">{{ $t('Network error') }}</p>
          <p class="txt">{{ $t('Please check the results and try again later.') }}</p>
        </div>

        <div
          v-if="paymentFailed"
          class="result-network-error">
          <img
            class="img"
            src="@/assets/images/blance/the1/error@3x.png" >
          <p class="txt">{{ $t('Paymentfailed') }}</p>
        </div>
        <!-- 重新选择支付方式 -->
        <div
          v-if="changeSelcted"
          class="changeSelctType">
          <img
            class="img"
            src="@/assets/images/cashier/light@2x.png">
          <p
            v-if="Insufficient"
            class="txt">{{ $t('Insufficient Funds') }}</p>
          <p
            v-if="Unavailable"
            class="txt">{{ $t('Payment Unavailable') }}</p>
          <p
            v-if="PaymentFailed"
            class="txt">{{ $t('Payment Failed') }}</p>
          <p class="txt2">{{ $t('Please try again') }}</p>
          <common-button
            v-if="PaymentFailed"
            type="danger"
            style="margin-top:1.24rem;margin-bottom:.2rem;"
            @click.native="changeSelectMethod">{{ $t('Try Again') }}</common-button>
          <common-button
            v-else
            type="danger"
            style="margin-top:1.24rem;margin-bottom:.2rem;"
            @click.native="changeSelectMethod">{{ $t('CHANGE METHOD') }}</common-button>
          <common-button
            @click.native="goLeave">{{ $t('Cancel2') }}</common-button>
        </div>
      </div>
    </common-popup>
    <cashierSelectBankAccount
      :visible.sync="selectBankAccountVisible"
      :data-obj = "dataObj"
      :current-index="currentIndex"
      @changeBank = "changeBank"
      @addCard = "addCard"
      @gocdcp = "gocdcp"
    />
    <wraperCdcp
      v-if="wraperCdcp"
      :visible.sync="wraperCdcp"
      :data-obj = "dataObj"
      :transaction-no = "transactionNo"
      :current-busi-type = "currentBusiType"
      @cdcpOk = "cdcpOk"
    />
    <!-- 收银台离开挽留弹窗 -->
    <toast
      v-if="saveLeave"
      :title-position= "0.02"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goLeave"
      @cancle="cancleLeave"
    >
      <p slot="content">{{ $t('Areyousuretoleavethispage') }}</p>
      <p
        slot="cancle"
        @click="no">{{ $t('Cancel') }}
      </p>
      <p
        slot="confirm"
        @click="yes">{{ $t('Yes') }}
      </p>
    </toast>
    <!-- 收银台支付失败重试弹窗 -->
    <toast
      v-if="showRetrydialog"
      :title-position= "0.02"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="retryToPay"
      @cancle="goLeave"
    >
      <p slot="title">{{ this.$t('No Internet Connection') }}</p>
      <p slot="content">{{ $t('Dolfin can’t find your internet connection. Make sure you’re connected and try again.') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('TRYAGAIN') }}</p>
    </toast>
  </div>
</template>
<script>
import cashierSelectBankAccount from '@/pages/cashier/cashierSelectBankAccount'
import { getCashierData, scanedResultQuery } from '@/api'
import { enumPayMethodCodeFirst, CASHIER_SENSE, enumPayMethodCodeSecond, CASHIER_TRANSATION_STATUS } from '@/utils/const'
import animateSuccess from '@/pages/cashier/animateSuccess'
import handlInitData from '@/mixins/handlInitData'
import switchPay from '@/pages/cashier/mixins/switchPay'
import methodsItem from '@/pages/cashier/modules/methodsItem'
import wraperCdcp from '@/pages/cashier/paymethods/wraperCdcp'
import * as CASHIER_BURRY from '@/pages/burry/cashier'
import toast from '@/pages/balance/common/dialog'

// 检查kplus 支付结果 用到的两个时间对象
let CheckDeepLinktimes = 0
let CheckDeepLinktimer = ''

export default {
  name: 'SimpleCashier',
  components: { cashierSelectBankAccount, animateSuccess, methodsItem, wraperCdcp, toast },
  filters: {
    sense(code) {
      const str = CASHIER_SENSE[code] || 'transfer'
      return str
    }
  },
  mixins: [handlInitData, switchPay],
  props: {
    cashierVisible: {
      type: Boolean,
      default: false
    },
    transactionNo: {
      type: String,
      default: ''
    },
    transOrderNo: {
      type: String,
      default: ''
    },
    paymentToken: {
      type: String,
      default: ''
    },
    paymentMethod: {
      type: String,
      default: ''
    },
    currentBusiType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // busiType: '',
      enumPayMethodCodeFirst,
      selectBankAccountVisible: false,
      riksId: '',
      currentIndex: -1,
      currentBank: {},
      dataObj: {
        payOrderModel: {}
      },
      showLoading: false,
      networkError: false,
      cashierAnimateStatusTxt: this.$t('Processing'),
      paymentFailed: false,
      wraperCdcp: false,
      saveLeave: false,
      kycCheckFlag: 1,
      hasKycActionData: true,
      animateCutdownTime: 0,
      inCludeHimSelf: true, // 优惠券开关
      me_checked: true, // 是否存在优惠券
      changeSelcted: false, // 是否显示重新选择支付方式
      Insufficient: false, // 不同情况显示的提示语
      Unavailable: false, // 不同情况显示的提示语
      PaymentFailed: false, // 不同情况显示的提示语
      useCouponBol: false, // 是否显示用券
      oldAmountBol: false, // 是否显示原金额
      actualTxt: '', // 实际支付金额
      coupons: {}, // 优惠券信息
      discountAmount: '',
      year: '',
      month: '',
      month2: '',
      day: '',
      commonReqData: {}
    }
  },
  computed: {
    show: {
      get() {
        return this.cashierVisible
      },
      set(val) {
        this.$emit('update:cashierVisible', val)
      }
    },
    amount() {
      return this.dataObj.payOrderModel.amount
    },
    btnok() {
      if (this.dataObj.payMethodModelList && this.dataObj.payMethodModelList.length > 0 && this.currentBank.status !== 0 && this.currentBank.payMethodCodeSecond !== 'SPECIAL' && !this.showLoading) {
        return true
      }
      return false
    },
    littleTxt() {
      return String(this.dataObj.payOrderModel.amount).length > 13
    },
    // 文案信息
    name() {
      return JSON.stringify(this.coupons) !== '{}' ? this.coupons.hitPrizeInfoList[0].name : ''
    },
    // 过期时间
    expireTime() {
      return JSON.stringify(this.coupons) !== '{}' ? this.coupons.hitPrizeInfoList[0].expireTime : ''
    }
  },
  watch: {
    transactionNo(flag) {
      console.log('flag', flag)
      if (flag) {
        this.initData()
      }
    },
    wraperCdcp(flag) {
      // 当从卡支付回退到本页面后
      if (!flag) {
        // 重新监听返回键
        this.listenBankPress()
        // 进入事件
        if (this.selectBankAccountVisible) {
          CASHIER_BURRY.PAY_SUCCESS_COUNTER_ENTRY()
        } else {
          CASHIER_BURRY.PAY_DETAIL_COUNTER_ENTRY()
        }
      }
    },
    showLoading(flag) {
      if (flag) {
        CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
        CASHIER_BURRY.SUCCESS_COUNTER_ENTER()
      }
    }
  },
  created() {
    // this.busiType = this.$route.query.busiType
    // this.cashierVisible = true
    // 此處不能放開 需要等創建單號后 才可以調用
    this.initData()
    this.listenBankPress()
    // lnwang
    this.$SDK.onBackPress(() => {
      if (this.showLoading === 'true') {
        // 收银台成功支付
        CASHIER_BURRY.BACK(2);
      } else if (this.networkError === 'true') {
        // lnwang  收银台请求错误
        CASHIER_BURRY.BACK(4);
      } else if (this.paymentFailed === 'true') {
        // lnwang  支付失败
        CASHIER_BURRY.BACK(5);
      } else {
        CASHIER_BURRY.BACK(1);
      }
    })
  },
  destroyed() {
    console.log('cashier destory')
  },
  methods: {
    async initData() {
      const queryObj = { transactionNo: this.transactionNo }
      if (this.paymentToken) {
        queryObj.paymentToken = this.paymentToken
      }
      if (this.paymentMethod) {
        queryObj.paymentMethod = this.paymentMethod
      }
      const deviceInfoObj = await this.$SDK.getCommonInfo()
      this.$DeviceInfo = deviceInfoObj
      const res = await getCashierData({
        ...queryObj,
        deviceInfo: escape(JSON.stringify(this.$DeviceInfo)),
        clientInfo: escape(JSON.stringify(this.$ClientInfo))
      })
      this.handlInitData(res, async () => {
        // FIXME: 临时需求：前端屏蔽kbank支付方式  张旭 张雪岩 20181018
        // this.dataObj.payMethodModelList = this.dataObj.payMethodModelList.filter(item => item.payMethodCodeSecond !== enumPayMethodCodeSecond.KBANK)
        // 对支付方式列表按照优先级进行排序
        // this.dataObj.payMethodModelList.sort((a, b) => a.priority - b.priority)
        // this.dataObj.payMethodModelList.sort((a, b) => b.status - a.status)
        // await this.hasDeplApp()
        this.computedCurrentIndex()
        this.computedCurrentObj()
        // 是否显示优惠券
        if (JSON.stringify(this.coupons) !== '{}') {
          if (Number(this.coupons.actualPayAmount) >= Number(this.coupons.hitPrizeInfoList[0].limitAmount) || Number(this.coupons.actualPayAmount) === 0.00) {
            // 实际支付金额
            this.useCouponBol = true;
            this.oldAmountBol = true;
            this.actualTxt = this.coupons.actualPayAmount;
          } else {
            this.actualTxt = this.dataObj.payOrderModel.amount;
            this.useCouponBol = false;
            this.oldAmountBol = false;
          }
          this.discountAmount = this.coupons.hitPrizeInfoList[0].discountAmount
        } else {
          // 实际支付金额
          this.actualTxt = this.dataObj.payOrderModel.amount;
          this.useCouponBol = false;
          this.oldAmountBol = false;
          this.discountAmount = ''
        }
        console.log(this.actualTxt)
        this.kycCheckFlag = this.dataObj.kycCheckResultModel && this.dataObj.kycCheckResultModel.kycCheckFlag
        const hasKycActionData = this.dataObj.kycCheckResultModel && this.dataObj.kycCheckResultModel.kycPromptJsonMsg && this.dataObj.kycCheckResultModel.kycPromptJsonMsg.actionData
        if (hasKycActionData === 'null' || !hasKycActionData) {
          this.hasKycActionData = false
        }
      })
      CASHIER_BURRY.PAY_DETAIL_COUNTER_ENTRY()
    },
    getbizCode(bizCode) {
      return this.$t(CASHIER_SENSE[bizCode])
    },
    listenBankPress() {
      this.$SDK.onBackPress(() => {
        this.saveLeave = true
        if (this.showLoading) {
          CASHIER_BURRY.SUCCESS_COUNTER_BACK()
        } else {
          CASHIER_BURRY.PAY_DETAIL_COUNTER_BACK()
        }
      })
    },
    no() {
      // lnwang  收银台挽留弹窗中toast 选择取消
      CASHIER_BURRY.NO()
    },
    yes() {
      // lnwang  收银台挽留弹窗中toast 选择确认
      CASHIER_BURRY.YES()
    },
    close() {
      // lnwang  收银台弹窗 CLOSE
      CASHIER_BURRY.CLOSE(1);
      this.saveLeave = true
      if (this.showLoading) {
        // lnwang  收银台成功支付关闭弹窗
        CASHIER_BURRY.CLOSE(2)
        CASHIER_BURRY.SUCCESS_COUNTER_CLOSE()
      } else {
        CASHIER_BURRY.PAY_DETAIL_COUNTER_CLOSE()
      }
      if (this.networkError) {
        // lnwang  收银台请求错误
        CASHIER_BURRY.CLOSE(3)
      }
      if (this.paymentFailed === 'true') {
        // lnwang  支付失败
        CASHIER_BURRY.CLOSE(4);
      }
      if (this.changeSelcted === true) {
        CASHIER_BURRY.CLICK_CLOSE();
      }
    },
    async handleClick() {
      // lnwang  收银台弹窗选择完成
      CASHIER_BURRY.CONFIRM();
      CASHIER_BURRY.PAY_DETAIL_COUNTER_CONFIRM({
        type: this.currentBusiType,
        amount: this.dataObj.payOrderModel.amount,
        paymentMethod: this.currentBank.payMethodCodeFirst,
        paymentMethod2: this.currentBank.payMethodCodeSecond
      })
      console.log('之前的deviceinfo:', this.$DeviceInfo)
      // deviceinfo里面的指纹相关参数会变化 所以每次支付需要重新获取
      const deviceInfoObj = await this.$SDK.getCommonInfo()
      this.$DeviceInfo = deviceInfoObj
      console.log('之hou的deviceinfo:', this.$DeviceInfo)
      if (this.me_checked !== true || this.oldAmountBol !== true) {
        this.commonReqData = {
          transactionNo: this.transactionNo,
          paymentMethod: this.currentBank.payMethodCodeFirst,
          paymentMethod2: this.currentBank.payMethodCodeSecond,
          paymentMethod3: this.currentBank.payMethodCodeThird,
          paymentAmount: this.me_checked !== true || this.oldAmountBol !== true ? this.dataObj.payOrderModel.amount : this.coupons.actualPayAmount, // 是否选择优惠券
          cashierStyle: this.dataObj.cashierStyle.code,
          deviceInfo: escape(JSON.stringify(this.$DeviceInfo)),
          clientInfo: escape(JSON.stringify(this.$ClientInfo))
        }
      } else {
        this.commonReqData = {
          transactionNo: this.transactionNo,
          paymentMethod: this.currentBank.payMethodCodeFirst,
          paymentMethod2: this.currentBank.payMethodCodeSecond,
          paymentMethod3: this.currentBank.payMethodCodeThird,
          paymentAmount: this.me_checked !== true || this.oldAmountBol !== true ? this.dataObj.payOrderModel.amount : this.coupons.actualPayAmount, // 是否选择优惠券
          cashierStyle: this.dataObj.cashierStyle.code,
          deviceInfo: escape(JSON.stringify(this.$DeviceInfo)),
          clientInfo: escape(JSON.stringify(this.$ClientInfo)),
          prizeInfoModel: this.me_checked !== true || this.oldAmountBol !== true ? '' : this.coupons.hitPrizeInfoList[0] // 优惠券信息
        }
      }
      console.log('commonReqData', this.commonReqData)
      if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.OFLN) {
        this.cstpPay({ ...this.commonReqData })
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
        this.ccpPay({ ...this.commonReqData })
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.BALA) {
        this.balaPay({ ...this.commonReqData })
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.ODD) {
        this.oddPay({ ...this.commonReqData })
      } else if (this.currentBank.payMethodCodeFirst === enumPayMethodCodeFirst.DELI) {
        if (this.currentBank.payMethodCodeSecond === enumPayMethodCodeSecond.BBL) {
          this.deliKplusBBlPay({ ...this.commonReqData })
        } else if (this.currentBank.payMethodCodeSecond === enumPayMethodCodeSecond.KBANK) {
          this.deliKplusBBlPay({ ...this.commonReqData })
        }
      } else {
        console.error('不支持的一级支付方式:', this.currentBank.payMethodCodeFirst)
        this.$toast({
          message: `不支持的一级支付方式: ${this.currentBank.payMethodCodeFirst}`,
          position: 'middle',
          duration: 3000
        })
        // lnwang  支付报告错误
        CASHIER_BURRY.ERROR(1);
      }
    },
    // 便利店支付
    async cstpPay(commonReqData) {
      console.log('便利店支付')
      this.showLoading = true
      this.$refs.animateSuccess.initData()
      this.firstReqData = { ...commonReqData }
      this.switchPay(this.currentBank.payMethodCodeFirst, commonReqData, (payret) => {
        console.log('payret', payret)
        this.$SDK.goNativeQrRechange(payret.data.resultData.payGatewayOrderNo)
        // cenpay方式成功后跳转到原声的cenpay页面，关闭当前收银台页面，避免在二维码页面回退再次回到收银台
        CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
        this.$SDK.closeWebView()
        // setTimeout(() => {
        //   this.$SDK.closeWebView()
        // }, 250)
      }, 'simpleCashier')
    },
    // 卡支付
    async ccpPay(commonReqData) {
      // 新卡支付入口
      if (this.currentBank.payMethodCodeSecond === enumPayMethodCodeSecond.SPECIAL) {
        this.gocdcp()
        CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
        return
      }
      // 已经绑定的卡
      this.showLoading = true
      this.$refs.animateSuccess.initData()
      console.log('click')
      const reqData = {
        ...commonReqData,
        promotionInfo: {},
        additionalMessage: '',
        cardUuid: this.currentBank.bizId,
        creditCardInfo: {
          saveCardFlag: true
        }
      }
      this.firstReqData = reqData
      const res = await this.switchPay(this.currentBank.payMethodCodeFirst, reqData, '', 'simpleCashier')
      console.log('res:', res)
    },
    // 银行账户支付
    async oddPay(commonReqData) {
      this.showLoading = true
      this.$refs.animateSuccess.initData()
      const reqData = {
        ...commonReqData,
        promotionInfo: {},
        additionalMessage: '',
        cardId: this.currentBank.bizId
      }
      this.firstReqData = reqData
      const res = await this.switchPay(this.currentBank.payMethodCodeFirst, reqData, '', 'simpleCashier')
      console.log('res:', res)
    },
    // deeplink kplus bbl 支付
    async deliKplusBBlPay(commonReqData) {
      this.showLoading = true
      // console.log(this.$refs.animateSuccess.initData())
      this.$refs.animateSuccess.initData()
      console.log('click')
      const reqData = {
        ...commonReqData,
        promotionInfo: {}
      }
      this.firstReqData = reqData
      const res = await this.switchPay(this.currentBank.payMethodCodeFirst, reqData, async (payret) => {
        console.log('payret', payret)
        const additionalData = JSON.parse(payret.data.resultData.additionalData)
        const schema = additionalData.callBackAppUrl
        console.log('schema:', schema)
        const appRet = await this.$SDK.goOtherNativeAPP(schema)
        this.checkKplusRet(appRet)
      }, 'simpleCashier')
      console.log('res:', res)
    },
    checkKplusRet(appRet) {
      // 取消
      if (appRet.status === 0) {
        this.checkKplusRetFromServer((status) => {
          if (status === CASHIER_TRANSATION_STATUS.SUCC) {
            CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
            this.$emit('paynow', this.dataObj)
          } else if (status === CASHIER_TRANSATION_STATUS.PEND) {
            this.showLoading = false
          } else if (status === CASHIER_TRANSATION_STATUS.CLOSE) {
            this.paymentFailed = true
          } else if (status === CASHIER_TRANSATION_STATUS.INIT) {
            this.paymentFailed = true
          }
        })
      // 成功
      } else if (appRet.status === 1) {
        this.checkKplusRetFromServer((status) => {
          if (status === CASHIER_TRANSATION_STATUS.SUCC) {
            CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
            this.$emit('paynow', this.dataObj)
          } else if (status === CASHIER_TRANSATION_STATUS.PEND) {
            this.setCheckPayResultTimer()
          } else if (status === CASHIER_TRANSATION_STATUS.CLOSE) {
            this.paymentFailed = true
          } else if (status === CASHIER_TRANSATION_STATUS.INIT) {
            this.paymentFailed = true
          }
        })
        // 失败
      } else if (appRet.status === -1002) {
        this.paymentFailed = true
      }
    },
    setCheckPayResultTimer() {
      this.addCutdownTimerOnce()
      CheckDeepLinktimer = setTimeout(() => {
        CheckDeepLinktimes += 1
        console.log(`loop查询${CheckDeepLinktimes}次`)
        if (CheckDeepLinktimes === 5) {
          this.networkError = true
          clearTimeout(CheckDeepLinktimer)
          return
        }
        this.checkKplusRetFromServer()
      }, 1000 * CheckDeepLinktimes)
    },
    addCutdownTimerOnce() {
      let flag = true
      if (flag) {
        flag = false
        this.animateCutdownTime = 10
        const timer = setInterval(() => {
          this.animateCutdownTime -= 1
          if (this.animateCutdownTime === 0) {
            clearInterval(timer)
          }
        }, 1000)
      }
    },
    async checkKplusRetFromServer(cb) {
      const payRet = await scanedResultQuery({
        transactionNo: this.transactionNo
      })
      if (payRet.data.resultCode === 1) {
        cb(payRet.data.resultData.transactionStatus)
      } else {
        this.paymentFailed = true
      }
    },
    // 余额支付
    async balaPay(commonReqData) {
      this.showLoading = true
      // console.log(this.$refs.animateSuccess.initData())
      this.$refs.animateSuccess.initData()
      console.log('click')
      const reqData = {
        ...commonReqData,
        promotionInfo: {},
        additionalMessage: ''
      }
      this.firstReqData = reqData
      const res = await this.switchPay(this.currentBank.payMethodCodeFirst, reqData, '', 'simpleCashier')
      console.log('res:', res)
    },
    selectBank() {
      this.selectBankAccountVisible = false;
      console.log('selectBank')
    },
    changeBank(idx) {
      this.selectBankAccountVisible = false;
      console.log('changeBank', idx)
      this.currentIndex = idx
      this.computedCurrentObj()
      // 匹配当前支付方式的优惠券
      for (const i of this.dataObj.promoHitResList) {
        if (this.dataObj.payMethodModelList[idx].displayName === i.firstPayment) {
          this.coupons = i;
        }
      }
    },
    // 判断有没有返回支持depl (kplus or bbl)支付方式的app
    async hasDeplApp() {
      let hasKplusMethod = false
      let kplusIndex = 0
      let hasBBLMethod = false
      let bblIndex = 0
      const payMethodModelList = this.dataObj.payMethodModelList || []
      payMethodModelList.forEach((item, idx) => {
        if (item.payMethodCodeFirst === enumPayMethodCodeFirst.DELI) {
          if (item.payMethodCodeSecond === enumPayMethodCodeSecond.KBANK) {
            hasKplusMethod = true
            kplusIndex = idx
          }
        }
      })
      if (hasKplusMethod) {
        console.log('支持k plus 支付方式')
        const ret = await this.$SDK.checkInstallKplus()
        if (ret) {
          console.log('且 安装了kplus app', ret)
          // alert('且 安装了kplus app', ret)
        } else {
          payMethodModelList.splice(kplusIndex, 1)
          console.log('没有安装了kplus app， 删除该支付方式')
        }
      }
      payMethodModelList.forEach((item, idx) => {
        if (item.payMethodCodeFirst === enumPayMethodCodeFirst.DELI) {
          if (item.payMethodCodeSecond === enumPayMethodCodeSecond.BBL) {
            hasBBLMethod = true
            bblIndex = idx
          }
        }
      })

      if (hasBBLMethod) {
        console.log('支持bbl 支付方式')
        const ret = await this.$SDK.checkInstallBBL()
        if (ret) {
          console.log('且 bbl app', ret)
        } else {
          payMethodModelList.splice(bblIndex, 1)
          console.log('没有安装了 bbl app， 删除该支付方式')
        }
      }
    },
    computedCurrentIndex() {
      let index = 0
      let hasDefaultFlag = false
      // const availableList =  this.dataObj.payMethodModelList.filters( item => item.status ===1 )
      // 有一个默认的选择且可用
      const payMethodModelList = this.dataObj.payMethodModelList || []
      payMethodModelList.forEach((item, idx) => {
        if (item.defaultFlag === true && item.status === 1) {
          index = idx
          hasDefaultFlag = true
        }
      })
      // 没有 一个默认的选择且可用的情况，选择第一个可用的， 此时不用再次考虑priority(前面已经对此排序过)
      let breakOut = true
      if (!hasDefaultFlag) {
        payMethodModelList.forEach((item, idx) => {
          if (breakOut) {
            if (item.status === 1) {
              index = idx
              breakOut = false
            }
          }
        })
      }
      this.currentIndex = index
      // 匹配当前支付方式的优惠券
      if (this.dataObj.promoHitResList) {
        for (const i of this.dataObj.promoHitResList) {
          if (this.dataObj.payMethodModelList[this.currentIndex].displayName === i.firstPayment) {
            this.coupons = i;
          }
        }
      }
    },
    computedCurrentObj() {
      const payMethodModelList = this.dataObj.payMethodModelList || []
      this.currentBank = payMethodModelList[this.currentIndex] || {}
      // 匹配当前支付方式的优惠券
      if (this.dataObj.promoHitResList) {
        for (const i of this.dataObj.promoHitResList) {
          if (this.dataObj.payMethodModelList[this.currentIndex].displayName === i.firstPayment) {
            this.coupons = i;
          }
        }
        console.log('this.coupons', this.coupons)
      }
    },
    async addCard() {
      console.log('跳转绑卡')
      const ret = await this.$SDK.goNativeActionAddCard()
      console.log(ret)
      // 绑卡回来重新查询支付方式列表
      this.initData()
    },
    gocdcp(idx) {
      this.wraperCdcp = true
      CASHIER_BURRY.PAY_SUCCESS_COUNTER_CREDIT_ONLINE(idx + 1)
    },
    cdcpOk() {
      console.log('cdcpOk')
      // this.wraperCdcp = false
    },
    methodsItemClick() {
      if (!this.kycCheckFlag) {
        return
      }
      this.selectBankAccountVisible = true
      CASHIER_BURRY.PAY_DETAIL_COUNTER_PAY_METHOD()
      CASHIER_BURRY.PAY_DETAIL_COUNTER_LEAVE()
      CASHIER_BURRY.PAY_SUCCESS_COUNTER_ENTRY()
    },
    goLeave() {
      if (this.changeSelcted === true) {
        CASHIER_BURRY.CLICK_CANCEL();
      }
      CASHIER_BURRY.COUNTER_QUIT_YES(this.selectBankAccountVisible, this.showLoading)
      this.saveLeave = false
      // if (this.dataObj.payOrderModel.bizCode === 'APP_PAY_VIRTUAL_GOODS') {
      //   return this.$SDK.closeWebView()
      // }
      return this.$emit('update:cashierVisible', false)
    },
    // getSignData() {
    //   if (signObj) {
    //     return signObj
    //   }
    //   return new Promise((relsove) => {
    //     signQuery({
    //       transactionNo: this.$route.query.transactionNo
    //     }).then((ret) => {
    //       signObj = ret.data.resultData
    //       relsove(signObj)
    //     })
    //   })
    // },
    cancleLeave() {
      CASHIER_BURRY.COUNTER_QUIT_NO()
      this.saveLeave = false
      this.listenBankPress()
    },
    async goVerify() {
      console.log('goVerify')
      const action = this.dataObj.kycCheckResultModel.kycPromptJsonMsg.actionData
      await this.$SDK.goNativeAction(action)
      this.initData()
    },
    getkycCheckStr() {
      let jsonObj
      let str
      try {
        jsonObj = this.dataObj.kycCheckResultModel && this.dataObj.kycCheckResultModel.kycPromptJsonMsg
        if (this.$DeviceInfo.language === 'en_US') {
          str = jsonObj.en
        } else {
          str = jsonObj.th
        }
      } catch (error) {
        str = this.$t('Sorry, you can not make a payment until you finish the the verifications.')
      }
      return str
    },
    retryToPay() {
      this.showRetrydialog = false
      this.retryAjax()
      console.log('retry')
    },
    // 切换开关
    toggle() {
      this.me_checked = !this.me_checked;
      if (this.me_checked === true) {
        this.actualTxt = this.coupons.actualPayAmount;
        CASHIER_BURRY.CLICK_DOWNLOAD()
      } else {
        this.actualTxt = this.dataObj.payOrderModel.amount;
      }
      console.log('开关', this.me_checked)
    },
    // 重新选择支付方式
    changeSelectMethod() {
      CASHIER_BURRY.CLICK_CHANGE_METHOD();
      this.changeSelcted = false;
      this.initData()
      this.listenBankPress()
      // lnwang
      this.$SDK.onBackPress(() => {
        if (this.showLoading === 'true') {
          // 收银台成功支付
          CASHIER_BURRY.BACK(2);
        } else if (this.networkError === 'true') {
          // lnwang  收银台请求错误
          CASHIER_BURRY.BACK(4);
        } else if (this.paymentFailed === 'true') {
          // lnwang  支付失败
          CASHIER_BURRY.BACK(5);
        } else {
          CASHIER_BURRY.BACK(1);
        }
      })
    },
    yearMonthDay(code) {
      if (code !== '') {
        const aa = String(new Date(code).getFullYear());
        this.year = aa.substring(aa.length - 2);
        this.month = new Date(code).getMonth() + 1;
        this.day = new Date(code).getDate();
        const chnarr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        const enarr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Spt', 'Oct', 'Nov', 'Dec'];
        for (const i in chnarr) {
          if (this.month === chnarr[i]) {
            this.month2 = enarr[i];
          }
        }
      }
      return code !== '' ? this.day + this.month2 + this.year : ''
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.opcatify {
  opacity: .3;
}
.simple-cashier {
  font-size: .36rem;
  height: 10rem;
  position: relative;
  .title {
    height: 1.2rem;
    line-height: 1.2rem;
    text-align: center;
    box-sizing: border-box;
    color: $color-gray-g;
    border-bottom: 1px solid $color-gray-e;
    position: relative;
    .custom-ico {
     position: absolute;
      right: .34rem;
      font-weight: bold;
      color: $color-gray-f;
    }
  }
  .titleY {
    height: 1.4rem;
    line-height: 1.4rem;
    text-align: center;
    box-sizing: border-box;
    color: $color-gray-g;
    border-bottom: 1px solid $color-gray-e;
    position: relative;
    .custom-ico {
     position: absolute;
      right: .34rem;
      font-weight: bold;
      color: $color-gray-f;
    }
  }
  .amount {
    box-sizing: border-box;
    padding-top: .16rem;
    text-align: center;
    padding-bottom: .24rem;
    .des {
      font-size: .28rem;
      color: $color-gray-f;
      line-height: .52rem;
    }
    .desY {
      font-size: .48rem;
      color: #A1A5B9;
      line-height: .8rem;
      letter-spacing: 0;
      text-align: center;
      text-decoration: line-through;
    }
    .desNO{
      font-family: The1Official-Regular;
      font-size: .36rem;
      color: #A1A5B9;
      letter-spacing: 0;
      line-height: .8rem;
      text-align: center;
      margin-top :.16rem;
    }
    .money {
      font-family: The1Official_Bold !important;
      font-size: .96rem;
      color: $color-red;
      text-align: right;
      line-height: 1.20rem;
      text-align: center;
      padding-right: .5rem;
      .txt-b {
        font-family: The1Official_Bold !important;
        font-size: .56rem;
        position: relative;
        top: -0.07rem;
      }
      span {
        font-family: The1Official_Bold !important;
      }
      .little-txt-money {
        font-size: .35rem;
      }
    }
    .moneyY {
      font-family: The1Official_Bold !important;
      font-size: .72rem;
      color: $color-red;
      text-align: right;
      text-align: center;
      .txt-b {
        font-family: The1Official_Bold !important;
        font-size: .56rem;
        position: relative;
        top: -0.07rem;
      }
      span {
        font-family: The1Official_Bold !important;
      }
      .little-txt-money {
        font-size: .35rem;
      }
    }
    .little-txt-money {
      font-size: .5rem;
    }
  }
  .amountY {
    box-sizing: border-box;
    padding-top: .16rem;
    text-align: center;
    .des {
      font-size: .28rem;
      color: $color-gray-f;
      line-height: .52rem;
    }
    .desY {
      font-size: .48rem;
      color: #A1A5B9;
      line-height: .8rem;
      letter-spacing: 0;
      text-align: center;
      text-decoration: line-through;
    }
    .desNO{
      font-family: The1Official-Regular;
      font-size: .36rem;
      color: #A1A5B9;
      letter-spacing: 0;
      line-height: .8rem;
      text-align: center;
      margin-top :.16rem;
    }
    .money {
      font-family: The1Official_Bold !important;
      font-size: .96rem;
      color: $color-red;
      text-align: right;
      line-height: 1.20rem;
      text-align: center;
      padding-right: .5rem;
      .txt-b {
        font-family: The1Official_Bold !important;
        font-size: .56rem;
        position: relative;
        top: -0.07rem;
      }
      span {
        font-family: The1Official_Bold !important;
      }
      .little-txt-money {
        font-size: .35rem;
      }
    }
    .moneyY {
      font-family: The1Official_Bold !important;
      font-size: .72rem;
      color: $color-red;
      text-align: right;
      text-align: center;
      .txt-b {
        font-family: The1Official_Bold !important;
        font-size: .56rem;
        position: relative;
        top: -0.07rem;
      }
      span {
        font-family: The1Official_Bold !important;
      }
      .little-txt-money {
        font-size: .35rem;
      }
    }
    .little-txt-money {
      font-size: .5rem;
    }
  }
  .hei9 {
    height: .9rem;
  }
  .payment-method {
    padding-bottom: .2rem;
    font-size: .28rem;
    color: $color-gray-h;
    letter-spacing: 0;
  }
  .item {
    padding: 0 .4rem 0 .4rem;
  }
  .gateway {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .pay-value {
      font-size: .28rem;
      color: #141E50;
      padding-bottom: .2rem;
    }
  }
  .name {
    box-sizing: border-box;
    height: 1rem;
    line-height: 1rem;
    border-bottom: 1px solid #E4E4E4;
    display: flex;
    justify-content: space-between;
    .key{
      color: #838080;
      font-size: .28rem;
    }
    .value {
      font-size: .28rem;
      color: #000000;
      text-align: right;
    }

  }
  .hide {
    display: none;
  }
  .btn-wrapper {
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    margin-left: 50%;
    transform: translateX(-50%);
    width: 5.6rem;
    position: absolute;
    bottom: .48rem;
  }
  .cashier-success-container-bg {
    position: absolute;
    top: 1.2rem;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    padding-top: 1.2rem;
    display: flex;
    justify-content: center;
  }
  .result-network-error {
    position: absolute;
    top: 1.2rem;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    padding-top: 1.2rem;
    display: flex;
    justify-content: start;
    flex-direction: column;
    align-items: center;
    z-index: 1001;
    .img {
      height: 1.2rem;
      width: 1.2rem;
    }
    .txt {
      padding-top: .32rem;
    }
  }
  .kycCheckFlagWrong {
    font-size: .28rem;
    color: $color-red;
    margin-top: .12rem;
    padding: 0 .4rem 0 .4rem;
    line-height: .4rem;
    letter-spacing: 0;
    padding: 0 .4rem 0 .4rem;
  }
  .width12 {
    width: 1.2rem;
  }
}
  .has-coupon {
    .use-coupon {
      .use-coupon-box {
        width: 7.22rem;
        margin: 0 auto;
        height: 2.92rem;
        background: url("../../assets/images/cashier/activecouponbackground.png") no-repeat center center;
        background-size: 100% 100%;
        z-index: 99;
        .coupon-top {
            // border:.04rem solid #65449B;
            border-bottom:none;
            border-radius: 0.16rem;
            margin-bottom: .38rem;
        }
        .save-amount {
          font-family: The1Official-Regular;
          font-size: .36rem;
          color: #0D9DA2;
          letter-spacing: 0;
          text-align: center;
          line-height: .85rem;
          // margin: .17rem 0 .16rem 0;
        }
        .save-info {
          width: 7.22rem;
          height: .84rem;
          .left-img {
            width: 0.6rem;
            height: 0.6rem;
            float: left;
            margin: 0 .32rem 0 0.5rem;
            img {
              width: 100%;
              height: 100%;
              vertical-align: top;
              margin-top: .12rem;
            }
          }
          .right-txt {
            width: 5.3rem;
            letter-spacing: 0;
            font-size: 0.28rem;
            color: #4F577C;
            float: left;
            line-height: .42rem;
            height: .84rem;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
          }
        }
        .valid-and-use {
          width: 7.22rem;
          height: 0.76rem;
          // border-top: 0.04rem dashed rgba(101,68,155,0.40);
          // border-bottom:.04rem solid #65449B;
          // border-left:.04rem solid #65449B;
          // border-right:.04rem solid #65449B;
          border-radius: 0.16rem;
          font-size: 0.24rem;
          box-sizing: border-box;
          position: relative;
          // &:before {
          //   content: "";
          //   width: 0.28rem;
          //   height: 0.28rem;
          //   position: absolute;
          //   left: -0.18rem;
          //   top: -0.18rem;
          //   border-radius: 0.32rem;
          //   // border: 0.04rem solid #65449b;
          //   z-index: 999;
          //   background: $color-white;
          // }
          // &:after {
          //   content: "";
          //   width: 0.28rem;
          //   height: 0.28rem;
          //   position: absolute;
          //   top: -0.18rem;
          //   right: -0.18rem;
          //   // border: 0.04rem solid #65449b;
          //   border-radius: 0.32rem;
          //   background: $color-white;
          //   z-index: 999;
          // }
          .valid-left {
              height:.36rem;
              line-height:.44rem;
              float:left;
              margin:0 0 0 .49rem;
              font-size:.24rem;
              color:#4F577C;
              font-family: The1Official-Regular;
          }
          .txt {
              float: right;
              margin-left: 2rem;
              width: .94rem;
              font-size:.24rem;
              color:#4F577C;
              line-height:.44rem;
          }
        }
      }
      // .use-coupon-box {
      //     width:6.06rem;
      //     margin:0 auto;
      //     border:.04rem solid #65449B;
      //     border-radius:.16rem;
      //     box-shadow:0 .04rem .16rem 0 rgba(79,84,124,.2);
      //     z-index:99;
      // }
    }
    .no-use-coupon {
      .no-user-tip {
        height: 0.5rem;
        line-height: 0.5rem;
        text-align: center;
        font-size: 0.32rem;
        color: $color-gray-h;
        font-family: The1Official-Regular;
        margin: 0.16rem 0 0 0.1rem;
      }
      .use-coupon-box {
        width: 7.18rem;
        height: 2.28rem;
        margin: 0 auto;
        // border: 0.04rem solid rgba(79,87,124,0.20);
        // border-radius: 0.16rem;
        background: url("../../assets/images/cashier/inactivecouponbackground.png") no-repeat center center;
        // box-shadow: 0 0.04rem 0.16rem 0 rgba(79,87,124,0.10), 0 2px 8px 0 rgba(79,87,124,0.20);
        overflow: hidden;
        .left-img {
          width: 0.6rem;
          height: 0.6rem;
          float: left;
          margin: 0.35rem 0.37rem 0 0.48rem;
          img {
            width: 100%;
            height: 100%;
            vertical-align: top;
          }
        }
        .right-txt {
          width: 5.3rem;
          line-height: 0.42rem;
          font-size: 0.28rem;
          color: #4F577C;
          float: left;
          margin-top: .30rem;
          height: .84rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
      }
      .amount-num {
        text-align: center;
      }
      .valid-left2 {
        height:.36rem;
        line-height:.36rem;
        float:left;
        margin:0 0 0 .48rem;
        font-size:.24rem;
        color:#4F577C;
        font-family: The1Official-Regular;
      }
      .txt {
          float: right;
          margin-left: 2rem;
          width: .94rem;
          font-size:.24rem;
          color:#4F577C;
          line-height:.44rem;
      }
      .valid-and-use {
        width: 7.18rem;
        height: 0.76rem;
        // border-top: 0.04rem dashed rgba(101,68,155,0.40);
        // border-bottom:.04rem solid #65449B;
        // border-left:.04rem solid #65449B;
        // border-right:.04rem solid #65449B;
        border-radius: 0.16rem;
        font-size: 0.24rem;
        box-sizing: border-box;
        position: relative;
        margin-top: .38rem;
        &:before {
          content: "";
          width: 0.28rem;
          height: 0.28rem;
          position: absolute;
          left: -0.18rem;
          top: -0.18rem;
          border-radius: 0.32rem;
          // border: 0.04rem solid #65449b;
          z-index: 999;
          background: $color-white;
        }
        &:after {
          content: "";
          width: 0.28rem;
          height: 0.28rem;
          position: absolute;
          top: -0.18rem;
          right: -0.18rem;
          // border: 0.04rem solid #65449b;
          border-radius: 0.32rem;
          background: $color-white;
          z-index: 999;
        }
        .valid-left {
            height:.36rem;
            line-height:.36rem;
            float:left;
            margin:.18rem 0 0 .32rem;
            font-size:.24rem;
            color:#4F577C;
            font-family: The1Official-Regular;
        }
        .txt {
            float: right;
            margin-left: 2rem;
            width: .94rem;
            font-size:.24rem;
            color:#4F577C;
            line-height:.44rem;
        }
      }
    }
  }
  .no-user-tip {
    height: 0.5rem;
    line-height: 0.5rem;
    text-align: center;
    font-size: 0.32rem;
    color: $color-gray-h;
    font-family: The1Official-Regular;
    margin: 0.16rem 0 0 0.1rem;
  }
  .weui-switch {
    float: right;
    margin: 0 .5rem .16rem 0.16rem;
    display: block;
    position: relative;
    width: .8rem;
    height: .48rem;
    border: 1px solid #DFDFDF;
    outline: 0;
    border-radius: .32rem;
    box-sizing: border-box;
    background-color: #CDCBCB;
    transition: background-color 0.1s, border 0.1s;
    cursor: pointer;
  }
  .weui-switch:before {
    content: " ";
    position: absolute;
    top: 0;
    left: 0;
    width: .8rem;
    height: .48rem;
    border-radius: .32rem;
    background-color: #CDCBCB;
    transition: transform 0.35s cubic-bezier(0.45, 1, 0.4, 1);
  }
  .weui-switch:after {
    content: " ";
    position: absolute;
    top: 0.04rem;
    left: 0.04rem;
    width: .4rem;
    height: .4rem;
    border-radius: .3rem;
    background-color: #FFFFFF;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
    transition: transform 0.35s cubic-bezier(0.4, 0.4, 0.25, 1.35);
  }
  .weui-switch-on {
    border-color: #FF3E5B;
    background-color: #FF3E5B;
  }
  .weui-switch-on:before {
    border-color: #FF3E5B;
    background-color: #FF3E5B;
  }
  .weui-switch-on:after {
    transform: translateX(.36rem);
  }
  .changeSelctType {
    top: 1.2rem;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    padding-top: .8rem;
    position: absolute;
    z-index: 1000;
    display: flex;
    justify-content: start;
    flex-direction: column;
    align-items: center;
    .img {
      height: 1.2rem;
      width: 1.2rem;
    }
    .txt {
      margin: .6rem 0 .2rem 0;
      font-size: .48rem;
    }
    .txt2 {
      font-size: .36rem;
    }
    .cancelStyle {
      color: #A1A5B9;
      opacity: .1rem;
      border: .02rem solid #A1A5B9;
      border-radius: 28p.56rem;
      background: #fff;
    }
  }
</style>
