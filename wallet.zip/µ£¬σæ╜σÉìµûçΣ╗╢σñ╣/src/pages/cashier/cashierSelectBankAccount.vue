<template>
  <common-popup
    v-model="show"
    :close-on-click-modal="false"
    position="bottom"
    style="width:100%"
  >
    <div class="select-bank-account">
      <div class="title">
        <common-icon
          class="custom-ico"
          name="more"
          size=".4rem"
          @click="close()"
        />
        <span>{{ $t('Select a Bank Account/Card') }}</span>
      </div>
      <div
        v-if="payMethodModelList.length"
        class="item">
        <template v-for="(method, idx) in payMethodModelList">
          <div
            v-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.ODD"
            :key="idx"
            class="list-item">
            <common-item
              :class="{ 'can-not-use': method.status=== 0 }"
              :title="getBankName(method)"
              :border="false"
              icon-color="#4D7BFE"
              @click="changeBank(method, idx)"
            >
              <img
                slot="img"
                :src="method.h5LogoUrl"
                class="img"
              >
              <img
                v-if="idx === currentIndex"
                slot="icon"
                class="custom-ico"
                src="@/assets/images/cashier/the1/selection_small@3x.png">
            </common-item>
            <div class="item-border-right"/>
          </div>
          <div
            v-else-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.BALA"
            :key="idx"
            class="list-item">
            <common-item
              :class="{ 'can-not-use': method.status=== 0 }"
              :title="getItemName(method)"
              :label="getBalanceAmount(method)"
              :border="false"
              icon-color="#4D7BFE"
              @click="changeBank(method, idx)"
            >
              <img
                slot="img"
                :src="method.h5LogoUrl"
                class="img"
              >
              <img
                v-if="idx === currentIndex"
                slot="icon"
                class="custom-ico"
                src="@/assets/images/cashier/the1/selection_small@3x.png">
            </common-item>
            <div class="item-border-right"/>
          </div>

          <div
            v-else-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.OFLN"
            :key="idx"
            class="list-item">
            <div
              :class="{ 'can-not-use': method.status=== 0 }"
              class="ofln-item"
              @click="changeBank(method, idx)"
            >
              <span class="card-container">
                <img
                  :src="method.h5LogoUrl"
                  class="img"
                >
                <p class="value">
                  <span>{{ getItemName(method) }}</span>
                  <img
                    :src="method.payOrgModelList[0].h5LogoUrl"
                    class="ofln-img"
                  >
                </p>
              </span>

              <img
                v-if="idx === currentIndex"
                class="custom-ico"
                src="@/assets/images/cashier/the1/selection_small@3x.png">
            </div>
            <div class="item-border-right"/>
          </div>

          <div
            v-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.DELI"
            :key="idx"
            class="list-item">
            <common-item
              :class="{ 'can-not-use': method.status=== 0 }"
              :title="getItemName(method)"
              :border="false"
              icon-color="#4D7BFE"
              @click="changeBank(method, idx)"
            >
              <img
                slot="img"
                :src="method.h5LogoUrl"
                class="img"
              >
              <img
                v-if="idx === currentIndex"
                slot="icon"
                class="custom-ico"
                src="@/assets/images/cashier/the1/selection_small@3x.png">
            </common-item>
            <div class="item-border-right"/>
          </div>


          <div
            v-else-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.CCP && method.payMethodCodeSecond === enumPayMethodCodeSecond.SPECIAL"
            :key="idx"
            class="list-item">
            <common-item
              :border="false"
              :title="$t('Add Credit/Debit Card')"
              icon-color="#4D7BFE"
              @click="goCdcpPay(idx)"
            >
              <img
                slot="img"
                src="@/assets/images/cashier/the1/add_cdcp@3x.png"
                class="img"
              >
              <common-icon
                slot="icon"
                name="more"
                size=".4rem"
              />
            </common-item>
            <div class="item-border-right"/>
          </div>

          <div
            v-else-if="method.payMethodCodeFirst === enumPayMethodCodeFirst.CCP && method.payMethodCodeSecond !== enumPayMethodCodeSecond.SPECIAL"
            :key="idx"
            class="list-item">
            <common-item
              :class="{ 'can-not-use': method.status=== 0 }"
              :title="getBankName(method)"
              :border="false"
              icon-color="#4D7BFE"
              @click="changeBank(method, idx)"
            >
              <img
                slot="img"
                :src="method.h5LogoUrl"
                class="img"
              >
              <img
                v-if="idx === currentIndex"
                slot="icon"
                class="custom-ico"
                src="@/assets/images/cashier/the1/selection_small@3x.png">
            </common-item>
            <div class="item-border-right"/>
          </div>
          <div
            v-else-if="method.showAddBtn"
            :key="idx"
            class="list-item">
            <common-item
              :border="false"
              :title="$t('Add new account')"
              icon-color="#4D7BFE"
              @click="addCard"
            >
              <img
                slot="img"
                src="@/assets/images/cashier/the1/bank@3x.png"
                class="img"
              >
              <common-icon
                slot="icon"
                name="more"
                size=".4rem"
              />
            </common-item>
            <div class="item-border-right"/>
          </div>
        </template>
        <!-- <div
          v-if="showAddBtn"
          class="list-item">
          <common-item
            :border="false"
            :title="$t('Add new account')"
            icon-color="#4D7BFE"
            @click="addCard"
          >
            <img
              slot="img"
              src="@/assets/images/cashier/the1/bank@3x.png"
              class="img"
            >
            <common-icon
              slot="icon"
              name="more"
              size=".4rem"
            />
          </common-item>
          <div class="item-border-right"/>
        </div> -->
      </div>
      <div
        v-else
        class="no-info"
      >
        {{ $t('No information') }}
      </div>
      <!-- <div
        v-if="showAddBtn"
        class="botom"
      >
        <img
          src="@/assets/images/cashier/the1/add_card@3x.png"
          class="img">
        <span @click="addCard">{{ $t('Add new account/card') }}</span>
      </div> -->
    </div>
  </common-popup>
</template>
<script>
import { enumPayMethodCodeFirst, CASHIER_PAYMENT_METHODS, enumPayMethodCodeSecond, ENUM_ERRORCODE } from '@/utils/const'
import * as CASHIER_BURRY from '@/pages/burry/cashier'

export default {
  name: 'CashierSelectBankAccount',
  filters: {
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dataObj: {
      type: Object,
      default: () => {}
    },
    currentIndex: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      enumPayMethodCodeFirst,
      enumPayMethodCodeSecond,
      typeBalance: []
    }
  },
  computed: {
    show: {
      get() {
        return this.visible
      },
      set(val) {
        this.$emit('update:visible', val)
      }
    },
    showAddBtn() {
      const availableArr = this.dataObj.availablePayMethodCodeFirstList ? this.dataObj.availablePayMethodCodeFirstList : []
      return availableArr.includes(enumPayMethodCodeFirst.ODD)
    },
    payMethodModelList() {
      if (!this.showAddBtn) {
        return this.dataObj.payMethodModelList || []
      }
      let index
      let flag = true
      const payMethodModelList = [...(this.dataObj.payMethodModelList || [])]
      payMethodModelList.forEach((item, idx) => {
        if (item.status === 0 && flag) {
          index = idx
          flag = false
        }
      })
      if (flag) {
        index = payMethodModelList.length
      }
      payMethodModelList.splice(index, 0, { showAddBtn: true })
      return payMethodModelList
    }
  },
  watch: {
  },
  // async created() {
  //   const ret = await this.$.checkInstallKplus()
  //   if (ret) {
  //     this.installedKplus = true
  //   }
  // },
  created() {
    // lnwang
    this.$SDK.onBackPress(() => {
      // 选择支付方式选择back
      CASHIER_BURRY.BACK(3);
    })
  },
  methods: {
    close() {
      this.$emit('update:visible', false)
      CASHIER_BURRY.PAY_SUCCESS_COUNTER_BACK()
    },
    handleClick() {
      console.log('click')
    },
    getBankName(method) {
      // return ' Kbank Account (5435)'
      const last4Num = method.accountNo.slice(-4)
      return `${this.$t(CASHIER_PAYMENT_METHODS[method.displayName])} (${last4Num})`
    },
    getBalanceAmount(method) {
      if (method.errorCode === ENUM_ERRORCODE.CASHIER_BALANCE_LACK) {
        return this.$t('Insufficient balance')
      }
      return method.availableAmount ? `${this.$t('AvaiableAmount')} ฿ ${method.availableAmount}` : ''
    },
    async addCard() {
      CASHIER_BURRY.PAY_SUCCESS_COUNTER_ADD_CARD_ACCOUNT()
      CASHIER_BURRY.PAY_SUCCESS_COUNTER_LEAVE()
      // console.log('跳转绑卡')
      // const ret = await this.$SDK.goNativeActionAddCard()
      // console.log(ret)
      this.$emit('addCard')
      // lnwang  收银台选择支付方式 添加新卡账户
      CASHIER_BURRY.CREDIT_ONLINE_5()
    },
    changeBank(method, idx) {
      if (method.status === 0) {
        return
      }
      // 收银台选择支付方式balance位于第几个
      for (const i of this.payMethodModelList) {
        if (i.payMethodCodeFirst === 'ODD') {
          this.typeBalance.push('1')
        }
      }
      this.$emit('changeBank', idx)
      // 埋点相关
      CASHIER_BURRY.changeBank(method, idx)
      if (method.payMethodCodeFirst === 'ODD') {
        // lnwang  收银台选择支付方式 ODD
        CASHIER_BURRY.ODD_2()
      } else if (method.payMethodCodeFirst === 'BALA') {
        // 选择balance支付方式
        if (this.typeBalance.length === 1) {
          CASHIER_BURRY.BALANCE_2()
        } else {
          CASHIER_BURRY.BALANCE_1()
        }
      } else if (method.payMethodCodeFirst === 'CCP') {
        // 选择信用卡支付方式
        CASHIER_BURRY.CREDIT_CARD_3()
      } else if (method.payMethodCodeSecond === 'CENPAY') {
        // 选择CENPAY支付方式
        CASHIER_BURRY.CENPAY_4()
      }
    },
    goCdcpPay(idx) {
      // this.$router.push({ name: 'cdcp' })
      this.$emit('gocdcp', idx)
      // lnwang  收银台选择支付方式 绑定信用卡
      CASHIER_BURRY.ADD_CARD_ACCOUNT()
    },
    getItemName(method) {
      return this.$t(CASHIER_PAYMENT_METHODS[method.displayName])
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.select-bank-account {
  position: relative;
  font-size: .32rem;
  height: 10rem;
  .title {
    height: 1.4rem;
    line-height: 1.4rem;
    text-align: center;
    box-sizing: border-box;
    border-bottom: 1px solid #ddd;
    position: relative;
    .custom-ico {
      position: absolute;
      left: .34rem;
      transform: rotate(180deg);
    }
  }
  .item {
    padding: 0 .4rem 0 .4rem;
    height: 7.2rem;
    overflow-y: auto;
    position: relative;
    .item-border-right {
      position: absolute;
      left: .4rem;
      right: 0;
      height: 1px ;
      background-color: #E7E8ED;
    }
    .custom-ico {
      width: .4rem;
    }
  }
  .botom {
    position: fixed;
    bottom: 0;
    display: flex;
    left: 0;
    right: 0;
    justify-content: center;
    align-items: center;
    color: $color-red;
    font-size: .32rem;
    height: 1.4rem;
    background: #FFFFFF;
    box-shadow: 0 10px 60px 0 rgba(0,0,0,0.08);
    .img {
      width: 29px;
      padding-right: .14rem;
    }
  }

}
.can-not-use {
  opacity: .5;
}

.ofln-item {
    box-sizing: border-box;
  height: 1.4rem;
  line-height: 1.4rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .custom-ico {
    font-weight: bold;
    color: $color-gray-f;
  }
  .card-container {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .img{
    width: .6rem;
    height: .6rem;
  }
  .ofln-img {
    height: .32rem;
  }
  .value {
    font-size: .36rem;
    color: $color-gray-g;
    text-align: left;
    padding-left: .2rem;
    display: flex;
    flex-direction: column;
    line-height: initial;
  }
}
.no-info {
  text-align: center;
  padding-top: 30%;
}
</style>

