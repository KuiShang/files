<template>
  <simpleCashier
    v-if="cashierVisible"
    :cashier-visible.sync="cashierVisible"
    :transaction-no = "transactionNo"
    :payment-token = "paymentToken"
    :payment-method = "paymentMethod"
    :current-busi-type= "getBusiType()"
    @paynow = "paynow"
  />
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import { ALL_BUSI_TYPE } from '@/utils/const'
import BUSI from '@/pages/cashier/busiType/busi'

export default {
  name: 'WraperSimpleCashier',
  components: { simpleCashier },
  data() {
    return {
      transactionNo: '123123',
      cashierVisible: false,
      ALL_BUSI_TYPE,
      paymentMethod: '',
      paymentToken: '',
      busiType: '',
      testshow: false
    }
  },
  watch: {
    async cashierVisible(value) {
      if (value === false) { // 关闭收银台 报进入
        // this.$SDK.closeWebViewAndSendResult()
        // 关闭收银台不能报
        this.$SDK.closeWebViewAndSendResult({ resultCode: 0 })
      }
    }
  },
  created() {
    this.transactionNo = this.$route.query.transactionNo
    this.busiType = this.$route.query.busiType
    this.paymentToken = this.$route.query.paymentToken
    this.paymentMethod = this.$route.query.paymentMethod
    this.busiType = this.$route.query.busiType
    this.cashierVisible = true
  },
  methods: {
    paynow(dataObj) {
      // 被扫场景
      console.log('wraperSimpleCashier成功，开始跳转结果页')
      if (this.busiType === BUSI.scaned) {
        this.$router.push({ name: 'scanedResult', query: { transactionNo: this.transactionNo, from: 'cashier' } })
      } else if (this.busiType === BUSI.APP_PAY_VIRTUAL_GOODS) { // payment gateway
        this.$router.push({ name: 'gatewayResult', query: { transactionNo: this.transactionNo } })
      }
    },
    getBusiType() {
      if (this.busiType === BUSI.scaned) {
        return ALL_BUSI_TYPE.SCANDED
      } else if (this.busiType === BUSI.APP_PAY_VIRTUAL_GOODS) { // payment gateway
        return ALL_BUSI_TYPE.APP_PAY_VIRTUAL_GOODS
      }
      return ''
    }
  }

}
</script>
