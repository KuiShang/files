<template>
  <div class="cdcp">
    <!-- <messagebox
      ref="messagebox"
      confirm-button-text="OK"
    >
      <div class="card">
        <p class="title">CVV/CCV</p>
        <img
          src="@/assets/images/cashier/the1/cvv@3x.png"
          class="img">
        <p class="txt">The <span class="bold">3 digits</span> on the back of your credit card.</p>
      </div>
    </messagebox> -->
    <!-- 收银台支付失败重试弹窗 -->
    <toast
      v-if="showRetrydialog"
      :title-position= "0.02"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="retryToPay"
      @cancle="goLeave"
    >
      <p slot="title">{{ this.$t('No Internet Connection') }}</p>
      <p slot="content">{{ $t('Dolfin can’t find your internet connection. Make sure you’re connected and try again.') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('TRYAGAIN') }}</p>
    </toast>

    <toast
      v-if="pendingBox || cdcpPendingBox"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "false"
      @closeDialog="closeWeb"
    >
      <p slot="title">{{ $t('Network error') }}</p>
      <p slot="content">{{ $t('Please check the results and try again later.') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
    <div class="banner">
      <div class="left">
        <!-- <img
          src="@/assets/images/cashier/the1/cardunion@3x.png"
          class="img"> -->
        <template v-for="item in computeInitData.creditCardOrgModelList">
          <img
            :src="item.h5LogoUrl"
            :key="item.orgCode"
            class="img"
          >
        </template>
      </div>
      <div class="right">
        <img
          src="@/assets/images/cashier/the1/SecurityProtected@3x.png"
          class="img">
      </div>
    </div>
    <common-datetime-picker
      ref="picker"
      :start-date="new Date()"
      v-model="pickerValue"
      :end-date="new Date(new Date().getFullYear() + 30, 11, 31)"
      :cancel-text="$t('Cancel')"
      :confirm-text="$t('Yes')"
      type="date"
      @confirm="handleConfirm"
    />
    <common-form
      ref="ruleForm"
      :model="ruleForm"
      :rules="rules"
      class="cdcp-form">
      <common-form-item
        class="rule-form-item"
        prop="cardNumber">
        <div class="item-container">
          <common-input
            v-model="ruleForm.cardNumber"
            :border="false"
            :maxlength="23"
            :holder="$t('Credit/Debit Card Number')"
            :style-obj="{right: 0}"
            :add-blank="true"
            clear-postion-right="0"
            type="tel"
            @input="cardOrgQuery"
            @focus="cardInputFocus"
            @blur="cardInputBlur"
          />
          <img
            v-if="bankLogo.length > 1 && cardNumFocusFlag"
            :src="bankLogo"
            class="custom-ico"
          >
          <p class="border"/>
        </div>
      </common-form-item>
      <common-form-item
        class="rule-form-item"
        prop="cardHolder">
        <div class="item-container">
          <common-input
            v-model="ruleForm.cardHolder"
            :border="false"
            :maxlength="130"
            :holder="$t('Card Holder Name')"
            :style-obj="{right: 0}"
            validate-type="name"
            clear-postion-right="0"
            type="text"
          />
          <p class="border"/>
        </div>
      </common-form-item>
      <common-form-item
        class="rule-form-item"
        prop="date">
        <div
          class="item-container"
          @click="openPicker">
          <div class="imitate-input">
            <span :class="['imitate-holder-txt', { 'imitate-input-tip-focus': ruleForm.date}]">{{ $t('Expire Date(MM/YY)') }}</span>
            <div class="txt">{{ ruleForm.date }}</div>
            <common-icon
              class="custom-ico-arrow"
              name="moreunfold"
              size=".6rem"
            />
          </div>
        </div>
      </common-form-item>
      <common-form-item
        class="rule-form-item"
        prop="cvv">
        <div class="item-container">
          <common-input
            v-model="ruleForm.cvv"
            :border="false"
            :maxlength="4"
            :style-obj="{right: 0}"
            :holder="$t('Security Code (CVV/CVC)')"
            clear-postion-right="0"
            type="tel"
            @focus="cvvFocus"
            @blur="cvvBlur"
          />
          <img
            v-if="cvvFocusFlag"
            src="@/assets/images/cashier/the1/info@3x.png"
            class="cvv-info"
            @click="showCVVInfo">
          <p class="border"/>
        </div>
      </common-form-item>
      <!-- <common-form-item
        class="rule-form-item"
        prop="lastName">
        <div class="item-container">
          <common-input
            v-model="ruleForm.lastName"
            :border="false"
            :maxlength="130"
            :holder="$t('LastName')"
            :style-obj="{right: 0}"
            clear-postion-right="0"
            validate-type="name"
            type="text"
          />
          <p class="border"/>
        </div>
      </common-form-item> -->
    </common-form>
    <div
      v-if="!isDirectCardPay"
      class="savecard">
      <img
        v-if="saveFlag"
        src="@/assets/images/cashier/the1/selection_small@3x.png"
        class="saveimg"
        @click="changeSaveFlag">
      <img
        v-else
        src="@/assets/images/cashier/the1/selection_small_Unselected@3x.png"
        class="saveimg"
        @click="changeSaveFlag">
      <p
        class="savetxt"
        @click="changeSaveFlag">{{ $t('Savethiscardasfutureuse') }}</p>
    </div>
    <div
      v-else
      class="save-card-txt">
      {{ $t('B1.00 will be deducted for verification, you will receive refund within 2 working days.') }}
    </div>
    <div
      v-if="!isDirectCardPay"
      class="btn-wrapper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick(2)">{{ $t('pay2') }} ฿ {{ computeInitData.payOrderModel && computeInitData.payOrderModel.amount | tofloat | thousandBitSeparator }}</common-button>
    </div>
    <div
      v-else
      class="btn-wrapper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick(1)">{{ $t('CONFIRM') }}</common-button>
    </div>
  </div>
</template>
<script>
import { cardOrgQuery, getCashierData } from '@/api'
import { enumPayMethodCodeFirst, ALL_BUSI_TYPE, enumPayMethodCodeSecond } from '@/utils/const'
import switchPay from '@/pages/cashier/mixins/switchPay'
import * as CASHIER_BURRY from '@/pages/burry/cashier'
import handlInitData from '@/mixins/handlInitData'
import toast from '@/pages/balance/common/dialog'
import * as TRANSFER_BURRY from '@/pages/burry/transfer'

// let firstTimeLoadStartDate = '' // 第一次加载 startdate
let titleName = ''
const MONTH = {
  0: '01',
  1: '02',
  2: '03',
  3: '04',
  4: '05',
  5: '06',
  6: '07',
  7: '08',
  8: '09',
  9: '10',
  10: '11',
  11: '12'
}
export default {
  name: 'Cdcp',
  components: { toast },
  mixins: [switchPay, handlInitData],
  props: {
    cashierInitInfo: {
      type: Object,
      default: () => {}
    },
    transactionNo: {
      type: String,
      default: ''
    },
    currentBusiTypeProxy: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      ruleForm: {
        cardHolder: '',
        cvv: '',
        // lastName: '',
        cardNumber: '',
        date: ''
      },
      rules: {
        cardNumber: [
          { required: true, message: this.$t('Thisfieldcannotbeblank'), trigger: 'blur' },
          { min: 16, max: 23, message: this.$t('CardNumbershouldbe1319digits'), trigger: 'blur' }
        ],
        cvv: [
          { required: true, message: this.$t('Thisfieldcannotbeblank'), trigger: 'blur' },
          { min: 3, max: 4, message: this.$t('CVVCCVshouldbe34digits'), trigger: 'blur' }
        ],
        cardHolder: [
          { required: true, message: this.$t('Thisfieldcannotbeblank'), trigger: 'blur' }
        ],
        // lastName: [
        //   { required: true, message: this.$t('Thisfieldcannotbeblank'), trigger: 'blur' }
        // ],
        date: [
          { required: true, message: this.$t('Thisfieldcannotbeblank'), trigger: 'blur' }
        ]
      },
      btnok: true,
      saveFlag: true,
      bankLogo: '',
      orgCode: '',
      month: '',
      yearfull: '',
      cvvFocusFlag: true,
      cardNumFocusFlag: false,
      isDirectCardPay: false, // 是否是直接跳转只卡支付，绑卡并支付场景
      showloading: false,
      pendingBox: false,
      pickerValue: new Date()
    }
  },
  computed: {
    computeInitData() {
      if (this.isDirectCardPay === true) {
        return this.dataObj || {}
      }
      return this.cashierInitInfo || {}
    },
    currentBusiType() {
      if (this.isDirectCardPay === true) {
        return ALL_BUSI_TYPE.BIND_AND_PAY
      }
      return this.currentBusiTypeProxy
    },
    cdcpPendingBox() {
      return this.$store.state.cdcpPendingBox
    }
  },
  async created() {
    titleName = await this.$SDK.getTitleName()
    console.log('或取到的titleName:', titleName)
    // 绑卡并支付 直接跳转到卡支付需要初始化数据
    if (window.location.hash.search('#/cashier/cdcp') !== -1) {
      this.$SDK.onBackPress(() => {
        TRANSFER_BURRY.BACK(3)
      })
      this.isDirectCardPay = true
      this.initDirectCardData()
      this.$SDK.setTitle({
        title: this.$t('Confirm Card Information'),
        mHeaderTitle: {
          showEnd: 0
        }
      })
    } else {
      this.$SDK.setTitle({
        title: this.$t('add Credit/Debit Card'),
        mHeaderTitle: {
          showEnd: 0
        }
      })
    }
    this.goOcrCard();
    if (this.isDirectCardPay) {
      this.$SDK.onBackPress(() => {
        TRANSFER_BURRY.BACK(5)
      })
    }
  },
  destroyed() {
    this.$SDK.setTitle({
      title: titleName,
      mHeaderTitle: {
        showEnd: 0
      }
    })
    this.$indicator.close()
  },
  methods: {
    async initDirectCardData() {
      this.$SDK.putCache({
        key: 'transOrderNo_before_cashier_leave',
        value: this.$route.query.transactionNo,
        cacheMode: 2
      })
      const res = await getCashierData({
        transactionNo: this.$route.query.transactionNo,
        deviceInfo: escape(JSON.stringify(this.$DeviceInfo)),
        clientInfo: escape(JSON.stringify(this.$ClientInfo))
      })
      this.handlInitData(res)
    },
    async goOcrCard() {
    /* eslint-disable */
      let res = await this.$SDK.scanCreditCard()
      console.log(res)
      // res = {
      //   outData: {bankCardNumber: "4093448800036270", cardOwnerName: "TEERAPHONG MAHATHAN", bankName: "krungsri", expiryDate: "12/28", effectiveDate: "11/14"}
      // }
      // 客户端返回，关闭卡支付
      if (res.status === 0) {
        this.$SDK.closeWebView()
        return
      }
      if (!res.outData) {
        console.warn('卡识别数据为空', res)
      } else {
        // 回显卡号
        if (res.outData.bankCardNumber && res.outData.bankCardNumber !== 'undefined') {
          try {
            this.ruleForm.cardNumber = res.outData.bankCardNumber.replace(/\s/g, "").replace(/(\d{4})(?=\d)/g, "$1 ");
          } catch (error) {
            this.ruleForm.cardNumber = res.outData.bankCardNumber
          }
        }
        // 回显姓名
        if (res.outData.cardOwnerName && res.outData.cardOwnerName !== 'undefined') {
          this.ruleForm.cardHolder = res.outData.cardOwnerName
        }
        const date = res.outData.expiryDate
        if (date && date.indexOf('/') !== -1) {
          const dateArr = date.split('/') // ["12", "2019"] ["12", "19"]
          const year = dateArr[1] // 原始获取的年份
          let yearTwo = '' // 两位数的年份
          let yearFour = '' // 四位数的年份
          if (String(year).length === 2) {
            yearTwo = year
            yearFour = String(new Date().getFullYear()).substring(0, 2) + yearTwo
          } else if (String(year).length === 4) {
            yearTwo = String(year).substring(2)
            yearFour = year
          }
          // 回显日期
          this.month = dateArr[0]
          this.yearfull = yearFour
          this.ruleForm.date = `${dateArr[0]}/${yearTwo}`
          this.pickerValue = new Date(`${this.yearfull}/${this.month}/1`)
        } else {
          console.warn('时间未匹配到 “/”，忽略日期时间', date)
        }
      }
      // alert(JSON.stringify(res))
    },
    getInitDate() {
      // if (this.yearfull && this.month) {
      //   // 最后强制加入日期1号，避免ios , 只有年月，没有日 特有bug  new Date("2019/08")会在ios报错 解决办法 new Date("2019/08/1")
      //   if (!firstTimeLoadStartDate) {
      //     firstTimeLoadStartDate = new Date(`${this.yearfull}/${this.month}/1`)
      //   }
      //   console.log('yearfull:', this.yearfull)
      //   console.log('month:', this.month)
      //   console.log('month/yearfull:', `${this.yearfull}/${this.month}`)
      //   console.log('firstTimeLoadStartDate:', firstTimeLoadStartDate)
      //   return firstTimeLoadStartDate
      // }
      // console.log('else firstTimeLoadStartDate:', new Date())
      return new Date(`${this.yearfull}/${this.month}/1`)
    },
    handleClick(type) {
      // type 为2 pay 为1 为confirm
      console.log('card pay')
      // 绑卡场景
      if (this.isDirectCardPay) {
         TRANSFER_BURRY.ADD_CARD();
      } else {
         TRANSFER_BURRY.PAY();
      }
      // lnwang  绑定新卡选择 pay
      CASHIER_BURRY.PAY()
      CASHIER_BURRY.CREDIT_CARD_ONLINE_PAY()
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.cppPay()
        } else {
          // lnwang  绑定新卡save card报告错误
          CASHIER_BURRY.ERROR(2)
          console.log('error submit!!');
          // lnwang
          if (type === '1') {
            if (this.isDirectCardPay) {
              TRANSFER_BURRY.ERROR(1);
            }
          } else {
            TRANSFER_BURRY.ERROR(2);
          }
          
          return false;
        }
        return ''
      })
    },
    openPicker() {
      console.log('openPicker')
      this.$refs.picker.open()
    },
    handleConfirm(date) {
      console.log(date)
      const month = MONTH[date.getMonth()]
      console.log(date.getMonth())
      const yearfull = String(date.getFullYear())
      const year = yearfull.substring(2)
      this.ruleForm.date = `${month}/${year}`
      this.month = month
      this.yearfull = yearfull
    },
    changeSaveFlag() {
      this.saveFlag = !this.saveFlag
      CASHIER_BURRY.CREDIT_CARD_ONLINE_SAVE_CARD()
      if (this.saveFlag === 'true') {
        TRANSFER_BURRY.SAVE_CARD()
      } else {
        // lnwang  绑定新卡选择save card
        CASHIER_BURRY.SAVE_CARD()
      }
      
    },
    async cppPay() {
      if (!this.orgCode) {
        this.$toast({
          message: this.$t('Unsupported card. Please try other cards'),
          position: 'middle',
          duration: 3000
        })
        return
      }
      // if (this.showloading) {
      //   return
      // }
      // this.showloading = true
      let tempCardDataObj = {}
      const payMethodModelList = this.computeInitData.payMethodModelList
      payMethodModelList.forEach((item) => {
        if (item.payMethodCodeFirst === enumPayMethodCodeFirst.CCP && item.payMethodCodeSecond === enumPayMethodCodeSecond.SPECIAL) {
          tempCardDataObj = item
        }
      })
      const deviceInfoObj = await this.$SDK.getCommonInfo()
      this.$DeviceInfo = deviceInfoObj
      let transactionNo
      if (this.isDirectCardPay) {
        transactionNo = this.$route.query.transactionNo
      } else {
        transactionNo = this.transactionNo
      }
      const commonReqData = {
        transactionNo,
        paymentMethod: tempCardDataObj.payMethodCodeFirst,
        paymentMethod2: tempCardDataObj.payMethodCodeSecond,
        paymentMethod3: '',
        paymentAmount: this.computeInitData.payOrderModel.amount,
        deviceInfo: escape(JSON.stringify(this.$DeviceInfo)),
        clientInfo: escape(JSON.stringify(this.$ClientInfo)),
        creditCardInfo: {
          saveCardFlag: this.saveFlag,
          cardNo: this.ruleForm.cardNumber.replace(/\s/g, ''),
          cardHolder: this.ruleForm.cardHolder,
          expiryMonth: this.month,
          expiryYear: this.yearfull,
          cardType: '',
          bankName: '',
          cvv: this.ruleForm.cvv,
          cardOrgCode: this.orgCode
        },
        cashierStyle: this.computeInitData.cashierStyle.code
      }
      this.firstReqData = { ...commonReqData }
      this.$indicator.open({
        text: 'Loading...',
        spinnerType: 'fading-circle'
      })
      let cdcpType = 'cdcp'
      if (this.isDirectCardPay === true) {
        cdcpType = 'cashierCdcp'
      }
      const payret = await this.switchPay(enumPayMethodCodeFirst.CCP, commonReqData, () => {
        this.$indicator.close()
      }, cdcpType)
      console.log(payret)
      this.$emit('cdcpOk')
    },
    async cardOrgQuery(num = '') {
      const numClear = num.replace(/\s/g, '')
      this.orgCode = ''
      this.bankLogo = ''
      // 卡中心限制最小八位， 八位一下查询回抛异常
      if (numClear.length < 13) {
        return
      }
      const ret = await cardOrgQuery({
        cardNo: numClear
      })
      console.log(ret.data)
      if (!ret.data || !ret.data.resultData) {
        this.bankLogo = ''
        return
      }
      const creditCardOrgModelList = this.computeInitData.creditCardOrgModelList || []
      creditCardOrgModelList.forEach((item) => {
        if (item.orgCode === ret.data.resultData.orgCode) {
          this.orgCode = ret.data.resultData.orgCode
          this.bankLogo = item.h5LogoUrl
        }
      })
    },
    showCVVInfo() {
      console.log(123)
      if (this.isDirectCardPay) {
        TRANSFER_BURRY.CCV_INFO_ICON(2);
      } else {
        // lnwang 增加埋点
        TRANSFER_BURRY.CCV_INFO_ICON(1);
      }
      // this.$refs.messagebox.value = true
      // 此处message-box 不能通过再html模板中的方式引用，会出现 关闭messagebox弹窗的时候 无法关闭 modal遮罩的问题
      // 原因： 所有的modal为同一个modal, 如果messagebox嵌套再原来的cdcp内部，那么modal也会再cdcp内部，因此关闭messagebox后 modal会遮住cdcp
      // message-box-cashier-cdcp-cardinfo 样式再app.vue里有设置,此文件里css有scope所以设置了无法起作用
      const htm = `
      <div class="message-box-cashier-cdcp-cardinfo">
        <p class="title">CVV/CCV</p>
        <img
          src="${require('@/assets/images/cashier/the1/cvv@3x.png')}"
          class="img">
        <p class="txt">${this.$t('The')} <span class="bold">3 ${this.$t('digits')}</span> ${this.$t('onthebackofyourcreditcard')}</p>
      </div>`
      this.$messagebox({
        title: '',
        message: htm,
        confirmButtonText: this.$t('OK')
      })
    },
    cvvFocus() {
      console.log(123)
      this.cvvFocusFlag = false
    },
    cvvBlur() {
      // setTimeout(() => {
      this.cvvFocusFlag = true
      // }, 600)
    },
    cardInputFocus() {
      this.cardNumFocusFlag = false
    },
    cardInputBlur() {
      // 如果失去焦点后要判断是否有卡组织 来toast  需要判断有无卡组织 还要判断卡号位数，
      this.cardNumFocusFlag = true
    },
    closeWeb() {
      if (this.pendingBox) {
        this.pendingBox = false
      } else {
        this.$store.commit('setCdcpPendingBox', false)
      }
      this.$SDK.closeWebViewAndSendResult({ resultCode: 0 })
    },
    retryToPay() {
      this.showRetrydialog = false
      this.handleClick()
      console.log('retry')
    },
    goLeave() {
      // 绑卡场景关闭webview
      if (this.isDirectCardPay) {
         this.$SDK.closeWebViewAndSendResult({ resultCode: 0 })
      } else {
      // 收银台场景 关闭收银台
        this.$parent.$parent.$parent.$emit('update:cashierVisible', false)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.cdcp {
  font-size: .14rem;
  .banner {
    padding: 0 .36rem;
    height: .84rem;
    background: $color-gray-i;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .left {
      .img {
        height: .48rem;
        padding-right: .1rem;
      }
    }
    .right {
      .img {
        height: .46rem;
      }
    }
  }
  .cdcp-form {
    padding: 0 .36rem;
    .item-container {
      position: relative;
      .custom-ico {
        position: absolute;
        top: .5rem;
        right: 0rem;
        width: .6rem;
      }
      .cvv-info {
        position: absolute;
        top: .35rem;
        right: -0.1rem;
        width: .28rem;
        padding: .3rem;
      }
      .border {
        height: 1px;
        background-color: $color-gray-f;
      }
    }
  }
  .savecard {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    padding-left: .4rem;
    padding-top: .6rem;
    .saveimg {
      width: .4rem;
      height: .4rem;
    }
    .savetxt {
      font-size: .36rem;
      color: $color-gray-h;
      padding-left: .2rem;
    }
  }
  .save-card-txt {
    font-size: .24rem;
    color: $color-gray-f;
    padding: .4rem .3rem;
  }
  .imitate-input {
    position: relative;
    // padding-top: .4rem;
    // padding-bottom: .4rem;
    height: 0.8rem;
    padding-top: 0.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: .4rem;
    color: $color-gray-g;
    border-bottom: .02rem solid $color-gray-f;
    .imitate-holder-txt {
      font-size: 14px;
      color: $color-gray-f;
      position: absolute;
      top: 0.5rem;
      font-size: .4rem;
    }
    .imitate-input-tip-focus {
      top: 0.25rem;
      font-size: 14px;
    }
    .txt {
      color: $color-gray-g;
    }
    .custom-ico-arrow {
      color: $color-gray-f;
      margin-bottom: .2rem;
    }
  }
  .btn-wrapper {
    padding-top: .6rem;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    margin-left: 50%;
    transform: translateX(-50%);
    width: 6.7rem;
  }
  .rule-form-item {
    margin-top: .2rem;
  }
}
</style>
