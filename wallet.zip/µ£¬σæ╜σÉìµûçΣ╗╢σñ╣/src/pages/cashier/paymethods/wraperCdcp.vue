<template>
  <common-popup
    v-model="show"
    position="right"
    style="width:100%;height:100%"
  >
    <button
      v-if="textBtn"
      @click="test">text</button>
    <cdcp
      :cashier-init-info = "dataObj"
      :transaction-no = "transactionNo"
      :current-busi-type-proxy= "currentBusiType"
      @cdcpOk = "$emit('cdcpOk')"
    />
  </common-popup>
</template>
<script>
import cdcp from '@/pages/cashier/paymethods/cdcp'
import * as CASHIER_BURRY from '@/pages/burry/cashier'

export default {
  name: 'WraperCdcp',
  components: { cdcp },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dataObj: {
      type: Object,
      default: () => {}
    },
    currentIndex: {
      type: Number,
      default: 0
    },
    transactionNo: {
      type: String,
      default: ''
    },
    currentBusiType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      textBtn: false
    }
  },
  computed: {
    show: {
      get() {
        return this.visible
      },
      set(val) {
        this.$emit('update:visible', val)
      }
    }
  },
  created() {
    // this.$SDK.setTitle({
    //   title: this.$t('creditCard')
    // })
    console.log('cdcp加载了')
    CASHIER_BURRY.CREDIT_CARD_ONLINE_ENTRY()
    this.$SDK.onBackPress(() => {
      console.log('onBackPress')
      CASHIER_BURRY.CREDIT_CARD_ONLINE_BACK()
      CASHIER_BURRY.CREDIT_CARD_ONLINE_LEAVE()
      CASHIER_BURRY.BACK(6)
      this.$emit('update:visible', false)
    })
  },
  destroyed() {
  },
  methods: {
    test() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

