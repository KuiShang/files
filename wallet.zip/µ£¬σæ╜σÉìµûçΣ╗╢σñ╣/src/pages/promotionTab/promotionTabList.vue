<template>
  <div class="promotion-tab-list" v-if="resultData && resultData.length">
    <template v-if="scence === 0">
      <div
        v-for="(item, index) in resultData"
        :key="`${item.componentName}${index}`">
        <!-- picture_banner -->
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'picture_banner'">
          <picture-banner :props-data="item.componentInfos[0]" />
        </template>
        <!-- couponList组件 -->
        <template v-if="item.componentName === 'Couponlist'">
          <coupon-list :props-data="item" />
        </template>
        <!-- couponGroup组件 -->
        <template v-if="item.componentName === 'Coupon Group'">
          <coupon-group :props-data="item" />
        </template>
        <!-- the 1 info组件 -->
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'The 1 info banner'">
          <the-one-info :props-data="item.componentInfos[0]"/>
        </template>
        <!-- 轮播图组件 -->
        <template v-if="item.componentName === 'Banner'">
          <slider-wrapper :props-data="item" />
        </template>
        <!-- the1 itemList2组件 -->
        <template v-if="item.componentName === 'itemlist2'">
          <item-list2  :promotion-bottom-data="item" />
        </template>
        <template v-if="item.componentName === 'TaskList'">
          <promotion-top :promotion-top-data="item" />
        </template>
        <template v-if="item.componentName === 'ItemList'">
          <promotion-bottom  :promotion-bottom-data="item" />
        </template>
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'Middle_Icon'">
          <img-wrapper :top-image="item.componentInfos[0]" />
        </template>
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'Content'">
          <content-wrapper :content-html="item.componentInfos[0]" />
        </template>
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'Button on bottom'">
          <button-wrapper :button-data="item.componentInfos[0]" />
        </template>
        <template v-if="item.componentInfos && item.componentInfos.length && item.componentName === 'Banner-label'">
          <thumbnail
            :thumbnail-style="thumbnailStyle"
            :banner-label="item.componentInfos[0]"/>
        </template>
      </div>
    </template>
    <template v-if="scence === 1 && resultData.length">
      <div
        v-if="seeAllList && seeAllList.length"
        :style="{top: $utils.getSysType('isJdApp') === false ? '0.88rem' : '0'}"
        class="all-tab">
        <scroll
          ref="scroll"
          class="all-tab-content"
          :data="seeAllList"
          :isSupportUpdate="true"
          :hasNewData="hasNewData"
          :completePullUpDate="completePullUpDate"
          @complete="completeFn">
          <div>
            <template v-if="resultData[0].componentName === 'TaskList'">
              <task-list-all :resultData="seeAllList"></task-list-all>
            </template>
            <template v-if="resultData[0].componentName === 'Couponlist'">
              <all-coupon :resultData="seeAllList"></all-coupon>
            </template>
            <template v-if="resultData[0].componentName === 'Banner'">
              <banner-list :resultData="seeAllList"></banner-list>
            </template>
          </div>
        </scroll>
      </div>
    </template>
  </div>
</template>

<script>
import promoMixin from '@/mixins/promotionTab';

export default {
  name: 'PromotionTabList',
  mixins: [promoMixin]
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.all-tab {
  // padding-top: 0.2rem;
  position: absolute;
  padding-top: 0.2rem;
  top: 0;
  bottom: 0;
  overflow: hidden;
  width: 100%;
  background: #F3F3F6;
}
.all-tab-content {
  height: 100%;
}
</style>
