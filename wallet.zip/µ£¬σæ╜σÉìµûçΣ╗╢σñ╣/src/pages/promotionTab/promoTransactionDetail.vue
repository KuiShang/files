<template>
  <div v-if="dataObj" class="result">
      <div class="head">
        <!-- <div class="fle-container">
          <img v-if="dataObj.logo" :src="dataObj.logo" class="img" alt="">
          <span class="txt-title">{{logoName}}</span>
        </div> -->
        <div class="money-wrapper">
          <div class="point">{{$t('the1Points')}}</div>
          <p class="txt-money" v-show="dataObj.point">+{{dataObj.point | thousandBitSeparator}}</p>
        </div>
      </div>
      <ul class="list">
        <li class="item">
          <span class="key">{{$t('the1PayMethod')}}</span>
          <span>{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{$t('the1PayTo')}}</span>
          <div class="fle-container">
            <img v-if="dataObj.logo" :src="dataObj.logo" class="img" alt="">
            <span class="txt-title">{{logoName}}</span>
          </div>
        </li>
        <li class="item">
          <span class="key">{{$t('the1TransactionTime')}}</span>
          <span>{{transactionTime}}</span>
        </li>
        <li class="item">
          <span class="key">{{$t('the1PaymentAmount')}}</span>
          <span>฿ {{dataObj.amount | thousandBitSeparator}}</span>
        </li>
      </ul>
</div>
</template>
<script>
  /**截止到2018-07-09，支持的交易类型有充值和转账
   * 转账：
   *     账户分为2种——余额账户和银行账户，关键的字段是balancePayFlag（true表示余额相关）,inOutFlag（"+":入款; "-":出款）
   *     转账情况有4种
   *     1、余额转银行，
   *     2、余额转余额，
   *     3、银行转余额，
   *     4、他到他人转账到余额
   *
   * */
  import moment from "moment";
  import {queryT1PDetail}  from '@/api';
  import { enumPayMethodCodeFirst, CASHIER_PAYMENT_METHODS } from '@/utils/const';
  import { mapGetters } from 'vuex';
  import handlInitData from '@/mixins/handlInitData';

  export default {
    name: 'PromoTransactionDetail',
    mixins: [handlInitData],
    data() {
      return {
        dataObj: {}
        // dataObj: {
        //   "logo":"http://wiki.cbpmgt.com/confluence/s/zh_CN/5638/166de1c97785b23076ca9b543dbfab25c6f13e92.57/_/favicon.ico",
        //   "point": 10000,
        //   "amount": 10000,
        //   "tt": '{"en": "Family Mart", "th": "TH Family Mart"}',
        //   "time": new Date().getTime(),
        //   "paymethod": "ODD.KBANK"
        // }
      }
    },
    computed: {
      logoName() {
        let title = '';
        if (this.dataObj.tt) {
          if (typeof this.dataObj.tt === 'string') {
            title = JSON.parse(this.dataObj.tt);
          } else {
            title = this.dataObj.tt;
          }
          if (title[this.language.toLowerCase()]) {
            return title[this.language.toLowerCase()];
          }
          return '';
        }
        return '';
      },
      amountText(){
        let data = this.dataObj || {}
        let amount = Number(data.amount || 0).toFixed(2)
        // return  (amount ? (data.inOutFlag ? data.inOutFlag + " " : "")  : "") + "฿ " + amount 
        return amount = Number(data.amount || 0);
      },
      transactionTime(){
        return this.dataObj && this.dataObj.time ?
          moment(this.dataObj.time).locale(this.language.toLowerCase()).format("DD MMM YYYY, HH:mm") : "";
      },
      /**内容的显示格式为：银行编码(银行卡号后4位)
       * 注意：数据都有为null的可能，增加容错性
       * */
      paymentMethodText(){
        if (!this.dataObj.paymethod) {
          return '';
        }
        if (this.dataObj.paymethod.split('.')[0] === enumPayMethodCodeFirst.ODD) {
          const last4Num = this.dataObj.payAccountNo ? this.dataObj.payAccountNo.slice(-4) : ''
          // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
          // 产品貟慧要求 去掉 卡号后四位
          return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.paymethod])}`
          // return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.paymethod])} (${last4Num})`
        } else if (this.dataObj.paymethod.split('.')[0] === enumPayMethodCodeFirst.BALA) {
          // return this.dataObj.payMethodCodeFirst
          // return 'Balance'
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.paymethod]);
        } else if (this.dataObj.paymethod.split('.')[0] === enumPayMethodCodeFirst.OFLN) {
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.paymethod]);
        } else if (this.dataObj.paymethod.split('.')[0] === enumPayMethodCodeFirst.CCP) {
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.paymethod]);
        }
        return '';
      },
      ...mapGetters(['language'])
    },
    beforeRouteLeave (to, from, next) {
      this.$indicator.close()
      next()
    },
    created() {
      this.initData()
      this.$SDK.setTitle({
        title: this.$t('the1PointDetail'),
        mHeaderTitle: {
          showHead: 1,
          showBack: 1,
          showEnd: 0
        }
      })
    },
    methods: {
      async initData() {
        let query = this.$route.query, queryAPI, postData;
        /**customerId, 客户唯一标识
         * tranNo, 交易单号
         * tranType, 交易类别
         * bizSystem, 业务系统
         * */
        queryAPI = queryT1PDetail;
        postData = {...query};
        this.$indicator.open({
          text: 'Loading...',
          spinnerType: 'fading-circle'
        })
        const res = await queryAPI(postData);
        console.log('res', res)
        this.$indicator.close()
        this.handlInitData(res)
      }
    }
  }
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
  .result {
    height: 100%;
    background-color: #f6f6f6;
    .head {
      background-color: #fff;
      box-sizing: border-box;
      text-align: center;
      padding-top: .4rem;
      .fle-container {
        display: flex;
        justify-content: center;
        align-items: center;
        .img {
          width: 0.4rem;
          height: .4rem;
          border-radius: 50%;
        }
        .txt-title {
          text-align: center;
          padding-left: .2rem;
          font-family: The1Official_Bold;
          font-size: .28rem;
          color: $color-gray-h;
        }
      }
      .money-wrapper {
        .point {
          font-family: The1Official_Bold;
          font-size: 0.28rem;
          color: #4F577C;
        }
        .txt-money {
          font-size: .92rem;
          text-align: center;
          line-height: 1.44rem;
          height: 1.44rem;
          font-family: The1Official_Bold;
          font-size: .96rem;
          color: $color-red;
          padding-bottom: 0.64rem;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
    }
    .list {
      background-color: #fff;
      padding: 0 .4rem;
      margin-top: .2rem;
      padding-top: .2rem;
      padding-bottom: .2rem;
      .item {
        display: flex;
        justify-content: space-between;
        word-break: break-all;
        padding-top: .2rem;
        padding-bottom: .2rem;
        // height: .9rem;
        line-height: .9rem;
        font-size: .28rem;
        color: $color-gray-h;
        text-align: right;
        line-height: .52rem;
        .key {
          color: $color-gray-f;
        }
        span {
          // line-height: .9rem;
          max-width: 46%;
          color: #141E50;
        }
        .fle-container {
          flex: 1;
          display: flex;
          justify-content: flex-end;
          align-items: center;
          .img {
            width: 0.4rem;
            height: .4rem;
            border-radius: 50%;
          }
          .txt-title {
            text-align: center;
            padding-left: .2rem;
            font-size: .28rem;
            color: $color-gray-h;
          }
        }
      }
    }
  }
</style>
