<template>
  <div class="promotion-wrapper" >
    <div class="promotion-wrapper-top" v-if="JSON.stringify(promotionTopData) !== {}">
      <div class="promotion-wrapper-top-title clearFix">
        <div class="title-l" v-if="promotionTopData.layoutTitle1">{{ promotionTopData.layoutTitle1 }}</div>
        <div
          v-if="promotionTopData.total>3"
          class="title-r"
          @click="handleClick">
          <span class="more">{{ promotionTopData.layoutTitle2 ? promotionTopData.layoutTitle2 : 'See All' }}</span>
        </div>
      </div>
      <ul class="promotion-item-list content-radius" v-if="promotionTopData.componentInfos && promotionTopData.componentInfos.length">
        <li
          v-for="(item, index) in promotionTopData.componentInfos"
          :key="index">
          <div
            :class="{'border-none': index === promotionTopData.componentInfos.length - 1}"
            class="promotion-item-wrapper">
            <promotion-item :promotion-item="item" />
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import PromotionItem from '@/pages/promotionTab/components/promotionItem/promotionItem';

export default {
  name: 'PromotionTabTop',
  components: {
    PromotionItem
  },
  props: {
    promotionTopData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  computed: {
    ...mapGetters(['pageId'])
  },
  data() {
    return {
    }
  },
  methods: {
    handleClick() {
      console.log(this.pageId);
      const json = this.$utils.linkToSeeAll(this.pageId, this.promotionTopData);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          this.$router.push(json);
          this.$router.go(0);
        }
      }
      // let query = {};
      // if (this.promotionTopData && JSON.stringify(this.promotionTopData) !== '{}') {
      //   query.componentId = this.promotionTopData.componentId;
      //   query.parentPageId = this.$route.query.pageId ? this.$route.query.pageId : 33;
      //   query.layoutId = this.promotionTopData.id;
      // }
      // if (this.$utils.getSysType('isJdApp')) {
      //   let querySearch = [];
      //   if (JSON.stringify(query) !== '{}') {
      //     for (const prop in query) {
      //       let searchStr = '';
      //       if (Object.prototype.hasOwnProperty.call(query, prop)) {
      //         searchStr += prop;
      //         searchStr += '=';
      //         searchStr += query[prop];
      //         querySearch.push(searchStr);
      //       }
      //     }
      //   }
      //   const json = {
      //     type: 'native',
      //     address: '/webview/web',
      //     params: {
      //       url: `${window.location.origin}/#/promotionAllTab?${querySearch.join('&')}`,
      //       textColor: '#141E50',
      //       title: 'Free Point',
      //       mHeaderTitle: {
      //         showEnd: 0
      //       }
      //     }
      //   };
      //   this.$SDK.goNativeAction(json);
      // } else {
      //   this.$router.push(
      //     {
      //       path: 'promotionAllTab',
      //       query
      //     }
      //   );
      // }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

.promotion-wrapper {
  padding: 0 0.4rem 0;
}

.promotion-wrapper-top {
  .content-radius{
    box-shadow: 0 0 0.4rem 0 rgba(161,165,185,0.3);
    border-radius: 0.2rem;
  }
  margin-bottom: 0.6rem;
  .promotion-wrapper-top-title {
    height: 0.6rem;
    padding-top: 0.54rem;
    margin-bottom: 0.24rem;
    line-height: 0.6rem;
    .title-l {
      float: left;
      font-size: 0.4rem;
      color: #141E50;
      letter-spacing: 0;
    }
    .title-r {
      float: right;
      font-size: 0.32rem;
      color: #A1A5B9;
      letter-spacing: 0;
      .more {
        vertical-align: top;
      }
    }
  }
  .promotion-item-list {
    background: $color-white;
    border-radius: 0.24rem;
    .promotion-item-wrapper {
      margin: 0 0.26rem 0 0.4rem;
      @include border-1px($color-gray-e);
      &.border-none {
        @include border-none();
      }
    }
  }
}
</style>
