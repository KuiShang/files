<template>
  <div class="task-list">
    <ul v-if="resultData.length">
      <li
        v-for="(item, index) in resultData"
        :class="{'border-none': index === resultData.length - 1}"
        :key="index">
        <div
          class="promotion-item-wrapper">
          <promotion-item :promotion-item="item"/>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import PromotionItem from '@/pages/promotionTab/components/promotionItem/promotionItem';
export default {
  name: 'TaskListAll',
  components: {
    PromotionItem
  },
  props: {
    resultData: {
      type: Array,
      default() {
        return []
      }
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/mixin.scss";
.task-list {
  ul {
    padding-left: 0.4rem;
    background: #fff;
    li {
      padding-right: 0.46rem;
      @include border-1px($color-gray-e);
      &.border-none {
        @include border-none();
      }
    }
  }
}
</style>
