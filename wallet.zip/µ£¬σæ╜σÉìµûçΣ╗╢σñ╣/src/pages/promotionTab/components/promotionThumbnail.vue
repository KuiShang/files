<template>
  <div
    class="thumbnail-wrapper"
    @click="handleClick">
    <thumbnail
      :thumbnail-style="thumbnailStyle"
      :banner-label="promotionItem"/>
    <div class="thumbnail-c" :style="{color: promotionItem.title2Color}">{{ promotionItem.title2 }}</div>
    <div class="thumbnail-b" :style="{color: promotionItem.title3Color}">{{ promotionItem.title3 }}</div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import Thumbnail from '@/pages/promotionTab/components/base/thumbnail/thumbnail';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';

export default {
  name: 'PromotionThumbnail',
  components: {
    Thumbnail
  },
  props: {
    promotionItem: {
      type: Object,
      default() {
        return {};
      }
    },
    burryName: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      thumbnailStyle: {
        wrapper: {
          height: '3.4rem'
        },
        img: {
          width: '0.6rem',
          height: '0.6rem',
          left: '0.3rem',
          bottom: '0.22rem'
        },
        content: {
          'padding-left': '1.06rem',
          'padding-right': '0.3rem',
          height: '0.6rem',
          'font-size': '0.28rem',
          'line-height': '0.48rem'
        }
      }
    }
  },
  computed: {
    imgList() {
      if (this.promotionItem.imageUrl) {
        return this.promotionItem.imageUrl.split('}}');
      }
      return '';
    },
    ...mapGetters(['language', 'promotionTracePoint'])
  },
  methods: {
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.promotionItem.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.promotionItem.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(this.promotionItem);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.thumbnail-wrapper {
  display: block;
  overflow: hidden;
  height: 4.72rem;
  box-shadow: 0 0.04rem 0.08rem 0 rgba(161,165,185,0.50);
  border-radius: 0.2rem;
  .thumbnail-c {
    padding-right: 0.3rem;
    margin-top: 0.16rem;
    margin-bottom: 0.12rem;
    margin-left: 0.3rem;
    font-size: 0.4rem;
    color: $color-gray-g;
    line-height: 0.48rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .thumbnail-b {
    padding-right: 0.3rem;
    margin-left: 0.3rem;
    font-size: 0.24rem;
    color: $color-gray-f;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
