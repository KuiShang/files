<template>
  <div class="banner-list" v-if="resultData && resultData.length">
    <ul>
      <li :key="key" v-for="(item, key) in resultData">
        <div class="box" @click="handleClick(item)">
          <div class="box-top-wrapper">
            <div class="box-top" v-if="item.imageUrl" v-lazy:background-image="item.imageUrl"></div>
          </div>
          <div class="box-bottom" :style="{'color': item.title1Color}">{{item.title1}}</div>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';

export default {
  name: 'BannerList',
  props: {
    resultData: {
      type: Array,
      default() {
        return []
      }
    },
  },
  computed: {
    ...mapGetters(['promotionTracePoint'])
  },
  methods: {
    handleClick(item) {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && item.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, item.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(item);
      console.log('json', json);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.banner-list {
  padding: 0 0.4rem 0;
  ul {
    li {
      margin-bottom: 0.4rem;
      &:last-child {
        margin-bottom: 0;
      }
      .box {
        width: 100%;
        height: 5.56rem;
        background: #FFFFFF;
        box-shadow: 0 0.02rem 0.08rem 0 rgba(0,0,0,0.12), 0 0.02rem 0.12rem 0 rgba(0,0,0,0.12);
        border-radius: 0.16rem;
        overflow: hidden;
        .box-top-wrapper {
          width: 100%;
          height: 3.76rem;
          .box-top {
            width: 100%;
            height: 3.76rem;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
          }
        }
        .box-bottom {
          padding: 0.2rem 0.4rem 0;
          font-family: The1Official_Bold;
          font-size: 0.36rem;
          color: #141E50;
          line-height: 0.6rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp:2;
          /*! autoprefixer: off */
          -webkit-box-orient: vertical;
          /* autoprefixer: on */
        }
      }
    }
  }
}
</style>
