<template>
  <div class="img-wrapper" v-if="JSON.stringify(topImage) !== '{}'">
    <img
      v-lazy="topImage.imageUrl"
      class="top-img" >
  </div>
</template>

<script>

export default {
  name: 'ImgWrapper',
  props: {
    topImage: {
      type: Object,
      default() {
        return {};
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.img-wrapper {
  padding: 0.66rem 0 0.64rem 0;
  text-align: center;
  .top-img {
    width: 1.26rem;
    height: 1.26rem;
    vertical-align: top;
    border-radius: 50%;
    box-shadow: 0 0.16rem 0.4rem 0 rgba(171,175,199,0.61);
  }
}
</style>