
<template>
  <div ref="wrapper">
    <div>
      <slot></slot>
      <div class="pullup-wrapper" v-if="!completePullUpDate">
        <div v-show="!completePullUpDate">
          <loading></loading>
        </div>
      </div>
      <div class="before-trigger" v-if="isSupportUpdate && !hasNewData">{{$t('notMoreData')}}</div>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll';
import Loading from './loading/loading';
import {mapMutations } from 'vuex';

export default {
  name: 'Scroll',
  components: {
    Loading
  },
  props: {
    completePullUpDate: {
      type: Boolean,
      default: true
    },
    hasNewData: {
      type: Boolean,
      default: true
    },
    probeType: {
      type: Number,
      default: 1
    },
    click: {
      type: Boolean,
      default: true
    },
    data: {
      type: Array,
      default: null
    },
    listenScroll: {
      type: Boolean,
      default: false
    },
    pullup: {
      type: Boolean,
      default: false
    },
    beforeScroll: {
      type: Boolean,
      default: false
    },
    refreshDelay: {
      type: Number,
      default: 20
    },
    isSupportUpdate: {
      type: Boolean,
      default: false
    }
  },
  mounted() {
    setTimeout(() => {
      this._initScroll()
    }, 20)
  },
  methods: {
    _initScroll() {
      if (!this.$refs.wrapper) {
        return
      }
      this.scroll = new BScroll(this.$refs.wrapper, {
        probeType: this.probeType,
        click: this.click,
        pullUpLoad: {
          threshold: -40
        }
      })
      this.scroll.on('scrollEnd', () => {
          console.log(this.scroll.y);
          this.setPromotionScrollY(this.scroll.y);
      })
      if (this.listenScroll) {
        let me = this
        this.scroll.on('scroll', (pos) => {
          me.$emit('scroll', pos)
        })
      }

      if (this.pullup) {
        this.scroll.on('scrollEnd', () => {
          if (this.scroll.y <= (this.scroll.maxScrollY + 50)) {
            this.$emit('scrollToEnd')
          }
        })
      }

      if (this.beforeScroll) {
        this.scroll.on('beforeScrollStart', () => {
          this.$emit('beforeScroll')
        })
      }
      if (this.isSupportUpdate) {
        this.scroll.on('pullingUp', () => {
          if (this.completePullUpDate) {
            console.log(1312);
            this.$emit('complete');
          }
          this.scroll.finishPullUp()
        })
      }
    },
    disable() {
      this.scroll && this.scroll.disable()
    },
    enable() {
      this.scroll && this.scroll.enable()
    },
    refresh() {
      this.scroll && this.scroll.refresh()
    },
    scrollTo() {
      this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
    },
    scrollToElement() {
      this.scroll && this.scroll.scrollToElement.apply(this.scroll, arguments)
    },
    ...mapMutations({
      setPromotionScrollY: 'SET_PROMOTION_SCROLL_Y'
    })
  },
  watch: {
    data() {
      setTimeout(() => {
        this.refresh()
      }, this.refreshDelay)
    }
  }
}
</script>

<style scoped lang="scss">
@import "@/assets/css/var.scss";
.pullup-wrapper {
    width: 100%;
    transition: all;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0.2rem 0;
  }

  .before-trigger {
    padding: 0.4rem 0;
    text-align: center;
    font-size: 0.32rem;
    color: $color-gray-f;
  }
</style>
