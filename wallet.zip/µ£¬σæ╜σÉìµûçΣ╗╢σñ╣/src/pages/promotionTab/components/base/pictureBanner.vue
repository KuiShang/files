<template>
  <div class="picture-banner" v-if="JSON.stringify(propsData) !== '{}'">
    <div v-lazy:background-image="propsData.imageUrl" class="top-img"></div>
  </div>
</template>

<script>

export default {
  name: 'PictureBanner',
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.picture-banner {
  .top-img {
    width: 100%;
    height: 4.2rem;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
  }
}
</style>