<template>
  <div
    v-if="JSON.stringify(bannerLabel) !== '{}'"
    :style="thumbnailStyle.wrapper"
    v-lazy:background-image="imgList[0] ? imgList[0] : ''"
    class="thumbnail-t">
    <img
      v-show="isShadow"
      src="./boxShadow@3x.png"
      class="box-shadow">
    <img
      :style="thumbnailStyle.img"
      v-lazy="imgList[1] ? imgList[1] : ''" 
      class="thumbnail-left">
    <div
      :style="[thumbnailStyle.content, {color: bannerLabel.title1Color}]"
      class="thumbnail-t-content">{{ bannerLabel.title1 }}</div>
  </div>
</template>
<script>
export default {
  name: 'Thumbnail',
  props: {
    thumbnailStyle: {
      type: Object,
      default: () => {}
    },
    isShadow: {
      type: Boolean,
      default: false
    },
    bannerLabel: {
      type: Object,
      default: () => {}
    }
  },
  computed: {
    imgList() {
      if (this.bannerLabel.imageUrl) {
        return this.bannerLabel.imageUrl.split('}}');
      }
      return '';
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.thumbnail-t {
  position: relative;
  overflow: hidden;
  width: 100%;
  background-position: center;
  background-size: cover;
  .box-shadow {
    width: 100%;
    height: 1.8rem;
  }
  .thumbnail-left {
    position: absolute;
    z-index: 10;
    border-radius: 50%;
  }
  .thumbnail-t-content {
    position: absolute;
    left: 0;
    right: 0;
    background: rgba(0,0,0,0.70);
    bottom: 0;
    color: $color-white;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
