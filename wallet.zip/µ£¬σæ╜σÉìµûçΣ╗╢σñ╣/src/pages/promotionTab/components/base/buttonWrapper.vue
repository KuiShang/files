<template>
  <div class="button" v-if="JSON.stringify(buttonData) !== '{}'">
    <common-button
      type="danger"
      :style="{color: buttonData.title1Color}"
      @click="handleClick">{{ buttonData.title1 }}</common-button>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';

export default {
  name: 'ButtonWrapper',
  props: {
    buttonData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  computed: {
    ...mapGetters(['promotionTracePoint'])
  },
  methods: {
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.buttonData.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.buttonData.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(this.buttonData);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>

.button {
  display: flex;
  justify-content: center;
  z-index: 20;
  width: 100%;
  text-align: center;
  padding: 0.4rem 0;
  position: fixed;
  bottom: 0;
}
</style>

