<template>
  <div class="slider" ref="slider">
    <div class="slider-group" ref="sliderGroup">
      <slot></slot>
    </div>
    <div class="dots">
      <span v-for="(item, index) in dots" class="dot" :key="index"
      :class="{active : index === currentPageIndex}"></span>
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll';

export default {
  props: {
    loop: {
      type: Boolean,
      default: true
    },
    autoPlay: {
      type: Boolean,
      default: true
    },
    click: {
      type: Boolean,
      default: true
    },
    interval: {
      type: Number,
      default: 4000
    }
  },
  data () {
    return {
      dots: [],
      currentPageIndex: 0
    }
  },
  mounted () {
    setTimeout(() => {
      this._setSliderWidth()
      this._initDots()
      this._initSlider()

      if (this.autoPlay) {
        this._play()
      }
    }, 20)

    window.addEventListener('resize', () => {
      if (!this.slider) {
        return
      }
      this._setSliderWidth(true)
    })
  },
  methods: {
    _initDots() {
      this.dots = this.children.length / 3
    },
    _setSliderWidth(isResize) {
      this.children = this.$refs.sliderGroup.children
      let width = 0
      let sliderWidth = this.$refs.slider.clientWidth
      for (let i = 0; i < this.children.length; i++) {
        const child = this.children[i]
        this.addClass(child, 'slider-item')
        child.style.width = sliderWidth + 'px'
        width += sliderWidth
      }
      if (this.loop & !isResize) {
        width += 2 * sliderWidth
      }
      this.$refs.sliderGroup.style.width = width + 'px'
    },
    addClass(el, className) {
      if (this.hasClass(el, className)) {
        return
      }
      let newClass = el.className.split(' ')
      newClass.push(className)
      el.className = newClass.join(' ')
    },
    hasClass(el, className) {
      let reg = new RegExp('(^|\\s)' + className + '(\\s|$)')
      return reg.test(el.className)
    },
    _initSlider() {
      this.slider = new BScroll(this.$refs.slider, {
        scrollX: true,
        scrollY: false,
        momentum: false,
        click: this.click,
        eventPassthrough: 'vertical',
        snap: {
          loop: this.loop,
          threshold: 0.3,
          speed: 400
        }
      })

      this.slider.on('scrollEnd', () => {
        let pageIndex = this.slider.getCurrentPage().pageX
        this.currentPageIndex = pageIndex % this.dots

        if (this.autoPlay) {
          clearTimeout(this.timer)
          this._play()
        }
      })
    },
    _play() {
      this.timer = setTimeout(() => {
        this.slider.next()
      }, this.interval)
    }
  },
  destroyed () {
    clearTimeout(this.timer)
  }
}
</script>

<style lang="scss" scoped>
.slider {
  min-height: 1px;
  position: relative;
  .slider-group {
    position: relative;
    overflow: hidden;
    white-space: nowrap;
    .slider-item {
      float: left;
      box-sizing: border-box;
      overflow: hidden;
      text-align: center;
      .item-wrapper {
        position: relative;
        display: block;
        width: 100%;
        height: 100%;
        overflow: hidden;
        text-decoration: none;
      }
      .item-background {
        display: block;
        width: 100%;
        height: 4.2rem;
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
      }
      .item-content {
        position: absolute;
        left: 0;
        right: 0;
        bottom: -0.02rem;
        top: 0;
        background-image: linear-gradient(-180deg, rgba(0,0,0,0.00) 66%, rgba(0,0,0,0.20) 75%, #000000 100%);
        .content {
          margin: 4.04rem 0.4rem 0;
          font-size: 0.36rem;
          white-space: normal;
          color: #FFFFFF;
          letter-spacing: 0;
          text-align: left;
          line-height: 0.6rem;
          text-shadow: 0 0.02rem 0.12rem rgba(0,0,0,0.24);
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp:2;
          /*! autoprefixer: off */
          -webkit-box-orient: vertical;
          /* autoprefixer: on */
        }
      }
    }
  }
  .dots {
    position: absolute;
    right: 0;
    left: 0;
    bottom: 0.26rem;
    font-size: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    .dot {
      margin: 0 0.1rem;
      width: 0.08rem;
      height: 0.08rem;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.5);
      &.active {
        width: 0.16rem;
        height: 0.16rem;
        border-radius: 50%;
        background: #fff;
      }
    }
  }
}
</style>
