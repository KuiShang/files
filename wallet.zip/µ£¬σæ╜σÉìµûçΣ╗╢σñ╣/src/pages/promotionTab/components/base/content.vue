<template>
  <div
    class="promotion—tab-content"
    v-if="JSON.stringify(contentHtml) !== '{}'"
    v-html="contentHtml.content" />
</template>

<script>

export default {
  name: 'Content',
  props: {
    contentHtml: {
      type: Object,
      default() {
        return {};
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.promotion—tab-content {
  box-sizing: border-box;
  padding: 0.3rem 0.4rem 0;
  width: 100%;
  overflow: hidden;
  font-size: 0.32rem;
}
</style>