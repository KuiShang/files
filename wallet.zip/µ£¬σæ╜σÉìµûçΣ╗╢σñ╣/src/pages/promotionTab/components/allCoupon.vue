<template>
  <div class="content" v-if="resultData && resultData.length">
    <ul>
      <li :key="key" v-for="(item, key) in resultData">
        <coupon-item :item-data="item" />
      </li>
    </ul>
  </div>
</template>
<script>
import CouponItem from '@/pages/promotionTab/components/coupon/coupon';
export default {
  name: 'AllCoupon',
  components: {
    CouponItem
  },
  props: {
    resultData: {
      type: Array,
      default() {
        return []
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.content {
  padding: 0 0.4rem 0;
  ul {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-bottom: -0.14rem;
    li {
      width: 3.24rem;
      height: 4.72rem;
      margin-bottom: 0.2rem;
    }
  }
}
</style>
