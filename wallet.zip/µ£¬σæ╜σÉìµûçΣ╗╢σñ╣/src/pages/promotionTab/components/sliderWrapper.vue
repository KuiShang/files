<template>
  <div class="slider-wrapper" >
    <div class="slider-top">
      <div class="slider-top-l">{{propsData.layoutTitle1}}</div>
      <div class="slider-top-r" @click="goSeeAll" v-if="propsData.total > 4">
        {{propsData.layoutTitle2 ? propsData.layoutTitle2 : 'See All'}}
      </div>
    </div>
    <div style="width: 100%;height: 4.2rem;" v-if="JSON.stringify(propsData) !== '{}' && propsData.componentInfos.length && silderArr.length">
      <slider>
        <div v-for="(item, index) in silderArr" :key="index">
          <div class="item-wrapper needsclick" @click="handleClick(item)">
            <!-- <div class="item-background" v-lazy:background-image="item.imageUrl"></div> -->
            <div class="item-background" :style="{'background-image': `url('${item.imageUrl}')`}"></div>
            <!-- <div class="item-content"> 
              <div class="content" :style="{color: item.title1Color}">{{item.title1}}</div>
            </div> -->
          </div>
        </div>
      </slider>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';
import Slider from '@/pages/promotionTab/components/base/silder';

export default {
  name: 'SliderWrapper',
  components: {
    Slider
  },
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      silderArr: []
    }
  },
  computed: {
    ...mapGetters(['promotionTracePoint', 'pageId'])
  },
  mounted() {
    this.silderArr = this.silderArr.concat(this.propsData.componentInfos,
      this.propsData.componentInfos, this.propsData.componentInfos)
  },
  methods: {
    goSeeAll() {
      console.log(this.pageId);
      const json = this.$utils.linkToSeeAll(this.pageId, this.propsData);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          this.$router.push(json);
          this.$router.go(0);
        }
      }
    },
    handleClick(item) {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && item.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, item.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(item);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    },
    loadImage() {
      if (!this.checkLoaded) {
        this.$refs.scroll.refresh();
        this.checkLoaded = true;
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

.slider-wrapper {
  position: relative;
  width: 100%;
  overflow: hidden;
  padding-bottom: 0.2rem;
  .slider-top {
    height: 1.2rem;
    display: flex;
    box-sizing: border-box;
    padding: 0.4rem 0.4rem 0.2rem;
    justify-content: space-between;
    align-items: center;
    .slider-top-l {
      font-size: 0.4rem;
      color: #141E50;
    }
    .slider-top-r {
      font-size: 0.36rem;
      color: #A1A5B9;
    }
  }
}
</style>
