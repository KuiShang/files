<template>
  <div class="wrapper">
    <div class="title">
      <div class="title-l">{{propsData.layoutTitle1}}</div>
      <div class="title-r" @click="goSeeAll" v-if="propsData.total > 6">
        {{propsData.layoutTitle2 ? propsData.layoutTitle2 : 'See All'}}
      </div>
    </div>
    <div class="content" v-if="propsData.componentInfos && propsData.componentInfos.length">
      <ul>
        <li :key="key" v-for="(item, key) in propsData.componentInfos">
          <coupon-item :item-data="item" />
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import CouponItem from '@/pages/promotionTab/components/coupon/coupon';
export default {
  name: 'CouponList',
  components: {
    CouponItem
  },
  props: {
    propsData: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      
    }
  },
  computed: {
    ...mapGetters(['pageId'])
  },
  mounted() {
    console.log(55555555);
    console.log(this.propsData);
    console.log(55555555);
  },
  methods: {
    goSeeAll() {
      console.log(this.pageId);
      const json = this.$utils.linkToSeeAll(this.pageId, this.propsData);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          this.$router.push(json);
          this.$router.go(0);
        }
      }
    },
    handleClick() {
      const json = this.$utils.setJumpUrl(this.promotionItem);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.wrapper {
  .title {
    padding: 0 0.4rem 0;
    margin-top: 0.54rem;
    margin-bottom: 0.24rem;
    line-height: 0.6rem;
    display: flex;
    justify-content: space-between;
    .title-l {
      font-size: 0.4rem;
      color: #141E50;
      letter-spacing: 0;
    }
    .title-r {
      font-size: 0.32rem;
      color: #A1A5B9;
    }
  }
  .content {
    padding: 0 0.4rem 0;
    ul {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      justify-content: space-between;
      margin-bottom: -0.14rem;
      li {
        // width: 3.24rem;
        // width: 3.48rem;
        // height: 4.96rem;
        width: 3.24rem;
        height: 4.72rem;
        margin-bottom: 0.2rem;
      }
    }
  }
}
</style>
