<template>
  <div class="my-coupon">
    <div class="position-under"></div>
    <div class="coupon-wrapper">
      <div class="content-wrapper">
        <div @click="handleClick">
          <div class="content-top" v-lazy:background-image="imgList[0] ? imgList[0] : ''">
            <div class="content-bg">
              <div class="title">
                <div class="icon">
                  <div class="icon-img" v-lazy:background-image="imgList[1] ? imgList[1] : ''"></div>
                </div>
                <div class="message" :style="{'color': itemData.title1Color}">{{itemData.title1}}</div>
              </div>
              <div class="run-out" v-show="couPonStatus === 2"></div>
            </div>
          </div>
          <div class="content-center" :style="{'color': itemData.title2Color}">{{itemData.title2}}</div>
        </div>
        <div class="content-bottom">
          <div class="button button-get" v-if="couPonStatus === 0" @click="getCoupon">{{$t('discoveryGetCoupon')}}</div>
          <div class="button button-view" v-if="couPonStatus === 1" @click="gotoMyCoupon">{{$t('discoveryViewCoupon')}}</div>
          <div class="run-out" v-if="couPonStatus === 2">{{$t('discoveryRunOut')}}</div>
        </div>
      </div>
    </div>
    <toast
      v-if="showDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      :is-promotion="isPromotion"
      :scroll-y="scrollY"
      @closeDialog="goKYC"
      @cancle="cancel"
    >
      <p style="fontSize: 0.4rem;font-family: The1Official_Bold;" slot="title">{{ $t('discoveryKYCTitle') }}</p>
      <p style="fontSize: 0.36rem;" slot="content">{{ $t('discoveryKYC') }}</p>
      <p slot="cancle">{{ $t('discoveryCancel') }}</p>
      <p slot="confirm">{{ $t('discoveryConfirm') }}</p>
    </toast>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';
import Toast from '@/pages/balance/common/dialog';
import handlInitData from '@/mixins/handlInitData';
import { DiscoverygetCoupon } from '@/api'
export default {
  name: 'Coupon',
  components: {
    Toast
  },
  mixins: [handlInitData],
  props: {
    itemData: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      isPromotion: false,
      scrollY: 0,
      repeatInit: false,
      showDialog: false,
      detailLink: '',
      defaultCouponStatus: 0, // 0:get, 1: view coupon, 2: run out
      businessData: {},
      KYCData: ''
    }
  },
  computed: {
    imgList() {
      if (this.itemData.imageUrl) {
        return this.itemData.imageUrl.split('}}');
      }
      return '';
    },
    couPonStatus() {
      // 当前是否有返回的状态码
      if (this.dataObj.activityStatus && typeof this.dataObj.activityStatus === 'number') {
        console.log('this.dataObj.activityStatus', this.dataObj.activityStatus);
        // 1 go to my coupon
        // 2 get
        // 3 run out
        let map = new Map();
        map.set(1, 1);
        map.set(2, 0);
        map.set(3, 2);
        return map.get(this.dataObj.activityStatus);
      } else {
        return this.defaultCouponStatus;
      }
    },
    ...mapGetters(['promotionTracePoint', 'promotionScrollY'])
  },
  mounted() {
    console.log('itemData' ,this.itemData.businessData);
    if (this.itemData.businessData.resultCode === '1') {
      const businessData = typeof this.itemData.businessData.resultData === 'string' ?
        JSON.parse(this.itemData.businessData.resultData) : this.itemData.businessData.resultData;
      if (businessData.resultFlag) {
        this.businessData = businessData;
        const defaultStatus = this.businessData.promos[0].activityStatus;
        this.detailLink = this.businessData.promos[0].detailLink;
        let map = new Map();
        map.set(1, 1);
        map.set(2, 0);
        map.set(3, 2);
        this.defaultCouponStatus = map.get(defaultStatus);
        console.log('this.defaultCouponStatus', this.defaultCouponStatus);
      }
    }
  },
  methods: {
    goKYC() {
      this.$SDK.goNativeKYC(this.KYCData);
      this.showDialog = false;
    },
    cancel() {
      this.showDialog = false;
    },
    gotoMyCoupon() {
      this.$SDK.goNativeCouponList()
    },
    async getCoupon() {
      console.log(this.$utils.GetQueryStringHash('scence'), this.promotionScrollY);
      if (!this.businessData.promos || !this.businessData.promos.length) {
        return;
      }
      this.isPromotion = false;
      this.scrollY = 0;
      const res = await DiscoverygetCoupon({
        activityId: this.businessData.promos[0].promoId,
        deviceInfo: JSON.stringify(this.$DeviceInfo)
      });
      this.handlInitData(res);
      if (!this.dataObj || this.dataObj === '{}') {
        return;
      }
      if (typeof this.dataObj === 'string') {
        this.dataObj = JSON.parse(this.dataObj);
      }
      if (this.dataObj.gotSuccess === 1) {
        this.$toast({
          message: this.$t('discoveryGetSuccess'),
          position: 'middle',
          duration: 3000
        });
      } else {
        if (this.dataObj.errorCode) {
          let errorCode = typeof errorCode === 'String' ? this.dataObj.errorCode : String(this.dataObj.errorCode);
          let map = new Map();
          map.set('100000001', this.$t('discoveryCouponRunOut'));
          map.set('100000022', this.$t('discoveryUnableGet'));
          map.set('100000038', this.$t('Cannot get this coupon now'));
          map.set('100000042', this.$t('Sorry, something went wrong. Please try again later'));
          map.set('100000039', 'KYC4');
          map.set('100000040', 'KYC6');
          map.set('100000037', 'KYC');
          if (map.get(errorCode).startsWith('KYC')) {
            this.showDialog = true;
            if (this.$utils.GetQueryStringHash('scence') === '1') {
              this.isPromotion = true;
              this.scrollY = -this.promotionScrollY;
            }
            if (map.get(errorCode) === 'KYC') {
              this.KYCData = '';
            } else if((map.get(errorCode) === 'KYC6') ){
              this.KYCData = {
                "businessName": "OFFLINE" 
              };
            } else {
              this.KYCData = {
                "businessName": "PAYMENT" 
              };
            }
          } else if (map.get(errorCode)) {
            this.$toast({
              message: map.get(errorCode),
              position: 'middle',
              duration: 3000
            });
          } else {
            this.$toast({
              message: this.$t('discoveryNoGot'),
              position: 'middle',
              duration: 3000
            });
          }
        }
      }
    },
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.itemData.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.itemData.tracePoint);
        }
      }
      if (!this.detailLink) {
        return;
      }
      if (this.$utils.getSysType('isJdApp')) {
        this.$SDK.goNativeAction({
          type: 'native',
          address: '/webview/web',
          params: {
            url: encodeURIComponent(this.detailLink),
            textColor: '#141E50',
            mHeaderTitle: {
              showEnd: 0
            }
          }
        });
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/mixin.scss";
.my-coupon {
  position: relative;
  width: 100%;
  height: 100%;
  .position-under {
    position: absolute;
    background: #D8D8D8;
    box-shadow: 0 0.08rem 1.04rem 0 #C7D5E2;
    width: 2.8rem;
    height: 4.4rem;
    transform: translate(-50%, -50%);
    left: 50%;
    top: 50%;
  }
  .coupon-wrapper {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    @include bg-image('Coupon_BG');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    box-sizing: border-box;
    // padding: 0.08rem 0.12rem 0 0.12rem;
    // width: 3.24rem;
    // height: 4.72rem;
    .content-wrapper {
      border-radius: 0.16rem;
      // width: 3.24rem;
      // height: 4.72rem;
      width: 100%;
      height: 100%;
      // width: 3.16rem;
      // height: 4.72rem;
      // box-shadow: 0 0 0.08rem 0 rgba(161,165,185,0.50);
      overflow: hidden;
      .content-top {
        position: relative;
        height: 2.44rem;
        width: 100%;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        .content-bg {
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          top: 0;
          background: linear-gradient(-180deg, rgba(0,0,0,0.00) 62%, rgba(0,0,0,0.18) 73%, rgba(0,0,0,0.50) 100%);
          box-shadow: inset 0 0 0.04rem 0 rgba(0,0,0,0.12);
          .run-out {
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            background-color: rgba(161,165,185,0.40);
          }
          .title {
            display: flex;
            position: absolute;
            left: 0.2rem;
            right: 0;
            bottom: 0.2rem;
            .icon {
              box-sizing: border-box;
              width: 0.48rem;
              height: 0.48rem;
              background-color: #fff;
              padding: 0.02rem;
              border-radius: 50%;
              box-shadow: 0 0.04rem 0.08rem 0 rgba(0,0,0,0.12), 0 0.02rem 0.12rem 0 rgba(0,0,0,0.12);
              .icon-img {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
              }
            }
            .message {
              min-width: 0;
              flex: 1;
              margin-left: 0.1rem;
              padding-right: 0.2rem;
              font-family: The1Official_Bold;
              font-size: 0.24rem;
              line-height: 0.48rem;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              color: #FFFFFF;
            }
          }
        }
      }
      .content-center {
        padding: 0.2rem 0.2rem 0;
        margin-bottom: 0.2rem;
        height: 0.8rem;
        font-family: The1Official_Bold;
        font-size: 0.28rem;
        color: #141E50;
        letter-spacing: 0;
        line-height: 0.4rem;
        overflow:hidden;
        text-overflow:ellipsis;
        display:-webkit-box;
        /*! autoprefixer: off */
        -webkit-box-orient: vertical;
        /* autoprefixer: on */
        -webkit-line-clamp:2; 
      }
      .content-bottom {
        padding: 0.24rem 0.2rem 0.2rem;
        .button {
          width: 2.84rem;
          margin: 0 auto;
          height: 0.64rem;
          box-sizing: border-box;
          border-radius: 0.32rem;
          font-family: The1Official_Bold;
          font-size: 0.28rem;
          line-height: 0.64rem;
          text-align: center;
          &.button-use {
            background: #FF3E5B;
          }
          &.button-get {
            border: 1px solid #FF3E5B;
            color: #FF3E5B;
          }
          &.button-view {
            color: #FFFFFF;
            background: #FF3E5B;
          }
        }
        .run-out {
          font-family: The1Official_Bold;
          font-size: 0.36rem;
          width: 2.84rem;
          margin: 0 auto;
          height: 0.64rem;
          line-height: 0.64rem;
          color: #A1A5B9;
          text-align: center;
        }
      }
    }
  }
}
</style>
