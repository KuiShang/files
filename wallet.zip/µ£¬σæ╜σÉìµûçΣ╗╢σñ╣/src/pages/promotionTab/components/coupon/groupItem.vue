<template>
  <div class="my-coupon">
    <div class="position-under"></div>
    <div class="coupon-wrapper">
      <div class="content-wrapper">
        <div @click="handleClick">
          <div class="content-top" v-lazy:background-image="imgList[0] ? imgList[0] : ''">
            <div class="content-bg">
              <div class="title">
                <div class="icon">
                  <div class="icon-img" v-lazy:background-image="imgList[1] ? imgList[1] : ''"></div>
                </div>
                <div class="message" :style="{'color': itemData.title1Color}">{{itemData.title1}}</div>
              </div>
              <div class="run-out" v-show="defaultCouponStatus === 2 || groupLeftCount === 0"></div>
            </div>
          </div>
          <div class="content-center" :style="{'color': itemData.title2Color}">{{itemData.title2}}</div>
        </div>
        <div class="content-bottom">
          <div class="button button-get" :class="{'not-get': groupLeftCount === 0}"
               v-if="defaultCouponStatus === 0" @click="getCouponClick">{{$t('discoveryGetCoupon')}}</div>
          <div class="button button-view" v-if="defaultCouponStatus === 1" @click="gotoMyCoupon">{{$t('discoveryViewCoupon')}}</div>
          <div class="run-out" v-if="defaultCouponStatus === 2">{{$t('discoveryRunOut')}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';
import handlInitData from '@/mixins/handlInitData';
import { GroupDiscoverygetCoupon } from '@/api'
export default {
  name: 'GroupItem',
  mixins: [handlInitData],
  props: {
    itemData: {
      type: Object,
      default() {
        return {}
      }
    },
    groupLeftCount: {
      type: Number,
      default() {
        return 0
      }
    },
    groupItemData: {
      type: Object,
      default() {
        return {
          activityStatus: 2
        };
      }
    },
    groupAidList: {
      type: Array,
      default() {
        return [];
      }
    },
    currentIndex: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      repeatInit: false,
      detailLink: '',
      defaultCouponStatus: 0, // 0:get, 1: view coupon, 2: run out
      KYCData: ''
    }
  },
  watch: {
    groupItemData: {
      handler(val) {
        console.log('itemData', val);
        if (JSON.stringify(val) === '{}') {
          return;
        }
        const defaultStatus = val.activityStatus;
        this.detailLink = val.detailLink;
        let map = new Map();
        map.set(1, 1);
        map.set(2, 0);
        map.set(3, 2);
        this.defaultCouponStatus = map.get(defaultStatus);
        console.log('this.defaultCouponStatus', this.defaultCouponStatus);
      },
      deep: true
    }
  },
  computed: {
    imgList() {
      if (this.itemData.imageUrl) {
        return this.itemData.imageUrl.split('}}');
      }
      return '';
    },
    ...mapGetters(['promotionTracePoint'])
  },
  methods: {
    gotoMyCoupon() {
      this.$SDK.goNativeCouponList()
    },
    getCouponClick() {
      if (this.groupLeftCount === 0) {
        return;
      }
      this.$emit('changeGroupDialog', true, this.currentIndex);
    },
    async getCoupon() {
      // if (!this.groupItemData.groupId || this.groupAidList.length === 0) {

      // }
      const res = await GroupDiscoverygetCoupon({
        activityId: this.groupItemData.activityId,
        groupId: this.groupItemData.groupId,
        activityIds: this.groupAidList,
        deviceInfo: JSON.stringify(this.$DeviceInfo)
      });
      this.handlInitData(res);
      if (!this.dataObj || this.dataObj === '{}') {
        return;
      }
      if (typeof this.dataObj === 'string') {
        this.dataObj = JSON.parse(this.dataObj);
      }
      console.log('1111', this.dataObj);
      if (this.dataObj.batches && this.dataObj.batches.length) {
        this.$emit('changeStatus', this.dataObj);
      }
      if (this.dataObj.gotSuccess === 1) {
        this.$toast({
          message: this.$t('discoveryGetSuccess'),
          position: 'middle',
          duration: 3000
        });
      } else {
        if (this.dataObj.errorCode) {
          let errorCode = typeof errorCode === 'String' ? this.dataObj.errorCode : String(this.dataObj.errorCode);
          let map = new Map();
          map.set('100000001', this.$t('discoveryCouponRunOut'));
          map.set('100000022', this.$t('discoveryUnableGet'));
          map.set('100000038', this.$t('Cannot get this coupon now'));
          map.set('100000042', this.$t('Sorry, something went wrong. Please try again later'));
          map.set('100000037', 'KYC');
          map.set('100000039', 'KYC4');
          map.set('100000040', 'KYC6');
          if (map.get(errorCode).startsWith('KYC')) {
            if (map.get(errorCode) === 'KYC') {
              this.KYCData = '';
            } else if((map.get(errorCode) === 'KYC6') ){
              this.KYCData = {
                "businessName": "OFFLINE" 
              };
            } else {
              this.KYCData = {
                "businessName": "PAYMENT" 
              };
            }
            this.$emit('changeKYCDialog', {
              showDialog: true,
              KYCData: this.KYCData
            });
          } else if (map.get(errorCode)) {
            this.$toast({
              message: map.get(errorCode),
              position: 'middle',
              duration: 3000
            });
          } else {
            this.$toast({
              message: this.$t('discoveryNoGot'),
              position: 'middle',
              duration: 3000
            });
          }
        }
      }
    },
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.itemData.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.itemData.tracePoint);
        }
      }
      if (!this.detailLink) {
        return;
      }
      if (this.$utils.getSysType('isJdApp')) {
        this.$SDK.goNativeAction({
          type: 'native',
          address: '/webview/web',
          params: {
            url: encodeURIComponent(this.detailLink),
            textColor: '#141E50',
            mHeaderTitle: {
              showEnd: 0
            }
          }
        });
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/mixin.scss";
.my-coupon {
  position: relative;
  width: 100%;
  height: 100%;
  .position-under {
    position: absolute;
    background: #D8D8D8;
    box-shadow: 0 0.08rem 1.04rem 0 #C7D5E2;
    width: 2.8rem;
    height: 4.4rem;
    transform: translate(-50%, -50%);
    left: 50%;
    top: 50%;
  }
  .coupon-wrapper {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    @include bg-image('Coupon_BG');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    box-sizing: border-box;
    // padding: 0.08rem 0.12rem 0 0.12rem;
    // width: 3.24rem;
    // height: 4.72rem;
    .content-wrapper {
      border-radius: 0.16rem;
      // width: 3.24rem;
      // height: 4.72rem;
      width: 100%;
      height: 100%;
      // width: 3.16rem;
      // height: 4.72rem;
      // box-shadow: 0 0 0.08rem 0 rgba(161,165,185,0.50);
      overflow: hidden;
      .content-top {
        position: relative;
        height: 2.44rem;
        width: 100%;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        .content-bg {
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          top: 0;
          background: linear-gradient(-180deg, rgba(0,0,0,0.00) 62%, rgba(0,0,0,0.18) 73%, rgba(0,0,0,0.50) 100%);
          box-shadow: inset 0 0 2px 0 rgba(0,0,0,0.12);
          .run-out {
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            background-color: rgba(161,165,185,0.40);
          }
          .title {
            display: flex;
            position: absolute;
            left: 0.2rem;
            right: 0;
            bottom: 0.2rem;
            .icon {
              box-sizing: border-box;
              width: 0.48rem;
              height: 0.48rem;
              background-color: #fff;
              padding: 0.02rem;
              border-radius: 50%;
              box-shadow: 0 0.04rem 0.08rem 0 rgba(0,0,0,0.12), 0 0.02rem 0.12rem 0 rgba(0,0,0,0.12);
              .icon-img {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
              }
            }
            .message {
              min-width: 0;
              flex: 1;
              margin-left: 0.1rem;
              padding-right: 0.2rem;
              font-family: The1Official_Bold;
              font-size: 0.24rem;
              line-height: 0.48rem;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              color: #FFFFFF;
            }
          }
        }
      }
      .content-center {
        padding: 0.2rem 0.2rem 0;
        margin-bottom: 0.2rem;
        height: 0.8rem;
        font-family: The1Official_Bold;
        font-size: 0.28rem;
        color: #141E50;
        letter-spacing: 0;
        line-height: 0.4rem;
        overflow:hidden;
        text-overflow:ellipsis;
        display:-webkit-box;
        /*! autoprefixer: off */
        -webkit-box-orient: vertical;
        /* autoprefixer: on */
        -webkit-line-clamp:2; 
      }
      .content-bottom {
        padding: 0.24rem 0.2rem 0.2rem;
        .button {
          width: 2.84rem;
          margin: 0 auto;
          height: 0.64rem;
          box-sizing: border-box;
          border-radius: 0.32rem;
          font-family: The1Official_Bold;
          font-size: 0.28rem;
          line-height: 0.64rem;
          text-align: center;
          &.button-use {
            background: #FF3E5B;
          }
          &.button-get {
            border: 1px solid #FF3E5B;
            color: #FF3E5B;
            &.not-get {
              opacity: 0.5;
              border: 1px solid #4F577C;
              color: #A1A5B9;
            }
          }
          &.button-view {
            color: #FFFFFF;
            background: #FF3E5B;
          }
        }
        .run-out {
          font-family: The1Official_Bold;
          font-size: 0.36rem;
          width: 2.84rem;
          margin: 0 auto;
          height: 0.64rem;
          line-height: 0.64rem;
          color: #A1A5B9;
          text-align: center;
        }
      }
    }
  }
}
</style>
