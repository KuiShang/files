<template>
  <div class="wrapper" v-if="propsData.componentInfos && propsData.componentInfos.length">
    <div class="title">
      <div class="title1">{{propsData.layoutTitle1}}</div>
      <div class="title2">{{propsData.layoutTitle2}}</div>
    </div>
    <div class="content"
      v-if="propsData.componentInfos && propsData.componentInfos.length"
      ref="groupScroll">
      <ul ref="list">
        <li :key="key" v-for="(item, key) in propsData.componentInfos">
          <group-item
            ref="groupComponent"
            @changeGroupDialog="changeGroupDialog"
            @changeKYCDialog="changeKYCDialog"
            @changeStatus="changeGroup"
            :item-data="item"
            :current-index="key"
            :group-left-count="preventCount"
            :group-aid-list="activityIdList"
            :group-item-data="batches && batches.length?batches[key]:{}" />
        </li>
      </ul>
    </div>
    <toast
      v-if="showDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goKYC"
      @cancle="cancel"
    >
      <p style="fontSize: 0.4rem;font-family: The1Official_Bold;" slot="title">{{ $t('discoveryKYCTitle') }}</p>
      <p style="fontSize: 0.36rem;" slot="content">{{ $t('discoveryKYC') }}</p>
      <p slot="cancle">{{ $t('discoveryCancel') }}</p>
      <p slot="confirm">{{ $t('discoveryConfirm') }}</p>
    </toast>
    <toast
      v-if="showGroupGetCouponDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="getGroup"
      @cancle="cancleGroupDialog"
    >
      <p style="fontSize: 0.4rem;font-family: The1Official_Bold;" slot="title">{{ $t('Confirmation') }}</p>
      <p style="fontSize: 0.36rem;" slot="content">{{ $t('you can get only') }} {{ preventCount }} {{ $t('coupon from the group please confirm to get') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
  </div>
</template>
<script>
import GroupItem from "@/pages/promotionTab/components/coupon/groupItem";
import handlInitData from '@/mixins/handlInitData';
import BScroll from 'better-scroll';
import Toast from '@/pages/balance/common/dialog';
import { GroupCouponStatus } from '@/api';
export default {
  name: "CouponGroup",
  mixins: [handlInitData],
  components: {
    GroupItem,
    Toast
  },
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      preventCount: 0,
      batches: [],
      showGroupGetCouponDialog: false,
      showDialog: false,
      itemIndex: 0,
      KYCData: ''
    };
  },
  computed: {
    activityIdList() {
      if (this.dataObj.batches && this.dataObj.batches.length) {
        return this.dataObj.batches.map(item => {
          return item.activityId;
        });
      } else {
        return [];
      }
    }
  },
  created() {
    if (this.propsData.componentInfos && this.propsData.componentInfos.length) {
      this.initData();
    }
  },
  mounted() {
    console.log(444444);
    console.log(this.propsData);
    this.$nextTick(() => {
      if (this.propsData.componentInfos.length) {
        let itemWidth = 3.24;
        let margin = 0.2;
        let width = (itemWidth + margin) * this.propsData.componentInfos.length - margin + 0.8;
        this.$refs.list.style.width = width + 'rem';
        console.log('group', this.$refs.groupScroll);
        this.scroll = new BScroll(this.$refs.groupScroll, {
          scrollX: true,
          scrollY: false,
          click: true,
          eventPassthrough: 'vertical'
        })
      }
    });
    console.log(55555555);
  },
  methods: {
    cancleGroupDialog() {
      this.showGroupGetCouponDialog = false;
    },
    getGroup() {
      this.showGroupGetCouponDialog = false;
      console.log('batches', this.batches);
      this.$nextTick(() => {
        this.$refs.groupComponent[this.itemIndex].getCoupon();
      });
    },
    goKYC() {
      this.$SDK.goNativeKYC(this.KYCData);
      this.showDialog = false;
    },
    cancel() {
      this.showDialog = false;
    },
    changeKYCDialog(data) {
      this.showDialog = data.showDialog;
      this.KYCData = data.KYCData;
    },
    changeGroupDialog(flag, index) {
      this.showGroupGetCouponDialog = flag;
      this.itemIndex = index;
    },
    changeGroup(json) {
      this.preventCount = json.groupLeftCount;
      this.batches = json.batches;
    },
    async initData() {
      this.$indicator.open({
        text: this.$t('Loading'),
        spinnerType: 'fading-circle'
      });
      let activityIds = this.propsData.componentInfos.map(item => {
        return item.activityId;
      });
      console.log('s', {
        groupId: this.propsData.couponGroupId,
        activityIds
      })
      if (!this.propsData.couponGroupId || activityIds.length === 0) {
        return;
      }
      const res = await GroupCouponStatus({
        groupId: this.propsData.couponGroupId,
        activityIds
      })
      this.$indicator.close();
      this.handlInitData(res);
      console.log(2222222);
      console.log(this.dataObj.batches, res);
      this.preventCount = this.dataObj.groupLeftCount;
      this.batches = this.dataObj.batches;
      console.log(2222222);
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.wrapper {
  .title {
    padding: 0 0.4rem 0;
    margin-top: 0.54rem;
    margin-bottom: 0.3rem;
    .title1 {
      font-family: The1Official_Bold;
      font-size: 0.4rem;
      line-height: 0.6rem;
      color: #141e50;
      letter-spacing: 0;
    }
    .title2 {
      margin-top: 0.1rem;
      font-size: 0.28rem;
      line-height: 0.4rem;
      color: #141E50;
    }
  }
  .content {
    height: 5.4rem;
    overflow: hidden;
    ul {
      display: flex;
      flex-direction: row;
      margin-bottom: -0.14rem;
      li {
        margin-right: 0.2rem;
        width: 3.24rem;
        height: 4.72rem;
        margin-bottom: 0.2rem;
        &:first-child {
          margin-left: 0.4rem;
        }
        &:last-child {
          margin-right: 0.4rem;
        }
      }
    }
  }
}
</style>
