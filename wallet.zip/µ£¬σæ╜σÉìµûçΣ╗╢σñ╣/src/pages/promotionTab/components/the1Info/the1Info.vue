<template>
  <div class="wrapper-box">
    <div class="pending-info" v-if="businessData.pending > 0 && (businessData.status === 1 || businessData.status === 5)">
      <i></i>
      <span>{{businessData.pending}} {{$t('the1Top')}}</span>
    </div>
    <div class="wrapper">
      <template v-if="businessData.status === 1 || businessData.status === 5">
        <div class="content-link">
          <div class="content-l">
            <div class="content-l-top">{{businessData.firstName}}</div>
            <div class="content-l-center">{{$t('the1PointsAmountTitle')}}</div>
            <div class="content-l-bottom">{{thousandBitSeparatorValue(businessData.point)}}</div>
          </div>
          <div class="content-r" @click="goQRCode">
            <div class="content-r-top"></div>
            <div class="content-r-bottom">
              <div class="bar-code" :style="{'background-image': `url('${barCode}')`}"></div>
              <div class="bar-num">{{setCardNumber(businessData.t1Card)}}</div>
              <div class="bar-icon"></div>
            </div>
          </div>
        </div>
      </template>
      <template v-if="businessData.status === 6">
        <div class="content-unlink">
          <div class="title">
            {{$t('the1UnlinkEarn1')}}
            <span>{{thousandBitSeparatorValue(businessData.pending)}}</span>
            {{$t('the1UnlinkEarn2')}}
          </div>
          <div class="message">{{$t('the1Tolink')}}</div>
          <div class="button" @click="goNativeThe1Bind('LINK2')">{{$t('the1Unlink')}}</div>
        </div>
      </template>
      <template v-if="businessData.status === 2 || businessData.status === 0">
        <div class="content-unpoint">
          <div class="title">{{$t('the1Tolink')}}</div>
          <div class="button" @click="goNativeThe1Bind('LINK1')">{{$t('the1Unlink')}}</div>
        </div>
      </template>
      <template v-if="this.propsData.businessData.resultCode === '0' || businessData.status < 0">
        <div class="content-unpoint">
          <div class="title">{{$t('the1WarnMsg')}}</div>
          <div class="button" @click="reloadPage('TRACE')">{{$t('the1TryAgain')}}</div>
        </div>
      </template>
    </div>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';

export default {
  name: "The1Info",
  components: {},
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  watch: {
    propsData() {
      this.initData();
    }
  },
  data() {
    return {
      barCode: "",
      businessData: {}
    };
  },
  mounted() {
    this.initData();
  },
  computed: {
    ...mapGetters(['language', 'promotionTracePoint'])
  },
  methods: {
    traceFn(key) {
      console.log(`${this.propsData.tracePoint}_${key}`);
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.propsData.tracePoint) {
          let tracePoint = `${this.propsData.tracePoint}_${key}`;
          PROMOTION_CLICK(this.promotionTracePoint, tracePoint);
        }
      }
    },
    thousandBitSeparatorValue(num, cent, isThousand) {
      if (num) {
        num = num.toString().split(".")[0];
        num = num.toString().replace(/\$|\,/g, "");
        if ("" == num || isNaN(num)) {
          return "";
        }
        var sign = num.indexOf("-") > -1 ? "-" : "";
        if (num.indexOf("-") > -1) {
          num = num.substring(1);
        }
        var cents = num.indexOf(".") > 0 ? num.substr(num.indexOf(".")) : "";
        cents = cents.length > 1 ? cents : "";
        num = num.indexOf(".") > 0 ? num.substring(0, num.indexOf(".")) : num;
        if ("" == cents) {
          if (num.length > 1 && "0" == num.substr(0, 1)) {
            return "";
          }
        } else {
          if (num.length > 1 && "0" == num.substr(0, 1)) {
            return "";
          }
        }
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
          num =
            num.substring(0, num.length - (4 * i + 3)) +
            "," +
            num.substring(num.length - (4 * i + 3));
        }
        return sign + num + cents;
      } else {
        return "0";
      }
    },
    initData() {
      if (this.propsData.businessData.resultCode === "1") {
        this.businessData =
          typeof this.propsData.businessData.resultData === "string"
            ? JSON.parse(this.propsData.businessData.resultData)
            : this.propsData.businessData.resultData;
        this.getScanCode();
      }
    },
    goNativeThe1Bind(val) {
      this.traceFn(val);
      this.$SDK.goNativeThe1Bind().then(res => {
        if (res.status === 1) {
          this.reloadPage();
        }
      });
    },
    setCardNumber(val) {
      if (val) {
        return val
          .toString()
          .replace(/\s/g, "")
          .replace(/(\d{4})(?=\d)/g, "$1 ");
      } else {
        return "";
      }
    },
    goQRCode() {
      this.traceFn('SHOWQR');
      this.$SDK.goNativeQRCode();
    },
    reloadPage(val) {
      if (val === 'TRACE') {
        this.traceFn('ERROR');
      }
      this.$SDK.reloadPage({ type: -1 }, resp => {
        console.log("reload" + JSON.stringify(resp));
      });
    },
    getScanCode() {
      const json = {
        codeType: 1, // 条形码
        imageType: 1, //png
        inputdata: this.businessData.t1Card ? this.businessData.t1Card : "",
        width: 192,
        height: 76,
        quality: 90,
        barCodeColor: "#000000"
      };
      this.$SDK.setBarCode(json, resp => {
        console.log("resp", resp);
        this.barCode = "data:image/png;base64," + resp.data;
      });
    },
    handleClick() {
      const json = this.$utils.setJumpUrl(this.promotionItem);
      if (json) {
        if (this.$utils.getSysType("isJdApp")) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.pending-info {
  width: 100%;
  height: 0.6rem;
  background: #FFEE86;
  line-height: 0.6rem;
  font-size: 0;
  color: #F08046;
  i {
    display: inline-block;
    @include bg-image("time");
    background-size: cover;
    vertical-align: middle;
    width: 0.28rem;
    height: 0.28rem;
    margin-left: 0.4rem;
  }
  span {
    font-family: The1Official_Bold;
    vertical-align: top;
    font-size: 0.24rem;
    margin-left: 0.16rem;
  }
}
.wrapper {
  width: 100%;
  height: 3.8rem;
  @include bg-image("bg");
  background-repeat: no-repeat;
  background-size: 100% auto;
  margin-bottom: 0.2rem;
  .content-link {
    box-sizing: border-box;
    width: 100%;
    display: flex;
    padding: 0.48rem 0.4rem 0;
    .content-l {
      min-width: 0;
      padding-top: 0.04rem;
      flex: 1;
      .content-l-top {
        font-size: 0.48rem;
        color: #ffffff;
        letter-spacing: 0;
        line-height: 0.56rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .content-l-center {
        font-size: 0.24rem;
        color: #fc0100;
        margin-top: 0.68rem;
        margin-bottom: 0.12rem;
      }
      .content-l-bottom {
        font-family: The1Official_Bold;
        font-size: 0.92rem;
        color: #ffffff;
      }
    }
    .content-r {
      position: relative;
      width: 1.88rem;
      height: 2.88rem;
      margin-left: 0.4rem;
      background: #fff;
      border-radius: 0.04rem;
      box-sizing: border-box;
      padding: 0.16rem 0.28rem;
      .content-r-top {
        width: 0.48rem;
        height: 0.48rem;
        @include bg-image("QRcode");
        background-size: cover;
      }
      .content-r-bottom {
        position: absolute;
        left: 0;
        top: 1.04rem;
        transform: rotateZ(-90deg);
        height: 1.36rem;
        width: 1.92rem;
        .bar-code {
          width: 1.92rem;
          height: 0.76rem;
          background-size: contain;
        }
        .bar-num {
          font-size: 0.2rem;
          line-height: 0.32rem;
          color: #000000;
          text-align: center;
        }
        .bar-icon {
          position: absolute;
          @include bg-image("icon");
          width: 0.28rem;
          height: 0.28rem;
          transform: rotateZ(90deg);
          bottom: 0;
          left: 50%;
          background-size: contain;
          background-repeat: no-repeat;
        }
      }
    }
  }
  .content-unlink {
    padding: 0.72rem 0.4rem 0;
    text-align: center;
    .title {
      line-height: 0.56rem;
      font-size: 0.36rem;
      color: #ffffff;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 0.08rem;
      span {
        color: #ff0000;
      }
    }
    .message {
      opacity: 0.5;
      font-size: 0.28rem;
      color: #ffffff;
      line-height: 0.4rem;
      margin-bottom: 0.4rem;
    }
    .button {
      box-sizing: border-box;
      width: 4.28rem;
      height: 0.8rem;
      border-radius: 0.4rem;
      border: 1px solid #ffffff;
      margin: 0 auto;
      font-size: 0.32rem;
      color: #fff;
      line-height: 0.84rem;
    }
  }
  .content-unpoint {
    padding: 0.92rem 0.4rem 0;
    font-size: 0.36rem;
    color: #ffffff;
    text-align: center;
    line-height: 0.56rem;
    .title {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .button {
      box-sizing: border-box;
      width: 4.28rem;
      height: 0.8rem;
      border-radius: 0.4rem;
      border: 0.02rem solid #ffffff;
      margin: 0.68rem auto 0;
      font-size: 0.32rem;
      color: #fff;
      line-height: 0.84rem;
    }
  }
}
</style>
