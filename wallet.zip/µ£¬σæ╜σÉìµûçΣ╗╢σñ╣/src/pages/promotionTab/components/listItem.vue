<template>
  <div class="wrapper">
    <div
      class="thumbnail-wrapper"
      @click="handleClick">
      <thumbnail
        :thumbnail-style="thumbnailStyle"
        :banner-label="propsData"/>
    </div>
    <div class="content" :style="{color: propsData.title2Color}">{{ propsData.title2 }}</div>
    <div class="date" :style="{color: propsData.title3Color}">{{ propsData.title3 }}</div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';
import Thumbnail from '@/pages/promotionTab/components/base/thumbnail/thumbnail';

export default {
  name: 'ListItem',
  components: {
    Thumbnail
  },
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      thumbnailStyle: {
        wrapper: {
          height: '2.6rem'
        },
        img: {
          width: '0.6rem',
          height: '0.6rem',
          left: '0.2rem',
          bottom: '0.16rem'
        },
        content: {
          'padding-left': '1rem',
          'padding-top': '0.06rem',
          'padding-right': '0.2rem',
          'padding-bottom': '0.12rem',
          height: '0.4rem',
          'font-size': '0.28rem',
          'line-height': '0.48rem'
        }
      }
    }
  },
  computed: {
    imgList() {
      if (this.propsData.imageUrl) {
        return this.propsData.imageUrl.split('}}');
      }
      return '';
    },
    ...mapGetters(['promotionTracePoint'])
  },
  methods: {
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.propsData.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.propsData.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(this.propsData);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.wrapper {
  height: 4.6rem;
  .thumbnail-wrapper {
    display: block;
    overflow: hidden;
    height: 2.6rem;
    box-shadow: 0 0.04rem 0.08rem 0 rgba(161,165,185,0.50);
    border-radius: 0.2rem;
  }
  .content {
    font-size: 0.36rem;
    color: #000000;
    line-height: 0.48rem;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    /*! autoprefixer: off */
    -webkit-box-orient: vertical;
    /* autoprefixer: on */
    -webkit-line-clamp:2;
    margin-top: 0.14rem;
    margin-bottom: 0.14rem;
  }
  .date {
    font-family: SFUIDisplay-Regular;
    font-size: 0.24rem;
    color: #BBBBBB;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
