<template>
  <div class="promotion-item" v-if="JSON.stringify(promotionItem) !== {}" @click="handleClick">
    <img v-lazy="promotionItem.imageUrl" />
    <div class="content">
      <div
        :style="{color: promotionItem.title1Color}"
        class="content-t">{{ promotionItem.title1 }}</div>
      <div
        :style="{color: promotionItem.title2Color}"
        class="content-b">{{ promotionItem.title2 }}</div>
    </div>
    <div class="button"></div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import { PROMOTION_CLICK } from '@/pages/burry/promo.js';

export default {
  name: 'PromotionItem',
  props: {
    promotionItem: {
      type: Object,
      default() {
        return {};
      }
    },
    burryName: {
      type: String,
      default: ''
    }
  },
  computed: {
    ...mapGetters(['language', 'promotionTracePoint'])
  },
  methods: {
    handleClick() {
      if (this.$utils.getSysType('isJdApp')) {
        if (this.promotionTracePoint && this.promotionItem.tracePoint) {
          PROMOTION_CLICK(this.promotionTracePoint, this.promotionItem.tracePoint);
        }
      }
      const json = this.$utils.setJumpUrl(this.promotionItem);
      if (json) {
        if (this.$utils.getSysType('isJdApp')) {
          this.$SDK.goNativeAction(json);
        } else {
          window.location.href = json;
        }
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.promotion-item {
  display: flex;
  align-items: center;
  padding: 0.48rem 0;
  img {
    display: block;
    width: 0.84rem;
    height: 0.84rem;
    margin-right: 0.26rem;
    border-radius: 50%;
  }
  .content {
    min-width: 0;
    flex: 1;
    .content-t {
      margin-bottom: 0.02rem;
      font-size: 0.36rem;
      color: #141E50;
      letter-spacing: 0;
      text-align: left;
      line-height: 0.6rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .content-b {
      font-size: 0.28rem;
      color: #A1A5B9;
      letter-spacing: 0;
      text-align: left;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .button {
    width: .48rem;
    height: .48rem;
    background: url('./arrow.png') no-repeat;
    background-size: cover;
  }
}
</style>
