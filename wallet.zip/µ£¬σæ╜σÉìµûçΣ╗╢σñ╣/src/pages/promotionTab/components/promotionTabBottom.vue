<template>
  <div class="promotion-wrapper-bottom"
    v-if="JSON.stringify(promotionBottomData) !== '{}'">
    <div
      class="title">{{ promotionBottomData.layoutTitle1 }}</div>
    <div class="content">
      <ul v-if="promotionBottomData.componentInfos && promotionBottomData.componentInfos.length">
      <li
        v-for="(item, index) in promotionBottomData.componentInfos"
        :key="`${index}`">
        <promotion-thumbnail :promotion-item="item" />
      </li>
      </ul>
    </div>
  </div>
</template>
<script>
import PromotionThumbnail from '@/pages/promotionTab/components/promotionThumbnail';

export default {
  name: "promotionTabBottom",
  components: {
    PromotionThumbnail
  },
  props: {
    promotionBottomData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {};
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.promotion-wrapper-bottom {
  padding: 0.48rem 0.4rem 0;
  .title {
    font-size: 0.48rem;
    color: $color-gray-g;
    letter-spacing: 0;
    margin-bottom: 0.3rem;
  }
  .content {
    li {
      margin-bottom: 0.38rem;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
}
</style>
