<template>
  <div>
    <div class="new-users-bg">
      <div class="join-box">
        <h3
          v-if="effectiveIdFlag"
          class="title">
          {{ firstName }} ชวนคุณมาใช้ Dolfin
        </h3>
        <h3
          v-if="!effectiveIdFlag"
          class="title">
          คุณได้รับคำชวนจากเพื่อน ให้ใช้ Dolfin
        </h3>
        <h3 class="txt">สัมผัสกับโลกแห่งการใช้จ่ายแบบใหม่ และเพลิดเพลินกับไลฟ์สไตล์แบบไร้เงินสด พร้อมสิทธิพิเศษมากมายกับ Dolfin</h3>
        <div
          v-if="effectiveIdFlag"
          class="phone-box">
          <div class="item-container">
            <common-input
              ref="commonInput"
              v-model="phoneNumber"
              :border="false"
              :maxlength="maxlength"
              :holder="ใส่เบอร์มือถือของคุณ"
              :style-obj="{right: 0}"
              clear-postion-right="0"
              type="tel"
              @blur="cardInputBlur"
              @focus="cardInputFocus"/>
            <p class="border" />
          </div>
          <div
            v-if="showError"
            class="error-txt">อย่าลืมใส่ข้อมูลให้ครบถ้วนนะ
          </div>
          <div
            v-if="overTimesError"
            class="error-txt">วันนี้ชวนเพื่อนครบแล้ว ลองชวนใหม่วันหลังนะ
          </div>
        </div>
        <div
          v-if="effectiveIdFlag"
          class="btn-container">
          <common-button
            :disabled="!btnok"
            class="btn-style"
            type="danger"
            @click.native="handleClick">โหลดแอป Dolfin
          </common-button>
        </div>
        <div
          v-if="!effectiveIdFlag"
          class="btn-container">
          <common-button
            :disabled="!btnok"
            class="btn-style"
            type="danger"
            @click.native="getDolfin">โหลดแอป Dolfin
          </common-button>
        </div>
      </div>
    </div>
    <div
      v-if="effectiveIdFlag"
      class="promotion">
      <div class="title">Special Promotion for new user</div>
      <div class="img"/>
    </div>
    <div class="explain-box">
      <div class="title">Why you use should Dolfin?</div>
      <div class="item">
        <coupon-explain :props-data="propsData"/>
      </div>
    </div>
    <div
      class="terms"
      @click="goToSeeTerms">ข้อตกลงและเงื่อนไข</div>
  </div>
</template>

<script>
import CouponExplain from '@/pages/invitation/components/couponExplain';
import { JoinInvitation } from '@/api'
import { PROMOTION_CLICK, PROMOTION_ENTER } from '@/pages/burry/promo';

export default {
  components: {
    CouponExplain
  },
  data() {
    return {
      effectiveIdFlag: true,
      invitation: '',
      firstName: '',
      maxlength: 10,
      phoneNumber: '',
      showError: false,
      btnok: false,
      overTimesError: false,
      value: '',
      propsData: {
        componentInfos: [
          {
            id: 39,
            imageUrl:
              '//img1.360buyimg.com/da/jfs/t1/25469/40/5576/75855/5c3e95e0Eb188b24b/a6f7dbf54b60160b.jpg',
            title1:
              'werqr werqr werqr werqr werqr ',
            title2:
              'title2 title2 title2 '
          },
          {
            id: 19,
            imageUrl:
              '//m.360buyimg.com/babel/jfs/t1/21900/8/4577/82699/5c34450fE281ba944/475b08f9457bc574.jpg',
            title1:
              'werqr werqr werqr werqr ',
            title1Color: '',
            title2:
              'title2 title2 title2 title22 title2 title2  title2'
          },
          {
            id: 39,
            imageUrl:
              '//img1.360buyimg.com/pop/jfs/t1/22397/6/5090/132740/5c384a77E79489d56/eef4722f654bed7e.jpg',
            title1:
              'werqr werqr werqr werqr r werqr werqr werqr werqr'
          },
          {
            id: 39,
            imageUrl:
              '//m.360buyimg.com/babel/jfs/t1/12104/14/5583/35044/5c3da73bE8bddc1c2/1e2aac67102e2803.jpg',
            title1:
              'werqr werqr werqr  werqr werqr werqr werqr ',
            title2:
              'title2 title2 title2 title2 title2 ti title2'
          }
        ]
      }
    };
  },
  watch: {
    phoneNumber(val) {
      if (val.slice(0, 1) === '0') {
        this.maxlength = 12
      } else if (val.slice(0, 1) !== '0') {
        this.maxlength = 11
      }
      this.phoneNumber = this.sortNum(val)
      this.value = val.replace(/[^\d]/g, '')
      console.log(this.value.length)
      if ((this.phoneNumber.slice(0, 1) === '0' && this.value.length === 10) || (this.phoneNumber.slice(0, 1) !== '0' && this.value.length === 9)) {
        this.btnok = true
      } else {
        this.btnok = false
      }
    }
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('Invite friends')
    })
  },
  methods: {
    async handleClick() {
      this.btnok = false
      PROMOTION_CLICK('INVITE_FRIENDS_ACCEPT', 'CLICK_DOWNLOAD')
      const res = await JoinInvitation({
        phoneNumber: this.value,
        invitation: encodeURIComponent(this.invitation),
        userAgent: window.navigator.userAgent
      })
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        if (res.data.resultData.responseCode === 1) {
          const response = res.data.resultData.response
          window.location.href = response.dynamicLink
        } else {
          const errorCode = res.data.resultData.errorCode
          if (errorCode === 'join.too.many') {
            PROMOTION_CLICK('INVITE_FRIENDS_ACCEPT', 'ERROR')
            this.overTimesError = true
            this.showError = false
          }
        }
        this.btnok = true
      }
    },
    getDolfin() {
      window.location.href = 'https://cjdfintech.page.link/gate'
    },
    goToSeeTerms() {
      this.$router.push({ name: 'termAndConditions' })
    },
    cardInputBlur() {
      if ((this.phoneNumber.slice(0, 1) === '0' && this.value.length === 10) || (this.phoneNumber.slice(0, 1) !== '0' && this.value.length === 9)) {
        this.showError = false
      } else {
        this.showError = true
      }
    },
    cardInputFocus() {
      this.showError = false
    },
    initData() {
      this.invitation = this.$utils.getQueryString('invitation');
      this.firstName = this.$utils.getQueryString('firstName');
      // this.invitation = this.$route.query.invitation;
      // this.firstName = this.$route.query.firstName;
      console.log(this.invitation)
      if (this.invitation === '' || this.invitation === null) {
        this.effectiveIdFlag = false
        this.btnok = true
      }
      PROMOTION_ENTER('INVITE_FRIENDS_ACCEPT')
    },
    sortNum(val) {
      return val.toString().replace(/(\d{4})(?=\d)/g, '$1 ')
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.new-users-bg {
  width: 100%;
  height: 8rem;
  background: url("../../assets/images/invitation/freeform@2x.png") no-repeat 0
    0;
  background-size: cover;
  padding-top: 0.6rem;
  box-sizing: border-box;
  .join-box {
    width: 6.7rem;
    min-height:7.36rem;
    position:relative;
    box-sizing: border-box;
    background: $color-white;
    margin: 0 auto;
    border-radius: 0.2rem;
    box-shadow: 0 0.04rem 0.18rem 0 rgba(0, 0, 0, 0.1);
    padding: 0.5rem 0 0 .4rem;
    color: $color-gray-g;
    .title {
      font-size: 0.4rem;
      line-height: 0.6rem;
    }
    .txt {
      width: 5.76rem;
      line-height: 0.54rem;
      font-size: 0.32rem;
      margin-bottom: 0.32rem;
    }
    .phone-box {
      width: 5.76rem;
      padding-bottom:  2.72rem;
      .item-container {
        font-size: 0.28rem;
        .border {
          height: 0.02rem;
          background-color: $color-gray-f;
        }
      }
      .error-txt {
        height:.36rem;
        line-height:.36rem;
        font-size:.24rem;
        color:$color-red;
        margin-top:.16rem;
      }
    }
    .btn-container {
      width: 5.6rem;
      height: 1.12rem;
      text-align: center;
      line-height: 1.12rem;
      position:absolute;
      bottom:.8rem;
      color: $color-white;
      border-radius: 0.56rem;
      font-size: 0.36rem;
      margin-left: 0.16rem;
      .btn-style{
        width:100%;
        height:100%;
      }
    }
  }
}
.promotion {
  width: 100%;
  margin-top: 0.8rem;
  background: $color-white;
  .title {
    height: 0.6rem;
    line-height: 0.6rem;
    padding-left: 0.4rem;
    font-size: 0.4rem;
    color: $color-gray-g;
    font-family: The1Official-Bold;
  }
  .img {
    height: 4.2rem;
    background: $color-gray-d;
    margin-top: 0.32rem;
  }
}
.explain-box {
  width: 100%;
  margin-top: 0.8rem;
  background: $color-white;
  .title {
    height: 0.6rem;
    line-height: 0.6rem;
    padding-left: 0.4rem;
    font-size: 0.4rem;
    color: $color-gray-g;
    font-family: The1Official-Bold;
  }
  .item {
    width:100%;
    margin-top:.32rem;
  }
}
.terms {
  height:.46rem;
  line-height:.46rem;
  font-size:.28rem;
  text-decoration: underline;
  font-family: The1Official-Regular;
  color:$color-gray-g;
  margin-bottom:.8rem;
  padding-left:.4rem;
}
</style>
