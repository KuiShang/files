<template>
  <div>
    <div class="history-bg">
      <h3 class="title">{{ this.$t('Invitation list') }}</h3>
      <div
        v-if="count !== 0"
        class="history-box">
        <div
          v-for="(item,index) in rules"
          :key="index"
          class="item">
          <div class="item-left">{{ item.firstName }}<sub>******</sub></div>
          <div class="item-right">
            <p class="state">{{ $t(item.state) }}</p>
            <div class="time">{{ item.time }}</div>
          </div>
        </div>
      </div>
      <div
        v-if="count === 0"
        class="request-box">
        <h3 class="empty-title">{{ this.$t('Let’s invite your friend') }}</h3>
        <h3 class="empty-txt">{{ this.$t('New payment experience and more privileges is awaiting your friends to explore') }}</h3>
        <div
          class="btn-container"
          @click="getChannelDatay">{{ $t('Invite Now') }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import { HistoryData, GetSharing } from '@/api'
import { PROMOTION_CLICK, PROMOTION_ENTER } from '@/pages/burry/promo';

export default {
  data() {
    return {
      rules: [],
      page: 1,
      pageSize: 1000,
      subjectId: '',
      count: 0,
      entrance: ''
    }
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('Invitation status')
    })
    PROMOTION_ENTER('INVITE_FRIENDS_HISTORY')
    this.$SDK.onBackPressNativeContinue(() => {
      PROMOTION_CLICK('INVITE_FRIENDS_HISTORY', 'CLICK_BACK')
    })
  },
  methods: {
    async initData() {
      // this.subjectId = this.$utils.GetQueryString('subjectId');
      this.subjectId = this.$route.query.subjectId;
      this.entrance = this.$route.query.entrance;
      const res = await HistoryData({
        subjectId: this.subjectId,
        page: this.page,
        pageSize: this.pageSize
      });
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        if (res.data.resultData.responseCode === 1) {
          const response = res.data.resultData.response
          this.count = response.count
          this.rules = response.friendList
        } else {
          const errorCode = res.data.resultData.errorCode
        }
      }
    },
    async getChannelDatay() {
      PROMOTION_CLICK('INVITE_FRIENDS_HISTORY', 'CLICK_INVITENOW')
      const res = await GetSharing({
        subjectId: this.subjectId,
        entry: this.entry
      });
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        if (res.data.resultData.responseCode === 1) {
          const transData = res.data.resultData
          this.$SDK.shareByOS(JSON.stringify(transData))
        }
      }
    }
  }
};

</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.history-bg {
    width:7.5rem;
    height:100%;
    background:url('../../assets/images/invitation/Graphic_freeform@2x.png')no-repeat 0 -1.8rem;
    background-size:cover;
    .title {
        height:.42rem;
        line-height:.54rem;
        font-size:.32rem;
        color:$color-white;
        padding:.8rem 0 0 .4rem;
        font-family: The1Official-Regular;
        margin-bottom:.4rem;
    }
    .history-box {
        width:6.7rem;
        min-height:9.12rem;
        background:$color-white;
        margin: 0 auto;
        border-radius:.2rem;
        box-shadow:0 .04rem .18rem 0 rgba(0,0,0,0.10);
        padding:.3rem .4rem 0;
        box-sizing: border-box;
        overflow-x: hidden;
        overflow-y: auto;
        .item {
            width:6.3rem;
            height:1.5rem;
            @include border-1px($color-gray-e);
            .item-left {
                float:left;
                margin:.3rem 0 0 .2rem;
                height:.6rem;
                line-height:.6rem;
                font-size:.36rem;
                color:$color-gray-g;
            }
            .item-right {
                float:right;
                margin:.4rem .4rem 0 0;
                width:2.1rem;
                .state {
                    height:.46rem;
                    line-height:.46rem;
                    font-size:.28rem;
                    text-align:right;
                    color:#009DA2 ;
                }
                .time {
                    height:.4rem;
                    line-height:.4rem;
                    font-size:.24rem;
                    font-family: The1Official-Regular;
                    color:$color-gray-f;
                    text-align:right;
                }
            }
        }
    }
    .request-box {
      width: 6.7rem;
      min-height: 9.12rem;
      background: $color-white;
      margin: 0 auto;
      border-radius: .2rem;
      box-shadow: 0 .04rem .18rem 0 rgba(0,0,0,0.10);
      padding: .3rem .4rem 0;
      box-sizing: border-box;
      position:relative;
      .empty-title {
        height: .6rem;
        line-height: .6rem;
        font-size: .44rem;
        text-align: center;
        color: $color-gray-g;
        font-family: The1Official-Bold;
        margin-top:.6rem;
      }
      .empty-txt {
        height: .6rem;
        line-height: .6rem;
        font-size: .36rem;
        text-align: center;
        color: $color-gray-g;
        font-family: The1Official-Regular;
        margin-top:.2rem;
      }
      .btn-container {
        width:5.6rem;
        height:1.12rem;
        line-height:1.12rem;
        text-align:center;
        font-size:.36rem;
        color:$color-white;
        background:$color-red;
        border-radius:.56rem;
        position:absolute;
        bottom:.78rem;
        left:.56rem;
      }
    }
}
</style>
