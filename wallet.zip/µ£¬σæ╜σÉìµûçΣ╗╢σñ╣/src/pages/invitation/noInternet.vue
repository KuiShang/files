<template>
  <div class="neterror">
    <img
      src="@/assets/images/invitation/connection_error@2x.png"
      class="img">
    <p class="txt">{{ $t('No net connection') }}</p>
    <p class="txt-info">{{ $t('Make sure you are connected to the internet and try again.') }}</p>
    <div class="btn-wraper">
      <!-- <common-button
        plain
        type="danger"
        size="small"
        @click="handleClick">{{ $t('TRYAGAIN') }}</common-button> -->
      <div
        class="btn-container"
        @click="handleClick">{{ $t('PLEASE TRY AGAIN') }}</div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Error',
  methods: {
    handleClick() {
      this.$router.go(-1)
      // this.$SDK.goNativeMain()
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.neterror {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 1.6rem;
  .img {
    width: 1.6rem;
    height: 1.38rem;
  }
  .txt {
    color: $color-gray-g;
    font-size: .48rem;
    line-height:.8rem;
    text-align: center;
    margin:.6rem 0 .2rem;
  }
  .txt-info {
      width:5.9rem;
      text-align:center;
      margin:0 auto;
      line-height:.6rem;
      font-size:.36rem;
      font-family: The1Official-Regular;
      color: $color-gray-g;
  }
  .btn-wraper {
    padding-top: 1rem;
    position: fixed;
    bottom:.8rem;
    left:.8rem;
    right:.8rem;
    .btn-container {
        height: 1.12rem;
        width: 5.9rem;
        font-size: .36rem;
        border: 1px solid $color-red;
        color: $color-red;
        border-radius: .56rem;
        text-align: center;
        line-height: 1.12rem;
        font-family: The1Official_Bold;
    }
  }
}
</style>

