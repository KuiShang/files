<template>
  <div>
    <div
      v-if="!showIt"
      class="invite-bg"/>
    <div
      v-if="showIt"
      class="img-box">
      <img :src="imageUrl">
    </div>
    <div class="invite-info-box">
      <h3 class="invite-title">{{ this.$t('Invite friends') }}</h3>
      <div
        v-if="showIt"
        class="history"
        @click="seeHistory">{{ this.$t('Invitation status') }}
        <div class="right">
          <img
            src="@/assets/images/invitation/friends/arrow.png"
            class="img">
        </div>
      </div>
      <div class="explain">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</div>
      <div
        v-if="showIt"
        class="works"
        @click="showInstruction">
        {{ this.$t('How it works') }}
      </div>
      <div
        v-if="showIt"
        class="terms"
        @click="showTermsConditions">
        {{ this.$t('Terms & Conditions') }}
      </div>
      <div
        v-if="showIt"
        class="send"
        @click="sendInvite">
        {{ this.$t('Invite') }}
      </div>
      <div
        v-if="!showIt"
        class="send"
        @click="goToLoadPage">
        {{ this.$t('Invite') }}
      </div>
    </div>
    <toast
      v-if="showDialog"
      :show-cancle="true"
      @cancle="cancle"
      @closeDialog="closeDialog">
      <p slot="title">{{ this.$t('Update your version') }}</p>
      <p slot="content">
        <template>{{ this.$t('Please update your app to get the best Dolfin experience and latest features.') }}</template>
      </p>
      <p slot="cancle">{{ this.$t('LATER') }}</p>
      <p slot="confirm">{{ this.$t('UPDATE NOW') }}</p>
    </toast>
    <toast
      v-if="showKycDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goKYC"
      @cancle="cancel1">
      <p slot="title">{{ $t('Verify Your Identity') }}</p>
      <p slot="content">{{ $t('Please provide more information to verify your identity before use this feature') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
  </div>
</template>

<script>
import toast from '@/pages/balance/common/dialog'
import { InvitationFriendsData, GetSharing, HistoryData } from '@/api'
import { PROMOTION_CLICK, PROMOTION_ENTER } from '@/pages/burry/promo';

export default {
  name: 'InvitationFriends',
  components: { toast },
  data() {
    return {
      showIt: false,
      showDialog: false,
      subjectId: '',
      imageUrl: '',
      showKycDialog: false,
      entry: '',
      kycParams: {},
      pageName: 'INVITE_F'
    }
  },
  created() {
    this.initData();
    PROMOTION_ENTER('INVITE_FRIENDS')
    this.$SDK.setTitle({
      title: this.$t('Invite friends')
    })
    this.$SDK.onBackPressNativeContinue(() => {
      PROMOTION_CLICK('INVITE_FRIENDS', 'CLICK_BACK')
    })
  },
  methods: {
    sendInvite() {
      PROMOTION_CLICK('INVITE_FRIENDS', 'CLICK_SENDINVITATION')
      this.Value1 = this.$utils.DistinguishedVersionNumber('1.4.0');
      // this.Value1 = true;
      if (this.Value1 === true) {
        this.getChannelDatay()
      } else {
        this.showDialog = true;
        PROMOTION_CLICK('update app popup', 'POPUP_UPDATEAPP')
      }
    },
    goToLoadPage() {
      PROMOTION_CLICK('INVITE_FRIENDS', 'CLICK_SENDINVITATION')
      this.Value1 = this.$utils.DistinguishedVersionNumber('1.4.0');
      // this.Value1 = true;
      if (this.Value1 === true) {
        this.$router.push({ name: 'newUsersJoin' })
      } else {
        this.showDialog = true;
        PROMOTION_CLICK('update app popup', 'POPUP_UPDATEAPP')
      }
    },
    closeDialog() {
      this.showDialog = false
      PROMOTION_CLICK('update app popup', 'CLICK_UPDATENOW')
      this.$SDK.jumpToAppMarket()
    },
    cancle() {
      this.showDialog = false
      PROMOTION_CLICK('INVITE_FRIENDS', 'CLICK_UPDATELATER')
    },
    showInstruction() {
      PROMOTION_CLICK('INVITE_FRIENDS', 'PROMOTION_CLICK')
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=88'
      this.$SDK.goNativeWebview(url)
    },
    showTermsConditions() {
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=87'
      this.$SDK.goNativeWebview(url)
    },
    async initData() {
      // const pageName = this.$utils.getQueryString('pageName');
      this.entry = this.$utils.getQueryString('entrance');
      // this.entry = this.$route.query.entrance;
      const res = await InvitationFriendsData({
        pageName: this.pageName
      });
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        if (res.data.resultData.responseCode === 1) {
          const response = res.data.resultData.response
          if (response.subjectId && response.subjectId !== '') {
            this.imageUrl = response.imageUrl
            this.subjectId = response.subjectId;
            this.showIt = true;
          }
        } else {
          const errorCode = res.data.resultData.errorCode
        }
      }
    },
    async seeHistory() {
      PROMOTION_CLICK('INVITE_FRIENDS', 'CLICK_VIEWHISTORY')
      this.$router.push({
        name: 'invitationHistory',
        query: {
          subjectId: this.subjectId,
          entrance: this.entry
        }
      })
    },
    async getChannelDatay() {
      const res = await GetSharing({
        subjectId: this.subjectId,
        entry: this.entry
      });
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        if (res.data.resultData.responseCode === 1) {
          const transData = res.data.resultData
          this.$SDK.shareByOS(transData)
        } else {
          const errorCode = res.data.resultData.errorCode
          if (errorCode === 'kyc.condition.failed') {
            this.kycParams = res.data.resultData.skipParam
            this.showKycDialog = true
          }
          if (errorCode === 'kyc.not.exists') {
            this.showKycDialog = true
          }
          if (errorCode === 'subject.not.found' || errorCode === 'subject.expired') {
            this.$toast({
              message: this.$t('Sorry, this activity expired.'),
              position: 'middle',
              duration: 3000
            })
          }
        }
      }
    },
    goKYC() {
      this.showKycDialog = false;
      this.$SDK.goNativeKYC(this.kycParams).then((res) => {
        // alert(JSON.stringify(res));
        // //完善kyc回调
        // if (res.status === 0) {
        //   this.initData();
        // }
      });
      this.$SDK.onForeground(() => {
        // alert('回到前台，查询kyc');
        // this.initData();
      })
    },
    cancel1() {
      this.showKycDialog = false;
      this.$SDK.closeWebView();
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.invite-bg {
  width: 100%;
  height:4.2rem;
  background: #D8D8D8;
}
.img-box {
  width:100%;
  height:4.2rem;
  img {
    width:100%;
    height:100%;
  }
}
.invite-info-box {
  width:100%;
  padding:.6rem .4rem 0;
  box-sizing: border-box;
  font-family: The1Official-Regular;
  font-size:.32rem;
  color:$color-gray-g;
  .invite-title {
      font-family: The1Official-Bold;
      font-size:.4rem;
      color:$color-gray-g;
      line-height:.6rem;
      float:left;
  }
  .history {
      float:right;
      width:2.62rem;
      height:.42rem;
      margin-top:.2rem;
      color: #59358C;
      font-family: The1Official-Regular;
      font-size:.28rem;
      .right {
          width:.32rem;
          height:.32rem;
          float:right;
          .img {
              width:100%;
              height:100%;
          }
      }
  }
  .explain {
      line-height:.54rem;
      margin-top:1rem;
  }
  .works {
      width:100%;
      height:.44rem;
      margin-top:.6rem;
      line-height:.54rem;
  }
  .terms {
  height:.44rem;
  line-height:.44rem;
  font-size:.24rem;
  text-decoration: underline;
  font-family: The1Official-Regular;
  color:$color-gray-g;
  margin:.6rem 0 .8rem 0;
}
  .send {
      width:5.6rem;
      height:1.12rem;
      line-height:1.12rem;
      text-align:center;
      color:#fff;
      background:$color-red;
      font-size:.36rem;
      margin:.8rem auto;
      border-radius:.56rem;
      text-transform: Uppercase ;
  }
}
</style>
