<template>
  <div class="my-coupon">
    <div class="coupon-wrapper">
      <div class="content-wrapper">
        <div>
          <div
            v-lazy:background-image="imgList[0] ? imgList[0] : ''"
            class="content-top">
            <div class="content-bg"/>
          </div>
          <div
            :style="{'color': itemData.title2Color}"
            class="content-title">
            {{ itemData.title1 }}
          </div>
          <div
            :style="{'color': itemData.title2Color}"
            class="content-center">
            {{ itemData.title2 }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'GroupItem',
  props: {
    itemData: {
      type: Object,
      default() {
        return {}
      }
    },
    groupAidList: {
      type: Array,
      default() {
        return [];
      }
    },
    currentIndex: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
    }
  },
  computed: {
    imgList() {
      if (this.itemData.imageUrl) {
        return this.itemData.imageUrl.split('}}');
      }
      return '';
    }
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/mixin.scss";
@import "@/assets/css/var.scss";
.my-coupon {
  position: relative;
  width: 100%;
  height: 100%;
//   .position-under {
//     position: absolute;
//     background: #D8D8D8;
//     box-shadow: 0 0.08rem 1.04rem 0 #C7D5E2;
//     width: 2.8rem;
//     height: 4.4rem;
//     transform: translate(-50%, -50%);
//     left: 50%;
//     top: 50%;
//   }
  .coupon-wrapper {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 0;
    // @include bg-image('Coupon_BG');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    box-sizing: border-box;
    // padding: 0.08rem 0.12rem 0 0.12rem;
    // width: 3.24rem;
    // height: 4.72rem;
    .content-wrapper {
      border-radius: 0.2rem;
      // width: 3.24rem;
      // height: 4.72rem;
      width: 100%;
      height: 100%;
      // width: 3.16rem;
      // height: 4.72rem;
      box-shadow: 0 0.04rem 0.18rem 0 rgba(0,0,0,0.1);
      overflow: hidden;
      .content-top {
        position: relative;
        height: 5.16rem;
        width: 100%;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        .content-bg {
          width:6.7rem;
          height:5.16rem;
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          top: 0;
          background: linear-gradient(-180deg, rgba(0,0,0,0.00) 62%, rgba(0,0,0,0.18) 73%, rgba(0,0,0,0.50) 100%);
          box-shadow: inset 0 0 2px 0 rgba(0,0,0,0.12);
          .run-out {
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            background-color: rgba(161,165,185,0.40);
          }
          .title {
            display: flex;
            position: absolute;
            left: 0.2rem;
            right: 0;
            bottom: 0.2rem;
            .icon {
              box-sizing: border-box;
              width: 0.48rem;
              height: 0.48rem;
              background-color: #fff;
              padding: 0.02rem;
              border-radius: 50%;
              box-shadow: 0 0.04rem 0.08rem 0 rgba(0,0,0,0.12), 0 0.02rem 0.12rem 0 rgba(0,0,0,0.12);
              .icon-img {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
              }
            }
            .message {
              min-width: 0;
              flex: 1;
              margin-left: 0.1rem;
              padding-right: 0.2rem;
              font-family: The1Official_Bold;
              font-size: 0.24rem;
              line-height: 0.48rem;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              color: #FFFFFF;
            }
          }
        }
      }
      .content-title {
          margin-top: .34rem;
          height: .6rem;
          line-height: .66rem;
          font-size: .36rem;
          font-family: The1Official-Bold;
          color: $color-gray-g;
          padding-left: .4rem;
      }
      .content-center {
        width: 5.9rem;
        padding-left: .4rem;
        font-family: The1Official-Regular;
        font-size: 0.32rem;
        color: $color-gray-g;
        letter-spacing: 0;
        height: 1rem;
        line-height: .54rem;
        overflow: hidden;
        text-overflow: ellipsis;
        display:-webkit-box;
        /*! autoprefixer: off */
        -webkit-box-orient: vertical;
        /* autoprefixer: on */
        -webkit-line-clamp: 2;
      }
    }
  }
}
</style>
