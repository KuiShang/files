<template>
  <div>
    <div
      v-if="propsData.componentInfos && propsData.componentInfos.length"
      class="wrapper">
      <div
        v-if="propsData.componentInfos && propsData.componentInfos.length"
        ref="groupScroll"
        class="content">
        <ul ref="list">
          <li
            v-for="(item, key) in propsData.componentInfos"
            :key="key">
            <group-item
              ref="groupComponent"
              :item-data="item"
              :current-index="key"
              :group-left-count="preventCount"/>
          </li>
        </ul>
        <div class="point-box">
          <span
            v-for="(item, key) in propsData.componentInfos"
            :key="key"
            :class="{'active':key==currentPageIndex}"
            class="point"/>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import GroupItem from '@/pages/invitation/components/groupItem';
import BScroll from 'better-scroll';

export default {
  name: 'Couponexplain',
  components: {
    GroupItem
  },
  props: {
    propsData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      preventCount: 0,
      showGroupGetCouponDialog: false,
      currentPageIndex: 0
    };
  },
  created() {
  },
  mounted() {
    this.$nextTick(() => {
      if (this.propsData.componentInfos.length) {
        const itemWidth = 6.7;
        const margin = 0.4;
        const width = ((itemWidth + margin) * this.propsData.componentInfos.length) - (margin * 2);
        this.$refs.list.style.width = `${width} + rem`;
        console.log('group', this.$refs.groupScroll);
        this.scroll = new BScroll(this.$refs.groupScroll, {
          scrollX: true,
          scrollY: false,
          click: true,
          snap: true,
          eventPassthrough: 'vertical'
        })
        this.scroll.on('scrollEnd', () => {
          console.log(this.currentPageIndex);
          const pageIndex = this.scroll.getCurrentPage().pageX;
          this.currentPageIndex = pageIndex;
        })
      }
    });
  },
  methods: {
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.wrapper {
  .title {
    padding: 0 0.4rem 0;
    margin-top: 0.54rem;
    margin-bottom: 0.3rem;
    .title1 {
      font-family: The1Official_Bold;
      font-size: 0.4rem;
      line-height: 0.6rem;
      color: #141e50;
      letter-spacing: 0;
    }
    .title2 {
      margin-top: 0.1rem;
      font-size: 0.28rem;
      line-height: 0.4rem;
      color: #141E50;
    }
  }
  .content {
    height: 9.04rem;
    overflow: hidden;
    position:relative;
    ul {
      display:flex;
      flex-direction:row;
      position: absolute;
      li {
        flex-shrink:0;
        margin-right: 0.4rem;
        width: 6.7rem;
        height: 7.46rem;
      }
    }
    .point-box {
      position: absolute;
      left:.4rem;
      top:8.12rem;
      height:.18rem;
      .point {
        width:.18rem;
        height:.18rem;
        display:block;
        float:left;
        margin-right:.16rem;
        border-radius:.18rem;
        border: 1px solid #D4004A;
        &.active {
          width:.64rem;
          height:.18rem;
          background:linear-gradient(225deg, #E40521 0%, #E62249 46%, #831F82 100%);
        }
      }
    }
  }
}
</style>
