<template>
  <div class="request2pay">
    <div class="padtop"/>
    <moneyInput
      v-model="totalAmount"
      :maxlength= "9"
      :type="type"
      :component-id= "'totalAmount'"
      :placeholder="this.$t('Amount to Split')"
      @input="checkField($event, 'totalAmount')"
      @handleClear="handleMoneyClear">
      <span
        slot="afterfix"
        class="afterfix-txt">{{ $t('Baht') }}</span>
    </moneyInput>
    <p
      v-show="limitAmountShowFlag"
      class="tips">{{ this.$t('limitAmount') }} ฿{{ limitAmount | tofloat | thousandBitSeparator }}
    </p>

    <div class="add-wraper">
      <moneyInput
        v-model="sumMember"
        :only-integer = true
        :maxlength= "2"
        :type="type"
        :component-id= "'sumMember'"
        :placeholder="this.$t('Amount of People')"
        @input="checkField($event, 'sumMember')"
        @handleClear="handleMoneyClear">
        <div
          slot="afterfix"
          class="afterfix-span">
          <span class="afterfix-span-txt">{{ $t('Include me') }}</span>
          &nbsp;
          <common-switch v-model="inCludeHimSelf"/>
        </div>
      </moneyInput>
      <p
        v-show="limitMemberShowFlag"
        class="tips">{{ this.$t('limitPeople') }} {{ limitMember }} {{ this.$t('people') }}
      </p>
      <p
        v-show="limitMemberMoreShowFlag"
        class="tips">{{ $t('limitMemberMoreShowFlag') }}
      </p>
      <p
        v-show="limitMemberIntegerShowFlag"
        class="tips">{{ $t('NumberOfPeople') }}
      </p>
    </div>

    <div class="add-notes-wraper">
      <common-input
        ref="commonInput"
        v-model="notes"
        :border="false"
        :maxlength="30"
        :holder="this.$t('Notes(Optional)')"/>
    </div>

    <div class="payView payView3">
      <div class="fle-container">
        <span class="txt-title"> {{ $t('Amount per person') }}</span>
      </div>
      <p class="txt-money"> <span class="txt-b">฿ </span>{{ perAmount | tofloat | thousandBitSeparator }}</p>
      <p class="txt-des">
        {{ $t('Total') }} <span class="txt-collected">{{ billedAmount | tofloat | thousandBitSeparator }}</span></p>
    </div>
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">{{ this.$t('r2pConfirm') }}</common-button>
    </div>
    <v-dialog
      v-if="showKycDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goKYC"
      @cancle="cancel">
      <p slot="title">{{ $t('Verify Your Identity') }}</p>
      <p slot="content">{{ $t('Please provide more information to verify your identity before use this feature') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </v-dialog>
  </div>
</template>
<script>
import hasPayError from '@/mixins/hasAlertError'
import { requestToPayInit, CheckKycLevel } from '@/api'
import { enumCurrency } from '@/utils/const'
import moneyInput from '@/pages/request2pay/common/moneyInput'
import dialog from '@/pages/balance/common/dialog'
import hasAlertError from "../../mixins/hasAlertError"

export default {
  name: 'RequestToPay',
  components: {moneyInput , 'v-dialog': dialog},
  mixins: [hasPayError],
  data() {
    return {
      totalAmount: '', // 应账单总金额
      inCludeHimSelf: true, // 是否包含自己
      sumMember: '', // 收款总人数
      realMember: 0, // 实际人数/剩余人数
      notes: '',
      showKycDialog: false,
      kycParams:{},
      titleRightMsg: {
        text: this.$t('History'),
        show: 1,
        textSize: 18,
        textColor: '#141E50'
      },
      limitMember: 50, // 收款人数上限
      limitAmount: 100000, // 收款金额上限
      perAmount: 0, // 每人应付金额
      billedAmount: 0, // 账单实收总金额
      limitAmountShowFlag: false,
      limitMemberShowFlag: false,
      limitMemberMoreShowFlag: false,
      limitMemberIntegerShowFlag: false,

      active: false // 按钮点击状态
    }
  },
  computed: {
    btnok() {
      return this.active;
    },
    type() {
      let type = 'number';
      const ua = navigator.userAgent.toLowerCase();
      const isAndroid = ua.indexOf('android') > -1 || false;
      if (isAndroid) {
        type = 'tel'
      }
      return type
    }
  },
  watch: {
    // 是否包含自己
    inCludeHimSelf(val) {
      if (this.sumMember !== '' && Number(this.sumMember).toFixed(2) !== '0.00'
        && this.totalAmount !== '' && Number(this.totalAmount).toFixed(2) !== '0.00') {
        this.active = this.isShowTip(this.totalAmount, this.sumMember, val);
      }
      if (this.active) {
        this.billed();
      }
    }
  },
  created() {
    this.initData();
    this.setTitle();
  },
  methods: {
    async initData() {
      //let kycLevel = this.$utils.getQueryString('kycLevel');
      //alert(kycLevel);

      this.$indicator.open({
        text: 'Loading...',
        spinnerType: 'fading-circle'
      });
      const res = await CheckKycLevel();
      let kycLevel = res && res.data && res.data.resultData;
      console.log('res', res);
      this.$indicator.close();

      if(!kycLevel) {
        this.kycParams=res.data.actionData.params;
        // kyc等级小于30,则完善kyc信息
        // 2019-3-29 需求改为kyc4
        // 2019-4-23 由后端配置等级,返回bool,true为满足条件
        // 2019-4-26 由后端配置等级,返回bool,PAYMENT 董
        this.showKycDialog = true;
      }
    },
    // 设置标题和右上角按钮
    setTitle() {
      this.$SDK.setTitle({
        title: this.$t('Share Bill'),
        mHeaderTitle: {
          showEnd: 0
        }
      });
      this.$SDK.setTitleRight(this.titleRightMsg, () => {
        const json = {
          type: 'native',
          address: '/trade/transaction',
          params: {
            transactionType: 0,
            subjoin: { from: 'h5/rtp' }
          }
        };
        this.$SDK.goNativeAction(json);
      })
    },
    goKYC() {
      this.showKycDialog = false;
      this.$SDK.goNativeKYC(this.kycParams).then((res) => {
        // alert(JSON.stringify(res));
        // //完善kyc回调
        // if (res.status === 0) {
        //   this.initData();
        // }
      });
      this.$SDK.onForeground(() => {
        // alert('回到前台，查询kyc');
        this.initData();
      })
    },
    cancel() {
      this.showKycDialog = false;
      this.$SDK.closeWebView();
    },
    // 检查输入分笔总额和分笔总人数
    checkField(e, key) {
      // console.log('blur e', e);
      // console.log('blur key', key);
      // console.log('blur key value', this[key]);
      // this[key] = e.mp.detail.value;

      // if (this[key].length === 0 || this[key] === '') {
      //   this.active = false;
      //   return
      // }
      // if (!this.isNumber(this[key])) {
      //   this[key] = '';
      //   this.active = false;
      //   return
      // }
      // switch (key) {
      //   case 'sumMember':
      //     // this.active = this.isShowTip(this.totalAmount, this[key], this.inCludeHimSelf);
      //     break;
      //   case 'totalAmount':
      //     // this.active = this.isShowTip(this[key], this.sumMember, this.inCludeHimSelf);
      //     break;
      //   default:
      //     this.active = false;
      //     break;
      // }
      if (this.sumMember !== '') {
        // this.active = true;
        this.active = this.isShowTip(this.totalAmount, this.sumMember, this.inCludeHimSelf);
        // 计算实际收款额
        this.billed();
      }else if (this.totalAmount !== '') {
        // this.active = true;
        this.activet = this.isShowTip(this.totalAmount, this.sumMember, this.inCludeHimSelf);
        // 计算实际收款额
        this.billed();
      }else {
        this.active = false;
      }
    },
    // 控制提示标识
    isShowTip(totalAmount, sumMember, includeHimSelf) {
      let active = true;
      if (sumMember > this.limitMember) {
        // 总人数不能大于50
        this.limitMemberShowFlag = true;
        this.limitMemberMoreShowFlag = false;
        active = false;
      } else {
        this.limitMemberShowFlag = false;
      }
      if (totalAmount > this.limitAmount) {
        // 单次分笔金额不能大于100000
        this.limitAmountShowFlag = true;
        active = false;
      } else {
        this.limitAmountShowFlag = false;
      }
      if (active && includeHimSelf) {
        this.limitMemberIntegerShowFlag = false;
        // 包含自己，分单人数不能小于2
        if (sumMember !== '' && Number(sumMember).toFixed(2) !== '0.00') {
          if (sumMember < 2) {
            // 显示，分单人数小于2提示文案
            this.limitMemberMoreShowFlag = true;
            active = false;
          } else {
            this.limitMemberMoreShowFlag = false;
            if (totalAmount !== '' && Number(totalAmount).toFixed(2) !== '0.00') {
              active = true;
            } else {
              active = false;
            }
          }
        } else {
          active = false;
        }
      } else if (active && !includeHimSelf) {
        this.limitMemberMoreShowFlag = false;
        // 不包含自己,分单人数大于1
        if (sumMember !== '' && Number(sumMember).toFixed(2) !== '0.00') {
          if (sumMember < 1) {
            this.limitMemberIntegerShowFlag = true;
            active = false;
          } else {
            this.limitMemberIntegerShowFlag = false;
            if (totalAmount !== '' && Number(totalAmount).toFixed(2) !== '0.00') {
              active = true;
            } else {
              active = false;
            }
          }
        }
      } else if (!active) {
        this.limitMemberIntegerShowFlag = false;
        this.limitMemberIntegerShowFlag = false;
      }

      // if (active) {
      //   // 付款金额四舍五入为0，不能发起AA
      //   if (Math.round(totalAmount) < 1) {
      //     active = false;
      //   }
      // }
      return active;
    },
    handleMoneyClear() {
      this.active = false;
    },
    // 计算实际收款额
    billed() {
      /**
       * 被除数、除数都不为0
       * 单个收款金额=收款总金额÷人数，除不尽的情况，单个收款金额的最后一位进位
       */
      this.realMember = this.sumMember;
      if (this.inCludeHimSelf) {
        if (this.sumMember == 2) {
          // AA两人各一半
          this.perAmount = this.totalAmount * 0.5;
        } else {
          this.perAmount = this.totalAmount / this.realMember;
        }
      } else {
        this.perAmount = this.totalAmount / this.realMember;
      }

      if(!this.isNumber(this.perAmount)) {
        this.perAmount = 0;
        this.active = false;
        return;
      }else {
        // 截取均摊额度，截取数字   为了处理如 11.13/3这种IEEE 754标准引起的问题
        // let tempAmount = this.perAmount.toFixed(8);
        // let tempAmount2 = this.perAmount.toString();
        // let tempAmount3 = String(this.perAmount);
        // let tempAmount4 = this.formatFloat(this.perAmount, 8);
        // let tempAmount5 = this.formatFloatFloor(this.perAmount, 8);
        this.perAmount = this.formatFloatFloor(this.perAmount, 8);
      }

      if(this.formatFloatFloor(this.perAmount, 4) < 0.0099){
        // 平均收款金额小于0.01，不能发起AA
        const htm = `<div class="message-box-cashier-cdcp-cardinfo">
                        <p class="txt">Per person is too small, please check it.</p>
                      </div>`;
        this.$messagebox({
          title: '',
          message: htm,
          confirmButtonText: this.$t('OK')
        });
        this.perAmount = 0;
        this.billedAmount = 0;
        this.active = false;
        return;
      }

      // 除不尽，末尾进一
      let x = String(this.perAmount).indexOf('.') + 1; //小数点的位置
      let y = String(this.perAmount).length - x; //小数的位数
      if(y > 2){
        // 小数点后多于两位认为除不尽，末尾需进一
        const m = 10 ** 2;
        this.perAmount = Math.ceil(this.perAmount * m) / m;
      }

      let tempAmount;
      if (this.inCludeHimSelf) {
        // 包含自己
        this.realMember = (this.sumMember - 1);
        tempAmount = this.formatFloat(this.perAmount * this.realMember, 2);
        // if(this.isNumber(tempAmount)){
        //   this.billedAmount = tempAmount;
        // }else {
        //   this.billedAmount = 0;
        //   this.active = false;
        // }
      } else {
        // 不包含自己
        // this.billedAmount = this.totalAmount;
        tempAmount = this.formatFloat(this.perAmount * this.sumMember, 2);
      }
      if(this.isNumber(tempAmount)){
        this.billedAmount = tempAmount;
      }else {
        this.billedAmount = 0;
        this.active = false;
      }
    },
    formatFloatFloor(f, digit) {
      // 浮点运算，四舍五入处理方法
      const m = 10 ** digit;
      return Math.floor(f * m) / m;
    },
    formatFloat(f, digit) {
      // 浮点运算，四舍五入处理方法
      const m = 10 ** digit;
      return Math.round(f * m) / m;
    },
    isNumber(value) {
      var patrn = /^(-)?\d+(\.\d+)?$/;
      if (patrn.exec(value) == null || value == "") {
        return false
      } else {
        return true
      }
    },
    // 提交按钮事件
    async handleClick() {
      // console.log('之前的deviceinfo:', this.$DeviceInfo)

      this.$indicator.open({
        text: 'Loading...',
        spinnerType: 'fading-circle'
      });
        const postData = { theoryAmount: this.totalAmount,
          actualAmount: this.billedAmount,
          perAmount: this.perAmount,
          currency: enumCurrency.THB,
          memberSum: this.sumMember,
          includeSelf: this.inCludeHimSelf === true ? 1 : 0,
          note: this.notes,
          deviceInfo: this.$DeviceInfo };
        // alert(JSON.stringify(postData));
        // console.log('提交数据',JSON.stringify(postData));
        const res = await requestToPayInit(postData);
        console.log('返回的数据:', res);
        this.$indicator.close();
        if (res.data.resultCode === 1) {
          console.log('request to pay successful', res);
          const json = {
            type: 'native',
            address: '/qr/rtp',
            params: {
              serviceOddNo: res.data.resultData.serviceOddNo
            }
          };
          this.$SDK.goNativeAction(json);
          this.$SDK.closeWebView();
        } else if (res.data.resultCode === 0) {
          this.hasAlertError(res);
        }
      }
  }
}
</script>

<style lang="scss" scoped>
  @import "@/assets/css/var.scss";

  .add-notes-wraper /deep/ img.custom-ico{
    right: .1rem;
  }
  .add-wraper /deep/ .afterfix-span{
    display: inline-flex;
    justify-content: center;
    padding-bottom: .1rem;
  }
  .request2pay {
    font-size: .24rem;
    height: 100%;
    position: relative;
    box-sizing: border-box;
    background: $color-white;
    padding: 0rem .4rem 0 .4rem;
    .padtop {
      padding-top: 1rem;
    }
    .add-wraper{
      padding-top: .5rem;
    }
    .payView {
      background-color: #fff;
      box-sizing: border-box;
      text-align: center;
      padding-top: .61rem;
      .fle-container {
        display: flex;
        justify-content: center;
        align-items: center;
        .txt-title {
          text-align: center;
          padding-left: .2rem;
          font-size: .28rem;
          color: $color-gray-h;
        }
      }
      .txt-b {
        font-family: The1Official_Bold !important;
        font-size: .56rem;
        position: relative;
        top: -0.07rem;
      }
      .txt-money {
        padding-top: .68rem;
        font-size: .92rem;
        text-align: center;
        line-height: .52rem;
        font-family: The1Official_Bold;
        font-size: .96rem;
        color: $color-red;
      }
      .txt-collected{
        font-family: The1Official_Bold;
        color: $color-red;
      }
      .txt-des {
        padding-top: .52rem;
        font-size: .24rem;
        color: $color-gray-h;
        line-height: .52rem;
        padding-bottom: .61rem;
      }
    }
    .tips {
      padding-top: .20rem;
      line-height: .42rem;
      letter-spacing: 0;
      text-align: left;
      font-size: .28rem;
      color: $color-red;
    }
    .afterfix-txt {
      font-size: .28rem;
      color: $color-gray-g;
      padding-bottom: .15rem;
    }
    .afterfix-span-txt{
      margin-top: .15rem;
      width: 85px;
      color: $color-gray-g;
    }
    .add-notes-wraper {
      border-bottom: 1px solid #A1A5B9;
      padding-top: .2rem;
    }
    .btn-wraper {
      margin-top: .4rem;
      display: flex;
      justify-content: center;
      box-sizing: border-box;
    }
    .payView2 {
      box-sizing: border-box;
    }
  }
</style>
