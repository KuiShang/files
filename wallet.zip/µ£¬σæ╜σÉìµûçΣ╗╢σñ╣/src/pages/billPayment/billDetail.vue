<template>
  <div class="bill-detail-wrapper">
    <section class="header">
      <div class="tit">
        <span class="img"/>
        <span class="des">The Provincial Electricity Authority</span>
      </div>
      <span class="money">$20.00</span>
    </section>
    <section class="cost-info info">
      <ul>
        <li class="item">
          <span>Total Amount</span>
          <span>40.00</span>
        </li>
        <li class="item">
          <span>Total Amount</span>
          <span>40.00</span>
        </li>
      </ul>
    </section>
    <section class="other-info info">
      <ul>
        <li class="item">
          <span>CA/Refrence</span>
          <span>18765565</span>
        </li>
        <li class="item">
          <span>CA/Refrence</span>
          <span>18765565</span>
        </li>
      </ul>
    </section>
    <div class="btn-wrapper">
      <common-button
        type="danger"
        icon="saoma"
        @click.native="handleClick">Pay Now</common-button>
    </div>
  </div>
</template>
<script>
import * as types from '@/store/mutation-types'

export default {
  name: 'BillDetail',
  data() {
    return {
      result: {}
    };
  },
  created() {
    setTimeout(() => {
      this.$store.commit(types.SET_TiTLE, 'Transtion Detail')
      this.$store.commit(types.SET_TITLE_BLACK, false)
    }, 10)
    this.initData()
  },
  methods: {
    async initData() {
      const res = await this.axios.get('/th/wallet/billpayment/queryBillResult', {
        params: {
          transactionNo: this.$route.params.transactionNo,
          version: this.$DeviceInfo.appVersion
        }
      })
      if (res.data.code !== '000000') {
        console.log('error')
        return
      }
      this.result = res.data.data
    },
    handleClick() {
      console.log('click')
    }
  }

};
</script>
<style lang="scss" scoped>
.bill-detail-wrapper {
  font-size: .28rem;
  // height: calc(100% - 0.88rem);
  height: 100%;
  background-color: #f6f6f6;
  .header {
    height: 3.4rem;
    background-color: #fff;
    margin-bottom: 0.3rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    .tit {
      display: flex;
      justify-content: center;
      .img {
        display: inline-block;
        height: .6rem;
        width: .6rem;
        background: #000;
      }
      .des {
        font-family: SFUIText-Regular;
        font-size: 0.28rem;
        color: #838080;
        line-height: 0.52rem;
      }
    }
    .money {
      font-family: PingFangSC-Semibold;
      font-size: 0.92rem;
      color: #302B2B;
      text-align: center;
      line-height: 56px;
    }
  }
  .info {
    height: 3.3rem;
    background-color: #fff;
    .item {
      height: .9rem;
      line-height: .9rem;
      font-family: SFUIText-Regular;
      color: #838080;
      display: flex;
      justify-content: space-between;
      padding: 0 .36rem 0 .42rem;
    }
  }
  .btn-wrapper {
    padding-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}
</style>

