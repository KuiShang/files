<template>
  <div class="bill-payment-wrapper">
    <ul class="list">
      <li
        v-for="item in billList"
        :key="item.typeNo"
        class="item"
        @click="routerCompany(item.typeNo)"
      >
        <div class="container">
          <i
            :style="{backgroundImage: 'url(' + require(`../../assets/images/billPayment/${item.typeImg}.png`) + ')'}"
            class="logo"
          />
          <span class="title">{{ item.name }}</span>
          <i class="right-arrow"/>
        </div>
      </li>
    </ul>
    <div class="bottom-mask">
      <div class="btn-wraper">
        <common-button
          type="danger"
          icon="saoma"
          @click.native="handleClick">SCAN BILL</common-button>
      </div>
    </div>
  </div>
</template>
<script>
import * as types from '@/store/mutation-types'

export default {
  name: 'BillPayment',
  data() {
    return {
      billList: []
    };
  },
  computed: {
  },
  created() {
    setTimeout(() => {
      this.$store.commit(types.SET_TiTLE, 'Bill Payment')
      this.$store.commit(types.SET_TITLE_BLACK, false)
    }, 10)
    this.initData()
  },
  methods: {
    async initData() {
      const res = await this.axios.get('/th/wallet/billpayment/queryPaymentType', {
        params: {
          version: this.$DeviceInfo.appVersion
        }
      })
      if (res.data.code !== '000000') {
        console.log('error')
        return
      }
      const billList = res.data.data
      if (Array.isArray(billList)) {
        this.billList = billList
      } else {
        console.error(`${billList} is not array`)
      }
    },
    handleClick() {
      console.log('click')
    },
    routerCompany(typeNo) {
      this.$router.push({ name: 'billCompany', query: { typeno: typeNo } })
    }
  }
}
</script>
<style lang="scss" scoped>
.bill-payment-wrapper {
  font-size: .32rem;
  height: 100%;
  position: relative;
  .list {
    .item {
      box-sizing: border-box;
      // background: #FFFFFF;
      padding:0 0 0  0.47rem;
      .container {
        padding-right: .4rem;
        height: 1.5rem;
        display: flex;
        align-items: center;
        border-bottom: 1px solid  #EEEEEE;
        .logo {
          height: 0.8rem;
          width: 0.8rem;
          // background: url("../../assets/images/billPayment/leasing.png");
          background-size: cover;
        }
        .title {
          line-height: 0.53rem;
          padding-left: 0.37rem;
          flex-grow: 1;
          text-align: left;
        }
        .right-arrow {
          width: 0.24rem;
          height: 0.24rem;
          background: url("../../assets/images/billPayment/jiantou.png");
          background-size: cover;
        }
      }
    }
  }
  .bottom-mask {
    position: fixed;
    bottom: 0;
    height: 2.6rem;
    left: 0;
    right: 0;
    background-image: linear-gradient(-180deg, rgba(255,255,255,0.00) 0%, #FFFFFF 19%);
  }
  .btn-wraper {
    position: absolute;
    bottom: 0.8rem;
    left: 50%;
    transform: translate(-50%);
  }
}
</style>

