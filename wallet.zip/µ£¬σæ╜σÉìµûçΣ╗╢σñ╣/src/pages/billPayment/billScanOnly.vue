<template>
  <div class="bill-scan-wrapper">
    <span class="logo"/>
    <p class="des">Metropolitian Waterworks Authority</p>
    <span class="line"/>
    <div class="btn-wrapper">
      <common-button
        type="danger"
        icon="saoma"
        @click.native="handleClick">SCAN BILL</common-button>
    </div>
    <div class="tips">This antuority only support bill scanning to make payment</div>
  </div>
</template>
<script>
import * as types from '@/store/mutation-types'

export default {
  name: 'BillScan',
  data() {
    return {};
  },
  created() {
    setTimeout(() => {
      this.$store.commit(types.SET_TiTLE, 'The Metropolitan Electricty')
      this.$store.commit(types.SET_TITLE_BLACK, true)
    }, 10)
  },
  methods: {
    handleClick() {
      console.log('click')
    }
  }
};
</script>
<style lang="scss" scoped>
.bill-scan-wrapper {
  font-size: .24rem;
  height: 100%;
  background: url("../../assets/images/billPayment/77.png");
  background-size: cover;
  padding-top: 1.72rem;
  .logo {
    display: inline-block;
    width: 1.8rem;
    height: 1.8rem;
    background-color: #fff;
    border-radius: 50%;
    margin-left: 50%;
    transform: translateX(-50%);
  }
  .des {
    font-family: SFUIDisplay-Semibold;
    font-size: .42rem;
    color: #FFFFFF;
    text-align: center;
    width: 5rem;
    transform: translateX(-50%);
    margin-left: 50%;
    padding-top: .56rem;
  }
  .line {
    display: block;
    width: .4rem;
    height: 0.04rem;
    opacity: 0.2;
    background: #FFFFFF;
    margin-left: 50%;
    transform: translateX(-50%);
    margin-top: .36rem;
  }
  .btn-wrapper {
    padding-top: 2.22rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
  .tips {
    color: #fff;
    display: block;
    padding-top: .42rem;
    text-align: center;
    opacity: 0.5;
    font-family: SFUIDisplay-Regular;
  }
}
</style>

