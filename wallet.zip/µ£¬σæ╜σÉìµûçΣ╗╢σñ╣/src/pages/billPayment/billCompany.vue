<template>
  <div class="bill-company-wrapper">
    <ul class="list">
      <li
        v-for="item in companyList"
        :key="item.id"
        class="item"
        @click="routerKeyinOrCompany(item)">
        <div class="container">
          <i
            :style="{backgroundImage: 'url(' + require(`../../assets/images/billPayment/${item.imgUrl}.png`) + ')'}"
            class="logo"/>
          <span class="title">{{ item.name }}</span>
          <i class="right-arrow"/>
        </div>
      </li>
    </ul>
    <div class="btn-wraper">
      <common-button
        type="danger"
        icon="saoma"
        @click.native="handleClick">SCAN BILL</common-button>
    </div>
  </div>
</template>
<script>
import * as types from '@/store/mutation-types'

export default {
  name: 'BillCompany',
  data() {
    return {
      companyList: []
    };
  },
  created() {
    setTimeout(() => {
      this.$store.commit(types.SET_TiTLE, 'Bill Payment')
      this.$store.commit(types.SET_TITLE_BLACK, false)
    }, 10)
    this.initData()
  },
  methods: {
    async initData() {
      const res = await this.axios.get('/th/wallet/billpayment/getCompanyByPayType', {
        params: {
          version: this.$DeviceInfo.appVersion,
          type: this.$route.query.typeno
        }
      })
      if (res.data.code !== '000000') {
        console.log('error')
        return
      }
      const companyList = res.data.data
      if (Array.isArray(companyList)) {
        this.companyList = companyList
      } else {
        console.error(`${companyList} is not array`)
      }
    },
    handleClick() {
      console.log('click')
    },
    routerKeyinOrCompany(item) {
      const billType = item.billType
      console.log(billType)
      if (billType.keyin === 1) {
        this.$router.push({ name: 'billKeyin', params: { companyname: item.name, imgUrl: item.imgUrl } })
      } else if (billType.scan === 1) {
        this.$router.push({ name: 'billScanOlny', params: { companyname: item.name, imgUrl: item.imgUrl } })
      } else {
        console.warn('参数有误：', billType)
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.bill-company-wrapper {
  font-size: .32rem;
  .list {
    .item {
      box-sizing: border-box;
      // background: #FFFFFF;
      padding:0 0 0  0.47rem;
      .container {
        padding-right: .4rem;
        height: 1.5rem;
        display: flex;
        align-items: center;
        border-bottom: 1px solid  #EEEEEE;
        .logo {
          height: 0.8rem;
          width: 0.8rem;
          background-size: cover;
        }
        .title {
          line-height: 0.53rem;
          padding-left: 0.37rem;
          flex-grow: 1;
          text-align: left;
        }
        .right-arrow {
          width: 0.24rem;
          height: 0.24rem;
          background: url("../../assets/images/billPayment/jiantou.png");
          background-size: cover;
        }
      }
    }
  }
  .btn-wraper {
    position: absolute;
    bottom: 0.8rem;
    left: 50%;
    transform: translate(-50%);
  }
}
</style>

