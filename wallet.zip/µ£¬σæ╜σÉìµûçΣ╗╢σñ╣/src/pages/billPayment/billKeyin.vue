<template>
  <div class="bill-keyin-wrapper">
    <div class="post">
      <span class="img"/>
      <span
        class="des"
        v-text="$route.params.companyname"
      />
      <span class="line"/>
    </div>
    <div class="content">
      <p class="label">CA/Refence Number</p>
      <!-- <div class="input-waper">
        <input
          class="input"
          type="text"
          placeholder="Enter reference number">
      </div> -->
      <common-field
        v-model="number"
        type="number"
        label=""
        placeholder="Enter reference number"/>
      <p class="tips">Your contract account number will be auto-saved for future pay-ment</p>
      <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">Next</common-button>
      </div>
      <div class="hisory-record">
        <div class="title">
          <span class="text">Hisory record</span>
          <i
            class="del"
            @click="showDelete = !showDelete"/>
        </div>
        <ul class="records">
          <li class="item">
            <span>45351874999 Jack</span>
            <common-icon
              v-show="showDelete"
              class="custom-ico"
              name="delete_fill"
              size=".9rem"
              @click="removeHisory(1)"
            />
          </li>
          <li class="item">
            45351874999 Jack
          </li>
          <li class="item">
            45351874999 Jack
          </li>
        </ul>

      </div>

    </div>
  </div>
</template>
<script>
import * as types from '@/store/mutation-types'

export default {
  name: 'BillCompany',
  data() {
    return {
      showDelete: false,
      number: '',
      historyList: []
    };
  },
  created() {
    setTimeout(() => {
      this.$store.commit(types.SET_TiTLE, 'The Metropolitan Electricty')
      this.$store.commit(types.SET_TITLE_BLACK, true)
    }, 10)
    this.setTitle()
    this.initData()
  },
  methods: {
    setTitle() {

    },
    async initData() {
      const res = await this.axios.get('/th/wallet/billpayment/queryKeyInHistory', {
        params: {
          version: this.$DeviceInfo.appVersion,
          customerId: this.customerId
        }
      })
      if (res.data.code !== '000000') {
        console.log('error')
        return
      }
      const historyList = res.data.data
      if (Array.isArray(historyList)) {
        this.historyList = historyList
      } else {
        console.error(`${historyList} is not array`)
      }
    },
    handleClick() {
      this.$router.push({ name: 'billDetail', query: { transactionNo: this.number } })
    },
    removeHisory(item) {
      console.log(item)
    }
  }
};
</script>
<style lang="scss" scoped>
.bill-keyin-wrapper {
  font-size: .28em;
  .post {
    height: 3.72rem;
    background: url("../../assets/images/billPayment/Group4.png");
    background-size: cover;
    color: #fff;
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    align-items: center;
    box-sizing: border-box;
    padding: .4rem 0 .55rem 0;
    .img {
        display: inline-block;
        height: 1.2rem;
        width: 1.2rem;
        background: #eee;
        border-radius: 50%;
    }
    .des {
      font-size: .38rem;
      width: 5rem;
      text-align: center;
    }
    .line {
      display: block;
      width: .4rem;
      height: 0.04rem;
      opacity: 0.2;
      background: #FFFFFF;
    }
  }
  .content {
    padding: .29rem .40rem 0 .40rem;
    .label {
      font-family: Thonburi;
      font-size: .24rem;
      color: #838080;
    }
    .input-waper {
      height: 1.1rem;
      padding: .28rem 0rem .27rem 0rem;
      box-sizing: border-box;
      border-bottom: 1px solid #EEEEEE;;
      .input {
        border: 0;
        padding: 0;
        display: block;
        width: 100%;
        resize: none;
        box-sizing: border-box;
        font-size: .46rem;
        outline:none;
      }
      ::-webkit-input-placeholder { /* WebKit browsers */
        color: #D6D5D5;
      }
      :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
        color: #D6D5D5;
      }
      ::-moz-placeholder { /* Mozilla Firefox 19+ */
        color: #D6D5D5;
      }
      :-ms-input-placeholder { /* Internet Explorer 10+ */
        color: #D6D5D5;
      }
    }
    .tips {
      padding-top: .2rem;
      padding-bottom: .4rem;
      font-family: SFUIDisplay-Regular;
      font-size: .24rem;
      line-height: .29rem;
      color: #838080;
    }
    .btn-wraper {
      padding-bottom: .84rem;
      display: flex;
      justify-content: center;
    }
    .hisory-record {
      .title {
        display: flex;
        justify-content: space-between;
        .text {
          font-family: SFUIDisplay-Semibold;
          font-size: .32rem;
          color: #302B2B;
        }
        .del {
          display: inline-block;
          height: 0.36rem;
          width: 0.36rem;
          background: url("../../assets/images/billPayment/calendar@3x.png");
          background-size: cover;
        }
      }
      .records {
        padding-top: .4rem;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        align-items: flex-end;
        height: 1.6rem;
        .item {
          background: #F6F6F6;
          height: .7rem;
          line-height: .7rem;
          text-align: center;
          width: 3.2rem;
          position: relative;
          .custom-ico {
            color: #DDDDDD;
            position: absolute;
            right: -0.37rem;
            top: -0.35rem;
          }
        }
      }
    }
  }
}
</style>

