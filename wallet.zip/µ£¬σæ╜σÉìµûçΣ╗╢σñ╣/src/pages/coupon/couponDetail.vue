<template>
  <div class="coupon-detail">
    <div
      :style="{backgroundImage: 'url(' + bg + ')'}"
      :class="{op5: !bgStatus}"
      class="bg"
    >
      <img
        v-if="expsoon"
        class="nearly-expired"
        src="@/assets/images/coupon/nearlyexpire.png">
      <img
        :src="logo"
        class="logo"
      >
    </div>
    <div class="txt">
      <p class="merchant">{{ merchant }}</p>
      <p class="title">{{ title }}</p>
      <p class="date">
        <span
          v-if="validDate"
          class="valid-date">{{ $t('Valid from') }} {{ validDate }} {{ $t('to') }}</span>
        {{ date }}
      </p>
      <p
        v-if="groupBatchLeftCount !== -1"
        class="group-batch-left">
        <img src="./MyCoupon@2x.png">
        <span class="group-batch-left-count">{{ replaceCount($t('Coupons left')) }}</span>
      </p>
      <p class="detail-title">{{ $t('Coupon Detail') }}</p>
      <ul class="promo-detail">
        <li
          v-for="(item, idx) in detailArray"
          :key="idx"
          class="item"
        >{{ item }}</li>
      </ul>
      <div class="mask-container">
        <p class="detail-title mt4">{{ $t('Conditions') }}</p>
        <ul
          v-if="flag"
          class="promo-condition">
          <li
            v-for="(item, idx) in getContentArray"
            :key="idx"
            class="item"
          >{{ item }}</li>
          <span
            v-if="hasShowmore && flag"
            class="mask"
          />
        </ul>
        <ul
          v-else
          class="promo-condition"
        >
          <li
            v-for="(item, idx) in getContentArray"
            :key="idx"
            class="item"
          >{{ item }}</li>
        </ul>
        <p
          v-if="hasShowmore"
          class="read-more"
          @click="toggle">{{ toggleTxt }}</p>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  name: 'CouponDetail',
  props: {
    bg: {
      type: String,
      default: ''
    },
    logo: {
      type: String,
      default: ''
    },
    merchant: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    date: {
      type: String,
      default: ''
    },
    detail: {
      type: String,
      default: ''
    },
    content: {
      type: String,
      default: ''
    },
    expsoon: {
      type: Number,
      default: 0
    },
    validDate: {
      type: String,
      default: ''
    },
    bgStatus: {
      type: Boolean,
      default: true
    },
    groupBatchLeftCount: {
      type: Number,
      default: -1
    }
  },
  data() {
    return {
      flag: true
    }
  },
  computed: {
    hasShowmore() {
      return this.content.length > 150
    },
    getContent() {
      if (!this.hasShowmore) {
        return this.content
      }
      if (this.flag) {
        return this.content.substring(0, 150)
      }
      return this.content
    },
    toggleTxt() {
      if (this.flag) {
        return this.$t('Read more')
      }
      return this.$t('Show less')
    },
    detailArray() {
      return this.detail.split('\\n')
    },
    getContentArray() {
      return this.getContent.split('\\n')
    }
  },
  created() {
  },
  methods: {
    toggle() {
      this.flag = !this.flag
    },
    replaceCount(str) {
      if (this.groupBatchLeftCount === 0 || this.groupBatchLeftCount === 1) {
        return str.replace('100', this.groupBatchLeftCount).replace('Coupons', 'Coupon')
      }
      return str.replace('100', this.groupBatchLeftCount)
    }
    // getContent() {
    //   return this.content.substring(0, 200)
    // }
  }
}
</script>
<style lang="scss" scoped>
  .coupon-detail {
    margin-bottom: 2rem;
    .bg {
      height: 5.64rem;
      background-color: #ccc;
      position: relative;
      background-size: cover;
      .logo {
        background: #eee;
        box-shadow: 0 2px 4px 0 rgba(0,0,0,0.12), 0 1px 6px 0 rgba(0,0,0,0.12);
        border-radius: .5rem;
        width: 1rem;
        height: 1rem;
        position: absolute;
        bottom: -0.5rem;
        left: 50%;
        margin-left: -0.5rem;
      }
    }
    .op5 {
      opacity: .5;
    }
    .txt {
      padding: 0 .4rem;
      .merchant {
        margin-top: .7rem;
        font-size: 14px;
        color: #141E50;
        text-align: center;
      }
      .title {
        font-size: 24px;
        color: #141E50;
        letter-spacing: 0;
        text-align: center;
        margin-top: .4rem;
        word-break: break-all;
      }
      .date, .valid-date {
        font-size: 14px;
        color: #A1A5B9;
        letter-spacing: 0;
        text-align: center;
        line-height: 18px;
        margin: .32rem;
        margin-bottom: 0.05rem;
        .valid-date {
          margin: 0;
        }
      }
      .group-batch-left {
        // background-image: url('./MyCoupon@2x.png');
        display: flex;
        justify-content: center;
        align-items: center;
        img {
          height: .4rem;
        }
        .group-batch-left-count {
          font-size: 14px;
          color: #A1A5B9;
          letter-spacing: 0;
          text-align: center;
          padding-left: .2rem;
        }
      }
      .detail-title {
        font-family: The1Official_Bold;
        font-size: 18px;
        color: #141E50;
        letter-spacing: 0;
        text-align: left;
        line-height: 30px;
        margin-top: .8rem;
      }
      .mt4 {
        margin-top: .4rem;
      }
      .promo-detail {
        font-size: 14px;
        color: #141E50;
        letter-spacing: 0;
        text-align: left;
        margin-top: .2rem;
        border-bottom: 1px solid #E7E8ED;
        // padding-bottom: .4rem;
        line-height: 25px;
        .item {
          margin-bottom: .4rem;
          word-wrap: break-word;
          // text-indent: .4rem;
        }
      }
      .promo-condition {
        position: relative;
        margin-top: .2rem;
        font-size: 14px;
        color: #141E50;
        letter-spacing: 0;
        text-align: left;
        line-height: 25px;
        .item {
          margin-bottom: .6rem;
          word-wrap: break-word;
          // text-indent: .4rem;
        }
      }
      .read-more {
        font-size: 18px;
        color: #FF3E5B;
        letter-spacing: 0;
        text-align: left;
        line-height: 30px;
        padding-bottom: .3rem;
        padding-top: .2rem;
      }
      .mask-container {
        position: relative;
        .mask {
          position: absolute;
          top: 0;
          bottom: 0;
          z-index: 1;
          right: 0;
          left: 0;
          margin: 0;
          padding: 0;
          background-image: linear-gradient(rgba(255,255,255,0) 0% ,rgba(255,255,255,1));
        }
      }
    }
  }
</style>
