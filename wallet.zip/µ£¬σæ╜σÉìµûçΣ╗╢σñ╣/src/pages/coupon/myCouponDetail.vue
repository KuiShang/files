<template>
  <div class="coupon-use">
    <couponDetail
      :bg="dataObj.background"
      :logo="dataObj.logo"
      :merchant="multilingual.merchant"
      :title="multilingual.title"
      :date="dataObj.expDate"
      :detail="multilingual.desc"
      :content="multilingual.condition"
      :expsoon="dataObj.expSoon"
      :valid-date="dataObj.validDate"
      :bg-status="bgStatus"
    />
    <div
      v-if="!Paymentvoucher"
      class="btn-wraper">
      <common-button
        v-if="dataObj.couponStatus === 1 || dataObj.couponStatus === 2"
        :disabled="true"
        type="danger"
      >{{ btnText }}</common-button>
      <common-button
        v-else-if="dataObj.couponStatus === 0"
        height="1.4rem"
        type="danger"
        @click.native="handleClick"><div class="conta"><span class="itm">{{ btnText }}</span><span class="itt">{{ $t('valid for') }} {{ dataObj.countdownTime }} {{ $t('minutes after click') }}</span></div></common-button>
      <common-button
        v-else-if="dataObj.couponStatus === 3"
        height="1.4rem"
        type="danger"
        @click.native="handleClick"><div class="conta"><span class="itm">{{ btnText }}</span><span class="itt">{{ $t('Time Left') }} {{ formatSeconds(dataObj.timeLeft) }}</span></div></common-button>
    </div>
    <div
      v-show="Paymentvoucher"
      class="btn-wraper">
      <common-button
        height="1.4rem"
        type="danger"
        @click.native="handleClick2"><div class="conta"><span class="itm">{{ this.$t('USE') }}</span></div></common-button>
    </div>
    <toast
      v-if="showDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goUse"
      @cancle="cancleUse"
    >
      <p slot="title">{{ $t('Confirmation') }}</p>
      <p slot="content">{{ $t('This coupon is valid for') }} {{ dataObj.countdownTime }} {{ $t('minutes. Please confirm to cashier staff to use this coupon.') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
    <toast
      v-if="showGoCouponListDialog"
      :title-position= "0.3"
      :confirm-btn-plain="true"
      :font-size= "0.36"
      :show-cancle= "false"
      @closeDialog="gotoCouponList"
    >
      <p slot="title">{{ $t('Cannot use this coupon now') }}</p>
      <p slot="content">{{ $t('Sorry, please check the coupon validity period on coupon detail page') }}</p>
      <p slot="confirm">{{ $t('OK') }}</p>
    </toast>
  </div>
</template>
<script>
import { couponUseDetail, GroupDiscoverygetCoupoReportinformation } from '@/api'
import handlInitData from '@/mixins/handlInitData'
import couponDetail from '@/pages/coupon/couponDetail'
import toast from '@/pages/balance/common/dialog'

let couponId = ''
let timer = ''

export default {
  name: 'MyCouponDetail',
  components: { couponDetail, toast },
  mixins: [handlInitData],
  data() {
    return {
      showDialog: false,
      showGoCouponListDialog: false,
      Paymentvoucher: false // 券类型 (false:商家兑换券/true:支付券)
    }
  },
  computed: {
    multilingual() {
      const multilingual = this.dataObj.multilingual || {
        en_US: {},
        th_TH: {}
      }
      if (this.$DeviceInfo.language === 'en_US') {
        return multilingual.en_US
      }
      return multilingual.th_TH
    },
    btnText() {
      if (this.dataObj.couponStatus === 0) {
        return this.$t('USE NOW')
      } else if (this.dataObj.couponStatus === 1) {
        return this.$t('USED')
      } else if (this.dataObj.couponStatus === 2) {
        return this.$t('EXPIRED')
      } else if (this.dataObj.couponStatus === 3) {
        return this.$t('VIEW CODE')
      }
      return ''
    },
    bgStatus() {
      if (this.dataObj.couponStatus === 2) {
        return false
      }
      return true
    }
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('Coupon Detail'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    // this.$SDK.onForeground(() => {
    //   // alert('监听前台');
    //   this.initData()
    // })
  },
  methods: {
    async initData() {
      // this.$toast({
      //   message: 'Got Coupon',
      //   iconClass: 'icon jdfinace finace-icon-success_toast',
      //   position: 'middle',
      //   duration: 115000
      // })
      couponId = this.$route.query.couponId
      const res = await couponUseDetail({
        couponId
      })
      // 券类型 (1:商家兑换券/2:支付券)
      if (res.data.resultData.couponType === 2) {
        this.Paymentvoucher = true;
      }
      this.handlInitData(res, () => {
        if (this.dataObj.couponStatus === 3) {
          this.startTimer()
        }
      })
    },
    // 支付券use &pay
    async handleClick2() {
      couponId = this.$route.query.couponId
      const res = await GroupDiscoverygetCoupoReportinformation({
        couponId
      })
      if (res.data.resultCode === 1) {
        const ret = await this.$SDK.goNativeQrCoupon(res.data.resultData.actionData);
        console.log('优惠券二维码页面返回', ret)
      } else if (res.data.resultCode === 0) {
        this.$toast({
          message: this.$t('Sorry, something was wrong, please try it later'),
          position: 'middle',
          duration: 3000
        })
      }
    },
    handleClick() {
      // 1可用 0 不可用
      if (this.dataObj.validStatus === 0) {
        this.showGoCouponListDialog = true
        return
      }
      //  券状态 0 可用 1 已用 2 过期 3 使用中
      if (this.dataObj.couponStatus === 0) {
        this.showDialog = true
      } else if (this.dataObj.couponStatus === 3) {
        console.log('click123')
        this.$SDK.goNativeQrCoupon(this.dataObj.couponId, this.dataObj.merchantId)
      }
    },
    async goUse() {
      console.log('goUse')
      this.showDialog = false
      this.dataObj.couponStatus = 3
      this.startTimer()
      const ret = await this.$SDK.goNativeQrCoupon(this.dataObj.couponId, this.dataObj.merchantId)
      console.log('优惠券二维码页面返回', ret)
      this.initData()
    },
    cancleUse() {
      console.log('cancleUse')
      this.showDialog = false
    },
    gotoCouponList() {
      this.showGoCouponListDialog = false
      // this.$SDK.closeWebViewAndSendResult()
    },
    startTimer() {
      if (timer) {
        clearInterval(timer)
      }
      timer = setInterval(() => {
        if (this.dataObj.timeLeft === 0) {
          clearInterval(timer)
          this.dataObj.couponStatus = 1
          return
        }
        this.dataObj.timeLeft = this.dataObj.timeLeft - 1
      }, 1000)
    },
    formatSeconds(value) {
      /*eslint-disable*/
      let secondTime = parseInt(value)// 秒
      let minuteTime = 0// 分
      let hourTime = 0// 小时
      if(secondTime > 60) { 
        minuteTime = parseInt(secondTime/60)
        secondTime = parseInt(secondTime%60)
        if(minuteTime > 60) {
          hourTime = parseInt(minuteTime/60)
          minuteTime = parseInt(minuteTime%60)
        }
      }
      let result = ''
      if (secondTime < 10) {
        result = "0"+parseInt(secondTime)+""
      } else {
        result = ""+parseInt(secondTime)+""
      }
      if(minuteTime > 0) { 
        result = ""+parseInt(minuteTime)+":"+result
      }
      if(hourTime > 0) {
        result = ""+parseInt(hourTime)+":"+result
      }
      return result
    }
  }
}
</script>
<style lang="scss" scoped>
  .coupon-use {
    overflow-y: scroll;
  }
  .btn-wraper {
    position: fixed;
    bottom: .4rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    border-radius: 100px;
    background: white;
  }
  .conta {
    display: flex;
    flex-direction: column;
    height: 1.4rem;
    justify-content: space-around;
    padding: 0.05rem 0 0.05rem 0;
    box-sizing: border-box;
  }
  .itm {
    line-height: .5rem;
    font-family: The1Official_Bold;
    font-size: .36rem;
  }
  .itt {
    line-height: .5rem;
    font-size: .28rem;
  }
</style>
