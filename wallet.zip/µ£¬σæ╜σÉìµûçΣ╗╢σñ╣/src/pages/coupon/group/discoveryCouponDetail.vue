<template>
  <div class="coupon-use">
    <couponDetail
      :bg="dataObj.background"
      :logo="dataObj.logo"
      :merchant="multilingual.merchant"
      :title="multilingual.title"
      :valid-date="dataObj.validStartTime"
      :date="dataObj.validEndTime"
      :detail="multilingual.desc"
      :content="multilingual.condition"
      :bg-status="bgStatus"
      :group-batch-left-count="dataObj.batchLeftCount"
    />
    <div class="btn-wraper">
      <common-button
        v-if="dataObj.activityStatus === 1"
        type="danger"
        @click.native="handleClick">{{ btnText }}</common-button>
      <common-button
        v-else-if="dataObj.activityStatus === 2"
        :disabled="dataObj.groupLeftCount === 0"
        type="danger"
        @click.native="handleClick">{{ btnText }}</common-button>
      <common-button
        v-else-if="dataObj.activityStatus === 3"
        :disabled="true"
        type="danger"
      >{{ btnText }}</common-button>
      <common-button
        v-else-if="dataObj.activityStatus === 4"
        :disabled="true"
        type="danger"
      >{{ btnText }}</common-button>
    </div>
    <toast
      v-if="showKycDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="goKYC"
      @cancle="cancel"
    >
      <p slot="title">{{ $t('Verify Your Identity') }}</p>
      <p slot="content">{{ $t('Please provide more information to verify your identity before use this feature') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
    <toast
      v-if="showGroupGetCouponDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="getGroup"
      @cancle="cancel"
    >
      <p slot="title">{{ $t('Confirmation') }}</p>
      <p slot="content">{{ $t('you can get only') }} {{ dataObj.groupLeftCount }} {{ $t('coupon from the group please confirm to get') }}</p>
      <p slot="cancle">{{ $t('Cancel2') }}</p>
      <p slot="confirm">{{ $t('CONFIRM') }}</p>
    </toast>
  </div>
</template>
<script>
import { GroupDiscoveryCouponDetail, GroupDiscoverygetCoupon } from '@/api'
import { ENUM_ERRORCODE } from '@/utils/const'
import handlInitData from '@/mixins/handlInitData'
import couponDetail from '@/pages/coupon/couponDetail'
import toast from '@/pages/balance/common/dialog'

let batchId = ''
let activityId = ''
let groupId = ''
let kyc4 = false
let kyc6 = false
export default {
  name: 'GroupDiscoveryCouponDetail',
  components: { couponDetail, toast },
  mixins: [handlInitData],
  data() {
    return {
      showKycDialog: false,
      showGroupGetCouponDialog: false
    }
  },
  computed: {
    multilingual() {
      const multilingual = this.dataObj.multilingual || {
        en_US: {},
        th_TH: {}
      }
      if (this.$DeviceInfo.language === 'en_US') {
        return multilingual.en_US
      }
      return multilingual.th_TH
    },
    btnText() {
      if (this.dataObj.activityStatus === 1) {
        return this.$t('VIEW MY COUPON')
      } else if (this.dataObj.activityStatus === 2) {
        return this.$t('GET')
      } else if (this.dataObj.activityStatus === 3) {
        return this.$t('RUN OUT')
      } else if (this.dataObj.activityStatus === 4) {
        return this.$t('GET') // 没有领券资格 1.4 新增
      }
      return ''
    },
    bgStatus() {
      if (this.dataObj.activityStatus === 3 || (this.dataObj.activityStatus === 2 && this.dataObj.groupLeftCount === 0)) {
        return false
      }
      return true
    }
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('Coupon Detail'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
  },
  methods: {
    async initData() {
      batchId = this.$route.query.batchId
      activityId = this.$route.query.activityId
      groupId = this.$route.query.groupId
      this.$indicator.open({
        text: this.$t('Loading'),
        spinnerType: 'fading-circle'
      })
      const res = await GroupDiscoveryCouponDetail({
        batchId,
        activityId,
        groupId
      })
      this.$indicator.close()
      this.handlInitData(res)
    },
    handleClick() {
      //  券状态 2 可以领取 展示get 1 已领取 展示go to my coupon 3 展示太火爆 已领完
      if (this.dataObj.activityStatus === 1) {
        this.gotoMyCoupon()
      } else if (this.dataObj.activityStatus === 2) {
        // this.getCoupon()
        this.showGroupGetCouponDialog = true
      }
    },
    async getCoupon() {
      try {
        this.$indicator.open({
          text: this.$t('Loading'),
          spinnerType: 'fading-circle'
        })
        const res = await GroupDiscoverygetCoupon({
          activityId,
          groupId,
          activityIds: [activityId],
          deviceInfo: JSON.stringify(this.$DeviceInfo)
        })
        this.$indicator.close()
        if (res.data.resultCode === 1) {
          if (res.data.resultData.gotSuccess === 1) {
            this.$toast({
              message: this.$t('Got Coupon'),
              position: 'middle',
              iconClass: 'icon jdfinace finace-icon-success_toast',
              duration: 3000
            })
            // if (res.data.resultData.groupLeftCount === 0) {
            //   this.$toast({
            //     message: this.$t('Got Coupon'),
            //     position: 'middle',
            //     iconClass: 'icon jdfinace finace-icon-unsatisfy',
            //     duration: 3000
            //   })
            // } else {
            //   this.$toast({
            //     message: this.$t('Got Coupon'),
            //     position: 'middle',
            //     iconClass: 'icon jdfinace finace-icon-success_toast',
            //     duration: 3000
            //   })
            // }
          } else if (res.data.resultData.gotSuccess === 0) {
            let msg = this.$t('Sorry, something was wrong, please try it later')
            if (res.data.resultData.errorCode === '100000001') {
              // 该用户券与活动失效已领完
              msg = this.$t('Coupon\'ve just run out.')
              this.$toast({
                message: msg,
                iconClass: 'icon jdfinace finace-icon-unsatisfy',
                position: 'middle',
                duration: 3000
              })
            } else if (res.data.resultData.errorCode === '100000042') {
              msg = this.$t('Sorry, something went wrong. Please try again later')
              this.$toast({
                message: msg,
                position: 'middle',
                duration: 3000
              })
            } else if (res.data.resultData.errorCode === '100000022') {
              // 风控原因
              msg = this.$t('Unable to proceed. Please contact Customer Service for assistance.')
              this.$toast({
                message: msg,
                position: 'middle',
                duration: 3000
              })
            } else if (res.data.resultData.errorCode === '100000038') {
              // 未开始
              msg = this.$t('Cannot get this coupon now')
              this.$toast({
                message: msg,
                position: 'middle',
                duration: 3000
              })
            } else if (res.data.resultData.errorCode === '100000037') {
              // KYC等级不够
              this.showKycDialog = true
            } else if (res.data.resultData.errorCode === '100000039') {
              // KYC等级不够 kyc4
              kyc4 = true
              this.showKycDialog = true
            } else if (res.data.resultData.errorCode === '100000040') {
              // KYC等级不够 kyc6
              kyc6 = true
              this.showKycDialog = true
            }
          }
          const activityStatus = ((res.data.resultData.batches || [])[0] || {}).activityStatus
          this.dataObj.activityStatus = activityStatus || 2
          this.dataObj.groupLeftCount = res.data.resultData.groupLeftCount
        } else if (res.data.resultCode === 0) {
          if (res.data.actionData) {
            const ret = await this.$SDK.goNativeAction(res.data.actionData)
            console.log('结果ret', ret)
          } else {
            this.$toast({
              message: this.$t('Sorry, something was wrong, please try it later'),
              position: 'middle',
              duration: 3000
            })
          }
        }
      } catch (e) {
        this.$indicator.close()
        console.log('e', e)
      }
    },
    gotoMyCoupon() {
      this.$SDK.goNativeCouponList()
    },
    cancel() {
      this.showGroupGetCouponDialog = false
    },
    getGroup() {
      this.showGroupGetCouponDialog = false
      this.getCoupon()
    },
    goKYC() {
      this.showKycDialog = false
      if (kyc4) {
        this.$SDK.goNativeKYC({
          businessName: 'PAYMENT'
        })
      } else if (kyc6) {
        this.$SDK.goNativeKYC({
          businessName: 'OFFLINE'
        })
      } else {
        this.$SDK.goNativeKYC()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
 .coupon-use {
    overflow-y: scroll;
  }
  .btn-wraper {
    position: fixed;
    bottom: .4rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    border-radius: 100px;
    background: white;
  }
</style>
