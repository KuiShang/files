<template>
  <div class="gateway-loading">
    <animateSuccess
      ref="animateSuccess"
      :cutdown-time="animateCutdownTime"
      :status-txt="cashierAnimateStatusTxt"
    />
  </div>
</template>
<script>
import { openApiGateway, checkLogin } from '@/api';
import animateSuccess from '@/pages/cashier/animateSuccess';
import handlInitData from '@/mixins/handlInitData';
import BUSI from '@/pages/cashier/busiType/busi';
import { Base64 } from 'js-base64';

export default {
  name: 'GatewayLoading',
  components: { animateSuccess },
  mixins: [handlInitData],
  data() {
    return {
      animateCutdownTime: 0,
      cashierAnimateStatusTxt: this.$t('Loading')
    };
  },
  created() {
    this.listenBackpress()
    // this.initData()
    this.$SDK.setTitle({
      // title: this.$t('Loading'),
      title: this.$t(''),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    });
    this.$nextTick(() => {
      this.$refs.animateSuccess.initData();
    });
    console.log(this.$refs);
    this.isLogin();
  },
  destroyed() {
    this.$SDK.setTitle({
      title: '',
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    });
  },
  methods: {
    // loading页面禁止点击返回 -  产品需求 robert
    listenBackpress() {
      this.$SDK.onBackPress(() => {
        this.listenBackpress()
      })
    },
    /*eslint-disable*/
    async initData() {
      const appParams = await this.$SDK.getSubjoin();
      console.log('gateway客户端传递参数：解析前', appParams);
      const decodeData = JSON.parse(Base64.decode(appParams));
      // TODO:添加 customerId 找产品确认字段 明确由客户端添加
      //   const appParams = {
      // "apiType": "wallet_payment",
      // "appId": "20190412000006",
      // "charset": "UTF-8",
      // "data": "{\"attach\":\"CJD\",\"currency\":\"THB\",\"goodsType\":\"APP_PAY_VIRTUAL_GOODS\",\"mandatoryCheck\":\"1\",\"merchantNo\":\"300900100343\",\"merchantOrderNo\":\"20190412164033648658354147255767\",\"merchantUserId\":\"pop_test_ce1\",\"notifyUrl\":\"http://10.13.144.242:8080/notify/dolfin/backend.htm\",\"orderCountry\":\"TH\",\"orderInfo\":\"{\\\"shippingCountry\\\":\\\"TH\\\"}\",\"orderItems\":\"[{\\\"currency\\\":\\\"THB\\\",\\\"itemCategory\\\":\\\"2662\\\",\\\"itemName\\\":\\\"myByCAT50\\\",\\\"itemPrice\\\":50.00,\\\"itemQty\\\":1,\\\"itemSku\\\":\\\"107995\\\",\\\"itemUrl\\\":\\\"\\\"}]\",\"timeExpire\":\"20190413170009\",\"timeStart\":\"20190412164033\",\"totalAmount\":\"50.00\"}",
      // "merchantNo": "300900100343",
      // "sign": "knGpmh0lQ68rv7j5fD3FB0yt2IcqeySzgpwt9VfUMB0KPTds2ifbT19ORjZhghhm6tZt6yhNyNIfSbVSL7G5fPokpJuwA48nW5WaV7tWYDUNcySw7USSdkFEU/YNc7FH/RTUxw1XH4W0MrRHcGrEYY7xlnTxLCjEIrrDYJb9bgfUB2TytZ4etuRqAzuBLY+bBv+Yx8ZNhV+uDl+2wR8j1CDX14UsKArBjlYdmAyvahWVSD7RZ5Hl04pHy5DuAHNMLBX2pZ24SmXCWUtS+L89EVPwA9WnbYFC+WWOrGwTBUuZ6X+uj5QdvDvavmORyiVkSk6eIJX8I7Za2cDS6WgmUQ==",
      // "signType": "RSA2",
      // "timestamp": "20190412164033",
      // "version": "1.0.0"
      // }
      console.log('gateway客户端传递参数：解析后', decodeData);
      const res = await openApiGateway(decodeData);
      if (res && res.data && res.data.resultCode !== 1) {
        console.log('请求交易前置异常', res);
      } else {
        this.$router.replace({
          name: 'wraperSimpleCashier',
          query: {
            transactionNo: res && res.data && res.data.resultData.transactionNo,
            busiType: BUSI.APP_PAY_VIRTUAL_GOODS
          }
        });
      }
    },
    async isLogin() {
      const res = await checkLogin()
      this.handlInitData(res, () => {
        this.initData()
      })
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.gateway-loading {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}
</style>
