<template>
  <div class="result">
    <div v-if="showSuccess">
      <div
        class="head">
        <p class="pd8"/>
        <img
          class="img"
          src="@/assets/images/blance/the1/success_big@3x.png"
          alt="duigou">
        <p class="txt-title">{{ $t('PaymentSuccessfully') }}</p>
        <p class="txt-des">{{ $t('the1PaymentAmount') }} <span class="money">฿ {{ dataObj.orderAmount | tofloat | thousandBitSeparator }}</span></p>
      </div>
      <ul class="list">
        <li class="item">
          <span class="key">{{ $t('Receiver') }}</span>
          <span class="height45">{{ dataObj.merchantShortName }}</span>
        </li>
        <li
          v-if="dataObj.orderSubject"
          class="item">
          <span class="key">{{ $t('Order Subject') }}</span>
          <span>{{ dataObj.orderSubject }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Payment Method') }}</span>
          <span>{{ getDisplayName(dataObj) }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span>{{ dataObj.transactionNo }}</span>
        </li>
      </ul>
      <!-- <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">{{ $t('DONE') }}</common-button>
      </div> -->
    </div>
    <resultFail
      v-else
      :type-str="$t('TopUpFailed')"
      @click="tryAgain"/>
  </div>
</template>
<script>
import { scanedResultQuery, signQuery } from '@/api'
import handlInitData from '@/mixins/handlInitData'
import resultFail from '@/pages/balance/common/resultFail'
import { CASHIER_PAYMENT_METHODS, enumPayMethodCodeFirst } from '@/utils/const'

let signObj = null

export default {
  name: 'GatewayResult',
  components: { resultFail },
  mixins: [handlInitData],
  data() {
    return {
      showSuccess: true,
      titleRightMsg: {
        text: this.$t('DONE'),
        show: 1,
        textSize: 18,
        textColor: '#FF3E5B'
      }
    }
  },
  computed: {
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('payment'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
    this.$SDK.setTitleRight(this.titleRightMsg, () => {
      // this.$SDK.closeWebViewAndSendResult()
      this.handleClick()
    })
  },
  methods: {
    async handleClick() {
      const ret = await this.getSignData()
      console.log('SignData', ret)
      this.$SDK.closeWebViewAndSendResult({
        resultCode: 1,
        result: ret
      })
    },
    getSignData() {
      if (signObj) {
        return signObj
      }
      return new Promise((relsove) => {
        signQuery({
          transactionNo: this.$route.query.transactionNo
        }).then((ret) => {
          signObj = ret && ret.data && ret.data.resultData
          relsove(signObj)
        })
      })
    },
    async initData() {
      this.getSignData()
      const res = await scanedResultQuery({
        transactionNo: this.$route.query.transactionNo
      })
      this.handlInitData(res, () => {
        if (!this.dataObj.orderAmount) {
          this.showSuccess = false
        }
      }, () => {
        this.showSuccess = false
      })
    },
    getDisplayName(dataObj) {
      if (!dataObj.payResultModel) {
        return ''
      }
      const payMethodCodeFirst = dataObj && dataObj.payResultModel && dataObj.payResultModel.payMethodCodeFirst
      const displayName = dataObj.payResultModel && dataObj.payResultModel.displayName
      if (payMethodCodeFirst === enumPayMethodCodeFirst.ODD) {
        const last4Num = this.dataObj.payResultModel.maskedNo ? String(this.dataObj.payResultModel.maskedNo).slice(-4) : ''
        // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])} (${last4Num})`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.BALA) {
        // return this.dataObj.payMethodCodeFirst
        // return 'Balance'
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])}`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.OFLN) {
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])}`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
        const last4Num = this.dataObj.payResultModel.maskedNo ? String(this.dataObj.payResultModel.maskedNo).slice(-4) : ''
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])} (${last4Num})`
      }
      return ''
    },
    tryAgain() {
      // this.$router.push({ name: 'topup' })
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-bottom: .6rem;
    .pd8 {
      height: .8rem;
    }
    .img {
      width: 1.2rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
      margin-top: .4rem;
    }
    .txt-des {
      padding-top: .3rem;
      font-size: .32rem;
      color: $color-gray-h;
      text-align: center;
      .money {
        font-size: .32rem;
        color: $color-red;
        text-align: center;
        line-height: .38rem;
      }
    }
    .hide {
      opacity: 0;
      display: none;
    }
  }
  .list {
    background-color: #fff;
    padding: .3rem .4rem;
    margin-top: .2rem;
    padding-top: .1rem;
    .item {
      display: flex;
      justify-content: space-between;
      // height: .9rem;
      font-size: .28rem;
      color: $color-gray-g;
      text-align: right;
      height: .45rem;
      padding-top: .2rem;
      padding-bottom: .2rem;
      word-break: break-all;
      span {
        max-width: 46%;
      }
      .key {
        color: $color-gray-h;
        text-align: left;
      }
    }
  }

  .time-vertical {
      height: 4.33rem;
      box-sizing: border-box;
      background-color: #fff;
      padding: .36rem .4rem;
      padding-left: 1.09rem;
      .item {
        height: 0.85rem;
        line-height: 0.85rem;
        border-left: .02rem solid #d6d5d5;
        position: relative;
        .txt {
          line-height: initial;
          text-indent: .41rem;
          position: absolute;
          top: -.02rem;
          p{
            text-align: left
          }
          .txt-title {
            font-size: .32rem;
            color: $color-gray-a;
          }
          .txt-des {
            font-size: .20rem;
            color: $color-gray-c;
          }
        }
        &:nth-of-type(even) {
          height: 0.43rem;
          .txt {
            line-height: initial;
            text-indent: .41rem;
            position: absolute;
            top: -.36rem;
            p{
              text-align: left
            }
            .txt-title {
              font-size: .32rem;
              color: $color-gray-a;
            }
            .txt-des {
              font-size: .20rem;
              color: $color-gray-c;
            }
          }
        }
        &:last-of-type{
          border: none;
          height: 1.13rem;
        }
        &.item-ok {
          color: $color-blue;
          border-left: .02rem solid $color-blue;
        }
        img {
          position: absolute;
          left: -0.22rem;
          height: 0.44rem;
          width: 0.44rem;
        }
      }
      .item.not {
        border-color: #d6d5d5;
      }
    }
  .btn-wraper {
    margin-top: .8rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
