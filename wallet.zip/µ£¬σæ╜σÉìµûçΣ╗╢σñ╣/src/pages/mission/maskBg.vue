<template>
  <div>
    <div class="top-bg">
      <div
        :style="{ paddingTop:'+ paddingTop +',width,height}"
        class="top-img">
        <img
          :src="image">
      </div>
      <p class="txt">{{ txt }}</p>
      <div
        v-if="showBtn"
        class="get-shells">{{ btnTxt }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MaskBg',
  props: {
    paddingTop: {
      type: String,
      default: ''
    },
    image: {
      type: String,
      default: ''
    },
    txt: {
      type: String,
      default: ''
    },
    btnTxt: {
      type: String,
      default: ''
    },
    showBtn: {
      type: Boolean,
      default: false
    },
    width: {
      type: String,
      default: ''
    },
    height: {
      type: String,
      default: ''
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

@mixin commonBg {
    width:6.7rem;
    height:4.98rem;
    box-sizing:border-box;
    background:url('../../assets/images/mission/title-background@2x.png');
    background-size: 6.7rem 4.98rem;
}
@mixin commonIcon($width:2.16rem,$height:1.94rem) {
    width:$width;
    height:$height;
    margin:0 auto .12rem;
}
@mixin commonTxt {
    line-height:.8rem;
    text-align:center;
    font-size:.48rem;
    color:$color-white;
    font-family: The1Official-Bold;
}
@mixin commonShells {
    width:1.32rem;
    height:.48rem;
    line-height:.48rem;
    margin:0 auto;
    font-size:.24rem;
    font-family: The1Official-Regular;
    color:$color-gray-h;
    padding-left:.16rem;
    border-radius:.16rem;
    background:#fff url('../../assets/images/mission/shell_active@2x.png')no-repeat 1rem .08rem;
    background-size:.32rem .32rem;
}
.top-bg {
    @include commonBg;
    padding-top:1.12rem;
    .top-img {
        @include commonIcon;
        img {
            width:100%;
            height:100%;
        }
    }
    .txt {
        @include commonTxt;
        margin:.08rem auto .16rem;
    }
    .get-shells {
        @include commonShells;
    }
}

</style>
