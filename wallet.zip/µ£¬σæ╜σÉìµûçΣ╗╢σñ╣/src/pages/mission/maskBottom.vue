<template>
  <div>
    <div
      :style="{padding}"
      class="info">
      <p class="txt">{{ topTxt }}</p>
      <p
        v-if="numTxt"
        class="num">{{ numTxt }}</p>
      <p class="txt">{{ bottomTxt }}</p>
      <div
        v-if="termTxt"
        class="info-term"
        @click="seeTerm">{{ termTxt }}</div>
      <div
        :style="{margin}"
        class="btn"
        @click="getMore">
        {{ bottomBtnTxt }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MaskBottom',
  props: {
    padding: {
      type: String,
      default: ''
    },
    topTxt: {
      type: String,
      default: ''
    },
    numTxt: {
      type: String,
      default: ''
    },
    bottomTxt: {
      type: String,
      default: ''
    },
    termTxt: {
      type: String,
      default: ''
    },
    margin: {
      type: String,
      default: ''
    },
    bottomBtnTxt: {
      type: String,
      default: ''
    }
  },
  methods: {
    seeTerm() {
      this.$emit('goAndSee')
    },
    getMore() {
      this.$emit('getMoreDraw')
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

@mixin commonInfo {
    width:6.7rem;
    background-color:$color-white;
    text-align:center;
    border-radius:0 0 .16rem .16rem;
    box-sizing: border-box;
}
@mixin commonBtn($margin) {
    width:5.64rem;
    height:1.12rem;
    border-radius:1.12rem;
    line-height:1.12rem;
    font-size:.36rem;
    color:$color-white;
    background:$color-red;
    text-align:center;
}
@mixin commonBoldTxt {
    line-height:.8rem;
    text-align:center;
    font-size:.48rem;
    color:$color-gray-h;
    color:$color-white;
    font-family: The1Official-Bold;
}
@mixin commonTxt {
    line-height:.6rem;
    font-size:.36rem;
    color:$color-gray-h;
    font-family: The1Official-Regular;
    text-align:center;
}
@mixin commonUnderlineTxt {
    margin:.32rem auto .48rem;
    text-align:center;
    line-height:.54rem;
    font-size:.32rem;
    color:$color-gray-h;
    font-family: The1Official-Bold;
    text-decoration: underline;
    font-weight: bold;
}
.info {
    @include commonInfo;
    .txt{
        @include commonTxt;
    }
    .num {
        font-size:.42rem;
        font-family: The1Official-Bold;
        line-height:.6rem;
        color:$color-gray-h;
    }
    .info-term {
        @include commonUnderlineTxt;
    }
    .btn {
        @include commonBtn(.7rem auto 0);
    }
}

</style>
