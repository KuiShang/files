<template>
  <div class="base-bg">
    <div class="mask">
      <div class="top-shell"/>
      <div class="left-arrow"/>
      <div class="award-title txt">สะสมเปลือกหอยเพื่อลุ้นรับรางวัล</div>
      <div class="prize txt">ด้วยการเลือกทำภารกิจอย่างใดอย่างหนึ่ง</div>
      <div class="total-prize txt">ในเปลือกหอยด้านล่างให้ครบ 5 ครั้ง</div>
      <div class="use-dolfin txt">โดยทำภารกิจ 1 ครั้ง จะได้รับ เปลือกหอย 1 ฝา</div>
      <div
        class="btn"
        @click="goToNext">
        <span>ต่อไป</span>
        <div class="right-arrow"/>
      </div>
      <div class="bottom-shell"/>
    </div>
  </div>
</template>

<script>
import { MISSION_CLICK, MISSION_ENTER } from '@/pages/burry/mission';

export default {
  name: 'MissionGuidePageFirst',
  data() {
    return {
      titleRightMsg: require('../../assets/images/mission/info@2x.png')
    }
  },
  created() {
    this.$SDK.setTitle({
      title: 'วิธีการเล่น',
      mHeaderTitle: {
        showBack: 1
      }
    });
    // this.$SDK.setTitleRight(this.titleRightMsg, () => {
    //   this.handleClick()
    // })
    MISSION_ENTER('MISSION_MAIN_HOWTO1')
    this.$SDK.onBackPressNativeContinue(() => {
      MISSION_CLICK('MISSION_MAIN_HOWTO1', 'CLICK_BACK')
    })
  },
  methods: {
    goToNext() {
      MISSION_CLICK('MISSION_MAIN_HOWTO1', 'CLICK_NEXT')
      this.$router.push({ name: 'MissionGuidePageTwo' })
    },
    handleClick() {
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=91'
      this.$SDK.goNativeWebview(url)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
@mixin commonShellIcon($width,$height,$url) {
    width:$width;
    height:$height;
    background:url($url);
    background-size: $width $height;
}
.base-bg {
  width:7.5rem;
  height:100%;
  background:url('../../assets/images/mission/mission-mask-bg.png');
  background-size: cover;
  color:$color-white;
  .mask {
    width:7.5rem;
    height:calc(100% - 0.88rem);
    position:fixed;
    left:0;
    top:.88rem;
    right:0;
    bottom:0;
    box-sizing: border-box;
    padding-top:.36rem;
    background:rgba(0,0,0,0.85);
    z-index:999;
    .top-shell {
      @include commonShellIcon(5.74rem,1.8rem,'../../assets/images/mission/shell_label@2x.png');
      margin:0 auto;
    }
    .left-arrow {
      @include commonShellIcon(1.3rem,7.02rem,'../../assets/images/mission/line-to-shell@2x.png');
      position: absolute;
      left:.39rem;
      top:1.42rem;
    }
      .txt {
        line-height:.66rem;
        font-size:.32rem;
        text-align:center;
    }
    .award-title {
        margin-top:.26rem;
        font-size:.4rem;
        font-family: The1Official-Bold;
        font-weight:bold;
    }
    .prize, .total-prize {
        font-family: The1Official-Regular;
    }
    .use-dolfin {
        color:yellow;
        font-family: The1Official-Bold;
    }
    .btn {
        width:2.2rem;
        height:1rem;
        line-height:1rem;
        font-size:.36rem;
        border-radius:.5rem;
        border:.02rem solid $color-white;
        margin:.68rem auto;
        span {
            margin-left:.52rem;
        }
        .right-arrow {
            width:.48rem;
            height:.48rem;
            float:right;
            margin:.26rem .2rem 0 0;
            background:url('../../assets/images/mission/dark@2x.png');
            background-size:.48rem .48rem;
            transform:rotate(180deg);
        }
    }
    .bottom-shell {
      @include commonShellIcon(7.1rem,3.32rem,'../../assets/images/mission/tutorial-activities@2x.png');
      position: absolute;
      left:.2rem;
      top:8.06rem;
    }
  }
}
</style>
