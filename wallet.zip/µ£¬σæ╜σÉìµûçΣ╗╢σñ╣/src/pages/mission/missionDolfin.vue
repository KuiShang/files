<template>
  <div class="wrap-bg">
    <div class="container">
      <div class="shell-box">
        <div class="small-shell">
          <div
            v-for="i in 5"
            :key="i"
            :class="{'active':i <= times }"
            class="shell"/>
        </div>
        <div
          v-if="!satisfyFlag">
          <div class="lock_lucky"/>
          <div class="lucky-txt">
            <p>สะสมเปลือกหอยและลุ้นรับ Huawei Nova 5T</p>
            <p>โดยเลือกทำภารกิจด้านล่างให้ครบ 5 ครั้ง</p>
          </div>
        </div>
        <div v-if="satisfyFlag&&!getWinFlag">
          <div class="no-get"/>
          <div
            class="no-get-btn"
            @click="luckDraw">ลุ้นรับรางวัล</div>
        </div>
        <div v-if="satisfyFlag&&getWinFlag">
          <div v-if="winFlag">
            <div class="not-win"/>
            <div class="no-win-txt">
              <p>ขอบคุณที่ร่วมสนุก</p>
            </div>
          </div>
          <div v-if="!winFlag">
            <div class="win-5T"/>
            <div
              class="win-btn"
              @click="goToCouponList">ดูของรางวัลที่ได้รับ</div>
          </div>
        </div>
      </div>
      <div class="case">
        <div class="task-box">
          <div class="payment">
            <div
              v-if="showPayment"
              class="completion-payment"/>
            <div
              v-if="!showPayment"
              class="uncompleted-ayment"/>
          </div>
          <div class="card">
            <div
              v-if="showCard"
              class="add-card"/>
            <div
              v-if="!showCard"
              class="untied-card"/>
          </div>
          <div class="inactive-key">
            <div
              v-if="showInvited"
              class="invited"/>
            <div
              v-if="!showInvited"
              class="no-invited"/>
          </div>
        </div>
        <div>
          <div
            v-if="!fullFlag">
            <div class="teasure"/>
            <div class="teasure-txt">
              <p>รับฟรี! เงินรางวัล 100 บาท </p>
              <p>เมื่อทำภารกิจด้านล่างครบทั้ง 3 ภารกิจ</p>
            </div>
          </div>
          <div
            v-if="fullFlag">
            <div class="full-teasure"/>
            <div class="box-btn">ไปหน้าคูปอง</div>
          </div>
        </div>
      </div>
    </div>
    <div class="collecte">
      <span class="left-line"/>
      <span class="txt">เลือกภารกิจเพื่อเก็บเปลือกหอย</span>
      <span class="right-line"/>
    </div>
    <div class="collecte-methods">
      <shell
        :image-url="shellData.imagePayment"
        :text="shellData.paymentTxt"
        @tasks="goToPayment"/>
      <shell
        :image-url="shellData.imageAddCard"
        :text="shellData.addCardTxt"
        @tasks="goToAddCard"/>
      <shell
        :image-url="shellData.imageInvited"
        :text="shellData.invitedTxt"
        @tasks="goToInvited"/>
    </div>
    <div
      v-if="identityFlag"
      class="mask">
      <div class="content-box">
        <div class="identity">
          <mask-bg
            :padding-top="identityData.paddingTop"
            :image="identityData.image"
            :txt="identityData.txt"
            :btn-txt="identityData.btnTxt"
            :show-btn="identityData.showBtn"
            :width="identityData.width"
            :height="identityData.height"/>
          <mask-bottom
            :padding="identityData.padding"
            :top-txt="identityData.topTxt"
            :num-txt="identityData.numTxt"
            :bottom-txt="identityData.bottomTxt"
            :margin="identityData.margin"
            :bottom-btn-txt="identityData.bottomBtnTxt"
            @getMoreDraw="goKYC"
          />
        </div>
        <div
          class="close-btn"
          @click="closeIdentityBtn"/>
      </div>
    </div>
    <div
      v-if="paymentFlag"
      class="mask">
      <div class="content-box">
        <div class="payment-box">
          <mask-bg
            :padding-top="paymentData.paddingTop"
            :image="paymentData.image"
            :txt="paymentData.txt"
            :btn-txt="paymentData.btnTxt"
            :show-btn="paymentData.showBtn"/>
          <mask-bottom
            :padding="paymentData.padding"
            :top-txt="paymentData.topTxt"
            :bottom-txt="paymentData.bottomTxt"
            :term-txt="paymentData.termTxt"
            :margin="paymentData.margin"
            :bottom-btn-txt="paymentData.bottomBtnTxt"
            @goAndSee="seePaymentTerm"
            @getMoreDraw="getMorePaymentDraw"
          />
        </div>
        <div
          class="close-btn"
          @click="closePaymentBtn"/>
      </div>
    </div>
    <div
      v-if="addCardFlag"
      class="mask">
      <div class="content-box">
        <div class="add-card-box">
          <mask-bg
            :padding-top="addCardData.paddingTop"
            :image="addCardData.image"
            :txt="addCardData.txt"
            :btn-txt="addCardData.btnTxt"
            :show-btn="addCardData.showBtn"/>
          <mask-bottom
            :padding="addCardData.padding"
            :top-txt="addCardData.topTxt"
            :bottom-txt="addCardData.bottomTxt"
            :margin="addCardData.margin"
            :bottom-btn-txt="addCardData.bottomBtnTxt"
            @getMoreDraw="getMoreCardDraw"
          />
        </div>
        <div
          class="close-btn"
          @click="closeAddCardBtn"/>
      </div>
    </div>
    <div
      v-if="inviteFlag"
      class="mask">
      <div class="content-box">
        <div
          class="invite-box">
          <mask-bg
            :padding-top="inviteData.paddingTop"
            :image="inviteData.image"
            :txt="inviteData.txt"
            :btn-txt="inviteData.btnTxt"
            :show-btn="inviteData.showBtn"/>
          <mask-bottom
            :padding="inviteData.padding"
            :top-txt="inviteData.topTxt"
            :bottom-txt="inviteData.bottomTxt"
            :term-txt="inviteData.termTxt"
            :margin="inviteData.margin"
            :bottom-btn-txt="inviteData.bottomBtnTxt"
            @goAndSee="seeInviteTerm"
            @getMoreDraw="getMoreInviteDraw"
          />
        </div>
        <div
          class="close-btn"
          @click="closeInviteBtn"/>
      </div>
    </div>
    <div
      v-if="!result&&resultWrap"
      class="mask">
      <div class="content-box">
        <div class="win-prize">
          <div class="top-img"/>
          <div class="luck-info">
            <div class="share-title">ยินดีด้วย!</div>
            <div class="progress">คุณทำภารกิจสำเร็จเป็นลำดับที่ 33</div>
            <div class="other-reward">คุณสามารถกดรับคูปองเพื่อนำมาใช้</div>
            <div class="privilege">ยืนยันสิทธิ์ในการรับโทรศัพท์ Huawei Nova 5T</div>
            <div
              class="prize-btn"
              @click="goToCouponListTwo">รับรางวัล</div>
          </div>
        </div>
        <div
          class="close-btn"
          @click="closeWinPrizeBtn"/>
      </div>
    </div>
    <div
      v-if="result&&resultWrap"
      class="mask">
      <div class="content-box">
        <div class="not-win-prize">
          <div class="top-img"/>
          <div class="luck-info">
            <div class="share-title">ขอบคุณที่ร่วมสนุก</div>
            <div class="progress">คุณทำภารกิจสำเร็จเป็นลำดับที่ 33</div>
            <div class="other-reward">คุณยังมีโอกาสรับเงินรางวัล 100 บาท </div>
            <div class="privilege">และสิทธิพิเศษอื่น ๆ</div>
            <div
              class="prize-btn"
              @click="goRefresh">ตกลง</div>
          </div>
        </div>
        <div
          class="close-btn"
          @click="closeWinPrizeBtn"/>
      </div>
    </div>
  </div>
</template>

<script>
import { MeetTheScallop, OpenScallop } from '@/api'
import dialog from '@/pages/balance/common/dialog'
import { MISSION_CLICK, MISSION_ENTER } from '@/pages/burry/mission';
import MaskBg from './maskBg'
import MaskBottom from './maskBottom'
import Shell from './shell'

export default {
  name: 'MissionDolfin',
  components: { MaskBg, MaskBottom, Shell, 'v-dialog': dialog },
  data() {
    return {
      showPayment: false,
      satisfyFlag: false,
      getWinFlag: false,
      winFlag: false,
      showCard: false,
      showInvited: false,
      identityFlag: false,
      paymentFlag: false,
      addCardFlag: false,
      explainFlag: false,
      inviteFlag: false,
      fullFlag: false,
      result: false,
      resultWrap: false,
      kycFlag: false,
      showKycDialog: false,
      kycJump: '',
      titleRightMsg: require('../../assets/images/mission/info@2x.png'),
      identityData: {
        paddingTop: '1.22rem',
        image: require('../../assets/images/mission/icon-idcard@2x.png'),
        txt: 'ยืนยันตัวตนเพื่อเริ่มภารกิจ',
        width: '2.4rem',
        height: '2.4rem',
        padding: '.36rem 0 .48rem',
        topTxt: 'พิเศษเฉพาะคุณเท่านั้น รับโบนัสเพิ่ม',
        numTxt: '50 บาท',
        bottomTxt: 'เพียงยืนยันตัวตนของคุณให้สำเร็จ',
        margin: '.7rem auto 0',
        bottomBtnTxt: 'เริ่มการยืนยันตัวตนให้สำเร็จ'
      },
      paymentData: {
        paddingTop: '1.12rem',
        image: require('../../assets/images/mission/payment@2x.png'),
        txt: 'ใช้จ่ายผ่าน Dolfin',
        btnTxt: 'จะได้รับ',
        padding: '.48rem',
        topTxt: 'จ่ายเงินร้านค้าที่ร่วมรายการ',
        bottomTxt: 'ตั้งแต่ 50 บาทขึ้นไป',
        showTerm: true,
        termTxt: 'ดูรายชื่อร้านค้า',
        margin: '0 auto',
        bottomBtnTxt: 'ใช้จ่ายผ่าน Dolfin'
      },
      addCardData: {
        paddingTop: '1.12rem',
        image: require('../../assets/images/mission/addcard@2x.png'),
        txt: 'เพิ่มบัตรหรือบัญชี',
        btnTxt: 'จะได้รับ',
        padding: '.48rem',
        topTxt: 'ผูกบัญชีเงินฝาก หรือ',
        bottomTxt: 'เพิ่มบัตรเดบิต/เครดิต ใบใหม่',
        margin: '.48rem auto 0',
        bottomBtnTxt: 'เพิ่มบัตรหรือบัญชี'
      },
      inviteData: {
        paddingTop: '1.12rem',
        image: require('../../assets/images/mission/invite@2x.png'),
        txt: 'ใช้จ่ายผ่าน Dolfin',
        btnTxt: 'จะได้รับ',
        padding: '.48rem',
        topTxt: 'ชวนเพื่อนมาใช้งาน',
        bottomTxt: 'และยืนยันตัวตนสำเร็จ',
        termTxt: 'ดูขั้นตอนการชวนเพื่อน',
        margin: '0 auto',
        bottomBtnTxt: 'ชวนเพื่อนใช้ Dolfin'
      },
      shellData: {
        imagePayment: require('../../assets/images/mission/payment@2x.png'),
        imageAddCard: require('../../assets/images/mission/addcard@2x.png'),
        imageInvited: require('../../assets/images/mission/invite@2x.png'),
        paymentTxt: 'ใช้จ่ายผ่าน Dolfin',
        addCardTxt: 'เพิ่มบัตรหรือบัญชี',
        invitedTxt: 'ชวนเพื่อนใช้ Dolfin'
      },
      explainShellData: {
        SubWidth: '1.6rem',
        SubHeight: '1.9rem',
        IconWidth: '1.6rem',
        IconHeight: '1.44rem',
        textLineHeight: '.3rem',
        textMarginTop: '.18rem',
        imagePayment: require('../../assets/images/mission/payment@2x.png'),
        imageAddCard: require('../../assets/images/mission/addcard@2x.png'),
        imageInvited: require('../../assets/images/mission/invite@2x.png'),
        paymentTxt: 'ใช้จ่ายผ่าน Dolfin',
        addCardTxt: 'เพิ่มบัตรหรือบัญชี',
        invitedTxt: 'ชวนเพื่อนใช้ Dolfin'
      },
      number: 0,
      times: 0,
      missiondId: '',
      kycParams: {}
    }
  },
  created() {
    this.$SDK.setTitle({
      title: 'MISSION DOLFIN',
      mHeaderTitle: {
        showBack: 1
      }
    });
    // this.$SDK.setTitleRight(this.titleRightMsg, () => {
    //   MISSION_CLICK('MISSION_MAIN', 'CLICK_INFO_ICON')
    //   // this.handleTermClick()点击右上角图标的事件
    // })
    this.init()
    MISSION_ENTER('MISSION_MAIN')
    this.$SDK.onBackPressNativeContinue(() => {
      MISSION_CLICK('MISSION_MAIN', 'CLICK_BACK')
    })
  },
  methods: {
    async init() {
      const res = await MeetTheScallop()
      console.log(res)
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        this.times = res.data.resultData.part1.times
        this.missiondId = res.data.resultData.part2.missiondId
        const completeShell = res.data.resultData.part2.complete
        if (completeShell === 0) {
          this.satisfyFlag = false
          this.getWinFlag = false
        } else if (completeShell === 2) {
          this.satisfyFlag = true
          this.getWinFlag = false
        } else if (completeShell === 3) {
          this.satisfyFlag = true
          this.getWinFlag = true
          if (JSON.stringify(res.data.resultData.part2.reward) === '{}') {
            this.winFlag = true
          } else {
            this.winFlag = false
          }
        }
        const paymentCount = res.data.resultData.part3.payment
        const cardCount = res.data.resultData.part3.card
        const inviteCount = res.data.resultData.part3.invite
        if (paymentCount > 0) {
          this.showPayment = true
        }
        if (cardCount > 0) {
          this.showCard = true
        }
        if (inviteCount > 0) {
          this.showInvited = true
        }
        const completeBox = res.data.resultData.part3.complete
        if (completeBox === 3 && JSON.stringify(res.data.resultData.part3.reward) !== '{}') {
          this.fullFlag = true
        } else {
          this.fullFlag = false
        }
      } else if (dataFlag === 0) {
        const errorData = res.data.errorData
        if (errorData.errorCode === 'kyc-too-low') {
          this.kycParams = res.data.errorData.actionData
          this.kycJump = res.data.errorData.kycJump
          this.kycFlag = true
        }
      }
    },
    async luckDraw() {
      MISSION_CLICK('MISSION_MAIN', 'CLICK_LUCKYDRAW')
      const res = await OpenScallop()
      const dataFlag = res.data.resultCode
      if (dataFlag === 1) {
        const number = res.data.resultData.number
        if (number > 0) {
          this.resultWrap = true
          this.result = false
        } else {
          this.resultWrap = true
          this.result = true
        }
      }
    },
    goToPayment() {
      MISSION_CLICK('MISSION_MAIN', 'CLICK_MISSION_PAYMENT')
      if (this.kycFlag) {
        MISSION_ENTER('MISSION_MAIN_KYC3')
        this.identityFlag = true
      } else {
        MISSION_ENTER('MISSION_MAIN_PAYMENT')
        this.paymentFlag = true
      }
    },
    seePaymentTerm() {
      MISSION_CLICK('MISSION_MAIN_PAYMENT', 'CLICK_MERCHANTINFO')
      // console.log('查看支付的规则')
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=89'
      this.$SDK.goNativeWebview(url)
    },
    getMorePaymentDraw() {
      MISSION_CLICK('MISSION_MAIN_PAYMENT', 'CLICK_PAYMENT')
      // console.log('跳转到原生支付的地方')
      this.$SDK.goNativeQrCollect()
    },
    goToAddCard() {
      MISSION_CLICK('MISSION_MAIN', 'CLICK_MISSION_ADDSOF')
      if (this.kycFlag) {
        MISSION_ENTER('MISSION_MAIN_KYC3')
        this.identityFlag = true
      } else {
        MISSION_ENTER('MISSION_MAIN_ADDSOF')
        this.addCardFlag = true
      }
    },
    getMoreCardDraw() {
      MISSION_CLICK('MISSION_MAIN_ADDSOF', 'CLICK_ADDSOF')
      // console.log('跳转到原生绑卡的地方')
      this.$SDK.goNativeActionAddCard()
    },
    goToInvited() {
      MISSION_CLICK('MISSION_MAIN', 'CLICK_MISSION_INVITEFRIEND')
      if (this.kycFlag) {
        MISSION_ENTER('MISSION_MAIN_KYC3')
        this.identityFlag = true
      } else {
        MISSION_ENTER('MISSION_MAIN_INVITEFRIEND')
        this.inviteFlag = true
      }
    },
    seeInviteTerm() {
      MISSION_CLICK('MISSION_MAIN_INVITEFRIEND', 'CLICK_HOWTO')
      console.log('查看邀请的规则')
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=88'
      this.$SDK.goNativeWebview(url)
    },
    getMoreInviteDraw() {
      MISSION_CLICK('MISSION_MAIN_INVITEFRIEND', 'CLICK_INVITEFRIEND')
      // console.log('跳转到邀请的地方')
      this.$router.push({ name: 'invitationFriends' })
    },
    goRefresh() {
      this.closeWinPrizeBtn()
    },
    goToCouponList() {
      // console.log('跳转到优惠券列表')
      MISSION_CLICK('MISSION_MAIN', 'CLICK_MYCOUPON2')
      this.$SDK.goNativeCouponList()
    },
    goToCouponListTwo() {
      // console.log('跳转到优惠券列表')
      MISSION_CLICK('MISSION_MAIN', 'CLICK_MYCOUPON1')
      this.$SDK.goNativeCouponList()
    },
    closeIdentityBtn() {
      MISSION_CLICK('MISSION_MAIN_KYC3', 'CLICK_CLOSE')
      this.identityFlag = false
    },
    closePaymentBtn() {
      MISSION_CLICK('MISSION_MAIN_PAYMENT', 'CLICK_CLOSE')
      this.paymentFlag = false
    },
    closeAddCardBtn() {
      MISSION_CLICK('MISSION_MAIN_ADDSOF', 'CLICK_CLOSE')
      this.addCardFlag = false
    },
    closeInviteBtn() {
      MISSION_CLICK('MISSION_MAIN_INVITEFRIEND', 'CLICK_CLOSE')
      this.inviteFlag = false
    },
    closeWinPrizeBtn() {
      this.result = false
      this.resultWrap = false
      this.init()
    },
    goKYC() {
      MISSION_CLICK('MISSION_MAIN_KYC3', 'CLICK_VERIFYIDENTITY')
      this.showKycDialog = false;
      this.$SDK.goNativeKYC(this.kycParams).then((res) => {
      });
    },
    handleTermClick() {
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=91'
      this.$SDK.goNativeWebview(url)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

@mixin commonBg($paddingTop) {
    width:6.7rem;
    height:4.98rem;
    padding-top:$paddingTop;
    box-sizing:border-box;
    background:url('../../assets/images/mission/title-background@2x.png');
    background-size: 6.7rem 4.98rem;
}
@mixin commonShellIcon($width,$height,$url) {
    width:$width;
    height:$height;
    background:url($url);
    background-size: $width $height;
}
@mixin commonIcon($width,$height,$url) {
    @include commonShellIcon($width,$height,$url);
    margin:0 auto .12rem;
}
@mixin commonBtn($margin) {
    width:5.64rem;
    height:1.12rem;
    border-radius:1.12rem;
    line-height:1.12rem;
    font-size:.36rem;
    color:$color-white;
    margin:$margin;
    background:$color-red;
    text-align:center;
}
@mixin commonSmallBtn {
    width:3.12rem;
    height:.64rem;
    border-radius:.64rem;
    line-height:.64rem;
    font-size:.28rem;
    color:$color-white;
    margin:0 auto;
    background:$color-red;
    text-align:center;
}
@mixin commonInfo($padding) {
    width:6.7rem;
    padding:$padding;
    background-color:$color-white;
    text-align:center;
    border-radius:0 0 .16rem .16rem;
    box-sizing: border-box;
}
@mixin commonTxt {
    line-height:.8rem;
    text-align:center;
    font-size:.48rem;
    color:$color-white;
    font-family: The1Official-Bold;
}
@mixin commonFontTxt {
    line-height:.4rem;
    font-size:.24rem;
    font-family: The1Official-Bold;
    color:$color-gray-h;
    text-align:center;
}
@mixin commonShells {
    width:1.32rem;
    height:.48rem;
    line-height:.48rem;
    margin:0 auto;
    font-size:.24rem;
    font-family: The1Official-Regular;
    color:$color-gray-h;
    padding-left:.16rem;
    border-radius:.16rem;
    background:#fff url('../../assets/images/mission/shell_active@2x.png')no-repeat 1rem .08rem;
    background-size:.32rem .32rem;
}
@mixin commonPrice {
    width:6.7rem;
    height:4.52rem;
    background:$color-white;
    padding:.6rem 0 .32rem;
    border-radius:.16rem .16rem 0 0;
    box-sizing: border-box;
}
@mixin commonPriceIcon($url) {
    width:3.6rem;
    height:3.6rem;
    margin:0 auto;
    background:url($url);
    background-size:3.6rem 3.6rem;
}
@mixin commonPriceTxt {
    line-height:.6rem;
    font-size:.36rem;
    color:$color-red;
    font-family: The1Official-Bold;
    font-weight:bold;
    text-align:center;
}
@mixin commonPriceContentTxt($lineHeight) {
    line-height:$lineHeight;
    font-size:.32rem;
    color:$color-red;
    font-family: The1Official-Bold;
    font-weight:bold;
    text-align:center;
}
@mixin commonPart($padding){
  width:6.7rem;
  padding:$padding;
  background:rgba(222,222,222,0.2);
  box-sizing:border-box;
  font-family: The1Official-Bold;
  color:$color-gray-h;
}
@mixin commonCollecteMethods($width,$height,$fontSize,$color){
  width:$width;
  height:$height;
  margin:0 auto;
  display:flex;
  justify-content: space-between;
  font-family: The1Official-Bold;
  color:$color;
  font-size:$fontSize;
  text-align: center;
}

.wrap-bg {
    width:7.5rem;
    height:100%;
    background:url('../../assets/images/mission/background@2x.gif');
    background-size: cover;
    .container {
        width:7.5rem;
        padding-top:.5rem;
        .shell-box {
            @include commonShellIcon(6.7rem,3.78rem,'../../assets/images/mission/container-bg@2x.png');
            margin:0 auto;
            .small-shell {
                width:5.1rem;
                padding-top:.4rem;
                height:.64rem;
                margin:0 auto;
                display:flex;
                justify-content: space-between;
                .shell {
                  @include commonShellIcon(.64rem,.64rem,'../../assets/images/mission/shell_inactive@2x.png');
                }
                .active {
                  @include commonShellIcon(.64rem,.64rem,'../../assets/images/mission/shell_active@2x.png');
                }
            }
            .lock_lucky {
              @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/lock_luckydraw@2x.png');
                margin:0 auto;
            }
            .lucky-txt {
                width:4.6rem;
                margin:0 auto;
                @include commonFontTxt;
            }
            .no-get {
              @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/lock_luckydraw-active@2x.png');
              margin:0 auto;
            }
            .no-get-btn {
              @include commonSmallBtn;
            }
            .not-win {
              @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/unlock_luckydraw@2x.png');
              margin:0 auto .2rem;
            }
            .no-win-txt {
              margin:.2rem auto;
              @include commonFontTxt;
            }
            .win-5T {
              @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/huawei_reward@2x.png');
              margin:0 auto;
            }
            .win-btn {
              @include commonSmallBtn;
            }
        }
        .case {
            @include commonShellIcon(6.7rem,3.78rem,'../../assets/images/mission/container-bg@2x.png');
            margin:.32rem auto;
            .task-box {
                width:3.5rem;
                padding-top:.4rem;
                height:.64rem;
                margin:0 auto;
                display:flex;
                justify-content: space-between;
                .payment,.card,.inactive-key {
                    width:.64rem;
                    height:.64rem;
                }
                .uncompleted-ayment {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/inactive-payment@2x.png');
                    background-size:.64rem .64rem;
                }
                .completion-payment {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/active-payment@2x.png');
                    background-size:.64rem .64rem;
                }
                .untied-card {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/inactive-addcard@2x.png');
                    background-size:.64rem .64rem;
                }
                .add-card {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/active-addcard@2x.png');
                    background-size:.64rem .64rem;
                }
                .no-invited {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/inactive-invitefriend@2x.png');
                    background-size:.64rem .64rem;
                }
                .invited {
                    width:.64rem;
                    height:.64rem;
                    background:url('../../assets/images/mission/active-invitefriend@2x.png');
                    background-size:.64rem .64rem;
                }
            }
            .teasure {
                @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/inactive_teasure@2x.png');
                margin:0 auto;
            }
            .teasure-txt {
                width:4.6rem;
                margin:0 auto;
                @include commonFontTxt;
            }
            .full-teasure {
              @include commonShellIcon(1.92rem,1.92rem,'../../assets/images/mission/unlock_treasure@2x.png');
              margin:0 auto;
            }
            .box-btn {
              @include commonSmallBtn;
            }
        }
    }
    .collecte {
        width:6.7rem;
        height:.42rem;
        margin:0 auto .28rem;
        position:relative;
        .left-line {
            width:1.42rem;
            @include border-1px($color-white);
            position: absolute;
            margin-top:.2rem;
        }
        .right-line {
            width:1.42rem;
            @include border-1px($color-white);
            position: absolute;
            margin-top:.2rem;
            right:0;
        }
        .txt {
            line-height:.42rem;
            font-size:.28rem;
            color:$color-white;
            text-align:center;
            float:left;
            margin-left:1.6rem;
        }
    }
    .collecte-methods {
      @include commonCollecteMethods(6.62rem,2.16rem,.24rem,$color-white);
    }
    .mask {
        width:100%;
        height:100%;
        position:fixed;
        left:0;
        right:0;
        top:0;
        bottom:0;
        background:rgba(0,0,0,0.5);
        z-index:999;
        .content-box {
            width:6.7rem;
            position:absolute;
            top:2.3rem;
            left:.4rem;
            z-index:1000;
            border-radius:.16rem;
            .close-btn{
                @include commonIcon(.6rem,.6rem,'../../assets/images/mission/Close-Mark@2x.png');
                position: absolute;
                right:0;
                top:-.7rem;
            }
            .win-prize {
              @include commonPrice;
              .top-img {
                @include commonPriceIcon('../../assets/images/mission/huawei_reward@2x.png');;
              }
              .luck-info {
                width:6.7rem;
                padding:.32rem 0 .48rem;
                background:$color-white;
                border-radius:0 0 .16rem .16rem;
                .share-title,.progress {
                  @include commonPriceTxt;
                }
                .other-reward {
                  margin-top:.24rem;
                }
                .other-reward,.privilege {
                  @include commonPriceContentTxt(.54rem);
                }
                .prize-btn {
                  @include commonBtn(.8rem auto 0);
                }
              }
            }
            .not-win-prize {
              @include commonPrice;
              .top-img {
                @include commonPriceIcon('../../assets/images/mission/unlock_luckydraw@2x.png');
              }
              .luck-info {
                width:6.7rem;
                padding:.32rem 0 .48rem;
                background:$color-white;
                border-radius:0 0 .16rem .16rem;
                .share-title,.progress {
                  @include commonPriceTxt;
                }
                .other-reward {
                  margin-top:.26rem;
                }
                .other-reward,.privilege {
                  @include commonPriceContentTxt(.48rem);
                  line-height:.48rem;
                  font-size:.32rem;
                  text-align:center;
                  font-family: The1Official-Regular;
                  color:$color-gray-h;
                }
                .prize-btn {
                  @include commonBtn(.8rem auto 0);
                }
              }
            }
            .explain-box {
              width:6.7rem;
              height:7.5rem;
              background:$color-white;
              border-radius:.16rem;
              overflow-y: auto;
              overflow-x:hidden;
              .explain {
                .title {
                  height:1.18rem;
                  line-height:1.18rem;
                  text-align:center;
                  color:$color-gray-h;
                  font-size:.36rem;
                  font-family: The1Official-Bold;
                  font-weight:bold;
                  @include border-1px(rgba(222,222,222,0.2));
                }
                .part-one {
                  @include commonPart(.32rem .48rem .24rem);
                  .rule-title {
                    line-height:.5rem;
                    font-size:.32rem;
                    font-weight:bold;
                  }
                  .step-img {
                    height:1.14rem;
                    margin:.16rem 0 .26rem .32rem;
                    .part-one-payment {
                      width:1.28rem;
                      height:1.14rem;
                      background:url('../../assets/images/mission/payment@2x.png');
                      background-size:1.28rem 1.14rem;
                      float:left;
                    }
                    .part-one-arrow {
                      width:1.24rem;
                      height:1.14rem;
                      background:url('../../assets/images/mission/arrow@2x.png') no-repeat center;
                      background-size:contain;
                      float:left;
                      margin:0 .2rem;
                    }
                    .part-one-shell {
                      width:.64rem;
                      height:.64rem;
                      background:url('../../assets/images/mission/shell_active@2x.png');
                      background-size:.64rem .64rem;
                      float:left;
                      margin-top:.26rem;
                    }
                  }
                  .rule-txt {
                    height:.42rem;
                    line-height:.42rem;
                    margin:.26rem 0 .16rem .12rem;
                    font-size:.28rem;
                    font-family: The1Official-Regular;
                  }
                  .repeat-txt {
                    height:.42rem;
                    line-height:.42rem;
                    font-size:.28rem;
                    font-weight:bold;
                  }
                }
                .part-two {
                  @include commonPart(.32rem .48rem);
                  .title {
                    width:6rem;
                    line-height:.5rem;
                    font-size:.32rem;
                    font-weight: bold;
                    text-align: left;
                    margin-bottom:.32rem;
                  }
                  .part-two-collecte-methods {
                    @include commonCollecteMethods(5.42rem,2.16rem,.2rem,$color-gray-h);
                  }
                }
                .part-three {
                  @include commonPart(.38rem .54rem .6rem);
                  background:$color-white;
                  .reward-title {
                    line-height:.5rem;
                    text-align:center;
                    font-size:.32rem;
                    margin-bottom:.32rem;
                  }
                  .reward-type {
                    width:  5.62rem;
                    height:3.06rem;
                    display:flex;
                    justify-content: space-between;
                    font-size:.28rem;
                    .phone{
                      width:2.56rem;
                      height:3.06rem;
                      .phone-icon {
                        width:2.48rem;
                        height:2.48rem;
                        background:url('../../assets/images/mission/huawei_reward@2x.png');
                        background-size:2.48rem 2.48rem;
                      }
                      .phone-name {
                        width:2.48rem;
                        text-align:center;
                        margin-top:.16rem;
                      }
                    }
                    .baht{
                      width:2.56rem;
                      height:3.06rem;
                      .baht-icon {
                        width:2.48rem;
                        height:2.48rem;
                        background:url('../../assets/images/mission/unlock_treasure@2x.png');
                        background-size:2.48rem 2.48rem;
                      }
                      .baht-bonus {
                        width:2.48rem;
                        text-align:center;
                        margin-top:.16rem;
                      }
                    }
                  }
                }
                .part-four {
                  @include commonPart(.32rem .48rem .48rem);
                  .terms {
                    line-height:.54rem;
                    font-size:.32rem;
                    text-align:center;
                    margin-bottom:.32rem;
                    font-weight: bold;
                  }
                  .terms-item{
                    line-height:.44rem;
                    font-size:.28rem;
                    font-family: The1Official-Regular;
                  }
                }
              }
            }
        }
    }
}
</style>
