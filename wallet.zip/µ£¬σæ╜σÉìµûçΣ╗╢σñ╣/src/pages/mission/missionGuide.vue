<template>
  <div class="guide-bg">
    <h2>ยิ่งใช้</h2>
    <h2>ยิ่งฟิน</h2>
    <div class="award-title txt">พิชิตรางวัล</div>
    <div class="prize txt">โทรศัพท์ Huawei Nova 5T</div>
    <div class="total-prize txt">และเงินรางวัลรวมมูลค่ากว่าล้านบาท </div>
    <div class="use-dolfin txt">เมื่อใช้ Dolfin Wallet</div>
    <div
      class="btn"
      @click="goToNext">
      <span>ลุยเลย</span>
      <div class="right-arrow"/>
    </div>
  </div>
</template>

<script>
import { MISSION_CLICK, MISSION_ENTER } from '@/pages/burry/mission';

export default {
  name: 'MissionGuide',
  created() {
    MISSION_ENTER('MISSION_INTRO')
    this.$SDK.onBackPressNativeContinue(() => {
      MISSION_CLICK('MISSION_INTRO', 'CLICK_BACK')
    })
    this.$SDK.setTitle({
      title: '',
      mHeaderTitle: {
        showBack: 1
      }
    });
  },
  methods: {
    goToNext() {
      MISSION_CLICK('MISSION_INTRO', 'CLICK_START')
      this.$router.push({ name: 'MissionGuidePageFirst' })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
.guide-bg {
    width:7.5rem;
    height:100%;
    background:url('../../assets/images/mission/ground-intro@2x.png'),url('../../assets/images/mission/background@2x.gif');
    background-size: cover;
    color:$color-white;
    h2 {
        width:7.5rem;
        line-height:1.24rem;
        font-size:.96rem;
        text-align:center;
        font-family: The1Official-Bold;
    }
    .txt {
        line-height:.64rem;
        font-size:.36rem;
        text-align:center;
    }
    .award-title {
        margin-top:.26rem;
        font-family: The1Official-Regular;
    }
    .prize, .total-prize {
        font-family: The1Official-Bold;
    }
    .use-dolfin {
        font-family: The1Official-Regular;
    }
    .btn {
        width:2.2rem;
        height:1rem;
        line-height:1rem;
        font-size:.36rem;
        border-radius:.5rem;
        background:$color-red;
        margin:.46rem auto;
        span {
            margin-left:.43rem;
        }
        .right-arrow {
            width:.48rem;
            height:.48rem;
            float:right;
            margin:.26rem .2rem 0 0;
            background:url('../../assets/images/mission/dark@2x.png');
            background-size:.48rem .48rem;
            transform:rotate(180deg);
        }
    }
}
</style>
