<template>
  <div
    :style="{width:SubWidth,height:SubHeight}"
    class="method">
    <div
      :style="{ width:IconWidth,height:IconHeight}"
      class="icon"
      @click="handleClick">
      <img
        :src="imageUrl">
    </div>
    <p>{{ text }}</p>
  </div>
</template>

<script>
export default {
  name: 'Shell',
  props: {
    SubWidth: {
      type: String,
      default: ''
    },
    SubHeight: {
      type: String,
      default: ''
    },
    IconWidth: {
      type: String,
      default: ''
    },
    IconHeight: {
      type: String,
      default: ''
    },
    ImgWidth: {
      type: String,
      default: ''
    },
    ImgHeight: {
      type: String,
      default: ''
    },
    textLineHeight: {
      type: String,
      default: ''
    },
    textMarginTop: {
      type: String,
      default: ''
    },
    text: {
      type: String,
      default: ''
    },
    imageUrl: {
      type: String,
      default: ''
    }
  },
  methods: {
    handleClick() {
      this.$emit('tasks')
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";

@mixin commonSubStyle($width:1.92rem,$height:2.16rem) {
    width:$width;
    height:$height;
}
@mixin commonImgStyle($width:1.92rem,$height:1.72rem) {
    width:$width;
    height:$height;
    margin:0 auto;
}
@mixin textStyle($lineHeigh:.4rem,$MarginTop:.08rem) {
    line-height:$lineHeigh;
    margin-top:$MarginTop;
}
.method {
    @include commonSubStyle;
    .icon {
        @include commonImgStyle;
        img {
            width:100%;
            height:100%;
        }
    }
    p {
      width:100%;
      @include textStyle;
    }
}

</style>
