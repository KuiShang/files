<template>
  <div class="base-bg">
    <div class="mask">
      <div class="top-right-arrow"/>
      <div class="check-txt">สามารถดูกติกาและเงื่อนไขเพิ่มเติมได้ที่นี่</div>
      <div class="reward">รับเพิ่ม! เงินรางวัล 100 บาท </div>
      <div class="next-step">เพียงทำภารกิจด้านล่างให้ครบทั้ง 3 ภารกิจ</div>
      <div class="complete-bg"/>
      <div class="ready">ถ้าพร้อมที่จะทำภารกิจแล้ว..</div>
      <div
        class="btn"
        @click="goToNext">
        <span>ลุยเลย</span>
        <div class="right-arrow"/>
      </div>
    </div>
  </div>
</template>

<script>
import { MISSION_CLICK, MISSION_ENTER } from '@/pages/burry/mission';

export default {
  name: 'MissionGuidePageFirst',
  data() {
    return {
      titleRightMsg: require('../../assets/images/mission/info@2x.png')
    }
  },
  created() {
    this.$SDK.setTitle({
      title: 'วิธีการเล่น',
      mHeaderTitle: {
        showBack: 1
      }
    });
    // this.$SDK.setTitleRight(this.titleRightMsg, () => {
    //   this.handleClick()
    // })
    MISSION_ENTER('MISSION_MAIN_HOWTO3')
    this.$SDK.onBackPressNativeContinue(() => {
      MISSION_CLICK('MISSION_MAIN_HOWTO3', 'CLICK_BACK')
    })
  },
  methods: {
    goToNext() {
      MISSION_CLICK('MISSION_MAIN_HOWTO3', 'CLICK_NEXT')
      this.$router.push({ name: 'MissionDolfin' })
    },
    handleClick() {
      const url = 'http://mwallet.cjdfintech.com/#/pageCreator?pageId=91'
      this.$SDK.goNativeWebview(url)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/common.scss";
@import "@/assets/css/mixin.scss";
@mixin commonShellIcon($width,$height,$url) {
    width:$width;
    height:$height;
    background:url($url);
    background-size: $width $height;
}
.base-bg {
  width:7.5rem;
  height:100%;
  background:url('../../assets/images/mission/mission-mask-bg.png');
  background-size: cover;
  color:$color-white;
  .mask {
    width:7.5rem;
    height:calc(100% - 0.88rem);
    position:fixed;
    left:0;
    top:.88rem;
    right:0;
    bottom:0;
    box-sizing: border-box;
    padding-top:1.28rem;
    background:rgba(0,0,0,0.85);
    z-index:999;
    .top-right-arrow {
      @include commonShellIcon(.74rem,1.26rem,'../../assets/images/mission/line-to-t&c@2x.png');
      position: absolute;
      top:.18rem;
      right:.68rem;
    }
    .check-txt {
        line-height:.46rem;
        font-size:.28rem;
        text-align:center;
        font-family: The1Official-Regular;
    }
    .reward {
        line-height:.66rem;
        font-size:.4rem;
        font-family: The1Official-Bold;
        font-weight: bold;
        text-align:center;
        margin-top:.78rem;
    }
    .next-step {
        line-height:.66rem;
        font-size:.32rem;
        font-family: The1Official-Bold;
        font-weight: bold;
        text-align:center;
    }
    .complete-bg {
      @include commonShellIcon(4.48rem,1.3rem,'../../assets/images/mission/tutorial-activities-complete@2x.png');
      margin:.74rem auto;
    }
    .ready{
        line-height:.54rem;
        font-size:.32rem;
        text-align:center;
        margin-top:1.08rem;
    }
    .btn {
        width:2.2rem;
        height:1rem;
        line-height:1rem;
        font-size:.36rem;
        border-radius:.5rem;
        background:$color-red;
        margin:.4rem auto;
        span {
            margin-left:.52rem;
        }
        .right-arrow {
            width:.48rem;
            height:.48rem;
            float:right;
            margin:.26rem .2rem 0 0;
            background:url('../../assets/images/mission/dark@2x.png');
            background-size:.48rem .48rem;
            transform:rotate(180deg);
        }
    }
  }
}
</style>
