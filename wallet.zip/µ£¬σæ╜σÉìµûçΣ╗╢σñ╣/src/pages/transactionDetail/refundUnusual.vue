<template>
  <div class="refund-unusual">
    <img
      src="./img/ Cashback@3x.png"
      class="img">
    <p class="title">{{ $t('Refund Success') }}</p>
    <p class="txt tx1">{{ $t('Dolfin is updating your refund transaction.') }}</p>
    <p class="txt tx2">{{ $t('Please wait or try again later by go to Menu > Transaction History') }}</p>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="handleClick">{{ $t('GO TO HOME') }}</common-button>
    </div>
  </div>
</template>
<script>
export default {
  name: 'RefundUnusual',
  created() {
    this.$SDK.setTitle({
      title: '',
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
  },
  methods: {
    handleClick() {
      this.$SDK.closeWebViewAndSendResult()
    }
  }
};
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.refund-unusual {
  text-align: center;
  padding-top: .4rem;
  .img {
    width: 2rem;
  }
  .title {
    font-family: The1Official_Bold;
    font-size: 24px;
    color: $color-red;
    letter-spacing: 0;
    text-align: center;
  }
  .txt {
    font-size: .36rem;
    color: $color-gray-f;
    letter-spacing: 0;
    text-align: center;
    line-height: .6rem;
  }
  .tx1 {
    margin-top: .2rem;
    padding-left: .6rem;
    padding-right: .6rem;
  }
  .tx2 {
    padding-left: .4rem;
    padding-right: .4rem;
  }
  .btn-wraper {
    position: absolute;
    font-family: The1Official_Bold !important;
    bottom: .8rem;
    display: flex;
    box-sizing: border-box;
    margin-left: 50%;
    transform: translateX(-50%)
  }
}
</style>
