<template>
  <div v-if="dataObj" class="result">

    <!-- 充值 -->
    <template v-if="dataObj.busiScenarios == 1">
        <div class="head">
          <div class="fle-container">
            <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
            <span class="txt-title"> {{ $t('balancetopup') }}</span>
          </div>
          <p class="txt-money">{{ amountText }}</p>
          <!-- <p class="txt-des">{{ $t('topup2') }} {{statusText}}</p> -->
          <p class="txt-des"> {{statusText}}</p>
        </div>
        <ul class="list">
        <li class="item">
          <span class="key"> {{ $t('Transaction Type') }}</span>
          <span class="val" >{{ $t('topup') }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }} </span>
          <span class="val" >{{transactionTime}} </span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="val trans-no">{{dataObj.transOrderNo}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>
    <!-- 转账 -->
    <template v-else-if="dataObj.busiScenarios == 3">
      <!-- 1 Fin Account -->
      <template v-if="dataObj.transferChannel == 1">
        <div class="head">
          <div class="fle-container">
            <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
            <span class="txt-title" v-if ="dataObj.inOutFlag === '+'"> {{ $t('FROM') }} {{dataObj.payAccountName}}</span>
            <span class="txt-title" v-else>{{ $t('TO') }}  {{dataObj.receiverAccountName}}</span>
          </div>
          <p class="txt-money">{{ amountText }}</p>
          <!-- <p class="txt-des">{{ $t('transaction') }}  {{statusText}}</p> -->

          <p class="txt-des"> {{statusText}}</p>
        </div>
        <ul class="list">
          <li class="item">
            <span class="key">{{ $t('Transaction Type') }}</span>
            <span class="val" >{{ $t('transfer2') }}</span>
          </li>
          <li class="item" v-if ="dataObj.inOutFlag !== '+'">
            <span class="key">{{ $t('Payment Method') }}</span>
            <span class="val" >{{paymentMethodText}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Transaction Time') }}</span>
            <span  class="val">{{transactionTime}}</span>
          </li>
          <li class="item trans-no-item">
            <span class="key">{{ $t('Transaction No.') }}</span>
            <span class="val trans-no">{{dataObj.transOrderNo}}</span>
          </li>
          <li class="item" v-if="dataObj.remark">
            <span class="key">   {{ $t('Notes') }}</span>
            <span  class="val">{{dataObj.remark}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Get help & support') }}</span>
            <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
          </li>
        </ul>
      </template>

      <!-- Bank Account -->
      <template v-if="dataObj.transferChannel == 2">
        <div class="head">
          <div class="fle-container">
            <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
            <span class="txt-title"> {{ $t('Transfer to bank account') }}  </span>
          </div>
          <p class="txt-money">{{ amountText }}</p>
          <!-- <p class="txt-des">{{ $t('transaction') }}  {{statusText}}</p> -->
           <p class="txt-des"> {{statusText}}</p>
        </div>
        <ul class="list">
          <li class="item">
            <span class="key"> {{ $t('Fee') }}  </span>
            <span class="val">{{ dataObj.serviceCharge | tofloat | thousandBitSeparator }}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Transaction Type') }}</span>
            <span class="val">{{ $t('transfer2')}}</span>
          </li>

          <li class="item">
            <span class="key">   {{ $t('ReceiverAccount')  }}  </span>
            <span>{{ dataObj.receiverBankName + '(' + dataObj.receiverAccountNo  + ')'}}</span>
          </li>
         

          <li class="item">
            <span class="key">{{ $t('Payment Method') }}</span>
            <span class="val">{{paymentMethodText}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Transaction Time') }}</span>
            <span class="val">{{transactionTime}}</span>
          </li>
          <li class="item trans-no-item">
            <span class="key">{{ $t('Transaction No.') }}</span>
            <span class="val trans-no">{{dataObj.transOrderNo}}</span>
          </li>
          <li class="item" v-if="dataObj.remark">
            <span class="key">{{ $t('Notes') }}</span>
            <span class="val">{{dataObj.remark}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Get help & support') }}</span>
            <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
          </li>
        </ul>
      </template>


      <!-- Promptpay Account -->
      <template v-if="dataObj.transferChannel == 3">
        <div class="head">
          <div class="fle-container">
            <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
            <span class="txt-title">{{ $t('Transfer to promtpay account') }}  </span>
          </div>
          <p class="txt-money">{{ amountText }}</p>
          <p class="txt-des"> {{statusText}}</p>
          <!-- <p class="txt-des">{{ $t('Transaction No.') }} {{statusText}}</p> -->
        </div>
        <ul class="list">
          <li class="item">
            <span class="key">{{ $t('Transaction Type') }}</span>
            <span class="val">{{ $t('transfer2')}}</span>
          </li>

         
          <li class="item trans-no-item">
            <span class="key">{{ $t('Receiver') }} </span>
            <span class="val">{{ dataObj.receiverAccountName}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('ReceiverAccount') }}   </span>
            <span>{{ dataObj.receiverAccountNo }}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Payment Method') }}</span>
            <span class="val">{{paymentMethodText}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Transaction Time') }}</span>
            <span class="val">{{transactionTime}}</span>
          </li>
          <li class="item trans-no-item">
            <span class="key">{{ $t('Transaction No.') }}</span>
            <span class="val trans-no">{{dataObj.transOrderNo}}</span>
          </li>
          <li class="item" v-if="dataObj.remark">
            <span class="key">{{ $t('Notes') }}</span>
            <span class="val">{{dataObj.remark}}</span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Get help & support') }}</span>
            <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
          </li>
        </ul>
      </template>

    </template>


    <!-- 消费 -->
    <template v-if="dataObj.busiScenarios == 6">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{dataObj.logoName}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des">{{statusText}}</p>
          <!-- <p class="txt-des">{{statusText}}</p> -->
      </div>
      
      <!--  增加相应支付券场景-->
      <div
        v-if="couponDetail === 'null' || couponDetail === '{}'"
        class="couponDiv">
        <ul>
          <li :style="{height:flag!==true?'1.2rem':'auto'}">
            <img 
              :src="couponDetail.logo"
              alt="">
              <span class="imgcouponValue">{{ $t('Save') }}{{ couponDetail.couponName }}</span>
              <span 
                class="hide-detail"
                @click="toggle"> {{ toggleTxt }}</span>
                <common-icon
                  class="custom-ico botX"
                  name="less"
                  size=".3rem"
                  v-if='flag'
                  slot="img"
                />
                <common-icon
                  v-else
                  slot="img"
                  class="custom-ico botX"
                  name="moreunfold"
                  size=".3rem"
                />
                <div 
                  v-if="flag" style="float：left;margin-left: .4rem;">
                  <p class="coupOnC">{{ couponDetaildescribe }}</p>
                  <div class="borderXian"></div>
                  <div class="list" style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.29rem;">
                        <span class="key">Subtotal</span>
                        <span>฿{{ couponDetail.orderAmount }}</span>
                      </li>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.28rem;padding-bottom:.28rem;">
                        <span class="key">Discount Coupon</span>
                        <span>-฿{{ couponDetail.discountAmount }}</span>
                      </li>
                    </ul>
                  </div>
                  <div class="borderXian"></div>
                  <div class="list"  style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding-bottom: 0;min-height:.8rem;padding-top:.28rem;">
                        <span class="key">Total</span>
                        <span style="font-weight:bold;">฿{{ couponDetail.actualPaymentAmount }}</span>
                      </li>
                    </ul>
                  </div>
                </div>
          </li>
        </ul>
        
      </div>
      <div style="clear: both;"></div>
      <ul class="list">
        <!-- 营销相关 -->
        <template v-if="dataObj.coupon && dataObj.coupon.name && false">
          <li class="item coupon" >
            <span class="key">{{ $t('Subtotal') }}</span>
            <span class="val">{{ dataObj.coupon.orderAmount | tofloat | thousandBitSeparator }}  </span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Discount Coupon') }}</span>
            <span class="red val">{{ dataObj.coupon.couponAmount  | tofloat | thousandBitSeparator  }}  </span>
          </li>
          <li class="item">
            <span class="coupon-name"  >{{ getEnOrTh(dataObj.coupon.name)  }}</span>
          </li>
        </template>
        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Purchase') }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }} </span>
          <span class="val trans-no">{{dataObj.transOrderNo}}</span>
        </li>
       
        <li class="bar-code-txt">{{$t('Show this barcode to cashier staff to refund this transaction')}}</li>
        <li class="bar-code" ref="barCode" :style="{'background-image': `url('${barCode}')`}"></li>
        <li class="item trans-no-item ">
          <span class="key"> {{ $t('Merchant order NO.') }}   </span>
          <span class="val trans-no">{{dataObj.merchantOrderNo}}</span>
        </li>

      </ul>
    </template>

    <!-- 退款 -->
    <template v-if="dataObj.busiScenarios == 4">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{getEnOrTh(dataObj.logoName)}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <!-- <p class="txt-des">  {{ $t('Refund') }}   {{statusText}}</p> -->
         <p class="txt-des">   {{statusText}}</p>
      </div>
      <ul class="list">
        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Refund') }} </span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="val trans-no">{{dataObj.transOrderNo}}</span>
        </li>
        <li class="item trans-no-item" v-if="dataObj.merchantOrderNo" >
          <span class="key">{{ $t('Merchant order NO.') }} </span>
          <span class="val trans-no">{{dataObj.merchantOrderNo}}</span>
        </li>
        <li class="item" v-if="dataObj.associationRecord">
          <span class="key">{{ $t('Related Transaction') }} </span>
          <span
            class="red val"
            @click="goRelatedTransaction"> {{ $t('view') }}  </span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="val red" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>

    <!-- 营销 -->
    <template v-if="dataObj.busiScenarios == 5">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{dataObj.logoName}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <!-- <p class="txt-des">Received {{statusText}}</p> -->
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <ul class="list">
        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Promotion') }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>

       <!-- request to pay -->
    <template v-if="dataObj.busiScenarios == 7">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{getEnOrTh(dataObj.logoName)}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <ul class="list">
        <li class="item">
          <span class="key">{{ $t('Collection Detail')}}</span>
          <span class="red val" @click="viewRequestToPayStatus">{{ $t('view') }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Share Bill') }}  </span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>

    <!-- Purchase-Tag 30 -->
    <template v-if="dataObj.busiScenarios == 8">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{dataObj.logoName}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <!--  增加相应支付券场景-->
      <div
        v-if="couponDetail === 'null' || couponDetail === '{}'"
        class="couponDiv">
        <ul>
          <li :style="{height:flag!==true?'1.2rem':'auto'}">
            <img 
              :src="couponDetail.logo"
              alt="">
              <span class="imgcouponValue">{{ $t('Save') }}{{ couponDetail.couponName }}</span>
              <span 
                class="hide-detail"
                @click="toggle"> {{ toggleTxt }}</span>
                <common-icon
                  class="custom-ico botX"
                  name="less"
                  size=".3rem"
                  v-if='flag'
                  slot="img"
                />
                <common-icon
                  v-else
                  slot="img"
                  class="custom-ico botX"
                  name="moreunfold"
                  size=".3rem"
                />
                <div 
                  v-if="flag" style="float：left;margin-left: .4rem;">
                  <p class="coupOnC">{{ couponDetaildescribe }}</p>
                  <div class="borderXian"></div>
                  <div class="list" style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.29rem;">
                        <span class="key">Subtotal</span>
                        <span>฿{{ couponDetail.orderAmount }}</span>
                      </li>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.28rem;padding-bottom:.28rem;">
                        <span class="key">Discount Coupon</span>
                        <span>-฿{{ couponDetail.discountAmount }}</span>
                      </li>
                    </ul>
                  </div>
                  <div class="borderXian"></div>
                  <div class="list"  style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding-bottom: 0;min-height:.8rem;padding-top:.28rem;">
                        <span class="key">Total</span>
                        <span style="font-weight:bold;">฿{{ couponDetail.actualPaymentAmount }}</span>
                      </li>
                    </ul>
                  </div>
                </div>
          </li>
        </ul>
        
      </div>
      <div style="clear: both;"></div>
      <ul class="list">
       

       <!-- TODO: 此处三个英文文案未提供为添加 等待1.1上线之后在添加上来 -->
        <!-- 营销相关 -->
        <template v-if="dataObj.coupon && dataObj.coupon.name && false">
          <li class="item coupon" >
            <span class="key">{{ $t('Subtotal') }}</span>
            <span class="val">{{ dataObj.coupon.orderAmount | tofloat | thousandBitSeparator }}  </span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Discount Coupon') }}</span>
            <span class="red val">{{ dataObj.coupon.couponAmount  | tofloat | thousandBitSeparator  }}  </span>
          </li>
          <li class="item">
            <span class="coupon-name"  >{{ getEnOrTh(dataObj.coupon.name)  }}</span>
          </li>
        </template>

        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Purchase') }}  </span>
        </li>
        <li class="item" >
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
        <!-- 20190723 去掉 merchantOrderNo 新增 reference1 reference2  zhangyaqi -->
         <!-- <li class="item">
          <span class="key"> {{ $t('Merchant order NO.') }}   </span>
          <span class="val">{{dataObj.merchantOrderNo}}</span>
        </li> -->
        
         <li class="item"  v-if="dataObj.reference1">
          <span class="key"> {{ $t('Ref1') }}   </span>
          <span class="val">{{dataObj.reference1}}</span>
        </li>
         <li class="item"  v-if="dataObj.reference2">
          <span class="key"> {{ $t('Ref2') }}   </span>
          <span class="val">{{dataObj.reference2}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>

    <!-- 退款-Tag 30 -->
    <template v-if="dataObj.busiScenarios == 9">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{dataObj.logoName}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <ul class="list">

        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Refund') }}  </span>
        </li>
        <li class="item" >
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
         <!-- <li class="item trans-no-item">
          <span class="key"> {{ $t('Merchant order NO.') }}   </span>
          <span class="val trans-no">{{dataObj.merchantOrderNo}}</span>
        </li> -->
         <!-- 20190723 去掉 merchantOrderNo 新增 reference1 reference2  zhangyaqi -->
         <li class="item"  v-if="dataObj.reference1">
          <span class="key"> {{ $t('Ref1') }}   </span>
          <span class="val">{{dataObj.reference1}}</span>
        </li>
         <li class="item"  v-if="dataObj.reference2">
          <span class="key"> {{ $t('Ref2') }}   </span>
          <span class="val">{{dataObj.reference2}}</span>
        </li>
        <li class="item" v-if="dataObj.associationRecord">
          <span class="key">{{ $t('Related Transaction') }} </span>
          <span
            class="red val"
            @click="goRelatedTransaction"> {{ $t('view') }}  </span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>
    <!-- purchase-jdth payment -->
    <template v-if="dataObj.busiScenarios == 10">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{dataObj.logoName}}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <ul class="list">
        <!-- TODO: 此处三个英文文案未提供为添加 等待1.1上线之后在添加上来 -->
        <!-- 营销相关 -->
        <template v-if="dataObj.coupon && dataObj.coupon.name && false">
          <li class="item coupon" >
            <span class="key">{{ $t('Subtotal') }}</span>
            <span class="val">{{ dataObj.coupon.orderAmount | tofloat | thousandBitSeparator }}  </span>
          </li>
          <li class="item">
            <span class="key">{{ $t('Discount Coupon') }}</span>
            <span class="red val">{{ dataObj.coupon.couponAmount  | tofloat | thousandBitSeparator  }}  </span>
          </li>
          <li class="item">
            <span class="coupon-name"  >{{ getEnOrTh(dataObj.coupon.name)  }}</span>
          </li>
        </template>

        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Purchase') }}  </span>
        </li>
        <li class="item" >
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
         <li class="item trans-no-item">
          <span class="key"> {{ $t('Merchant order NO.') }}   </span>
          <span class="val trans-no">{{dataObj.merchantOrderNo}}</span>
        </li>
   
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>
    <!-- For compensation functionality refund -->
    <template v-if="dataObj.busiScenarios == 11">
      <div class="head">
        <div class="fle-container">
          <img v-if="dataObj.logoUrl" :src="dataObj.logoUrl" class="img" alt="">
          <span class="txt-title">{{ getEnOrTh(dataObj.logoName) }}</span>
        </div>
        <p class="txt-money">{{ amountText }}</p>
        <p class="txt-des"> {{statusText}}</p>
      </div>
      <ul class="list">
        <!-- TODO: 此处三个英文文案未提供为添加 等待1.1上线之后在添加上来 -->

        <li class="item">
          <span class="key">{{ $t('Transaction Type') }}</span>
          <span class="val">{{ $t('Refund') }}  </span>
        </li>
        <!-- 该类型没有支付方式 -->
        <!-- <li class="item" >
          <span class="key">{{ $t('Payment Method') }}</span>
          <span class="val">{{paymentMethodText}}</span>
        </li> -->
        <li class="item">
          <span class="key">{{ $t('Transaction Time') }}</span>
          <span class="val">{{transactionTime}}</span>
        </li>
        <li class="item trans-no-item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span class="trans-no val">{{dataObj.transOrderNo}}</span>
        </li>
      
        <li class="item">
          <span class="key">{{ $t('Get help & support') }}</span>
          <span class="red val" @click="goNewUrl">{{ $t('view') }}</span>
        </li>
      </ul>
    </template>
  </div>
</template>
<script>

  import {queryTradeDetail, queryMsgCenterTradeDetail }  from '@/api'
  import { enumPayMethodCodeFirst, CASHIER_PAYMENT_METHODS } from '@/utils/const'
  import * as TRANSFER_BURRY from '@/pages/burry/transDetail'
  import handlInitData from '@/mixins/handlInitData'

  export default {
    name: 'TransactionDetail',
    mixins: [handlInitData],
    props: ["redirectFrom"],
    data() {
      return {
        transData: {},
        barCode: '',
        flag: false,//Show hide Detail
        couponDetail: {},// 优惠券详情
        couponDetaildescribe: ''// 优惠券描述
      }
    },
    computed: {
      isBalanceToBank(){
        let data = this.dataObj || {};
        return data.busiScenarios == 3 && data.balancePayFlag  && data.bankName
      },
      transactionText(){
        let data = this.dataObj || {};
        return data.busiScenarios == 2 || this.isBalanceToBank? this.paymentMethodText : data.customerName;
      },
      amountText(){
        let data = this.dataObj || {}
        let amount = Number(data.amount || 0).toFixed(2)
        return  (amount ? (data.inOutFlag ? data.inOutFlag + " " : "")  : "") + this.$utils.thousandBitSeparator(amount)
      },
      transactionTime(){
        return this.dataObj && this.dataObj.createdDate ? new Date(this.dataObj.createdDate).format("dd-MM-yyyy hh:mm:ss") : "";
      },
      /**内容的显示格式为：银行编码(银行卡号后4位)
       * 注意：数据都有为null的可能，增加容错性
       * */
      paymentMethodText(){
        if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.ODD) {
          const last4Num = this.dataObj.payAccountNo ? `(${this.dataObj.payAccountNo.slice(-4)})` : ''
          // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
          return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])} ${last4Num}`
        } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.BALA) {
          // return this.dataObj.payMethodCodeFirst
          // return 'Balance'
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
        } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.OFLN) {
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
        } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.CCP) {
           const last4Num = this.dataObj.payAccountNo ? `(${this.dataObj.payAccountNo.slice(-4)})` : ''
          // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
          return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])} ${last4Num}`
        } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.DELI) {
          return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
        }
        return ''
      },
      statusText(){
        let curentLang = ''
        const deviceinfo = this.$DeviceInfo || {}
        if (deviceinfo.language === 'en_US') {
          curentLang = 'EN'
        } else {
          curentLang = 'TH'
        }
        if (this.dataObj.statusDes) {
          return JSON.parse(this.dataObj.statusDes)[curentLang]
        } else if  (this.dataObj.statusDesc) {
          return JSON.parse(this.dataObj.statusDesc)[curentLang]
        }
        return ({
          2: {
            EN: 'In Process',
            TH: 'ในกระบวนการ'
          },
          3: {
            EN: 'Success',
            TH: 'สำเร็จ'
          },
          4: {
            EN: 'Failed',
            TH: 'ล้มเหลว'
          }
        }[this.dataObj.status] || {})[curentLang];
      },
      toggleTxt() {
        if (this.flag) {
          return this.$t('Hide Detail')
        }
        return this.$t('Show Detail')
      }
    },
    created() {
      this.$SDK.onBackPress(() => {
        TRANSFER_BURRY.TRANSACTION_DETAIL_LEAVE()
        this.$SDK.closeWebViewAndSendResult()
      })
      TRANSFER_BURRY.TRANSACTION_DETAIL_ENTER()
      this.initData()
      this.$SDK.setTitle({
        title: this.$t('transaction')
      })
    },
    methods: {
      async initData() {
        let query = this.$route.query, queryAPI, postData;
        this.transData = Object.assign({}, query);

        if(this.redirectFrom == "center"){ // 查询交易明细（消息中心）
          queryAPI = queryMsgCenterTradeDetail;
          postData = {
            version: this.$DeviceInfo.appVersion,
            transOrderNo: query.transOrderNo
          };
        } else {
          /**customerId, 客户唯一标识
           * tranNo, 交易单号
           * tranType, 交易类别
           * bizSystem, 业务系统
           * */
          queryAPI = queryTradeDetail;
          postData = {...query};
        }
        this.$indicator.open({
          text: 'Loading...',
          spinnerType: 'fading-circle'
        })
        const res = await queryAPI(postData);
        // this.dataObj = res.data.resultData;
        console.log('res', res)
        this.couponDetail = res.data.resultData.promoBean ? res.data.resultData.promoBean : {};
        const deviceinfo = this.$DeviceInfo || {}
        if (deviceinfo.language === 'en_US') {
          this.couponDetaildescribe = this.couponDetail.shortDesicriptionMapcurentLang ? this.couponDetail.shortDesicriptionMapcurentLang[en_US] :'';
        } else {
          this.couponDetaildescribe = this.couponDetail.shortDesicriptionMapcurentLang ? this.couponDetail.shortDesicriptionMapcurentLang[th_TH] : '';
        }
        this.$indicator.close()
        this.handlInitData(res, () => {
           // 仅仅 消费详情时候需要 获取barcode
          if (this.dataObj.busiScenarios == 6) {
            this.getScanCode()
          }
        }, (handlInitDataDefaultErrorMethod) => {
          // public 1.2需求
          // pm: zhangyaqi
          // 当退款查询不到的场景 跳转到 一个  异常页面，这种场景 针对 退款收到一条消息 查询交易中心 交易中心由于异步一般查询结果为空 
          // 但是 交易中心 查询不到 不一定都是从 从消息中心过来的这种情况，容易出现漏洞，已经和产品反馈，产品坚持这样做   20190605
          // 服务端 李旭
          if (query.tranType === '6' && query.bizSystem === '2') {
            if (res.data.errorData.code === 'TC_E00003') {
             this.$router.push( { name: 'refundUnusual' })
            }
          } else {
            handlInitDataDefaultErrorMethod(res, this)
          }
        })
      },
      async goRelatedTransaction() {
        // this.$indicator.open({
        //   text: 'Loading...',
        //   spinnerType: 'fading-circle'
        // })
        // this.$router.push( { name: 'transationDetail', query: this.dataObj.associationRecord })
        const associationRecordObj = JSON.parse(this.dataObj.associationRecord)
        // const res = await queryTradeDetail(associationRecordObj)
        // this.$indicator.close()
        // this.dataObj = res.data.resultData

        const url = `${window.location.origin}/#/transationDetail?tranNo=${associationRecordObj.tranNo}&tranType=${associationRecordObj.tranType}&bizSystem=${associationRecordObj.bizSystem}`
        this.$SDK.goNativeWebview(url)

      },
      viewRequestToPayStatus() {
        console.log('go r2topay status')
        this.$SDK.goNativeAction(this.dataObj.actionData);
      },
      goNewUrl() {
        let lang = ''
        const deviceinfo = this.$DeviceInfo || {}
        if (deviceinfo.language === 'en_US') {
          lang = 'en_US '
        } else {
          lang = 'th_TH'
        }
        const json = {
          type: 'native',
          address: '/webview/web',
          params: {
            url: `http://cjdfaq.three-rd.com:3303/?lang=${lang}`,
            textColor: '#000',
            mHeaderTitle: {
              showHead: 1,
              showBack: 1,
              showEnd: 0,
              showProTpye: 1,
              titleBgColor: '#ffffff'
            },
          }
        };
        this.$SDK.goNativeAction(json);
      },
      getEnOrTh(json) {
        try{
          let curentLang = ''
          const deviceinfo = this.$DeviceInfo || {}
          if (deviceinfo.language === 'en_US') {
            curentLang = 'EN'
          } else {
            curentLang = 'TH'
          }
          return JSON.parse(json)[curentLang]
        } catch(e) {
          console.log('json解析错误', e)
          return ''
        }
      },
      setCardNumber(val) {
        if (val) {
          return val.toString()
            .replace(/\s/g, '')
            .replace(/(\d{4})(?=\d)/g, '$1 ')
        } else {
          return ''
        }
      },
      getScanCode() {
        this.$nextTick(() => {
          // 传给客户端的比例需要保证与图片比例高一致，默认传给客户端112*335 因为手机放大并非宽高等比缩放，所以只能保证宽/或高 一面等比缩放，不可同时改变
          const bodyWidth = document.body.clientWidth
          // const bodyHeight = document.body.clientHeight
          const uiWidth = 375
          // const uiHeight = 667
          const rateW = bodyWidth / uiWidth
          // const rateH = bodyHeight / uiHeight
          const barCode = this.$refs.barCode

          barCode.style.height = `${rateW * 112}px`
          barCode.style.width = `${rateW * 335}px`
        })
        const json = {
          codeType: 1,// 条形码
          imageType: 1,//png
          inputdata: this.dataObj.transOrderNo,
          width: 335*1.5,
          height: 112* 1.5,
          quality: 90,
          barCodeColor: '#000000'
        };
        this.$SDK.setBarCode(json,(resp) => {
          console.log('resp', resp);
          this.barCode = 'data:image/png;base64,' + resp.data;
        })
      },
      //切换showDetail
      toggle() {
        this.flag = !this.flag;
      }
    }
  }
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
  .result {
    height: 100%;
    background-color: #f6f6f6;
    .head {
      background-color: #fff;
      box-sizing: border-box;
      text-align: center;
      padding-top: .61rem;
      .fle-container {
        display: flex;
        justify-content: center;
        align-items: center;
        .img {
          width: 0.4rem;
          height: .4rem;
          border-radius: 50%;
        }
        .txt-title {
          text-align: center;
          padding-left: .2rem;
          font-family: The1Official_Bold;
          font-size: .28rem;
          color: $color-gray-h;
          white-space: nowrap;
        }
      }
      .txt-money {
        padding-top: .68rem;
        font-size: .92rem;
        text-align: center;
        line-height: .52rem;
        font-family: The1Official_Bold;
        font-size: .96rem;
        color: $color-red;
      }
      .txt-des {
        padding-top: .52rem;
        font-size: .24rem;
        color: $color-gray-h;
        line-height: .52rem;
        padding-bottom: .61rem;
      }
    }
    .list {
      background-color: #fff;
      padding: 0 .4rem;
      margin-top: .2rem;
      padding-top: .2rem;
      padding-bottom: .2rem;
      .item {
        display: flex;
        justify-content: space-between;
        // word-break: break-all;
        padding-top: .2rem;
        padding-bottom: .2rem;
        // height: .9rem;
        line-height: .9rem;
        font-size: .28rem;
        color: $color-gray-h;
        text-align: right;
        line-height: .52rem;
        .key {
          color: $color-gray-f;
        }
        .key, .val {
          // line-height: .9rem;
          max-width: 46%;
        }
        .coupon-name {
          font-size: 12px;
          color: #8D8D8D;
          text-align: left;
          padding-bottom: .2rem;
          border-bottom: 1px solid  #E7E8ED;
        }
      }
      .bar-code-txt {
        padding-top: .6rem;
        font-size: 12px;
        color: #4F577C;
        padding-bottom: .2rem;
      }
     .bar-code {
       height: 112px;
       width: 335px;
       margin: 0 auto;
       background-size: contain;
     }
      .trans-no-item {
        word-break:break-all;
        line-height: .45rem;
        padding-top: .2rem;
        padding-bottom: .2rem;
        .key {
          line-height: .45rem;
        }
        .trans-no {
          line-height: .45rem;
        }
      }
    }

    .red {
      color: $color-red;
    }
    .couponDiv {
      background-color: #fff;
      margin-top: .2rem;
      margin-bottom: .2rem;
      height: auto;
      width: 100%;
      li {
        float: left;
        min-height: 1.2rem;
        width: 100%;
        background-color: #fff;
        img {
          width: .6rem;
          height: .6rem;
          float: left;
          margin-left: .4rem;
          margin-top: .3rem;
        }
        .imgcouponValue {
          font-family: The1Official-Bold;
          font-size: .28rem;
          color: #141E50;
          letter-spacing: 0;
          text-align: left;
          float: left;
          margin-left: .2rem;
          line-height: 1.2rem;
          font-weight: bold;
        }
        .hide-detail {
          font-family: The1Official-Regular;
          font-size: .28rem;
          color: #FF3E5B;
          letter-spacing: 0;
          text-align: right;
          float: left;
          margin-left: 2.02rem;
          line-height: 1.2rem;
        }
        .botX {
          color: #FF3E5B;
          float: left;
          margin-left: .025rem;
          line-height: 1.2rem;
        }
        .coupOnC {
          font-family: The1Official-Regular;
          font-size: .28rem;
          color: #141E50;
          letter-spacing: 0;
          text-align: left;
          float: left;
          width: 6.7rem;
          margin:0 0 .29rem 0;
          line-height: .42rem;
        }
        .borderXian {
          width: 6.7rem;
          border-top: .02rem dashed#A1A5B9;
          height: .02rem;
          float: left;
        }
      }
    }
  }
</style>
