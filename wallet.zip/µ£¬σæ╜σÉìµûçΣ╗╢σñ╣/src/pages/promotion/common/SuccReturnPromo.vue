<template>
  <div
    v-show="hasPromoStatus !== 0"
    class="succ-return-promo">
    <h6>Promotion</h6>
    <div class="promo-box">
      <!-- 有营销资格 hasPromoStatus 1 -->
      <div
        v-show="hasPromoStatus === 1"
        class="promo-hit" >
        <div class="promo-desc">
          <h6>Cash Lucky Draw</h6>
          <p>Click to get up to <span>{{ promotionAmountMax }} thb</span> cashback</p>
        </div>
        <div class="treasure">
          <div
            v-for="(item, index) in arrPromotion"
            :id="getId(index)"
            :key="index"
            class="treasure-box viewport-flip">
            <!-- 翻面后 -->
            <a
              href="javascript:;"
              class="list reverse flip out hide">
              <!-- 展示中奖金额的span -->
              <span />
              <img
                class="gray_card"
                src="@/assets/images/promotion/gray_card@2x.png"
                alt="f">
              <img
                class="yellow_card"
                src="@/assets/images/promotion/yellow_card@2x.png"
                alt="f">
              <img
                class="coloured-ribbon"
                src="@/assets/images/promotion/ColouredRibbon.gif"
                alt="f">
            </a>
            <!-- 翻面前 -->
            <a
              href="javascript:;"
              class="list reverse flip">
              <img
                src="@/assets/images/promotion/card@2x.png"
                alt="z">
            </a>
          </div>
        </div>
      </div>
      <!-- 命中确认接口异常后尝试 hasPromoStatus 2 -->
      <div
        v-if="hasPromoStatus === 2"
        class="promotion-tryAgain">
        <h6>Sorry, something is wrong</h6>
        <p>
          <span @click="tryPromotion()">TRY AGAIN</span>
        </p>
      </div>
      <!-- 没有营销资格 hasPromoStatus 3-->
      <div
        v-show="hasPromoStatus === 3"
        class="noQualified-promotion">
        <h6>Unfortunately, no award this time. Thank you for participation.</h6>
      </div>
    </div>
  </div>
</template>
<script>
import { SuccReturnPromoMarkingQuer, SuccReturnPromoHit } from '@/api'

export default {
  name: 'SuccReturnPromo',
  data() {
    return {
      // hasPromoStatus 0是咩有营销资格
      hasPromoStatus: 0,
      promotionAmountMax: null,
      // 奖牌个数
      arrPromotion: [1, 2, 3, 4],
      arrPromotionAmount: [],
      titleRightMsg: {
        text: this.$t('DONE'),
        show: 1,
        textSize: 18,
        textColor: '#FF3E5B'
      },
      // 第一张牌翻面多久后，其他的翻面(毫秒);
      timeOfTurnOver: 800,
      // 在前面显示的元素，隐藏在后面的元素
      eleBack: null,
      eleFront: null,
      eleList: null,
      stop: false,
      promoInfoServer: null,
      aTreasureBox: null
    }
  },
  computed: {
    transactionNo() {
      return this.$utils.getQueryString('transactionNo')
    },
    customerId() {
      return this.$utils.getCookie('customerId')
    },
    platform() {
      const deviceInfo = this.$DeviceInfo
      if (deviceInfo.os === 'Android') {
        return 3;
      }
      return 4;
    }
  },
  async created() {
    // this.setTitle();
    if (!this.transactionNo || !this.customerId) return
    const resQuery = await SuccReturnPromoMarkingQuer({
      transactionNo: this.transactionNo,
      customerId: this.customerId,
      userIp: this.$DeviceInfo.ip,
      // webSite: 'h5',
      platform: this.platform,
      deviceInfo: this.$DeviceInfo
    })
    if (resQuery && resQuery.data && resQuery.data.resultCode === 1) {
      if (resQuery.data.resultData.status === true) {
        this.hasPromoStatus = 1;
        this.promotionAmountMax = resQuery.data.resultData.maxCashback;
        // alert(JSON.stringify(resQuery.data.resultData.promoInfo));
        this.promoInfoServer = resQuery.data.resultData.promoInfo;
        this.upAndDown();
        this.turnFace();
      }
    } else {
      this.hasPromoStatus = 0
    }
  },
  methods: {
    // setTitle() {
    //   this.$SDK.setTitleRight(this.titleRightMsg, () => {
    //     this.$SDK.closeWebViewAndSendResult()
    //   })
    // },
    upAndDown() {
      const self = this;
      this.aTreasureBox = document.querySelectorAll('.treasure-box');
      const aTreasureBoxLength = this.aTreasureBox.length;
      // 页面初始化给第0个元素增加样式运动
      this.aTreasureBox[0].classList.add('animate-bounce-up');
      if (aTreasureBoxLength === 1) return;
      for (let i = 0; i < aTreasureBoxLength; i += 1) {
        if (i === aTreasureBoxLength - 1) {
          // 最后一个要运动的元素
          this.aTreasureBox[i].addEventListener('webkitAnimationIteration', function AnimationIterationCb() {
            // if (!self.stop) return false;
            // console.log('webkitAnimationIteration1')
            this.classList.remove('animate-bounce-up');
            self.aTreasureBox[0].classList.add('animate-bounce-up');
          }, false);
        } else {
          this.aTreasureBox[i].addEventListener('webkitAnimationIteration', function AnimationIterationCb() {
            // if (!self.stop) return false;
            // console.log('webkitAnimationIteration2')
            this.classList.remove('animate-bounce-up');
            this.nextElementSibling.classList.add('animate-bounce-up');
          }, false);
        }
      }
    },
    turnFace() {
      // this.stop = true
      const self = this
      // 获取父元素的
      // 确定前面与后面元素
      function funBackOrFront(id) {
        // 纸牌元素们
        self.eleList = self.toArray(document.querySelectorAll(`#${id} .list`))
        // 已选择点击的元素
        if (id) {
          document.querySelector(`#${id}`).classList.add('selected')
        }
        self.eleList.forEach((item) => {
          if (item.classList.contains('out')) {
            self.eleBack = item
          } else {
            self.eleFront = item
          }
        });
      }

      async function flipFn() {
        // self.stop = true
        // 移除元素点击事件
        self.aTreasureBox.forEach((item) => {
          item.removeEventListener('click', flipFn, false);
          item.classList.remove('animate-bounce-up');
          item.classList.remove('animation-running')
          item.classList.add('animation-paused');
        })
        this.classList.remove('animate-bounce-up')
        this.classList.remove('animation-paused');
        this.classList.add('animation-running')
        this.classList.add('animate-shake-up')
        // 请求营销命中接口
        if (self.hasPromoStatus !== 1) return false;
        const choiceSpan = document.querySelector(`#${this.id} span`);
        const resHit = await SuccReturnPromoHit({
          transactionNo: self.transactionNo,
          customerId: self.customerId,
          userIp: self.$DeviceInfo.ip,
          platform: self.platform,
          promoInfo: self.promoInfoServer,
          // webSite: 'h5',
          deviceInfo: this.$DeviceInfo
        })
        console.log('resHit', resHit)
        const responseStatus = resHit.status;
        if (responseStatus) {
          if (responseStatus === 504) {
            self.hasPromoStatus = 2;
            this.classList.remove('animate-shake-up');
            self.aTreasureBox.forEach((item) => {
              item.addEventListener('click', flipFn, false);
            });
          } else if ((responseStatus >= 200 && responseStatus < 300) || (responseStatus === 304)) {
            if (resHit.data.resultCode === 1) {
              choiceSpan.innerHTML = resHit.data.resultData.cashback
              self.arrPromotionAmount = resHit.data.resultData.randomCash
              this.classList.remove('animate-shake-up')
            } else {
              self.hasPromoStatus = 3;
              // this.classList.remove('animate-shake-up')
            }
            // 切换的顺序如下
            // 1. 当前在前显示的元素翻转90度隐藏, 动画时间225毫秒
            // 2. 结束后，之前显示在后面的元素逆向90度翻转显示在前
            // 3. 完成翻面效果
            funBackOrFront(this.id)
            self.eleFront.classList.add('out')
            self.eleFront.classList.add('hide')
            self.eleFront.classList.remove('in')
            setTimeout(() => {
              // 去掉运动
              self.aTreasureBox.forEach((item) => {
                item.classList.remove('animate-bounce-up')
              });
              // 选择非选择元素的box
              const treasureBoxNotSelect = document.querySelectorAll('.treasure-box:not(.selected)')
              // 非选择元素的span
              const treasureBoxNotSelectSpan = self.toArray(document.querySelectorAll('.treasure-box:not(.selected) span'))
              treasureBoxNotSelectSpan.forEach((item, index) => {
                const itemSpan = item
                itemSpan.innerHTML = self.arrPromotionAmount[index]
              })
              // 延迟多久 省下牌翻面
              setTimeout(() => {
                treasureBoxNotSelect.forEach((item) => {
                  const notSelectChild = self.toArray(item.children);
                  notSelectChild.forEach((item2) => {
                    if (item2.classList.contains('out')) {
                      item2.classList.add('in')
                      item2.classList.remove('out')
                      item2.classList.remove('hide')
                    } else {
                      item2.classList.add('out')
                      item2.classList.add('hide')
                      item2.classList.remove('in')
                    }
                  });
                });
              }, self.timeOfTurnOver);

              self.eleBack.classList.remove('hide')
              self.eleBack.classList.add('in')
              self.eleBack.classList.remove('out')
              // 重新确定正反元素
              funBackOrFront()
            }, 225);
          } else {
            self.hasPromoStatus = 3;
          }
        } else {
          if (resHit.toString().indexOf('timeout') !== -1 || resHit.toString().indexOf('504') !== -1) {
            self.hasPromoStatus = 2;
            this.classList.remove('animate-shake-up');
            self.aTreasureBox.forEach((item) => {
              item.addEventListener('click', flipFn, false);
            });
          } else {
            self.hasPromoStatus = 3;
          }
        }
        return false;
      }
      this.aTreasureBox.forEach((item) => {
        item.addEventListener('click', flipFn, false);
      });
    },
    getId(index) {
      return `box${index + 1}`
    },
    tryPromotion() {
      this.hasPromoStatus = 1;
      this.aTreasureBox.forEach((item) => {
        item.classList.remove('animation-paused');
        item.classList.add('animation-running');
      })
    },
    // 将伪数组转为真实数组
    toArray(obj) {
      return Array.prototype.slice.call(obj);
    }
  }
}
</script>
<style lang="scss">
@import "@/assets/css/var.scss";

* {
  -webkit-tap-highlight-color: transparent;
}
/* 3s的时间为运动总时长 */
.animate-bounce-up {
  -webkit-animation: bounce-up 0.6s linear infinite;
  animation: bounce-up 0.6s linear infinite;
}

.animate-shake-up {
  -webkit-animation: shake-up 0.3s linear infinite;
  animation: shake-up 0.3s linear infinite;
}

.succ-return-promo {
  width: 100%;
  box-sizing: border-box;
  padding: 0.24rem 0.4rem 1.24rem;
  margin-top: 0.2rem;
  background-color: #fff;

  h6 {
    font-size: 0.28rem;
    color: $color-gray-g;
    letter-spacing: 0;
    line-height: 0.3rem;
  }

  .promo-box {
    width: 100%;
    box-sizing: border-box;
    border-radius: 0.04rem;
    margin-top: 0.16rem;
    padding: 0.18rem 0.4rem 0.42rem;
    background: url('../../../assets/images/promotion/promo_bg@2x.png') no-repeat 0 0;
    background-size: 100% 100%;
    text-align: center;

    .promo-hit {
      margin-bottom: -0.42rem;
    }

    .promo-desc {
      color: #FFFFFF;
      letter-spacing: 0;

      h6 {
        font-family: The1Official_Bold;
        font-size: 0.48rem;
        line-height: 0.8rem;
        color: #FFFFFF;
      }

      p {
        font-size: 0.32rem;
        line-height: 0.5rem;

        span {
          color: #FFF200;
        }
      }
    }

    .promotion-tryAgain {
      margin-top: 0.74rem;
      margin-bottom: 0.42rem;
      h6 {
        font-family: The1Official_Bold;
        font-size: 0.4rem;
        line-height: .66rem;
        color: #FFFFFF;
        letter-spacing: 0;
        text-align: center;
      }
      p {
        width: 100%;
        margin-top: 0.24rem;
        margin-bottom: 0.5rem;
        text-align: center;
        span {
          width: 2.4rem;
          height: 0.72rem;;
          display: inline-block;
          font-size: 0.32rem;
          font-family: The1Official_Bold;
          color: #8B572A;
          line-height: 0.72rem;
          background: url('../../../assets/images/promotion/Group2@2x.png') no-repeat 0 0;
          background-size: 100% 100%;
        }
      }
    }

    .noQualified-promotion {
      width: 100%;
      box-sizing: border-box;
      margin: 0.52rem 0 0.38rem;

      h6 {
        font-family: The1Official_Bold;
        font-size: 0.4rem;
        line-height: 0.66rem;
        color: #FFFFFF;
        letter-spacing: 0;
        text-align: center;
      }
    }
  }

  .treasure {
    width: 100%;
    margin-top: 0.22rem;
    display: flex;

    .treasure-box {
      position: relative;
      flex: 1;
      .hide {
        display: none;
      }
      a {
        display: inline-block;
        position: relative;
      }

      span {
        position: absolute;
        left: 50%;
        top: 39%;
        transform: translate(-50%, -50%);
        font-family: The1Official_Bold;
        font-size: 0.6rem;
        color: #7F91A5;
        letter-spacing: 0;
      }
      img:not(.coloured-ribbon) {
        max-width: 100%;
      }

      .yellow_card, .coloured-ribbon {
        display: none;
      }
    }

    .treasure-box.selected {
      span {
        color: #FD8100;
      }
      .gray_card {
        display: none;
      }

      .yellow_card, .coloured-ribbon {
        display: block;
      }
      .coloured-ribbon {
        position: absolute;
        z-index: 100;
        left: 50%;
        top: 39%;
        transform: translate(-50%, -50%) scale(0.5);
      }
    }
  }

  /* turn.css */
  .in {
    -webkit-animation-timing-function: ease-out;
    -webkit-animation-duration: 350ms;
    animation-timing-function: ease-out;
    animation-duration: 350ms;
  }

  .out {
    -webkit-animation-timing-function: ease-in;
    -webkit-animation-duration: 225ms;
    animation-timing-function: ease-in;
    animation-duration: 225ms;
  }

  .fade.out {
    opacity: 0;
    -webkit-animation-duration: 125ms;
    -webkit-animation-name: fadeout;
    animation-duration: 125ms;
    animation-name: fadeout;
  }

  .fade.in {
    opacity: 1;
    -webkit-animation-duration: 225ms;
    -webkit-animation-name: fadein;
    animation-duration: 225ms;
    animation-name: fadein;
  }


  .viewport-flip {
    -webkit-perspective: 1000;
    perspective: 1000;
    position: absolute;
  }

  .flip {
    -webkit-backface-visibility: hidden;
    -webkit-transform: translateX(0);
    /* Needed to work around an iOS 3.1 bug that causes listview thumbs to disappear when -webkit-visibility:hidden is used. */
    backface-visibility: hidden;
    transform: translateX(0);
  }

  .flip.out {
    -webkit-transform: rotateY(-90deg) scale(.9);
    -webkit-animation-name: flipouttoleft;
    -webkit-animation-duration: 175ms;
    transform: rotateY(-90deg) scale(.9);
    animation-name: flipouttoleft;
    animation-duration: 175ms;
  }

  .flip.in {
    -webkit-animation-name: flipintoright;
    -webkit-animation-duration: 225ms;
    animation-name: flipintoright;
    animation-duration: 225ms;
  }

  .flip.out.reverse {
    -webkit-transform: rotateY(90deg) scale(.9);
    -webkit-animation-name: flipouttoright;
    transform: rotateY(90deg) scale(.9);
    animation-name: flipouttoright;
  }

  .flip.in.reverse {
    -webkit-animation-name: flipintoleft;
    animation-name: flipintoleft;
  }

  // 暂停动画
  .animation-paused {
    animation-play-state: paused;
    -webkit-animation-play-state: paused;
  }
  // 动画开始
  .animation-running {
    animation-play-state: running;
    -webkit-animation-play-state: running;
  }
}

/* 宝箱抽奖的运动动画——上下左右 */
@keyframes bounce-up {
  50% {
    -webkit-transform: translateY(-0.1rem);
  }
  0%,100%
   {
     -webkit-transform: translateY(0rem);
  }
}
/* 宝箱左右颤抖动画 */
@keyframes shake-up {
  50% {
    transform:  rotateZ(6deg);
  }
  0%,100%
   {
    -webkit-transform:  rotateZ(-6deg);
  }
}
/* 宝箱翻面动画 */
@-webkit-keyframes fadein {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes fadein {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes fadeout {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

@keyframes flipouttoleft {
  from {
    transform: rotateY(0);
  }
  to {
    transform: rotateY(-90deg) scale(.9);
  }
}

@keyframes flipouttoright {
  from {
    transform: rotateY(0);
  }
  to {
    transform: rotateY(90deg) scale(.9);
  }
}

@keyframes flipintoleft {
  from {
    transform: rotateY(-90deg) scale(.9);
  }
  to {
    transform: rotateY(0);
  }
}

@keyframes flipintoright {
  from {
    transform: rotateY(90deg) scale(.9);
  }
  to {
    transform: rotateY(0);
  }
}
</style>
