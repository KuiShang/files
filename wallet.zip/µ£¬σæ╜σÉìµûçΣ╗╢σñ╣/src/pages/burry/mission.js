import Vue from 'vue'

// mission进入
export function MISSION_ENTER(pageName) {
  Vue.$SDK.buriedPointEntry({
    pageName
  })
}

// mission离开
export function MISSION_LEAVE(pageName) {
  Vue.$SDK.buriedPointLeave({
    pageName
  })
}

// mission点击按钮
export function MISSION_CLICK(pageName, eventId) {
  Vue.$SDK.buriedPoint({
    pageName,
    eventId
  })
}
