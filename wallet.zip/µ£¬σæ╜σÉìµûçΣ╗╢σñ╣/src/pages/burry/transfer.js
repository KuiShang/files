     
import Vue from 'vue'

// 转账选择页面  转账到余额
export function TRANSFER_MAINPAGE_TOONEFIN() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_MAINPAGE',
    eventId: 'TOONEFIN'
  })
}

// 转账选择页面 转账到promptpay账户
export function TRANSFER_MAINPAGE_TOPROMPTPAY() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_MAINPAGE',
    eventId: 'TOPROMPTPAY'
  })
}
// 转账选择页面 转账到银行账户
export function TRANSFER_MAINPAGE_TOBANKACCOUNT() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_MAINPAGE',
    eventId: 'TOBANKACCOUNT'
  })
}
// 转账选择页面 近期记录
export function TRANSFER_MAINPAGE_RECENTHISTORY(msg) {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_MAINPAGE',
    eventId: 'RECENTHISTORY',
    map: msg || {}
  })
}
// 转账到OneFin页面 转账按钮
export function TRANSFER_TOONEFIN_TRANSFER(msg, amount) {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOONEFIN',
    eventId: 'TRANSFER',
    map: msg || {}
  })

  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_4_transfer_dolfin_confirm',
        map: {
          revenueAamount: amount
        }
      },
      {
        channelType: 2,
        eventId: 'af_4_transfer_dolfin_confirm',
        map: {
          revenueAamount: amount
        }
      }
    ]
  )

}
// 转账到OneFin页面 通讯录按钮
export function TRANSFER_TOONEFIN_CONTACT() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOONEFIN',
    eventId: 'CONTACT'
  })
}
// 转账到PromptPay页面 通讯录按钮
export function TRANSFER_TOPROMPTPAY_CONTACT() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY',
    eventId: 'CONTACT'
  })
}
// 转账到PromptPay页面 Review Detail按钮
export function TRANSFER_TOPROMPTPAY_REVIEW_DETAIL() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY',
    eventId: 'REVIEW_DETAIL'
  })
}
// 转账到PromptPay确认页面 转账按钮
export function Transfer_ToPromptPay_ReviewDetail_TRANSFER(msg) {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY_REVIEWDETAIL',
    eventId: 'TRANSFER',
    map: msg || {}
  })
}
// 转账到银行账户 银行选择
export function Transfer_ToBankAccount_BANKTYPE() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT',
    eventId: 'BANKTYPE'
  })
}
// 转账到银行账户 输入账户 
export function Transfer_ToBankAccount_BANKACCOUNT() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT',
    eventId: 'BANKACCOUNT'
  })
}
// 转账到银行账户 相关账户 
export function Transfer_ToBankAccount_RELATEDBANKACCOUNT() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT',
    eventId: 'RELATEDBANKACCOUNT'
  })
}
// 转账到银行账户 转账按钮
export function Transfer_ToBankAccount_TRANSFER(msg, amount) {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT',
    eventId: 'TRANSFER',
    map: msg || {}
  }),

  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_4_transfer_bankacc_confirm',
        map: {
          revenueAamount: amount
        }
      },
      {
        channelType: 2,
        eventId: 'af_4_transfer_bankacc_confirm',
        map: {
          revenueAamount: amount
        }
      }
    ]
  )
}
// 收款码转账 确认按钮p2p
export function Transfer_ToCollect_CONFIRM(msg, amount, type) {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOCOLLECT',
    eventId: 'CONFIRM',
    map: msg || {}
  })

  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_4_scanpay_confirm',
        map: {
          revenueAamount: amount,
          codeType: type
        }
      },
      {
        channelType: 2,
        eventId: 'af_4_scanpay_confirm',
        map: {
          revenueAamount: amount,
          codeType: type
        }
      }
    ]
  )
}
// 转账到BankAccount成功页面 确认按钮 
export function Transfer_ToBankAccount_SuccessfulPage_DONE() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT_SUCCESSFULPAGE',
    eventId: 'DONE'
  })
}
// 转账到BankAccount失败页 重试按钮 
export function Transfer_ToBankAccount_FailedPage_TRYAGAIN() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT_FAILEDPAGE',
    eventId: 'TRYAGAIN'
  })
}

// 转账到OneFin成功页面 确认按钮 
export function TRANSFER_TOONEFIN_SUCCESSFULPAGE_DONE() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOONEFIN_SUCCESSFULPAGE',
    eventId: 'DONE'
  })
}
// 转账到OneFin失败页 重试按钮 
export function TRANSFER_TOONEFIN_FAILEDPAGE_TRYAGAIN() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOONEFIN_FAILEDPAGE',
    eventId: 'TRYAGAIN'
  })
}

// 转账到promptPay成功页 确认按钮 
export function Transfer_ToPromptPay_ReviewDetail_DONE() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY_SUCCESSFULPAGE',
    eventId: 'DONE'
  })
}
// 转账到promptPay失败页 重试按钮 
export function Transfer_ToPromptPay_ReviewDetail_TRYAGAIN() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY_FAILEDPAGE',
    eventId: 'TRYAGAIN'
  })
}
// 进入转账到PromptPay成功页面
export function Transfer_ToPromptpay_SuccessfulPage_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOPROMPTPAY_SUCCESSFULPAGE'
  })
}

// 离开转账到PromptPay成功页面
export function Transfer_ToPromptpay_SuccessfulPage_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOPROMPTPAY_SUCCESSFULPAGE'
  })
}

// 进入转账到PromptPay失败页
export function Transfer_ToPromptPay_FailedPage_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOPROMPTPAY_FAILEDPAGE'
  })
}
// 离开转账到PromptPay失败页
export function Transfer_ToPromptPay_FailedPage_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOPROMPTPAY_FAILEDPAGE'
  })
}

// 进入转账到OneFin成功页面
export function TRANSFER_TOONEFIN_SUCCESSFULPAGE_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOONEFIN_SUCCESSFULPAGE'
  })
}
// 离开转账到OneFin成功页面
export function TRANSFER_TOONEFIN_SUCCESSFULPAGE_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOONEFIN_SUCCESSFULPAGE'
  })
}

// 进入转账到OneFin失败页
export function TRANSFER_TOONEFIN_FAILEDPAGE_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOONEFIN_FAILEDPAGE'
  })
}
// 离开转账到OneFin失败页
export function TRANSFER_TOONEFIN_FAILEDPAGE_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOONEFIN_FAILEDPAGE'
  })
}

// 进入转账到BankAccount成功页面
export function Transfer_ToBankAccount_SuccessfulPage_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT_SUCCESSFULPAGE'
  })
}
// 离开转账到BankAccount成功页面
export function Transfer_ToBankAccount_SuccessfulPage_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT_SUCCESSFULPAGE'
  })
}

// 进入转账到BankAccount失败页
export function Transfer_ToBankAccount_FailedPage_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT_FAILEDPAGE'
  })
}
// 离开转账到BankAccount失败页
export function Transfer_ToBankAccount_FailedPage_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT_FAILEDPAGE'
  })
}

// 进入转账页面
export function TRANSFER_MAINPAGE_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_MAINPAGE',
  })
}
// 离开转账页
export function TRANSFER_MAINPAGE_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_MAINPAGE',
  })
}
// 进入转账到OneFin页面
export function TRANSFER_TOONEFIN_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOONEFIN',
  })
}
// 离开转账到OneFin页面
export function TRANSFER_TOONEFIN_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOONEFIN'
  })
}
// 进入转账到PromptPay页面
export function TRANSFER_TOPROMPTPAY_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOPROMPTPAY'
  })
}
// 离开转账到PromptPay页面
export function TRANSFER_TOPROMPTPAY_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOPROMPTPAY'
  })
}
// 进入转账到PromptPay确认页面
export function Transfer_ToPromptPay_ReviewDetail_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOPROMPTPAY_REVIEWDETAIL'
  })
}
// 离开转账到PromptPay确认页面
export function Transfer_ToPromptPay_ReviewDetail_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOPROMPTPAY_REVIEWDETAIL'
  })
}
// 进入转账到银行账户
export function Transfer_ToBankAccount_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT'
  })
}
// 离开转账到银行账户
export function Transfer_ToBankAccount_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT'
  })
}
// 进入收款码转账
export function Transfer_ToCollect_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOCOLLECT'
  })
}
// 离开收款码转账
export function Transfer_ToCollect_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOCOLLECT'
  })
}

// 进入银行相关账户
export function Transfer_TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT'
  })
}

// 离开银行相关账户
export function Transfer_TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT'
  })
}

// 进入选择银行页
export function Transfer_TRANSFER_TOBANKACCOUNT_BANKTYPE_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT_BANKTYPE'
  })
}

// 离开选择银行页
export function Transfer_TRANSFER_TOBANKACCOUNT_BANKTYPE_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT_BANKTYPE'
  })
}

// 进入转账到余额处理中
export function Transfer_TRANSFER_TOONEFIN_INPROCESS_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOONEFIN_INPROCESS'
  })
}

// 离开转账到余额处理中
export function Transfer_TRANSFER_TOONEFIN_INPROCESS_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOONEFIN_INPROCESS'
  })
}


// 进入转账到银行账户处理中
export function Transfer_TRANSFER_TOBANKACCOUNT_INPROCESS_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOBANKACCOUNT_INPROCESS'
  })
}

// 离开转账到银行账户处理中
export function Transfer_TRANSFER_TOBANKACCOUNT_INPROCESS_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOBANKACCOUNT_INPROCESS'
  })
}

// 进入转账到promptpay处理中
export function Transfer_TRANSFER_TOPROMPTPAY_INPROCESS_ENTRY() {
  Vue.$SDK.buriedPointEntry({
    pageName: 'TRANSFER_TOPROMPTPAY_INPROCESS'
  })
}

// 离开转账到promptpay处理中
export function Transfer_TRANSFER_TOPROMPTPAY_INPROCESS_LEAVE() {
  Vue.$SDK.buriedPointLeave({
    pageName: 'TRANSFER_TOPROMPTPAY_INPROCESS'
  })
}

// 转账到余额处理中 确认按钮
export function TRANSFER_TOONEFIN_INPROCESS() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOONEFIN_INPROCESS',
    eventId: 'DONE'
  })
}

// 转账到银行账户处理中  确认按钮
export function TRANSFER_TOBANKACCOUNT_INPROCESS() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOBANKACCOUNT_INPROCESS',
    eventId: 'DONE'
  })
}

// 转账到promptpay处理中  确认按钮
export function TRANSFER_TOPROMPTPAY_INPROCESS() {
  Vue.$SDK.buriedPoint({
    pageName: 'TRANSFER_TOPROMPTPAY_INPROCESS',
    eventId: 'DONE'
  })
}

// 转账成功结构页 af & firebase 上报
export function TRANSFER_PAYMENT_SUCCESS(params) {
  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_4_transfer_payment_success',
        map: {
          revenueAamount: params.amount,
          businessType: params.businessType,
          paymentMethod1: params.paymentMethod1,
          paymentMethod2: params.paymentMethod2
        }
      }
    ]
  )
}


// 绑账户成功成功结构页 af & firebase 上报
export function BIND_ACCOUNT_SUCCESS() {
  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_2_link_bankacc_success',
        map: {
        }
      },
      {
        channelType: 2,
        eventId: 'af_2_link_bankacc_success',
        map: {
        }
      }
    ]
  )
}

// 绑ka成功成功结构页 af & firebase 上报
export function BIND_CARD_SUCCESS() {
  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_2_link_credeb_success',
        map: {
        }
      },
      {
        channelType: 2,
        eventId: 'af_2_link_credeb_success',
        map: {
        }
      }
    ]
  )
}

// lnwang 
export function TRY_AGAIN(type) {
  if (type === '1') {
    // lnwang 添加新银行acoount失败，用户查看“添加银行帐户失败”页面
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKBANKACCOUNT_FAIL'
    })
  } else if (type === '2') {
    // lnwang 用户未能添加该卡
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_FAIL'
    })
  }
}
export function DONE() {
  // lnwang 完成
  Vue.$SDK.buriedPointCore({
    pageName: 'LINKBANKACCOUNT_SUCCESS'
  })
}

// lnwang  连接信用卡/借记卡
export function CCV_INFO_ICON(type) {
  if (type === '1') {
    // lnwang 用户单击ccv信息图标
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_ADDCARD'
    })
  } else if (type === '2') {
    // lnwang 用户单击ccv信息图标
    Vue.$SDK.buriedPointCore({
      pageName: 'CREDIT_CARD_ONLINE'
    })
  }
}
export function ADD_CARD() {
  // lnwang 用户单击Add Card按钮
  Vue.$SDK.buriedPointCore({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}
// lnwang 
export function ERROR(type) {
  if (type === '1') {
    // lnwang 当用户单击Add Card按钮时发生错误
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_ADDCARD'
    })
  } else if (type === '2') {
    // lnwang 卡中心绑卡PAY发生错误
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_ADDCARDANDPAY'
    })
  }
}

export function BACK(type) {
  if (type === '1') {
    // lnwang 添加卡成功后用户单击后退按钮
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKBANKACCOUNT_SUCCESS'
    })
  } else if (type === '2') {
    // lnwang 添加卡失败后用户单击后退按钮
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKBANKACCOUNT_FAIL'
    })
  } else if (type === '3') {
    // lnwang 查看页面“添加信用卡/借记卡”后退按钮
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_ADDCARD'
    })
  } else if (type === '4') {
    // lnwang 用户未能添加该卡后退按钮
    Vue.$SDK.buriedPointCore({
      pageName: 'LINKCARD_FAIL'
    })
  } else if (type === '5') {
    // lnwang 创建“添加信用卡/借记卡”后退按钮
    Vue.$SDK.buriedPointCore({
      pageName: 'CREDIT_CARD_ONLINE'
    })
  }
}
// lnwang 卡中心绑卡
export function SAVE_CARD() {
  Vue.$SDK.buriedPointCore({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}
// lnwang 卡中心绑卡PAY
export function PAY() {
  Vue.$SDK.buriedPointCore({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}


