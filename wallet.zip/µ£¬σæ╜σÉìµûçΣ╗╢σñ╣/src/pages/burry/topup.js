import Vue from 'vue'

function log(str) {
  if (true) {
    console.log('----------------------埋点   **topup** start-----------------------')
    console.log(str)
    console.log('-----------------------------埋点end   **topup**   end-------------')
  }
}


// 充值 充值确认按钮
export function TOPUP_TOPUP(amount) {
  log('充值 充值确认按钮')
  Vue.$SDK.buriedPoint({
    eventId: 'TOPUP',
    map: {
      page: 'TOP_UP',
    }
  })
  Vue.$SDK.buriedPointCore(
    [{
        channelType: 1,
        eventId: 'fire_3_topup_confirm',
        map: {
          revenueAamount: amount
        }
      },
      {
        channelType: 2,
        eventId: 'af_3_topup_confirm',
        map: {
          revenueAamount: amount
        }
      }
    ]
  )
}

// 充值 充值成功确认按钮
export function TOP_UP_SUCCESSFUL_PAGE_DONE() {
  log('充值 充值成功确认按钮')
  Vue.$SDK.buriedPoint({
    eventId: 'DONE',
    map: {
      page: 'TOP_UP_SUCCESSFUL_PAGE',
    }
  })
}

// 充值失败重试按钮
export function TOP_UP_FAILED_PAGE_TRYAGAIN() {
  log('充值失败重试按钮')
  Vue.$SDK.buriedPoint({
    eventId: 'TRYAGAIN',
    map: {
      page: 'TOP_UP_FAILED_PAGE',
    }
  })
}


// 充值页面进入
export function TOP_UP_ENTER() {
  log('充值页面进入')
  Vue.$SDK.buriedPointEntry({
    pageName: 'TOP_UP'
  })
}

// 充值页面离开
export function TOP_UP_LEAVE() {
  log('充值页面离开')
  Vue.$SDK.buriedPointLeave({
    pageName: 'TOP_UP'
  })
}

// 充值结果页面进入
export function TOP_UP_SUCCESSFUL_PAGE_ENTER() {
  log(' 充值结果页面进入')
  Vue.$SDK.buriedPointEntry({
    pageName: 'TOP_UP_SUCCESSFUL_PAGE'
  })
}

// 充值结果页面离开
export function TOP_UP_SUCCESSFUL_PAGE_LEAVE() {
  log('充值结果页面离开')
  Vue.$SDK.buriedPointLeave({
    pageName: 'TOP_UP_SUCCESSFUL_PAGE'
  })
}

// 充值结果shibai页面进入
export function TOP_UP_FAILED_PAGE_ENTER() {
  log('充值结果shibai页面进入')
  Vue.$SDK.buriedPointEntry({
    pageName: 'TOP_UP_FAILED_PAGE'
  })
}

// 充值结果shibai页面离开
export function TOP_UP_FAILED_PAGE_LEAVE() {
  log('充值结果shibai页面离开')
  Vue.$SDK.buriedPointLeave({
    pageName: 'TOP_UP_FAILED_PAGE'
  })
}
