import Vue from 'vue'

function log (str) {
    if (true) {
      console.log('------------------------------埋点 **transdetail**  start-----------------------')
      console.log(str)
      console.log('-----------------------------埋点  **transdetail**    end------------------------')
    }
  }
  
  // 页面 详情页进入
  export function TRANSACTION_DETAIL_ENTER() {
    log('页面 详情页进入')
    Vue.$SDK.buriedPointEntry({
      pageName: 'TRANSACTION_DETAIL'
    })
  }

// 页面 详情页离开
export function TRANSACTION_DETAIL_LEAVE() {
    log('页面 详情页离开')
    Vue.$SDK.buriedPointLeave({
        pageName: 'TRANSACTION_DETAIL'
    })
    }
