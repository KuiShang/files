import Vue from 'vue'
import { enumPayMethodCodeSecond, enumPayMethodCodeFirst } from '@/utils/const'
import { ALL_BUSI_TYPE } from '@/utils/const'

function log (str) {
  if (true) {
    console.log('------------------------------埋点 **cashier**  start-----------------------')
    console.log(str)
    console.log('-----------------------------埋点  **cashier**    end------------------------')
  }
}

// 付款详情页 返回
export function PAY_DETAIL_COUNTER_BACK() {
  log('点击：付款详情页 返回')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_DETAIL_COUNTER',
    eventId: 'BACK',
    map: {
      page: 'PAY_DETAIL_COUNTER'
    }
  })
}

// 付款详情页 关闭
export function PAY_DETAIL_COUNTER_CLOSE() {
  log('点击：付款详情页 点击关闭')
  Vue.$SDK.buriedPoint({
    eventId: 'CLOSE',
    map: {
      page: 'PAY_DETAIL_COUNTER'
    }
  })
}

// 付款详情页 选择支付方式
export function PAY_DETAIL_COUNTER_PAY_METHOD() {
  log('点击：付款详情页 选择支付方式')
  Vue.$SDK.buriedPoint({
    eventId: 'PAY_METHOD',
    map: {
      page: 'PAY_DETAIL_COUNTER'
    }
  })
}

// 付款详情页 确认
export function PAY_DETAIL_COUNTER_CONFIRM(Obj) {
  log('点击：付款详情页 确认')
  Vue.$SDK.buriedPoint({
    eventId: 'CONFIRM',
    map: {
      page: 'PAY_DETAIL_COUNTER'
    }
  })
  if (Obj.type === ALL_BUSI_TYPE.SCANDED) {

    Vue.$SDK.buriedPointCore(
      [{
          channelType: 1,
          eventId: 'fire_4_qrpay_confirm',
          map: {
            revenueAamount: Obj.amount,
            paymentMethod: Obj.paymentMethod,
            paymentMethod2: Obj.paymentMethod2
          }
        },
        {
          channelType: 2,
          eventId: 'af_4_qrpay_confirm',
          map: {
            revenueAamount: Obj.amount,
            paymentMethod: Obj.paymentMethod,
            paymentMethod2: Obj.paymentMethod2
          }
        }
      ]
    )
  }
}

// 动态成功页 返回
export function SUCCESS_COUNTER_BACK() {
  log('点击：动态成功页 返回')
  Vue.$SDK.buriedPoint({
    eventId: 'BACK',
    map: {
      page: 'SUCCESS_COUNTER'
    }
  })
}

// 动态成功页 关闭
export function SUCCESS_COUNTER_CLOSE() {
  log('点击：动态成功页 关闭')
  Vue.$SDK.buriedPoint({
    eventId: 'CLOSE',
    map: {
      page: 'SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 返回
export function PAY_SUCCESS_COUNTER_BACK() {
  log('点击：选择支付方式列表页 返回')
  Vue.$SDK.buriedPoint({
    eventId: 'BACK',
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
  PAY_SUCCESS_COUNTER_LEAVE()
  PAY_DETAIL_COUNTER_ENTRY()
}

// 选择支付方式列表页 余额
export function PAY_SUCCESS_COUNTER_BALANCE(n = 1) {
  log(`点击：选择支付方式列表页 第${n}张余额`)
  Vue.$SDK.buriedPoint({
    eventId: `BALANCE_${n}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 ODD_第${n}张卡
export function PAY_SUCCESS_COUNTER_ODD_N(n = 1) {
  log(`点击：选择支付方式列表页 ODD_第${n}张卡`)
  Vue.$SDK.buriedPoint({
    eventId: `ODD_${n}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 信用卡支付_第${n}张卡
export function PAY_SUCCESS_COUNTER_CREDIT_CARD_N(n = 1) {
  log(`点击：选择支付方式列表页 信用卡支付_第${n}张卡`)
  Vue.$SDK.buriedPoint({
    eventId: `CREDIT_CARD_${n}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 跳转银行APP支付
export function PAY_SUCCESS_COUNTER_DEEPLINK(n = 1) {
  log(`点击：选择支付方式列表页 信用卡支付_第${n}张卡`)
  Vue.$SDK.buriedPoint({
    eventId: `DEEPLINK_${n}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 cenpay支付
export function PAY_SUCCESS_COUNTER_CENPAY(idx = 1) {
  log(`点击：选择支付方式列表页 cenpay支付第${idx}`)
  Vue.$SDK.buriedPoint({
    eventId: `CENPAY_${idx}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 选择支付方式列表页 信用卡支付
export function PAY_SUCCESS_COUNTER_CREDIT_ONLINE(idx = 1) {
  log(`点击：选择支付方式列表页 第${idx}信用卡支付 SPECIAL`)
  Vue.$SDK.buriedPoint({
    eventId: `CREDIT_ONLINE_${idx}`,
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
  PAY_SUCCESS_COUNTER_LEAVE()
}

// 选择支付方式列表页 绑卡
export function PAY_SUCCESS_COUNTER_ADD_CARD_ACCOUNT () {
  log('点击：选择支付方式列表页 绑卡')
  Vue.$SDK.buriedPoint({
    eventId: 'ADD_CARD_ACCOUNT',
    map: {
      page: 'PAY_SUCCESS_COUNTER'
    }
  })
}

// 网络连接失败页 返回
export function NETWORK_ERROR_COUNTER_BACK() {
  log('点击：网络连接失败页 返回')
  Vue.$SDK.buriedPoint({
    eventId: 'BACK',
    map: {
    page: 'NETWORK_ERROR_COUNTER'
    }
  })
}

// 网络连接失败页 关闭
export function NETWORK_ERROR_COUNTER_CLOSE() {
  log('点击：网络连接失败页 关闭')
  Vue.$SDK.buriedPoint({
    eventId: 'CLOSE',
    map: {
      page: 'NETWORK_ERROR_COUNTER'
    }
  })
}

// 支付失败页 返回
export function PAYMENT_FAILED_BACK() {
  log('点击：支付失败页 返回')
  Vue.$SDK.buriedPoint({
    eventId: 'BACK',
    map: {
      page: 'PAYMENT_FAILED'
    }
  })
}

// 支付失败页 关闭
export function PAYMENT_FAILED_CLOSE() {
  log('点击：支付失败页 关闭')
  Vue.$SDK.buriedPoint({
    eventId: 'CLOSE',
    map: {
      page: 'PAYMENT_FAILED'
    }
  })
}

// 信用卡信息录入页面 返回
export function CREDIT_CARD_ONLINE_BACK() {
  log('点击：信用卡信息录入页面 返回')
  Vue.$SDK.buriedPoint({
    eventId: 'BACK',
    map: {
      page: 'CREDIT_CARD_ONLINE'
    }
  })
}

// 信用卡信息录入页面 保存卡信息
export function CREDIT_CARD_ONLINE_SAVE_CARD() {
  log('点击：信用卡信息录入页面 保存卡信息')
  Vue.$SDK.buriedPoint({
    eventId: 'SAVE_CARD',
    map: {
      page: 'CREDIT_CARD_ONLINE'
    }
  })
}

// 信用卡信息录入页面 支付
export function CREDIT_CARD_ONLINE_PAY() {
  log('点击：信用卡信息录入页面 支付')
  Vue.$SDK.buriedPoint({
    eventId: 'PAY',
    map: {
      page: 'CREDIT_CARD_ONLINE'
    }
  })
}

// 付款详情页 报错
export function PAY_DETAIL_COUNTER_ERROR(error) {
  log('点击：付款详情页 报错')
  Vue.$SDK.buriedPoint({
    eventId: 'ERROR',
    map: {
      error,
      page: 'PAY_DETAIL_COUNTER'
    }
  })
}

// 信用卡信息录入页面 报错
export function CREDIT_CARD_ONLINE_ERROR(error) {
  log('点击：信用卡信息录入页面 报错')
  Vue.$SDK.buriedPoint({
    eventId: 'ERROR',
    map: {
      error,
      page: 'CREDIT_CARD_ONLINE'
    }
  })
}

// 支付列表点击事件 (不包括跳转到卡支付页面的事件)
export function changeBank(method, idx) {
  if (method.payMethodCodeSecond === enumPayMethodCodeSecond.CENPAY) {
    PAY_SUCCESS_COUNTER_CENPAY(idx + 1)
  } else if (method.payMethodCodeSecond === enumPayMethodCodeSecond.SPECIAL) {
    // PAY_SUCCESS_COUNTER_CREDIT_ONLINE(idx + 1)
    // 新卡支付由 收银台直接调用上述方法，不适合再次统一处理  因为 新卡支付会跳转到绑卡页面 不会再次回到半屏收银台 
  } else if (method.payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
    PAY_SUCCESS_COUNTER_CREDIT_CARD_N(idx + 1)
  } else if (method.payMethodCodeFirst === enumPayMethodCodeFirst.ODD) {
    PAY_SUCCESS_COUNTER_ODD_N(idx + 1)
  } else if (method.payMethodCodeFirst === enumPayMethodCodeFirst.DEEPLINK) {
    PAY_SUCCESS_COUNTER_DEEPLINK(idx + 1)
  } else if (method.payMethodCodeFirst === enumPayMethodCodeFirst.BALA) {
    PAY_SUCCESS_COUNTER_BALANCE(idx + 1)
  }
  PAY_SUCCESS_COUNTER_LEAVE()
  PAY_DETAIL_COUNTER_ENTRY()
}

// 收银台报错
export function cashierError(callFrom, errorCode) {
  if (callFrom === 'simpleCashier') {
    PAY_DETAIL_COUNTER_ERROR(errorCode)
  } else {
    CREDIT_CARD_ONLINE_ERROR(errorCode)
  }
}

// 页面 收银台进入事件
export function PAY_DETAIL_COUNTER_ENTRY() {
  log('页面: 收银台进入事件')
  Vue.$SDK.buriedPointEntry({
    pageName: 'PAY_DETAIL_COUNTER'
  })
}

// 页面 收银台离开事件
export function PAY_DETAIL_COUNTER_LEAVE() {
  log('页面：PAY_DETAIL_COUNTER 收银台离开')
  Vue.$SDK.buriedPointLeave({
    pageName: 'PAY_DETAIL_COUNTER'
  })
}

// 页面 收银台列表进入事件
export function PAY_SUCCESS_COUNTER_ENTRY() {
  log('页面: 收银台列表进入事件')
  Vue.$SDK.buriedPointEntry({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}

// 页面 收银台列表离开事件
export function PAY_SUCCESS_COUNTER_LEAVE() {
  log('页面: 收银台列表离开事件')
  Vue.$SDK.buriedPointLeave({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}

// 页面 收银台卡支付进入事件
export function CREDIT_CARD_ONLINE_ENTRY() {
  log('页面: 收银台卡支付进入事件')
  Vue.$SDK.buriedPointEntry({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}

// 页面 收银台卡支付离开事件
export function CREDIT_CARD_ONLINE_LEAVE() {
  log('页面: 收银台卡支付离开事件')
  Vue.$SDK.buriedPointLeave({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}

// 页面 收银台卡支付离开事件
// export function CREDIT_CARD_ONLINE_BACK() {
//   log('点击: 收银台卡支付离开事件') 
//   Vue.$SDK.buriedPointLeave({
//     eventId: 'BACK',
//     map: {
//       page: 'CREDIT_CARD_ONLINE'
//     }
//   })
// }

// 页面 收银台 tanchuang 离开 click 事件
// 当前页面 true  支付列表页面，  false: 支付页面
// showLoading 是否是 loading页面
export function COUNTER_QUIT_YES(flag, showLoading) {
  log('埋点：收银台 tanchuang 离开 click 事件YES')
  Vue.$SDK.buriedPoint({
    eventId: 'YES',
    map: {
      page: 'COUNTER_QUIT'
    }
  })
  if (flag) {
    PAY_SUCCESS_COUNTER_LEAVE()
  } else if(showLoading) {
    // SUCCESS_COUNTER_LEAVE()  发现 一旦进入loading 即使 在success之前click关闭按钮，动画也会完成 也会报完成事件，所以这个事件不用在这里报，
  } else {
    PAY_DETAIL_COUNTER_LEAVE()
  }
}

// 页面 收银台 tanchuang 离开 cancle 事件
export function COUNTER_QUIT_NO() {
  log('页面:  收银台 tanchuang 离开 click 事件NO')
  Vue.$SDK.buriedPoint({
    eventId: 'NO',
    map: {
      page: 'COUNTER_QUIT'
    }
  })
}

// 页面 收银台 动态成功 进入
export function SUCCESS_COUNTER_ENTER() {
  log('页面:   收银台 动态成功 进入')
  Vue.$SDK.buriedPointEntry({
    pageName: 'SUCCESS_COUNTER'
  })
}

// 页面 收银台 tanchuang 离开 cancle 事件
export function SUCCESS_COUNTER_LEAVE() {
  log('页面:   收银台 动态成功 离开')
  Vue.$SDK.buriedPointLeave({
    pageName: 'SUCCESS_COUNTER'
  })
}

// 转账成功结构页 af & firebase 上报
export function QRPay_Success(params) {
  const arrData =  [
    {
      channelType: 1,
      eventId: 'fire_4_qrpay_success',
      map: {
        revenueAamount: params.revenueAamount,
        businessType: params.businessType,
        paymentMethod1: params.paymentMethod1,
        paymentMethod2: params.paymentMethod2
      }
    },
    {
      channelType: 2,
      eventId: 'af_4_qrpay_success',
      map: {
        revenueAamount: params.revenueAamount,
        businessType: params.businessType,
        paymentMethod1: params.paymentMethod1,
        paymentMethod2: params.paymentMethod2
      }
    }
  ]
log(arrData)

  Vue.$SDK.buriedPointCore(arrData)
}


export function BACK(type) {
  // lnwang  收银台 back
  if (type === 1) {
    log('页面:   收银台 back 离开')
    Vue.$SDK.buriedPoint({
      pageName: 'PAY_DETAIL_COUNTER'
    })
  } else if (type === 2) {
    // lnwang  收银台成功支付
    log('页面:   收银台成功支付   ')
    Vue.$SDK.buriedPoint({
      pageName: 'SUCCESS_COUNTER'
    })
  } else if (type === 3) {
    // lnwang  收银台选择支付方式back
    log('页面:   收银台选择支付方式back   ')
    Vue.$SDK.buriedPoint({
      pageName: 'PAY_SUCCESS_COUNTER'
    })
  } else if (type === 4) {
    // lnwang  收银台选择支付方式后请求错误
    log('页面:   收银台选择支付方式后请求错误   ')
    Vue.$SDK.buriedPoint({
      pageName: 'NETWORK_ERROR_COUNTER'
    })
  } else if (type === 5) {
    // lnwang  支付失败
    log('页面:   支付失败   ')
    Vue.$SDK.buriedPoint({
      pageName: 'PAYMENT_FAILED'
    })
  } else if (type === 6) {
    // lnwang  填写新卡 back
    log('页面:   填写新卡 back   ')
    Vue.$SDK.buriedPoint({
      pageName: 'CREDIT_CARD_ONLINE'
    })
  }
}


export function CLOSE(type) {
  // lnwang  收银台弹窗 CLOSE
  if (type === 1) {
    log('页面:   收银台弹窗 CLOSE')
    Vue.$SDK.buriedPoint({
      pageName: 'PAY_DETAIL_COUNTER'
    })
  } else if (type === 2) {
    // lnwang  收银台成功支付关闭弹窗
    log('页面:   收银台成功支付关闭弹窗   ')
    Vue.$SDK.buriedPoint({
      pageName: 'SUCCESS_COUNTER'
    })
  } else if (type === 3) {
    // lnwang  收银台请求错误
    log('页面:   收银台请求错误   ')
    Vue.$SDK.buriedPoint({
      pageName: 'NETWORK_ERROR_COUNTER'
    })
  } else if (type === 4) {
    // lnwang  支付失败
    log('页面:   支付失败   ')
    Vue.$SDK.buriedPoint({
      pageName: 'PAYMENT_FAILED'
    })
  }
}


// lnwang  收银台弹窗选择支付方式 
export function PAY_METHOD() {
  log('页面:   收银台弹窗选择支付方式 ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_DETAIL_COUNTER'
  })
}
// lnwang  收银台弹窗选择确认 
export function CONFIRM() {
  log('页面:   收银台弹窗选择确认  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_DETAIL_COUNTER'
  })
}
// lnwang  收银台挽留弹窗中toast 选择确认 
export function YES() {
  log('页面:   收银台挽留弹窗中toast 选择确认  ')
  Vue.$SDK.buriedPoint({
    pageName: 'COUNTER_QUIT'
  })
}
// lnwang  收银台挽留弹窗中toast 选择取消
export function NO() {
  log('页面:   收银台挽留弹窗中toast 选择取消  ')
  Vue.$SDK.buriedPoint({
    pageName: 'COUNTER_QUIT'
  })
}
// lnwang  收银台选择支付方式balance不在二行
export function BALANCE_1() {
  log('页面:   收银台选择支付方式balance不在二行  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  收银台选择支付方式balance在二行
export function BALANCE_2() {
  log('页面:   收银台选择支付方式balance在二行  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  收银台选择支付方式 ODD
export function ODD_2() {
  log('页面:   收银台选择支付方式 ODD  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  收银台选择支付方式 credit card
export function CREDIT_CARD_3() {
  log('页面:   收银台选择支付方式 credit card  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  收银台选择支付方式 
export function CENPAY_4() {
  log('页面:   收银台选择支付方式   ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  收银台选择支付方式 添加新卡账户
export function CREDIT_ONLINE_5() {
  log('页面:   收银台选择支付方式 添加新账户  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}


// lnwang  收银台选择支付方式 绑定信用卡
export function ADD_CARD_ACCOUNT() {
  log('页面:   收银台选择支付方式 绑定信用卡  ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_SUCCESS_COUNTER'
  })
}
// lnwang  绑定新卡选择save card  
export function SAVE_CARD() {
  log('页面:   绑定新卡选择save card    ')
  Vue.$SDK.buriedPoint({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}
// lnwang  绑定新卡选择 pay  
export function PAY() {
  log('页面:   绑定新卡选择 pay    ')
  Vue.$SDK.buriedPoint({
    pageName: 'CREDIT_CARD_ONLINE'
  })
}

  
export function ERROR(type) {
  // lnwang  支付报告错误
  if (type === 1) {
    log('页面:   支付报告错误    ')
    Vue.$SDK.buriedPoint({
      pageName: 'PAY_DETAIL_COUNTER'
    })
  } else if (type === 2) {
    // lnwang  绑定新卡save card报告错误
    log('页面:   绑定新卡save card报告错误    ')
    Vue.$SDK.buriedPoint({
      pageName: 'CREDIT_CARD_ONLINE'
    })
  }
}


// lnwang 
export function CLICK_DOWNLOAD() {
  log('页面:   使用优惠券    ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_DETAIL_COUNTER'
  })
  Vue.$SDK.buriedPointCore(
    [{
      channelType: 1,
      eventId: 'CLICK_DOWNLOAD'
    },
    {
      channelType: 2,
      eventId: 'CLICK_DOWNLOAD'
    }]
  )
}
export function CLICK_CLOSE() {
  log('页面:   关闭重试弹窗    ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_INSUFFFUND'
  })
  Vue.$SDK.buriedPointCore(
    [{
      channelType: 1,
      eventId: 'CLICK_CLOSE'
    },
    {
      channelType: 2,
      eventId: 'CLICK_CLOSE'
    }]
  )
}
export function CLICK_CHANGE_METHOD() {
  log('页面:   重试收银台    ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_INSUFFFUND'
  })
  Vue.$SDK.buriedPointCore(
    [{
      channelType: 1,
      eventId: 'CLICK_CHANGE_METHOD'
    },
    {
      channelType: 2,
      eventId: 'CLICK_CHANGE_METHOD'
    }]
  )
}
export function CLICK_CANCEL() {
  log('页面:   取消重试收银台    ')
  Vue.$SDK.buriedPoint({
    pageName: 'PAY_INSUFFFUND'
  })
  Vue.$SDK.buriedPointCore(
    [{
      channelType: 1,
      eventId: 'CLICK_CANCEL'
    },
    {
      channelType: 2,
      eventId: 'CLICK_CANCEL'
    }]
  )
}