// p2p
export function COLLET_TRANSFERMONEY_CONFIRM() {
  Vue.$SDK.buriedPoint({
    pageName: 'COLLET_TRANSFERMONEY',
    eventId: 'CONFIRM'
  })
}
