import Vue from 'vue'

// promotionTab首页进入
export function PROMOTION_ENTER(pageName) {
  Vue.$SDK.buriedPointEntry({
    pageName
  })
}

// promotionTab首页离开
export function PROMOTION_LEAVE(pageName) {
  Vue.$SDK.buriedPointLeave({
    pageName
  })
}

// promotionTab首页点击列表中GO按钮
export function PROMOTION_CLICK(pageName, eventId) {
  Vue.$SDK.buriedPoint({
    pageName,
    eventId
  })
}
