<template>
  <div class="neterror">
    <p class="txt">{{ $t('No net connection') }}</p>
    <div class="btn-wraper">
      <!-- <common-button
        plain
        type="danger"
        size="small"
        @click="handleClick">{{ $t('TRYAGAIN') }}</common-button> -->
      <div
        class="btn-container"
        @click="handleClick">{{ $t('TRYAGAIN') }}</div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Error',
  methods: {
    handleClick() {
      this.$router.go(-1)
      // this.$SDK.goNativeMain()
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.neterror {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 1.6rem;
  .img {
    width: 3.5rem;
    height: 3.5rem;
  }
  .txt {
    color: #A1A5B9;
    font-size: .40rem;
    text-align: center;
  }
  .btn-wraper {
    padding-top: 1rem;
    .btn-container {
        height: .64rem;
        width: 2.8rem;
        font-size: 16px;
        border: 1px solid $color-red;
        color: $color-red;
        border-radius: 0.5rem;
        text-align: center;
        line-height: .64rem;
        font-family: The1Official_Bold;
    }
  }
}
</style>

