<template>
  <div class="neterror">
    <img
      src="@/assets/images/error/404@3x.png"
      class="img">
    <p class="txt">failed</p>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click="handleClick">Back to Home</common-button>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Error',
  methods: {
    handleClick() {
      // this.$router.go(-1)
      this.$SDK.goNativeMain()
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.neterror {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 1rem;
  .img {
    width: 3.5rem;
    height: 3.5rem;
  }
  .txt {
    font-size: .40rem;
    color: $color-gray-h;
    text-align: center;
  }
  .btn-wraper {
    padding-top: 1rem;
  }
}
</style>

