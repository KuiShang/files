<template>
  <div class="another-bank-account-wraper">
    <p class="little-txt">Money transfer will be successed within <span class="red">1</span> working day</p>
    <section class="list-container">
      <div class="item-wraper">
        <div
          class="choose-item"
          @click="chooseBank"
        >
          <p
            v-show="payeeBank"
            class="title"
          >Choose Payee Bank</p>
          <div class="holder-container">
            <p
              v-show="!payeeBank"
              class="holder"
            >Choose Payee Bank</p>
            <p
              v-show="payeeBank"
              class="txt"
            >{{ payeeBank }}</p>
            <common-icon
              slot="icon"
              class="custom-ico"
              name="more"
              size=".35rem"
              style="color:#D6D5D5;"
            />
          </div>
        </div>
      </div>
      <div class="item-wraper">
        <common-input
          v-model="accountNumber"
          holder="Account Number"
        />
      </div>
      <div class="item-wraper">
        <common-input
          v-model="firstName"
          holder="First Name"
        />
      </div>
      <div class="item-wraper">
        <common-input
          v-model="lastName"
          holder="Last Name"
        />
      </div>
    </section>
    <moneyInput v-model="amount"/>
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">TRANSFER</common-button>
    </div>
    <feeConfirm
      :visible.sync="feeConfirmVisible"
      :money="amount"
      :fee="fee"
      @confirm="confirm"
    />
    <selectBankAccount
      :visible.sync="selectBankAccountVisible"
      :show-another="false"
      :list="bankList"
      @selectBank = "selectBank"
    />
    <simpleCashier
      :cashier-visible.sync="cashierVisible"
      :transaction-no = "transactionNo"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import moneyInput from '@/pages/balance/common/moneyInput'
import feeConfirm from '@/pages/balance/common/feeConfirm'
import selectBankAccount from '@/pages/balance/common/selectBankAccount'
import { queryBankList, createTransfer } from '@/api'
import simpleCashier from '@/pages/cashier/simple-cashier'
import { TRANSFER_TYPE } from '@/utils/const'

export default {
  name: 'AddAnotherBankAccount',
  components: { moneyInput, feeConfirm, selectBankAccount, simpleCashier },
  data() {
    return {
      amount: '',
      accountNumber: '',
      firstName: '',
      lastName: '',
      feeConfirmVisible: false,
      selectBankAccountVisible: false,
      bankList: [],
      currentIndex: 0,
      cashierVisible: false,
      transactionNo: '',
      transOrderNo: ''
    }
  },
  computed: {
    btnok() {
      if (this.lastName.trim() && this.firstName.trim() && this.accountNumber && this.amount && this.bankList[this.currentIndex]) {
        return true
      }
      return false
    },
    payeeBank() {
      const name = this.bankList[this.currentIndex] ? this.bankList[this.currentIndex].bankName : 0
      return name
    },
    fee() {
      return this.$route.query.fee
    }
  },
  methods: {
    check() {
      console.log('check')
    },
    handleClick() {
      console.log('click')
      this.feeConfirmVisible = true
    },
    async confirm() {
      const res = await createTransfer({
        version: this.$DeviceInfo.appVersion,
        amount: this.amount,
        fee: this.fee,
        currency: 'THB',
        bankName: this.bankList[this.currentIndex].bankName,
        bankAccount: this.accountNumber,
        accountName: this.firstName + this.lastName,
        deviceMsg: JSON.stringify(this.$DeviceInfo),
        busiType: TRANSFER_TYPE.NORMAL
      })
      if (res && res.data && res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
      } else {
        // this.$messagebox('提示', res.data.errorData.msg)
        this.$toast({
          message: res.data.errorData.msg,
          position: 'middle',
          duration: 3000
        })
      }
    },
    paynow() {
      console.log('pay')
      this.$router.push({ name: 'transferBankResult', query: { transOrderNo: this.transOrderNo } })
    },
    async chooseBank() {
      const res = await queryBankList({
        version: this.$DeviceInfo.appVersion
      })
      if (res.data.resultCode === 1) {
        this.bankList = res.data.resultData
        this.selectBankAccountVisible = true
      } else if (res.data.resultCode === 0) {
        if (res.data.actionData) {
          this.$SDK.goNativeAction(res.data.actionData)
        } else {
          this.$toast({
            message: res.data.errorData.msg,
            position: 'middle',
            duration: 3000
          })
        }
      }
    },
    selectBank(index) {
      console.log('celect')
      this.currentIndex = index
      this.selectBankAccountVisible = false
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.another-bank-account-wraper {
  height: 100%;
  background-color: $color-gray-e;
  font-size: .28rem;
  .little-txt {
    padding: 0 .3rem;
    line-height: .72rem;
    background: $color-gray-e;
    .red {
      color: $color-red;
    }
  }
  .list-container {
    background-color: #fff;
    margin-bottom: .2rem;
    .choose-item {
      height: 1.2rem;
      box-sizing: border-box;
      border-bottom: 1px solid #E5E5E5;
      .title {
        font-size: .24rem;
        color: $color-blue;
        padding-top: .14rem;
      }
      .holder-container {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        .txt {
          padding-top: .12rem;
          font-size: .32rem;
          color: $color-gray-a;
        }
        .holder {
          padding-top: .64rem;
          color: #bbb;
        }
      }
    }
    .item-wraper {
      padding:.2rem .4rem 0;
    }
  }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
