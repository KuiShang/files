<template>
  <div class="transferPrompt-confirm">
    <div class="padtop"/>
    <div class="content-wrapper">
      <dl class="payee">
        <dt>{{ this.$t('tag30_confirm_text_PayMoneyto') }}</dt>
        <dd>{{ this.promptPayInfo.receiverName }}</dd>
      </dl>
      <ul>
        <li>
          <section
            v-if="!!this.promptPayInfo.promptAccountNo"
            class="clearFix">
            <span class="title">{{ this.$t('tag30_confirm_text_PromptPayID') }}</span>
            <span class="content">{{ this.promptPayInfo.promptAccountNo }}</span>
          </section>
          <section
            v-if="!!this.promptPayInfo.reference1"
            class="clearFix">
            <span class="title">{{ this.$t('tag30_confirm_text_Ref1') }}</span>
            <span class="content">{{ this.promptPayInfo.reference1 }}</span>
          </section>
          <section
            v-if="!!this.promptPayInfo.reference2"
            class="clearFix">
            <span class="title">{{ this.$t('tag30_confirm_text_Ref2') }}</span>
            <span class="content">{{ this.promptPayInfo.reference2 }}</span>
          </section>
        </li>
        <li>
          <section
            v-if="!!this.promptPayInfo.amount"
            class="clearFix">
            <span class="title">{{ this.$t('tag30_confirm_text_amount')}} (฿)</span>
            <span class="content">{{ this.promptPayInfo.amount | tofloat | thousandBitSeparator }}</span>
          </section>
          <section
            v-if="!!this.promptPayInfo.fee"
            class="clearFix">
            <span class="title">{{ this.$t('Fee') }}</span>
            <span class="content">{{ this.promptPayInfo.fee | tofloat | thousandBitSeparator }}</span>
          </section>
        </li>
      </ul>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="handleClick">{{ this.$t('tag30_confirm_btn_PAYNOW') }}</common-button>
    </div>
    <!-- 半屏收银台 -->
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :transaction-no = "transactionNo"
      :trans-order-no = "transOrderNo"
      :current-busi-type= "ALL_BUSI_TYPE.TRANSFER_PROMOPY"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import storage from 'storejs'
import { promptTag30CreateOrder } from '@/api'
import { ALL_BUSI_TYPE } from '@/utils/const'
import simpleCashier from '@/pages/cashier/simple-cashier'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'transferPromptTag30Confirm',
  components: { simpleCashier },
  mixins: [hasPayError],
  data() {
    return {
      promptPayInfo: {},
      ALL_BUSI_TYPE,
      cashierVisible: false,
      transactionNo: '',
      transOrderNo: ''
    }
  },
  async created() {
    this.$SDK.setTitle({
      title: this.$t('payment'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress(() => {
      this.$router.go(-1)
    })
    const promptPayInfo = await this.$SDK.getCache({
      key: 'promptTag30Info',
      cacheMode: 2
    })
    this.promptPayInfo = JSON.parse(promptPayInfo);
  },
  methods: {
    async handleClick() {
      const Tag30CreateOrder = Object.assign(this.promptPayInfo, {
        deviceMsg: JSON.stringify(this.$DeviceInfo),
      })
       
      const res = await promptTag30CreateOrder(Tag30CreateOrder)
      if (res && res.data && res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
      } else if (res && res.data && res.data.resultCode === 0) {
        const errorMsg = {
          code: res.data.errorData && res.data.errorData.code || '',
          msg: res.data.errorData && res.data.errorData.msg || ''
        }
        this.hasPayError(res)
      }
    },
    paynow() {
      this.$router.push({ name: 'transferTh1Result', query: { transOrderNo: this.transOrderNo, transactionNo: this.transactionNo } })
    }
  },
  watch: {
    cashierVisible(value) {
      if (value == false) { // 关闭收银台 报进入
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_ENTRY()
      } else {
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_LEAVE()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.transferPrompt-confirm{
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  .padtop{
    padding-top: .2rem;
  }
  .content-wrapper{
    padding:0 0.4rem;
    background-color: $color-white;
    .payee{
      padding: 0.4rem 0 0.39rem;
      dt{
        font-size: 0.28rem;
        line-height: 0.46rem;
        color: $color-gray-h;
      }
      dd{
        margin-top: 0.1rem;
        font-size: 0.4rem;
        font-family: The1Official_bold;
        line-height: 0.66rem;
        color: $color-gray-g;
      }
    }
    ul{
      li{
        padding-top: 0.19rem;
        padding-bottom: 0.2rem;
        border-top: 1px dashed $color-gray-e;
        section {
          height: 0.72rem;
          line-height: 0.72rem;
        }
        .title{
          float: left;
          font-size: 0.28rem;
          color: $color-gray-f;
        }
        .content{
          display: flex;
          font-size: 0.28rem;
          align-items: center;
          float: right;
          color: $color-gray-h;
          text-align: right;
        }
      }
    }
  }
  .btn-wraper{
    margin-top:0.5rem;
    display: flex;
    justify-content: center;
  }
}
</style>
