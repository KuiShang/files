<template>
  <!-- tag30 支付成功的item -->
  <ul>
    <li
      v-if="!!tag30ResultItem.receiverName"
      class="item">
      <span class="key">{{ this.$t('tag30_result_txt_Biller') }}</span>
      <span>{{ this.tag30ResultItem.receiverName }}</span>
    </li>
    <li
      v-if="!!tag30ResultItem.promptAccountNo"
      class="item">
      <span class="key">{{ this.$t('tag30_confirm_text_PromptPayID') }}</span>
      <span>{{ tag30ResultItem.promptAccountNo }}</span>
    </li>
    <li
      v-if="!!tag30ResultItem.reference1"
      class="item">
      <span class="key">{{ this.$t('tag30_confirm_text_Ref1') }}</span>
      <span>{{ tag30ResultItem.reference1 }}</span>
    </li>
    <li
      v-if="!!tag30ResultItem.reference2"
      class="item">
      <span class="key">{{ this.$t('tag30_confirm_text_Ref2') }}</span>
      <span>{{ tag30ResultItem.reference2 }}</span>
    </li>
    <li
      v-if="!!tag30ResultItem.paymentMethod1"
      class="item">
      <span class="key">{{ this.$t('PaymentMethod') }}</span>
      <span>{{ bankWithName }}</span>
    </li>
  </ul>
</template>
<script>
import bankWithName4 from '@/mixins/bankWithName4'
export default {
  name: 'transferPromptTag30Result',
  mixins: [bankWithName4],
  props: {
    tag30ResultItem: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      dataObj: this.tag30ResultItem
    }
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.item {
  display: flex;
  justify-content: space-between;
  height: 0.9rem;
  font-size: 0.28rem;
  color: $color-gray-g;
  text-align: right;
  line-height: 0.9rem;
  .key {
    color: $color-gray-f;
  }
  span {
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
}
</style>