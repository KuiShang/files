<template>
<!-- tag 30 商家 tag29 个人码 -->
  <div class="blance-transfer-prompt">
    <moneyInput
      ref="moneyInput"
      v-model="amount"
      :readonly="readonly"
      :title ="this.$t('tag30_txt_payamount')"
      :busi-scenarios="'40'"
      @moneyFlag="receiveMoneyFlag"
      @moneyLimitOk="moneyLimitOk"
    />
    <div class="white-area" />
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">{{ this.$t('tag30_btn_reviewDetail') }}</common-button>
    </div>
  </div>
</template>
<script>
import storage from 'storejs'
import moneyInput from '@/pages/balance/common/moneyInput'
import { promptTag30ReviewDetail, queryPromptTag30Info } from '@/api'
import { BUSI_SCENARIOS, TRANSFER_CHANNELS } from '@/utils/const'
import hasPayError from '@/mixins/hasPayError'

export default {
  name: 'simpleCashier',
  components: { moneyInput },
  mixins: [hasPayError],
  data() {
    return {
      promptServerData: {},
      amount: '',
      feeConfirmVisible: false,
      BUSI_SCENARIOS,
      number: '',
      TRANSFER_CHANNELS, // 转账渠道
      customerObj: '',
      remark: '',
      moneyFlag: false,
      readonly: false,
      disabled: false,
      showContractEntry: true, // 展示调原生通讯录的icon
      notRegistered: false,
      showInvalidToast: false, // 无效账户的toast
      beforeIcontype: '', // 前置icon图片类型
      promptAccountType: '', // prompt账户类型
      promptLookupId: '',
      promptLookupRef: '',
      receiverName: '',
      billerId: '',
      reference1: ''
    }
  },
  computed: {
    btnok() {
      if (this.$route.query.type === 'scan') {
        return this.moneyFlag
      }
      return this.moneyFlag
    },
    busiType() {
      if (this.$route.query.type === 'scan') {
        return BUSI_SCENARIOS.PROMPTPAY
      }
      return BUSI_SCENARIOS.TRANSFER
    },
    busiScenarios() {
      if (this.$route.query.type === 'scan') {
        return BUSI_SCENARIOS.PROMPTPAY
      }
      return BUSI_SCENARIOS.TRANSFER
    }
  },
  watch: {
    number(val) {
      this.$refs.commonInput.currentValue = this.sortNum(val)
      const value = val.replace(/[^\d]/g, '')
      if (value.length === 9 || (value.length === 10 && value.slice(0, 1) === '0')) {
        this.beforeIcontype = 'mobile'
        this.promptAccountType = 'MSISDN'
      } else if (value.length === 13) {
        this.beforeIcontype = 'id'
        this.promptAccountType = 'NATID'
      } else if (value.length === 15) {
        this.beforeIcontype = 'ewallet'
        this.promptAccountType = 'EWALLETID'
      } else {
        this.beforeIcontype = ''
        this.promptAccountType = ''
      }
    }
  },
  async created() {
    // 监听物理返回按键
    this.$SDK.onBackPress(() => {
      this.$SDK.closeWebView()
    })
    // 设置当前页面的title
    this.$SDK.setTitle({
      title: this.$t('payment'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    // 从url的query取key 并请求服务端接口
    const promptkey = this.$route.query.key || '';
    if (!promptkey) return false;
    const res = await queryPromptTag30Info({
      key: promptkey
    })
    if (res && res.data && res.data.resultCode === 1) {
      const paramsObj = res.data.resultData
      this.promptServerData = res.data.resultData
      if (paramsObj.amount && parseFloat(paramsObj.amount) > 0) {
        this.amount = paramsObj.amount || ''
        this.readonly = true;
      } else {
        // 如果没有设置金额amout  则按钮不可用状态
        this.disabled = true
      }
    } else if (res && res.data && res.data.resultCode === 0) {
      this.hasPayError(res)
    }
  },
  methods: {
    async handleClick() {
      // TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_REVIEW_DETAIL()
      const postData = {
        // promptAccountNo: this.number.replace(/[^\d]/g, ''), // prompt账户号
        amount: this.amount,
        currency: 'THB',
        // transactionId: 1000,
        billerId: this.promptServerData.billerId,
        reference1: this.promptServerData.reference1
      }
      if (!!this.promptServerData.reference2) {
        postData.reference2 = this.promptServerData.reference2;
      }
      if (!!this.promptServerData.reference3) {
        postData.reference3 = this.promptServerData.reference3;
      }
      this.$indicator.open({
        text: this.$t('Loading'),
        spinnerType: 'fading-circle'
      })
      const res = await promptTag30ReviewDetail(postData)
      this.$indicator.close()
      if (res && res.data && res.data.resultCode === 1) {
        // 将返回的数据揉在一起存储到下一个路由
        const promptPayInfo = Object.assign(this.promptServerData, res.data.resultData, {
          amount : this.amount,
          currency: 'THB',
          promptAccountNo: this.promptServerData.billerId
        })
        this.$SDK.putCache({
          key: 'promptTag30Info',
          value: JSON.stringify(promptPayInfo),
          cacheMode: 2
        })
        this.$router.push({ name: 'transferPromptTag30Confirm' })
      } else if (res && res.data && res.data.resultCode === 0) {
        // 接口错误弹出错误信息
        this.hasPayError(res)
      }
    },
   
    sortNum(val) {
      return val.toString().replace(/(\d{4})(?=\d)/g, '$1 ')
    },
    moneyLimitOk() {
      this.$refs.moneyInput.amount = this.amount
    },
    getBeforeIconType(val) {
      if (val === 'MSISDN') {
        // 电话号码（9位或10位)
        this.beforeIcontype = 'mobile'
      } else if (val === 'NATID') {
        // 身份证号（13位）
        this.beforeIcontype = 'id'
      } else {
        // E-wallet Number(15位)
        this.beforeIcontype = 'ewallet'
      }
    },
    // 接受到金额是否可用
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.blance-transfer-prompt {
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  position: relative;
  .white-area {
      height: 0.7rem;
      background-color: $color-white;
    }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}
</style>

