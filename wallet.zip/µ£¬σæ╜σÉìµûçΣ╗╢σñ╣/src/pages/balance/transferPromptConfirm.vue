<template>
  <div class="transferPrompt-confirm">
    <div class="padtop"/>
    <div class="content-wrapper">
      <ul>
        <li>
          <span class="title">
            {{ this.$t('ReceiverName') }}
          </span>
          <span class="content">
            {{ promptPayInfo.receiverName }}
          </span>
        </li>
        <li>
          <span class="title">
            {{ this.$t('ReceiverAccount') }}
          </span>
          <span class="content">
            <img
              v-if="promptPayInfo.promptAccountType=='MSISDN'"
              src="@/assets/images/blance/promptPay/mobile@3x.png"
              class="mobile-icon"
              alt="">
            <img
              v-else-if="promptPayInfo.promptAccountType=='EWALLETID'"
              src="@/assets/images/blance/promptPay/ewallet@3x.png"
              class="mobile-icon"
              alt="">
            <img
              v-else
              src="@/assets/images/blance/promptPay/ID@3x.png"
              class="mobile-icon"
              alt="">
            {{ promptPayInfo.promptAccountNo }}
          </span>
        </li>
        <li>
          <span class="title">
            {{ this.$t('Amount') }} (฿)
          </span>
          <span class="content">
            {{ promptPayInfo.amount | tofloat | thousandBitSeparator}}
          </span>
        </li>
        <li>
          <span class="title">
            {{ this.$t('Fee') }} (฿)
          </span>
          <span class="content">
            {{ promptPayInfo.fee | tofloat | thousandBitSeparator  }}
          </span>
        </li>
        <li>
          <span class="title">
            {{ this.$t('Notes') }}
          </span>
          <span class="content">
            {{ promptPayInfo.remark }}
          </span>
        </li>
      </ul>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="handleClick">{{ this.$t('Confirm') }}</common-button>
    </div>
    <!-- 半屏收银台 -->
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :transaction-no = "transactionNo"
      :trans-order-no = "transOrderNo"
      :current-busi-type= "ALL_BUSI_TYPE.TRANSFER_PROMOPY"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import { createTransfer } from '@/api'
import { ALL_BUSI_TYPE } from '@/utils/const'
import simpleCashier from '@/pages/cashier/simple-cashier'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'TransferPromptConfirm',
  components: { simpleCashier },
  mixins: [hasPayError],
  data() {
    return {
      promptPayInfo: {},
      ALL_BUSI_TYPE,
      cashierVisible: false,
      transactionNo: '',
      transOrderNo: ''
    }
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_LEAVE()
    next()
  },
  async created() {
    this.$SDK.setTitle({
      title: this.$t('TOpromptpayAccount'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress(() => {
      this.$router.go(-1)
    })
    const temp = await this.$SDK.getCache({
      key: 'promptPayInfo',
      cacheMode: 2
    })
    this.promptPayInfo = JSON.parse(temp) || {}
    console.log(this.promptPayInfo)
  },
  methods: {
    async handleClick() {
      const res = await createTransfer(this.promptPayInfo)
      if (res && res.data && res.data.resultCode === 1) {
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_TRANSFER()
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
      } else if (res && res.data && res.data.resultCode === 0) {
        const errorMsg = {
          code: res.data.errorData && res.data.errorData.code || '',
          msg: res.data.errorData && res.data.errorData.msg || ''
        }
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_TRANSFER(errorMsg)
        this.hasPayError(res)
      }
    },
    paynow() {
      this.$router.push({ name: 'transferTh1Result', query: { transOrderNo: this.transOrderNo, transactionNo: this.transactionNo } })
    }
  },
  watch: {
    cashierVisible(value) {
      if (value == false) { // 关闭收银台 报进入
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_ENTRY()
      } else {
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_LEAVE()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.transferPrompt-confirm{
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  .padtop{
    padding-top: .2rem;
  }
  .content-wrapper{
    padding:  0.3rem 0;
    background-color: #fff;
    ul{
      li{
        height: 0.9rem;
        line-height: 0.9rem;
        padding: 0 0.4rem;
        font-size: 0.28rem;
        .title{
          float: left;
          color: $color-gray-f;
        }
        .content{
          display: flex;
          align-items: center;
          float: right;
          color: $color-gray-g;
          text-align: right;
          .mobile-icon{
            height: 0.6rem;
            width: 0.6rem;
            margin-right: 0.24rem;
          }
        }
      }
    }
  }
  .btn-wraper{
    margin-top:0.98rem;
    display: flex;
    justify-content: center;
  }
}
</style>
