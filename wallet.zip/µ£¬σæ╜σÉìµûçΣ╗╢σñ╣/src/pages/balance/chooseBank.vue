<template>
  <div class="transfer-tobank-choose">
    <div class="padtop"/>
    <div class="bank-list">
      <ul>
        <li
          v-for="(item,index) in bankList"
          :key="index"
          @click="selectBank(item)"
        >
          <img
            :src="item.h5Logo"
            height="0.6rem"
            width="0.6rem"
            alt=""
          >
          {{ item.bankName }}
          <common-icon
            class="custom-ico"
            name="more"
            size=".4rem"
          />
        </li>
      </ul>
    </div>
    <div class="padbottom"/>
  </div>
</template>
<script>
import { mapMutations, mapGetters } from 'vuex'
import { queryBankList } from '@/api'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'ChooseBank',
  mixins: [hasPayError],
  data() {
    return {
      bankList: ''
    }
  },
  computed: {
    ...mapGetters(['bankAccountInfoList'])
  },
  async created() {
    this.$SDK.setTitle({
      title: this.$t('ChooseBank'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress( () => {
      this.$router.go(-1)
    })
    // 如果vuex里面有值直接取，没值再次请求
    if (this.bankAccountInfoList.length === 0) {
      const res = await queryBankList()
      if (res && res.data && res.data.resultCode === 1) {
        this.setBankInfoList(res.data.resultData);
        this.bankList = res.data.resultData
      } else if (res && res.data && res.data.resultCode === 0) {
        this.hasPayError(res)
      }
    } else {
      this.bankList = this.bankAccountInfoList
    }
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_BANKTYPE_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_BANKTYPE_LEAVE()
    next()
  },
  methods: {
    selectBank(item) {
    
      this.setSelectBankInfo(item)
      this.$router.push({ name: 'transferBankAccount', query: { refer: 'bankList' } })
    },
    ...mapMutations({
      setSelectBankInfo: 'SET_SELECTBANKINFO',
      setBankInfoList: 'SET_BANKINFOLIST'
    })
  }
}
</script>
<style lang="scss" scoped]>
@import "@/assets/css/var.scss";
.transfer-tobank-choose{
  font-size: .24rem;
  background-color: $color-gray-i;
  height: 100%;
  overflow-y: auto;
  position: relative;
  .padtop{
    padding-top: .4rem;
  }
  .padbottom{
    padding-bottom: .4rem;
  }
  .bank-list{
    padding: 0 0.4rem;
    ul{
      width: 100%;
      li{
        position: relative;
        align-items: center;
        font-size: 0.36rem;
        color: $color-gray-g;
        letter-spacing: 0;
        text-align: left;
        height: 1.4rem;
        line-height: 1.4rem;
        background: #FFFFFF;
        padding: 0 .4rem 0 1.2rem;
        box-shadow: 0 2px 4px 0 $color-gray-f;
        border-radius: 2px;
        margin-bottom: 0.4rem;
        img{
          position: absolute;
          height: 0.6rem;
          width: 0.6rem;
          top: 50%;
          left: 0.4rem;
          margin-top: -0.3rem;
        }
        .custom-ico{
          float: right;
        }
      }
    }
  }
}
</style>
