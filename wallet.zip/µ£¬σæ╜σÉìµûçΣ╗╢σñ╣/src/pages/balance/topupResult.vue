<template>
  <div class="result">
    <div v-if="showSuccess">
      <div
        v-if="this.dataObj.status=='1' || this.dataObj.status=='2'"
        class="head">
         <ul class="time-vertical">
            <li class="item item-ok">
              <img src="@/assets/images/blance/complete@2x.png" alt=""> 
              <div class="txt">
                <p class="txt-title">{{ this.$t('PaymentSuccessfully') }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status > 1 }"
              class="item">
              <div class="txt">
                <p class="txt-des">{{ createdDate }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 2 }"
              class="item">
              <img
                v-if="dataObj.status >= 2"
                src="@/assets/images/blance/complete@2x.png" alt=""> 
              <img
                v-else
                src="@/assets/images/blance/waiting@2x.png" alt="">
              <div class="txt">
                <p class="txt-title">{{ this.$t('Processing') }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 3 }"
              class="item">
              <div class="txt">
                <p class="txt-des">{{ modifiedDate }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 3 }"
              class="item">
              <img
                v-if="dataObj.status >= 3"
                src="@/assets/images/blance/complete@2x.png" alt=""> 
              <img
                v-else
                src="@/assets/images/blance/waiting@2x.png" alt="">
              <div class="txt">
                <p class="txt-title">{{ this.$t('TransferSucess') }}</p>
                <p
                  v-if="this.scenarios=='2'" 
                  class="txt-des">{{ this.$t('arriveDay') }}</p>
                <p
                  v-else-if="this.scenarios=='3'||this.scenarios=='34'" 
                  class="txt-des">{{ this.$t('arriveQuickly') }}</p>
                <p
                  v-else 
                  class="txt-des">{{ successTime }}</p>
              </div>
            </li>
          </ul>
      </div>
      <div 
        v-else-if="this.dataObj.status=='3'"
        class="head">
        <p class="pd8"/>
        <img
          class="img"
          src="@/assets/images/blance/the1/success_big@3x.png"
          alt="duigou">
        <p class="txt-title">{{ $t('Balance Top Up Success!') }}</p>
        <p class="txt-des">{{ $t('Top Up Amount') }} <span class="money">฿ {{ dataObj.amount | tofloat | thousandBitSeparator }}</span></p>
      </div>
 
      <ul class="list">
        <li class="item" v-if="bankWithName">
          <span class="key">{{ $t('Top Up Method') }}</span>
          <span class="height45">{{ bankWithName }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('Transaction No.') }}</span>
          <span>{{ dataObj.transOrderNo }}</span>
        </li>
      </ul>
      <!-- <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">{{ $t('DONE') }}</common-button>
      </div> -->
    </div>
    <resultFail
      v-else
      :type-str="$t('TopUpFailed')"
      @click="tryAgain"/>
    <!-- 引导开通指纹人脸支付 -->
    <guideFingerprintPay/>
  </div>
</template>
<script>

import { topUpSucc } from '@/api'
import handlInitData from '@/mixins/handlInitData'
import bankWithName4 from '@/mixins/bankWithName4'
import resultFail from '@/pages/balance/common/resultFail'
import guideFingerprintPay from '@/pages/balance/common/guideFingerprintPay'
import * as TRANSFER_BURRY from '@/pages/burry/topup'

export default {
  name: 'TopupResult',
  components: { resultFail, guideFingerprintPay },
  mixins: [handlInitData, bankWithName4],
  data() {
    return {
      scenarios: '',
      showSuccess: true,
      titleRightMsg: {
        text: this.$t('DONE'),
        show: 1,
        textSize: 18,
        textColor: '#FF3E5B'
      }
    }
  },
  computed: {
    receiverAccount() {
      return `${this.dataObj.bankName} (${this.dataObj.bankAccount})`
    },
    createdDate() {
      return this.dataObj && this.dataObj.createdDate ? new Date(this.dataObj.createdDate).format("dd-MM-yyyy hh:mm:ss") : "";
    },
    modifiedDate() {
      return this.dataObj && this.dataObj.modifiedDate ? new Date(this.dataObj.modifiedDate).format("dd-MM-yyyy hh:mm:ss") : "";
    },
    successTime() {
      return this.dataObj && this.dataObj.successTime ? new Date(this.dataObj.successTime).format("dd-MM-yyyy hh:mm:ss") : "";
    }
  },
  created() {
    // 如果没有transOrderNo 则为失败
    if (!this.$route.query.transOrderNo) {
      this.showSuccess = false
      TRANSFER_BURRY.TOP_UP_FAILED_PAGE_ENTER()
      return
    }
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('balancetopup'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
    TRANSFER_BURRY.TOP_UP_SUCCESSFUL_PAGE_ENTER()
    this.$SDK.setTitleRight(this.titleRightMsg, () => {
      TRANSFER_BURRY.TOP_UP_SUCCESSFUL_PAGE_DONE()
      TRANSFER_BURRY.TOP_UP_SUCCESSFUL_PAGE_LEAVE()
      this.$SDK.closeWebViewAndSendResult()
    })
  },
  methods: {
    handleClick() {
      console.log('click')
      // this.$router.push({ name: 'topup' })
      this.$SDK.closeWebView()
    },
    async initData() {
      const res = await topUpSucc({
        version: this.$DeviceInfo.appVersion,
        transOrderNo: this.$route.query.transOrderNo
      })
      this.handlInitData(res, () => {
        if (!this.dataObj.amount) {
          this.showSuccess = false
        } else {
          this.entryBurry()
        }
        if (this.dataObj.status=='4') {
          this.showSuccess = false
        } else {
          this.entryBurry()
        }
      }, () => {
        this.showSuccess = false
      })
    },
    tryAgain() {
      TRANSFER_BURRY.TOP_UP_FAILED_PAGE_TRYAGAIN()
      // TRANSFER_BURRY.TOP_UP_FAILED_PAGE_LEAVE()
      this.$router.push({ name: 'topup' })
    },
    entryBurry() {
      this.$SDK.buriedPointCore(
        [{
            channelType: 1,
            eventId: 'fire_3_topup_payment_success',
            map: {
              revenueAamount: this.dataObj.amount,
              businessType: '1',
              paymentMethod: this.dataObj.paymentMethod1,
              paymentMethod2: this.dataObj.paymentMethod2
            }
          }
        ]
      )
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-bottom: .6rem;
    .pd8 {
      height: .8rem;
    }
    .img {
      width: 1.2rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
      margin-top: .4rem;
    }
    .txt-des {
      padding-top: .3rem;
      font-size: .32rem;
      color: $color-gray-h;
      text-align: center;
      .money {
        font-size: .32rem;
        color: $color-red;
        text-align: center;
        line-height: .38rem;
      }
    }
    .hide {
      opacity: 0;
      display: none;
    }
  }
  .list {
    background-color: #fff;
    padding: .3rem .4rem;
    margin-top: .2rem;
    padding-top: .1rem;
    .item {
      display: flex;
      justify-content: space-between;
      // height: .9rem;
      font-size: .28rem;
      color: $color-gray-g;
      text-align: right;
      height: .45rem;
      padding-top: .2rem;
      padding-bottom: .2rem;
      word-break: break-all;
     
      span {
        max-width: 46%;
      }
      .key {
        color: $color-gray-h;
        text-align: left;
      }
     
    }
  }

  .time-vertical {
      height: 4.33rem;
      box-sizing: border-box;
      background-color: #fff;
      padding: .36rem .4rem;
      padding-left: 1.09rem;
      .item {
        height: 0.85rem;
        line-height: 0.85rem;
        border-left: .02rem solid #d6d5d5;
        position: relative;
        .txt {
          line-height: initial;
          text-indent: .41rem;
          position: absolute;
          top: -.02rem;
          p{
            text-align: left
          }
          .txt-title {
            font-size: .32rem;
            color: $color-gray-a;
          }
          .txt-des {
            font-size: .20rem;
            color: $color-gray-c;
          }
        }
        &:nth-of-type(even) {
          height: 0.43rem;
          .txt {
            line-height: initial;
            text-indent: .41rem;
            position: absolute;
            top: -.36rem;
            p{
              text-align: left
            }
            .txt-title {
              font-size: .32rem;
              color: $color-gray-a;
            }
            .txt-des {
              font-size: .20rem;
              color: $color-gray-c;
            }
          }
        }
        &:last-of-type{
          border: none;
          height: 1.13rem;
        }
        &.item-ok {
          color: $color-blue;
          border-left: .02rem solid $color-blue;
        }
        img {
          position: absolute;
          left: -0.22rem;
          height: 0.44rem;
          width: 0.44rem;
        }
  
      }
      .item.not {
        border-color: #d6d5d5;
      }
    }
  .btn-wraper {
    margin-top: .8rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
