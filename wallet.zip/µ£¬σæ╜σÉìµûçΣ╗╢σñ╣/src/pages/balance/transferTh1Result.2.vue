<template>
<!-- prompty/bankacount/余额 the1Acount 公共结果页(成功 失败 处理中 his.dataObj.status) -->
  <div 
    v-if="requestFinish"
    class="container-result">
    <resultFail
      v-if="!showSuccess || this.dataObj.status=='4'"
      :type-str="this.$t('TransferFail')"
      @click="tryAgain"/>
    <div
      v-else
      class="result">
      <div class="head">
        <template v-if="this.dataObj.status=='1' || this.dataObj.status=='2'">
          <!-- 1 充值 2提现 -->
          <ul class="time-vertical">
            <li class="item item-ok">
              <img src="@/assets/images/blance/complete@2x.png" alt=""> 
              <div class="txt">
                <p class="txt-title">{{ this.$t('PaymentSuccessfully') }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status > 1 }"
              class="item">
              <div class="txt">
                <p class="txt-des">{{ createdDate }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 2 }"
              class="item">
              <img
                v-if="dataObj.status >= 2"
                src="@/assets/images/blance/complete@2x.png" alt=""> 
              <img
                v-else
                src="@/assets/images/blance/waiting@2x.png" alt="">
              <div class="txt">
                <p class="txt-title">{{ this.$t('Processing') }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 3 }"
              class="item">
              <div class="txt">
                <p class="txt-des">{{ modifiedDate }}</p>
              </div>
            </li>
            <li
              :class="{ 'item-ok': dataObj.status >= 3 }"
              class="item">
              <img
                v-if="dataObj.status >= 3"
                src="@/assets/images/blance/complete@2x.png" alt=""> 
              <img
                v-else
                src="@/assets/images/blance/waiting@2x.png" alt="">
              <div class="txt">
                <p class="txt-title">{{ this.$t('TransferSucess') }}</p>
                <p
                  v-if="this.scenarios=='2'" 
                  class="txt-des">{{ this.$t('arriveDay') }}</p>
                <p
                  v-else-if="this.scenarios=='3'||this.scenarios=='34'" 
                  class="txt-des">{{ this.$t('arriveQuickly') }}</p>
                <p
                  v-else 
                  class="txt-des">{{ successTime }}</p>
              </div>
            </li>
          </ul>
        </template>
        <template v-else>
          <!-- 转账 -->
          <img
          class="img"
          src="@/assets/images/blance/the1/success_big@3x.png"
          alt="duigou">
          <p class="txt-title">{{ this.$t('TransferSuccess') }}</p>
          <!-- <p class="txt-des">Transfer Amount <span class="money">฿ {{ dataObj.amount | tofloat | thousandBitSeparator }}</span></p> -->
          <p class="money"><span>฿</span>{{ dataObj.amount | tofloat | thousandBitSeparator }}</p>
          <p
            v-if="dataObj.serviceCharge"
            class="fee">{{ this.$t('Fee') }} ฿{{dataObj.serviceCharge}}</p>
        </template>
      </div>
      <div class="list">
        <ul v-if="true">
          <!-- tag30的结果页 -->
          <Tag30Result :tag30ResultItem="this.dataObj"/>
        </ul>
        <ul v-else>
          <li
            v-if="this.scenarios!='2'"
            class="item">
            <span class="key">{{ this.$t('ReceiverName') }}</span>
            <span>{{ dataObj.receiverName }}</span>
          </li>
           <li
            v-if="this.scenarios =='32'"
            key="scenarios32"
            class="item">
            <!-- 二码合一后 32场景根据产品需求不展示 ReceiverAccount -->
            <span class="key">{{ this.$t('EwalletPromptPay') }}</span>
            <span>{{ dataObj.receiverWalletAccount }}</span>
          </li>
           <li
            v-else
            key="scenarios32"
            class="item">
            <!-- 二码合一后 32场景根据产品需求不展示 ReceiverAccount -->
            <span class="key">{{ this.$t('ReceiverAccount') }}</span>
            <span v-if="this.scenarios=='2'">{{ receiverAccount }}</span>
            <!-- 32 主扫	收款码 二码合一 自己系统生成的promptpay码   33	request to pay（AA收款 -->
            <span v-else-if="this.scenarios=='1'||this.scenarios=='32' || this.scenarios=='33'">{{ dataObj.receiverWalletAccount }}</span>
            <!-- 34 主扫外部的 promptpay码 -->
            <span v-else-if="this.scenarios=='3'||this.scenarios=='34'">{{ dataObj.promptAccountNo }}</span>
          </li>
          <li class="item"
            v-if="this.dataObj.status!='1'"
            >
            <span class="key">{{ this.$t('PaymentMethod') }}</span>
            <span>{{ bankWithName }}</span>
          </li>
          <li
            v-if="dataObj.remark"
            class="item">
            <span class="key">{{ this.$t('Notes') }}</span>
            <span>{{ dataObj.remark }}</span>
          </li>
        </ul>
      </div>
      <!-- <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">DONE</common-button>
      </div> -->
    </div>
    <guideFingerprintPay/>
    <!-- <succReturnPromo
      v-if="this.scenarios=='32'||this.scenarios == '34'"
    /> -->
    <succReturnPromo v-if="false"/>
  </div>

</template>
<script>
import { transferResult } from '@/api'
import moment from 'moment'
import processResult from '@/pages/balance/common/processResult'
import handlInitData from '@/mixins/handlInitData'
import bankWithName4 from '@/mixins/bankWithName4'
import resultFail from '@/pages/balance/common/resultFail'
import guideFingerprintPay from '@/pages/balance/common/guideFingerprintPay'
import succReturnPromo from '@/pages/promotion/common/SuccReturnPromo'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'
import Tag30Result from './transferPromptTag30/transferPromptTag30Result'

export default {
  name: 'TransferTh1Result',
  components: { resultFail, guideFingerprintPay, succReturnPromo, processResult, Tag30Result },
  mixins: [handlInitData, bankWithName4],
  data() {
    return {
      requestFinish: false,
      scenarios: '',
      showSuccess: true,
       titleRightMsg: {
        text: this.$t('DONE'),
        show: 1,
        textSize: 18,
        textColor: '#FF3E5B'
      },
      tag30ResultItemD: {}
    }
  },
  watch: {
    tag30ResultItemD: {
      handler (a,b) {
        console.log(a);
        console.log(b);
      },
      deep: true
    }
  },
  computed: {
    receiverAccount() {
      return `${this.dataObj.bankName} (${this.dataObj.bankAccount})`
    },
    createdDate() {
      return this.dataObj && this.dataObj.createdDate ? moment(this.dataObj.createdDate).format('Do MMM YYYY HH:mm:ss') : ''
    },
    modifiedDate() {
      return this.dataObj && this.dataObj.modifiedDate ? moment(this.dataObj.modifiedDate).format('Do MMM YYYY HH:mm:ss') : ''
    },
    successTime() {
      return this.dataObj && this.dataObj.successTime ? moment(this.dataObj.successTime).format('Do MMM YYYY HH:mm:ss') : ''
    }
  },
  created() {
    // 如果没有transOrderNo则为失败 不开启loading
    if (!this.$route.query.transOrderNo) {
      this.requestFinish = true
      this.showSuccess = false
    }
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('TransferResult'), // 需要一个通用的title
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
    this.$SDK.setTitleRight(this.titleRightMsg, () => {
      // 2019-04-30 新增罗印需求：扫码结果页这个是主扫转账，到余额和转账到promptpay，this.$SDK.goNativeMain()
      // done按钮埋点
      this.leaveBurryAndBtn()
      if (this.scenarios == '1') { // 1 Fin Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.TRANSFER_TOONEFIN_INPROCESS()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.TRANSFER_TOONEFIN_SUCCESSFULPAGE_DONE()
        }
        this.$SDK.goNativeMain()
      } else if (this.scenarios == '2') { // Bank Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.TRANSFER_TOBANKACCOUNT_INPROCESS()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToBankAccount_SuccessfulPage_DONE()
        }
        this.$SDK.closeWebViewAndSendResult()
      } else if (this.scenarios == '3') { // Promptpay Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_INPROCESS()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_DONE()
        }
        this.$SDK.goNativeMain()
      }
    })
  },
  beforeRouteLeave (to, from, next) {
    this.$indicator.close()
    this.leaveBurryAndBtn()
    next()
  },
  methods: {
    async initData() {
      this.$indicator.open({
        text: 'Loading...',
        spinnerType: 'fading-circle'
      })
      const res = await transferResult({
        version: this.$DeviceInfo.appVersion,
        transOrderNo: this.$route.query.transOrderNo
      })
      this.$indicator.close()
      this.requestFinish = true
      this.handlInitData(res, () => {
        if(this.dataObj.busiScenarios === '31') {
          // 转账
          this.scenarios = this.dataObj.transferChannel // 转账里面的三种渠道 
        } else {
          this.scenarios = this.dataObj.busiScenarios
        }
        this.entryBurry() // 这里确定拿到返回结果再进行判断做埋点处理
      })
    },
    leaveBurryAndBtn() {
      this.$SDK.setTitleRight({show:0})
      this.$SDK.setTitle({
        title: this.$t('TransferResult'), // 需要一个通用的title
        mHeaderTitle: {
          showEnd: 1
        }
      })
      if (this.scenarios == '1') { // 1 Fin Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOONEFIN_INPROCESS_LEAVE()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.TRANSFER_TOONEFIN_SUCCESSFULPAGE_LEAVE()
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.TRANSFER_TOONEFIN_FAILEDPAGE_LEAVE()
        }
      } else if (this.scenarios == '2') { // Bank Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_INPROCESS_LEAVE()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToBankAccount_SuccessfulPage_LEAVE()
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.Transfer_ToBankAccount_FailedPage_LEAVE()
        }
      } else if (this.scenarios == '3') { // Promptpay Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOPROMPTPAY_INPROCESS_LEAVE()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToPromptpay_SuccessfulPage_LEAVE()
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.Transfer_ToPromptPay_FailedPage_LEAVE()
        }
      }
    },
    entryBurry() {
      if (this.scenarios == '1') { // 1 Fin Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOONEFIN_INPROCESS_ENTRY()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.TRANSFER_TOONEFIN_SUCCESSFULPAGE_ENTRY()
          TRANSFER_BURRY.TRANSFER_PAYMENT_SUCCESS({
            revenueAamount: this.dataObj.amount,
            businessType: this.scenarios,
            paymentMethod1: this.dataObj.paymentMethod1,
            paymentMethod2: this.dataObj.paymentMethod2
          })
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.TRANSFER_TOONEFIN_FAILEDPAGE_ENTRY()
        }
      } else if (this.scenarios == '2') { // Bank Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_INPROCESS_ENTRY()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToBankAccount_SuccessfulPage_ENTRY()
          TRANSFER_BURRY.TRANSFER_PAYMENT_SUCCESS({
            revenueAamount: this.dataObj.amount,
            businessType: this.scenarios,
            paymentMethod1: this.dataObj.paymentMethod1,
            paymentMethod2: this.dataObj.paymentMethod2
          })
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.Transfer_ToBankAccount_FailedPage_ENTRY()
        }
      } else if (this.scenarios == '3') { // Promptpay Account 
        if(this.dataObj.status === 2) { // 处理中
          TRANSFER_BURRY.Transfer_TRANSFER_TOPROMPTPAY_INPROCESS_ENTRY()
        } else if (this.dataObj.status === 3) { // 成功页
          TRANSFER_BURRY.Transfer_ToPromptpay_SuccessfulPage_ENTRY()
          TRANSFER_BURRY.TRANSFER_PAYMENT_SUCCESS({
            revenueAamount: this.dataObj.amount,
            businessType: this.scenarios,
            paymentMethod1: this.dataObj.paymentMethod1,
            paymentMethod2: this.dataObj.paymentMethod2
          })
        } else if (this.dataObj.status === 4) { // 失败页
          TRANSFER_BURRY.Transfer_ToPromptPay_FailedPage_ENTRY()
        }
      }
    },
    tryAgain() {
      if (this.scenarios == '1') {
        TRANSFER_BURRY.TRANSFER_TOONEFIN_FAILEDPAGE_TRYAGAIN()
      } else if (this.scenarios == '2') {
        TRANSFER_BURRY.Transfer_ToBankAccount_FailedPage_TRYAGAIN()
      } else if (this.scenarios == '3') {
        TRANSFER_BURRY.Transfer_ToPromptPay_ReviewDetail_TRYAGAIN()
      }
      this.$router.push({ name: 'transfer' })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.container-result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-bottom: .2rem;
    padding-top: .2rem;
    .time-vertical {
      height: 4.33rem;
      box-sizing: border-box;
      background-color: #fff;
      padding: .36rem .4rem;
      padding-left: 1.09rem;
      .item {
        height: 0.85rem;
        line-height: 0.85rem;
        border-left: .02rem solid #d6d5d5;
        position: relative;
        .txt {
          line-height: initial;
          text-indent: .41rem;
          position: absolute;
          top: -.02rem;
          p{
            text-align: left
          }
          .txt-title {
            font-size: .32rem;
            color: $color-gray-a;
          }
          .txt-des {
            font-size: .20rem;
            color: $color-gray-c;
          }
        }
        &:nth-of-type(even) {
          height: 0.43rem;
          .txt {
            line-height: initial;
            text-indent: .41rem;
            position: absolute;
            top: -.36rem;
            p{
              text-align: left
            }
            .txt-title {
              font-size: .32rem;
              color: $color-gray-a;
            }
            .txt-des {
              font-size: .20rem;
              color: $color-gray-c;
            }
          }
        }
        &:last-of-type{
          border: none;
          height: 1.13rem;
        }
        &.item-ok {
          color: $color-blue;
          border-left: .02rem solid $color-blue;
        }
        img {
          position: absolute;
          left: -0.22rem;
          height: 0.44rem;
          width: 0.44rem;
        }
      }
      .item.not {
        border-color: #d6d5d5;
      }
    }
    .fee{
      font-size: 0.28rem;
      color: $color-gray-h;
      text-align: center;
    }
    .img {
      width: 1.4rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
    }
    .money{
      display: flex;
      align-items: center;
      justify-content: center;
      height: 1.1rem;
      line-height: 1.1rem;
      font-family: The1Official_Bold;
      font-size: 0.72rem;
      color: $color-red;
      text-align: center;
      span{
        font-size: 0.4rem;
        font-family: The1Official_Bold;
        margin-right: 0.1rem;
      }
    }
    .txt-des {
      // padding-top: .2rem;
      font-size: .32rem;
      color: $color-gray-h;
      text-align: center;
      .money {
        font-size: .32rem;
        color: $color-red;
        text-align: center;
        line-height: .38rem;
      }
    }
    .hide {
      opacity: 0;
    }
  }
  .notes {
    margin-top: .2rem;
    background: #Fff;
    height: 1.2rem;
    font-size: .28rem;
    color: $color-gray-h;
    line-height: .36rem;
    padding: .33rem .35rem .33rem .35rem;
    box-sizing: border-box;
  }
  .list {
    background-color: #fff;
    padding: .3rem .4rem;
    margin-top: .2rem;
    .item {
      display: flex;
      justify-content: space-between;
      word-break: break-all;
      padding-top: .2rem;
      padding-bottom: .2rem;
      font-size: .28rem;
      text-align: right;
      line-height: .42rem;
      color: $color-gray-g;
      .key {
        color: $color-gray-f;
      }
      span{
        max-width: 46%;
      }
    }
  }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
