<template>
  <div class="transfer-prompt-detail">
    <div class="padtop"/>
    <div class="detail-wrapper">
      <ul>
        <li>
          a
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  name: 'ReviewDetail'
}
</script>
<style lang="scss" scoped]>
@import "@/assets/css/var.scss";
.transfer-prompt-detail{
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  position: relative;
  .padtop{
    padding-top: .2rem;
  }
  .detail-wrapper{

  }
}
</style>
