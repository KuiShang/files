<template>
<!-- 转账到余额 -->
  <div class="blance-transfer-the1">
    <div class="padtop"/>
    <div class="input-wraper">
      <div
        v-show="customerObj"
        class="phone-result-wrapper"
        @click="showCommonInput"
      >
        <p class="tit">{{ this.$t('TransfertoPhoneNumber') }}</p>
        <div class="phone">
          <span>{{ customerObj.phone }} </span>
          <span class="gray">/ </span>
          <img
            :src="customerObj.iconUrl"
            class="img"
            alt="">
          <span class="gray"> {{ customerObj.customerName }}</span>
        </div>
      </div>
      <common-input
        v-show="!customerObj"
        ref="commonInput"
        v-model="number"
        :border="false"
        :maxlength="10"
        :show-suggest="true"
        :style-obj="{right: '.4rem'}"
        :fetch-suggestions="querySearch"
        type="tel"
        :holder="this.$t('TransfertoPhoneNumber')"
        @blur="phoneblur"
        @focus="inputFocus"
        @chooseItem="chooseNum"
        @handleClear="handlePhoneClear"
      />
      <img
        v-show="showContractEntry"
        class="custom-ico"
        src="@/assets/images/blance/the1/contact@3x.png"
        @click="gotoPhoneList"
      >

      <div
        v-show="notRegistered"
        class="phone-result-wrapper2"
        @click="showCommonInput"
      >
        <span class="not-registed">{{ this.$t('NoDolfinAccount') }}</span>
      </div>
      <div
        v-show="notVerified"
        class="phone-result-wrapper2"
        @click="showCommonInput"
      >
        <span class="not-registed">{{ this.$t('accountNotVerified') }}</span>
      </div>
    </div>
    <moneyInput
      v-model="amount"
      :notes-entry="true"
      :transfer-channel="TRANSFER_CHANNELS.ONT_FIN"
      :busi-scenarios="BUSI_SCENARIOS.TRANSFER"
      @addNotes="receiveNotes"
      @moneyFlag="receiveMoneyFlag"
    />
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">{{ this.$t('transfer') }}</common-button>
    </div>
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :current-busi-type= "ALL_BUSI_TYPE.TRANSFER_TH1"
      :transaction-no = "transactionNo"
      :trans-order-no = "transOrderNo"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import feeConfirm from '@/pages/balance/common/feeConfirm'
import moneyInput from '@/pages/balance/common/moneyInput'
import { createTransfer, queryByPhone } from '@/api'
import { TRANSFER_TYPE, BUSI_SCENARIOS, ENUM_ERRORCODE, ALL_BUSI_TYPE, TRANSFER_CHANNELS } from '@/utils/const'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'TransferThe1Account',
  components: { simpleCashier, feeConfirm, moneyInput },
  mixins: [hasPayError],
  data() {
    return {
      amount: '',
      cashierVisible: false,
      feeConfirmVisible: false,
      BUSI_SCENARIOS,
      TRANSFER_CHANNELS,
      ALL_BUSI_TYPE,
      number: '',
      customerObj: '',
      transactionNo: '',
      transOrderNo: '',
      showSuccesPhone: false,
      remark: '',
      moneyFlag: false,
      showContractEntry: true,
      notRegistered: false,
      notVerified: false
    }
  },
  computed: {
    btnok() {
      return this.moneyFlag && this.showSuccesPhone
    }
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.TRANSFER_TOONEFIN_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.TRANSFER_TOONEFIN_LEAVE()
    next()
  },
  async created() {
    // this.initData()
    this.$SDK.setTitle({
      title: this.$t('toDolfinAccount'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress(() => {
      this.$router.push({ name: 'transfer'})
    })
    if (this.$route.query.type === 'history') {
      const temp = await this.$SDK.getCache({
        key: 'transfer_hisory_account',
        cacheMode: 2
      })
      this.customerObj = JSON.parse(temp || '')
      this.$nextTick(async () => {
        const temp = await this.$SDK.getCache({
          key: 'transfer_hisory_account',
          cacheMode: 2
        })
        this.$refs.commonInput.currentValue = String(JSON.parse(temp || '').phone)
      })
      this.showSuccesPhone = true
    }
  },
  methods: {
    handleClick() {
      console.log('click')
      this.confirm()
    },
    async confirm() {
      const res = await createTransfer({
        version: this.$DeviceInfo.appVersion,
        recipientAccountNo: this.customerObj.customerId,
        amount: this.amount,
        currency: 'THB',
        deviceMsg: JSON.stringify(this.$DeviceInfo),
        busiType: TRANSFER_TYPE.NORMAL,
        transferChannel: TRANSFER_CHANNELS.ONT_FIN,
        remark: this.remark
      })
      if (res && res.data && res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
        TRANSFER_BURRY.TRANSFER_TOONEFIN_TRANSFER(null, this.amount)
      } else if (res && res.data && res.data.resultCode === 0) {
        const errorMsg = {
          code: res.data.errorData && res.data.errorData.code || '',
          msg: res.data.errorData && res.data.errorData.msg || ''
        }
        TRANSFER_BURRY.TRANSFER_TOONEFIN_TRANSFER(errorMsg, this.amount)
        this.hasPayError(res)
      }
    },
    async gotoPhoneList() {
      console.log('gotoPhoneList')
      TRANSFER_BURRY.TRANSFER_TOONEFIN_CONTACT()
      const phoneObj = await this.$SDK.goNativeCustomContact()
      console.log(phoneObj)
      if (phoneObj.status === 0) {
        console.log('未选择任何联系人')
        return
      }
      this.customerObj = ''
      if (String(phoneObj.outData.phone).length > 10) {
        this.$refs.commonInput.currentValue = String(phoneObj.outData.phone).substring(0, 10)
      } else {
        this.$refs.commonInput.currentValue = phoneObj.outData.phone
      }
      this.notRegistered = false
      this.notVerified = false
      // this.chooseNum(phoneObj.outData.phone)
      // this.$nextTick(() => {
      //   this.$refs.commonInput.$el.querySelector('input').focus()
      // })
      this.phoneblur()
    },
    async chooseNum(number) {
      console.log(number)
      // if (number.length > 10) {
      //   this.customerObj = ''
      //   this.notRegistered = true
      //   this.showSuccesPhone = false
      //   return
      // }
      if (number.length < 9) {
        return
      }
      const res = await queryByPhone({
        version: this.$DeviceInfo.appVersion,
        phone: number
      })
      if (res && res.data && res.data.resultCode === 1) {
        this.customerObj = res.data.resultData
        this.showSuccesPhone = true
         this.notRegistered = false
      } else if (res && res.data && res.data.errorData.code === ENUM_ERRORCODE.NOT_VERIFIED) {
        this.customerObj = ''
        this.notVerified = true
        this.showSuccesPhone = false
      } else if (res && res.data && res.data.errorData.code === ENUM_ERRORCODE.CUSTOMER_NO_EXIT) {
        this.customerObj = ''
        this.notRegistered = true
        this.showSuccesPhone = false
      } else if(res && res.data && res.data.errorData.code === ENUM_ERRORCODE.NOT_LOGIN) {
        this.$SDK.goNativeAction(res.data.actionData)
      } else {
        this.hasPayError(res)
      }
    },
    showCommonInput() {
      this.customerObj = ''
      this.notRegistered = false
      this.notVerified = false
      console.log(this.$refs.commonInput.$el.querySelector('input'))
      this.$nextTick(() => {
        this.$refs.commonInput.$el.querySelector('input').focus()
      })
    },
    paynow() {
      this.$router.push({ name: 'transferTh1Result', query: { transOrderNo: this.transOrderNo, transactionNo: this.transactionNo } })
    },
    phoneblur() {
      console.log('blur')
      this.showSuccesPhone = false
      this.$nextTick(() => {
        this.chooseNum(this.number)
        this.showContractEntry = true
      })
    },
    receiveNotes(notes) {
      this.remark = notes
    },
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    },
    inputFocus() {
      this.showContractEntry = false
    },
    async querySearch(queryString, cb) {
      if (queryString.length > 2) {
        const phoneList = await this.$SDK.getPhonesByNumber(queryString)
        console.log('phonelist:', phoneList)
        cb(phoneList)
      } else {
        cb([])
      }
    },
    handlePhoneClear() {
      this.notRegistered = false
      this.notVerified = false
    }
  },
  watch: {
    cashierVisible(value) {
      if (value == false) { // 关闭收银台 报进入
        TRANSFER_BURRY.TRANSFER_TOONEFIN_ENTRY()
      } else {
        TRANSFER_BURRY.TRANSFER_TOONEFIN_LEAVE()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.blance-transfer-the1 {
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  position: relative;
    .padtop {
      padding-top: .2rem;
    }
    .input-wraper {
      height: 1.4rem;
      background-color: #fff;
      margin-bottom: .2rem;
      padding-left: .4rem;
      position: relative;
      .custom-ico {
        position: absolute;
        top: 0.46rem;
        right: 0.48rem;
        width: .6rem;
      }
      .phone-result-wrapper {
        position: relative;
        .tit {
          position: absolute;
          left: 0;
          -webkit-transition: 0.3s linear;
          transition: 0.3s linear;
          z-index: 2;
          top: 0.25rem;
          font-size: .28rem;
          color: $color-gray-f;
        }
        .phone {
          height: 0.8rem;
          padding-top: 0.5rem;
          width: 100%;
          display: block;
          border: 0;
          outline: none;
          font-size: .4rem;
          z-index: 2;
          background: transparent;
          line-height: .8rem;
          .img {
            width: .4rem;
            height: .4rem;
            border-radius: 50%;
            vertical-align: middle;
            top: -0.04rem;
            position: relative;
          }
          .gray {
            color: $color-gray-c;
          }
          .not-registed {
            color: $color-red;
            font-size: .36rem;
          }
        }
      }
      .phone-result-wrapper2 {
         position: absolute;
         height: 1.4rem;
         top: 0;
         right: 1rem;
         left: 0;
        .not-registed {
          color: $color-red;
          font-size: .28rem;
          position: relative;
          top: .75rem;
          left: 3.2rem;
        }
      }
    }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}
</style>

