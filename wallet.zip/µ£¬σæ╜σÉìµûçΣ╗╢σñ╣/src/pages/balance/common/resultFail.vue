<template>
  <div
    :class="{ 'bg-white': bgWhite === true }"
    class="result-fail">
    <div class="head">
      <img
        class="img"
        src="@/assets/images/blance/the1/error@3x.png">
      <p class="txt-title"> {{ typeStr }}</p>
      <p
        v-if="showText"
        class="txt-des">{{ textDes }}</p>
    </div>

    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="handleClick">{{ showBtnMessage }}</common-button>
    </div>
  </div>
</template>
<script>
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'TopupFail',
  props: {
    typeStr: {
      type: String,
      default: ''
    },
    // 点击按钮的文案
    showBtnMessage: {
      type: String,
      default: vue.$t('TRYAGAIN')
    },
    // 按钮背景bgWhite ture 为白色背景
    bgWhite: {
      type: Boolean,
      default: false
    },
    // plainStatus true 为朴素按钮
    plainStatus: {
      type: Boolean,
      default: false
    },
    //showText  true 显示文本
    showText: {
      type: Boolean,
      default: true
    },
     //showText  true 显示文本
    textDes: {
      type: String,
      default: vue.$t('PleaseTryitlatter')
    }
  },
  methods: {
    handleClick() {
      console.log('click')
      // this.$router.push({ name: 'topup' })
      this.$emit('click')
      // lnwang TRY_AGAIN操作
      TRANSFER_BURRY.TRY_AGAIN(1)
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.result-fail.bg-white {
   background-color: $color-white;
}
.result-fail {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-top: .8rem;
    padding-bottom: 1rem;
    .img {
      width: 1.2rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: #302B2B;
      text-align: center;
      margin-top: .4rem;
    }
    .txt-des {
      padding-top: .3rem;
      font-size: .32rem;
      color: $color-gray-h;
      text-align: center;
    }
  }

  .btn-wraper {
    margin-top: .5rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
