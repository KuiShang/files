<template>
  <div
    v-show="showDialog"
    class="mask"
    @touchmove.stop.prevent
  >
    <div
      :style="currentStyle"
      class="dialog-wrapper"
      ref="dialogWraper"
    >
      <div class="title" :style="`height: ${titlePosition}rem`">
        <slot name="title"/>
      </div>
      <div class="content" :style="`font-size: ${fontSize}rem`" >
        <slot name="content"/>
      </div>
      <div class="btn-container">
        <div
          class="cancel"
          @click="$emit('cancle')"
          v-if="showCancle"
        >
          <slot name="cancle">{{ $t('Cancel') }}</slot>
        </div>
        <div
          :class="{shouldPlain: confirmBtnPlain}"
          class="confirm"
          @click="closeDialog"
        >
          <slot name="confirm">{{ $t('Yes') }}</slot>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Dialog',
  props: {
    position: {
      type: String,
      default: '0'
    },
    titlePosition: {
      type: Number,
      default: 0.6
    },
    fontSize: {
      type: Number,
      default: 0.36
    },
    showCancle: {
      type: Boolean,
      default: false
    },
    confirmBtnPlain: {
      type: Boolean,
      default: false
    },
    isPromotion: {
      type: Boolean,
      default: false
    },
    scrollY: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      showDialog: true
    }
  },
  computed: {
    currentStyle() {
      if (this.isPromotion) {
        return {
          'margin-top': `${this.position}px`,
          top: `calc(50vh + ${this.scrollY}px)`
        }
      } else {
        return {
          'margin-top': `${this.position}px`,
          top: '50%'
        }
      }
    }
  },
  created() {
    this.$nextTick(() => {
      const dialog = this.$refs.dialogWraper
      setTimeout(() => {
        dialog.style.opacity = 1
        dialog.style.transform = "translateY(-50%) translateX(-50%)  scale(1)"
      }, 50);
    })
  },
  methods: {
    closeDialog() {
      this.$emit('closeDialog')
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.mask{
  position: fixed;
  z-index: 6666;
  // top: 0.88rem;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0,0,0,0.40);
  display: flex;
  .dialog-wrapper{
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%) translateX(-50%) scale(.3);
    transition: 0.2s ease-out;
    opacity: 0.1; 
    overflow: hidden;
    width: 6.5rem;
    background: #FFFFFF;
    // border: 1px solid #979797;
    border-radius: 10px;
    position: absolute;
    .title{
      font-size: 0.4rem;
      letter-spacing: 0;
      text-align: center;
      line-height: 0.6rem;
      height: 0.6rem;
      margin-top: 0.48rem;
      margin-bottom: 0.62rem;
      letter-spacing: 0;
      text-align: center;
      p {
          font-size: 0.4rem;
          text-align: center;
          font-family: The1Official_Bold;
          color: #141E50;
      }
    }
    .content{
      p.tit{
        font-size: .36rem;
        color: $color-gray-g;
        letter-spacing: 0;
        text-align: center;
        line-height: 0.3rem;
      }
      p.amount{
        line-height: 1.1rem;
        font-family: The1Official_Bold;
        font-size: 0.72rem;
        color: $color-gray-g;
        letter-spacing: 0;
        text-align: center;
        span{
          font-family: The1Official_Bold;
          font-size: 0.36rem;
          letter-spacing: 0;
          text-align: center;
          margin-right: 0.18rem;
        }
      }
      p.text{
        font-size: 0.36rem;
        color: $color-gray-f;
        letter-spacing: 0;
        text-align: center;
        span{
          font-size: 0.36rem;
          color: #000020;
          letter-spacing: 0;
          text-align: center;
          line-height: 0.3rem;
        }
      }
      // border-bottom: 0.02rem solid $color-gray-e;
      padding: 0 .6rem .8rem .6rem;
      font-size: 0.40rem;
      color: $color-gray-g;
      letter-spacing: 0;
      text-align: center;
      line-height: 0.6rem;
    }
    .btn-container {
      display: flex;
      border-radius: .5;
      background-color: #fff;
      justify-content:space-around;
      .cancle {
        border-right: 0.02rem solid #E7E8ED;
      }
      .confirm{
        p{
          font-family: The1Official_Bold !important;
        }
        font-size: 0.4rem;
        height: 1.2rem;
        line-height: 1.2rem;
        background-color: $color-red;
        color: #fff;
        letter-spacing: 0;
        text-align: center;
        flex-grow: 1;
        flex: 1;
      }
      .shouldPlain {
        border-top: 0.02rem solid $color-gray-e;
        color: $color-red;
        background-color: #fff;
      }
      .cancel{
        p{
          font-family: The1Official_Bold !important;
        }
        font-size: 0.4rem;
        height: 1.2rem;
        line-height: 1.2rem;
        color: $color-gray-h;
        background-color: #fff;
        letter-spacing: 0;
        text-align: center;
        flex-grow: 1;
        flex: 1;
        border-top: 0.02rem solid $color-gray-e;
        box-sizing: border-box
      }
      .heigh1 {
        height: .1rem;
      }
    }
  }
}
</style>
