<template>
  <common-popup
    v-model="show"
    :close-on-click-modal="false"
    style="width:6.2rem;border-radius: .2rem; padding-top: .74rem;"
  >
    <div class="card">
      <img
        v-if="appGuideNeedDataMap.openBFFType === 'FACE'"
        src="@/assets/images/common/faceID@3x.png"
        class="img">
      <img
        v-else
        src="@/assets/images/common/touchID@3x.png"
        class="img">
      <p class="title">{{ $t('Enable') }} {{ touchOrFace }}</p>
      <p class="txt">{{ $t('By enabling') }} {{ touchOrFace }}, {{ $t('you can use your') }}  {{ fingerprintOrFace }} {{ $t('to replace PIN code for an easier and safer payment.') }}</p>
      <p
        class="btn btn1"
        @click="enable">{{ $t('ENABLE NOW') }}</p>
      <P
        class="btn btn2"
        @click="reamind"> {{ $t('REMIND ME LATER') }} </P>
      <P
        class="btn btn3"
        @click="notAsk"> {{ $t('DON\'T ASK AGAIN') }} </P>
    </div>
  </common-popup>
</template>
<script>

export default {
  name: 'GuideFingerprintPay',
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      appGuideNeedDataMap: {},
      faceid: this.$t('Face ID'),
      touchid: this.$t('Touch ID'),
      face: this.$t('face'),
      fingerprint: this.$t('fingerprint')
    }
  },
  computed: {
    show: {
      get() {
        return this.visible
      },
      set(val) {
        this.$emit('update:visible', val)
      }
    },
    touchOrFace() {
      const appGuideNeedDataMap = this.appGuideNeedDataMap || {}
      if (appGuideNeedDataMap.openBFFType === 'FACE') {
        return this.faceid
      }
      return this.touchid
    },
    fingerprintOrFace() {
      const appGuideNeedDataMap = this.appGuideNeedDataMap || {}
      if (appGuideNeedDataMap.openBFFType === 'FACE') {
        return this.face
      }
      return this.fingerprint
    }
  },
  async created() {
    // this.visible = true
    const notAsk = await this.$SDK.putCache({
      key: 'notAskGuideFingerPay',
      cacheMode: 2
    })
    console.log('notAsk', notAsk)
    let appGuideNeedDataMap = ''
    const appGuideNeedDataMapStr = await this.$SDK.getCache({
      key: 'appGuideNeedDataMap',
      cacheMode: 2
    })
    if (appGuideNeedDataMapStr && appGuideNeedDataMapStr !== 'undefined') {
      try {
        appGuideNeedDataMap = JSON.parse(appGuideNeedDataMapStr)
      } catch (error) {
        console.error('捕获到json解析错误', appGuideNeedDataMapStr )
      }
      }
    if (!appGuideNeedDataMap) {
      return
    }
    this.appGuideNeedDataMap = appGuideNeedDataMap
    if (!appGuideNeedDataMap.canOpenBFF) {
      return
    }
    if (notAsk) {
      return
    }
    this.appGuideNeedDataMap = appGuideNeedDataMap
    this.visible = true
  },
  methods: {
    async enable() {
      console.log('enable')
      this.visible = false
      // alert(JSON.stringify(this.appGuideNeedDataMap))
      console.log('this.appGuideNeedDataMap:', this.appGuideNeedDataMap)
      // console.log('去指纹支付的actiondata：', this.appGuideNeedDataMap.guideUrl.actionData)
      const ret = await this.$SDK.goNativeAction(this.appGuideNeedDataMap.guideUrl.actionData)
      console.log('去指纹支付结果：', ret)
    },
    reamind() {
      this.visible = false
    },
    notAsk() {
      this.visible = false
      console.log('notAsk')
      this.$SDK.putCache({
        key: 'notAskGuideFingerPay',
        value: 'notAsk',
        cacheMode: 2
      })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.card {
  border-radius: .2rem;
  text-align: center;
  font-size: .36rem;
  color: $color-gray-g;
  .img {
    padding-bottom: .64rem;
    width: 1rem;
  }
  .title {
    font-family: The1Official_Bold;
  }
  .txt {
    line-height: .48rem;
    padding: .16rem .36rem .62rem .36rem;
  }
  .btn {
    line-height: 1.1rem;
    box-sizing: border-box;
    border-top: 1px solid $color-gray-e;
    font-family: The1Official_Bold;
    color: $color-gray-c;
  }
  .btn1 {
    color: $color-red;
  }
}
</style>
