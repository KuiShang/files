<template>
  <div class="result">
    <div v-if="showSuccess">
      <div class="head">
        <img
          class="img"
          src="@/assets/images/blance/the1/success_big@3x.png"
          alt="duigou">
        <p class="txt-title">{{ $t('Added successfully') }}</p>
        <p class="txt-des">{{ $t('You can use this account now') }}</p>
      </div>
      <div class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">{{ $t('DONE')}}</common-button>
      </div>
    </div>
    <resultFail
      v-else
      :plain-status="true"
      :bg-white="false"
      :type-str="AddAccountFailed"
      :text-des="textDes"
      @click="tryAgain"/>
  </div>
</template>
<script>
import resultFail from '@/pages/balance/common/resultFail'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'AddBankAccountResult',
  components: { resultFail },
  computed: {
    showSuccess() {
      const showStatus = this.$utils.getQueryString('result');
      if (showStatus === '1') {
        return true;
      }
      return false;
    },
    sendSdkResult() {
      const showStatus = this.$utils.getQueryString('result');
      if (showStatus === '1') {
        return {
          resultCode: 1
        };
      }
      return {
        resultCode: 0
      };
    },
    AddAccountFailed() {
      let str =  this.$t('AddAccountFailed')
      if (this.$route.query.type === 'CARD') {
        str = this.$t('Add Card Failed!')
      }
      return str
    },
    textDes() {
      let str =  this.$t('PleaseTryitlatter')
      if (this.$route.query.type === 'CARD') {
        str = this.$t('Recheck your information and try again')
      }
      return str
    }
  },
  created() {
    let str =  this.$t('Add Bank Account')
    const showStatus = this.$utils.getQueryString('result');
    if (showStatus === '1') {
       TRANSFER_BURRY.BIND_ACCOUNT_SUCCESS()
       // lnwang 添加银行帐户成功
       this.$SDK.onBackPress( () => {
         TRANSFER_BURRY.BACK(1)
       })
    } else {
        this.$SDK.onBackPress( () => {
         TRANSFER_BURRY.BACK(2)
       })
    }
    if (this.$route.query.type === 'CARD') {
      str = this.$t('add Credit/Debit Card');
      this.$SDK.onBackPress( () => {
         TRANSFER_BURRY.BACK(4)
      })
    }
    
    this.$SDK.setTitle({
      title: str,
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
  },
  methods: {
    handleClick() {
      // 增加js桥，调用关闭并给结果
      this.$SDK.closeWebViewAndSendResult(this.sendSdkResult);
      // lnwang  完成按钮
      TRANSFER_BURRY.DONE()
    },
    tryAgain() {
      if (this.$route.query.type === 'CARD') {
        this.$SDK.closeWebView();
        // lnwang
        TRANSFER_BURRY.TRY_AGAIN(2);
      } else {
        this.$SDK.closeWebViewAndSendResult(this.sendSdkResult);
      }
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: $color-white;
    box-sizing: border-box;
    text-align: center;
    padding-top: .8rem;
    padding-bottom: .6rem;
    .img {
      width: 1.2rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
      margin-top: .4rem;
    }
    .hide {
      opacity: 0;
      display: none;
    }
  }

  .btn-wraper {
    margin-top: .8rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
  .txt-des {
  padding-top: .3rem;
  font-size: .32rem;
  color: $color-gray-h;
  text-align: center;
}
}
</style>
