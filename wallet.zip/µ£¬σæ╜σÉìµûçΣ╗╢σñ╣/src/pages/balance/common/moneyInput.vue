<template>
  <div class="money-input-card">
    <p
      :class="['des', { 'input-focus': active }]"
    >{{ title }} </p>
    <common-field
      v-model="amount"
      :readonly= "readonly"
      :maxlength= "9"
      :type="type"
      label=""
      font-size=".96rem"
      placeholder="0"
      class="custom-common-field"
      @blur="check"
      @input="input"
      @focus="inputFocus"
    >
      <span
        slot="afterfix"
        class="afterfix-txt">{{ $t('Baht') }}</span>
    </common-field>
    <p
      v-show="isLowerOnceAmount && !isAvailable"
      class="tips"> {{ $t('Minimum amount is') }} ฿{{ timeLowerAmount | tofloat | thousandBitSeparator }}</p>
    <p
      v-show="isAvailable"
      class="tips">
      <span v-if="channelType === 'transfer'">
        {{ $t('The transfer amount exceed limit, you can transfer for the maximum at') }} ฿{{ availableAmount | tofloat | thousandBitSeparator }}
      </span>
       <span v-else>
        {{ $t('The topup amount exceed limit, you can topup for the maximum at') }} ฿{{ availableAmount | tofloat | thousandBitSeparator }}
      </span>
    </p>
    <!-- 今日还可转 -->
    <p
      v-show="(currentLimitType === LIMIT_TYPE.DAY) && showErrorTip && !isAvailable"
      class="tips"> {{ $t('Daily limit is') }} ฿{{ dayLimitAmount | tofloat | thousandBitSeparator }}</p>
    <p
      v-show="(currentLimitType === LIMIT_TYPE.TIMES) && showErrorTip && !isAvailable"
      class="tips">{{ $t('Transaction limit is') }} ฿{{ timeLimitAmount | tofloat | thousandBitSeparator }}</p>
    <p
      v-show="hasFee"
      class="fee"
    >
        <template v-if="fee==0">
          {{ this.$t('nofee') }}
        </template>
        <template v-else>
          {{ $t('Service fee is') }} {{ fee | tofloat | thousandBitSeparator  }}
        </template>
      </p>
    <div
      v-show="notesEntry"
      class="add-notes-wraper">
      <common-input
        v-if="!showNotes"
        ref="commonInput"
        v-model="notes"
        :border="false"
        :maxlength="30"
        :style-obj="{right: '.4rem'}"
        :holder="this.$t('addNotes')"
        @blur="checkNotes"
        @input="emitNotes"
      />
    </div>
    <toast
      :show-cancle="true"
      v-if="showDialog"
      @cancle="cancle"
      @closeDialog="closeDialog"
      >
      <p slot="title">{{ this.$t('VerifyYouridentity') }}</p>
      <p slot="content">
        <template
          v-if="channelType=='transfer'">
          {{ this.$t('VerifyTransferText') }}
        </template>
        <template
          v-else
        >
          {{ this.$t('VerifyTopupText') }}
        </template>
      </p>
      <p slot="cancle">{{ this.$t('NOTNOW') }}</p>
      <p slot="confirm">{{ this.$t('OK') }}</p>
    </toast>
  </div>
</template>
<script>
import handlInitData from '@/mixins/handlInitData'
import topupAndTransTh1 from '@/mixins/topupAndTransTh1'
import noKyc from '@/mixins/noKyc'
import hasPayError from '@/mixins/hasPayError'
import { queryOnceLimit } from '@/api'

export default {
  name: 'MoneyInput',
  mixins: [handlInitData, hasPayError, topupAndTransTh1, noKyc],
  props: {
    channelType: {
      type: String,
      default: 'transfer'
    },
    transferChannel: {
      type: Number,
      default: 0
    },
    title: {
      type: String,
      default: function() {
        return this.$t('Transfer Amount')
      }
    },
    btnText: {
      type: String,
      default: 'Transfer All'
    },
    notesEntry: {
      type: Boolean,
      default: false
    },
    busiScenarios: {
      type: String,
      default: ''
    },
    hasFee: {
      type: Boolean,
      default: false
    },
    fee: {
      type: String,
      default: ''
    },
    readonly: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      amount: '',
      active: false,
      showNotes: false,
      notes: '',
      showErrorTip: false
    }
  },
  computed: {
    type() {
      let type = 'number'
      const ua = navigator.userAgent.toLowerCase();
      const isAndroid = ua.indexOf('android') > -1 || false;
      if (isAndroid) {
        type = 'tel'
      }
      return type
    },
    isLowerOnceAmount() {
      if (this.amount=='' || Number(this.amount).toFixed(2) === '0.00') {
        return false
      }
      return -this.amount > -this.timeLowerAmount
    },
    isAvailable() {
      if (this.amount=='' || Number(this.amount).toFixed(2) === '0.00') {
        return false
      }
      return this.amount > this.availableAmount
    }
  },
  watch: {
    amount(val) {
      // if (this.currentLimitType === '') {
      //   this.initData()
      // }
      const value = typeof val === 'number' ? String(val) : val
      this.$emit('input', value);
      if (value.trim().length === 0) {
        this.active = false
      }
      const amount = Number(value)
      if (isNaN(amount)) {
        this.$emit('moneyFlag', false)
        this.showErrorTip = false
        return
      }
      if (this.amount === '' || amount.toFixed(2) === '0.00') {
        this.$emit('moneyFlag', false)
        this.showErrorTip = false
        return
      }
      let limitMoney = 0
      if (this.currentLimitType === this.LIMIT_TYPE.TIMES) {
        limitMoney = this.timeLimitAmount
      } else {
        limitMoney = this.dayLimitAmount
      }
      if (amount <= limitMoney) {
        if (amount < this.timeLowerAmount) {
          this.$emit('moneyFlag', false)
        } else if (amount > this.availableAmount) {
          this.$emit('moneyFlag', false)
        } else {
          this.$emit('moneyFlag', true)
          this.showErrorTip = false
        }
      } else {
        this.$emit('moneyFlag', false)
        this.showErrorTip = true
      }
    }
  },
  created() {
    this.initData()
  },
  methods: {
    async initData() {

      this.$indicator.open({
        text: 'Loading...',
        spinnerType: 'fading-circle'
      })
      const res = await queryOnceLimit({
        version: this.$DeviceInfo.appVersion,
        busiScenarios: this.busiScenarios,
        transferChannel: this.transferChannel
      })
      this.$indicator.close()
      if (res.data.resultCode === 0) {
        if (res.data.errorData.code == 'TWA4400005') {
          // kyc等级过低
          this.actionData = res.data.actionData
          this.showDialog = true
          this.$SDK.onForeground(() => {
            // alert('回到前台，查询kyc,初始化数据');
            this.initData();
          })
        } else {
          this.hasPayError(res)
        }
      } else {
        this.handlInitData(res, () => {
          this.computedCurrentLimitType()
          this.$emit('moneyLimitOk')
        })
      }
    },
    check() {
      if (String(this.amount).trim().length === 0) {
        this.active = false
      }
      this.$emit('blur', this.amount)
    },
    input() {
      this.$emit('input', this.amount)
    },
    inputFocus() {
      this.active = true
    },
    addNotes() {
      this.showNotes = true
      this.$nextTick(() => {
        this.$refs.transInput.focus()
      })
    },
    checkNotes() {
      if (!this.notes.trim()) {
        this.showNotes = false
      }
    },
    emitNotes() {
      this.$emit('addNotes', this.notes)
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.hide {
  display: none !important;
}
.money-input-card {

  box-sizing: border-box;
  background: $color-white;
  padding: .62rem 0rem 0 .4rem;




  .des {
    font-size: .28rem;
    color: $color-gray-f;
    padding-bottom: 5px;
    padding-right: .4rem;
    word-break: break-all;
  }
  .input-focus {
    color: $color-gray-f;
  }
  .tips {
    padding-top: .20rem;
    line-height: .42rem;
    letter-spacing: 0;
    text-align: left;
    font-size: .28rem;
    color: $color-red;
    padding-right: .4rem;
  }
  .fee{
    padding-top: .16rem;
    padding-bottom: .48rem;
    line-height: .42rem;
    letter-spacing: 0;
    text-align: left;
    font-size: .28rem;
    color: $color-gray-f;
  }
  .afterfix-txt {
    font-size: .28rem;
    color: $color-gray-g;
  }
  .custom-common-field {
    padding-right: .4rem;
  }
  .add-notes-wraper {
    padding-bottom: .2rem;
    padding-top: .2rem;
    .add-notes {
      padding-top: .75rem;
      padding-bottom: .4rem;
      font-size: .40rem;
      color: $color-gray-f;
    }
  }
  .notes-input-container {
    padding-top: .2rem;
    padding-bottom: .3rem;
    .trans-notes {
      font-size: .28rem;
      color: $color-gray-f;
      padding-top: .5rem;
    }
    .trans-input {
      font-size: .40rem;
      color: $color-gray-g;
      border: none;
      outline: none;
      padding-top: .05rem;
      padding-bottom: .2rem;
      width: 100%;
    }
  }
}
</style>

<style lang="scss">
.money-input-card {
      .mint-field-core {
  font:1px The1Official_Bold;
  font-family: The1Official_Bold ;
  color: initial;
}

}


</style>

