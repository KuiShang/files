<template>
  <messagebox
    v-model="show"
    :show-cancel-button= "true"
    confirm-button-text="Yes"
    cancel-button-text="Cancle"
    @confirm="$emit('confirm')"
    @cancel="$emit('cancel')"
  >
    <div class="content-wraper">
      <p class="title">{{ this.$t('TransferAmount') }}</p>
      <p class="money"><span class="bi">฿</span>{{ money }}</p>
      <p class="des">Recipient will receive <span class="blacka">฿{{ money }}</span>, service fee <span class="blacka">฿{{ fee }}</span>(in <span class="red">2</span>hours)</p>
    </div>
  </messagebox>
</template>
<script>
export default {
  name: 'FeeConfirm',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    money: {
      type: String,
      default: ''
    },
    fee: {
      type: String,
      default: ''
    }
  },
  computed: {
    show: {
      get() {
        return this.visible
      },
      set(val) {
        this.$emit('update:visible', val)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.content-wraper {
  padding: .54rem .4rem;
  .title {
    font-size: .32rem;
    color: $color-gray-a;
    letter-spacing: 0;
    text-align: center;
    line-height: .58rem;
  }
  .money {
    font-size: .60rem;
    color: $color-gray-a;
    text-align: center;
    line-height: .90rem;
    .bi {
      font-size: .40rem;
      color: $color-gray-a;
      text-align: center;
      position: relative;
      top: -0.14rem;
    }
  }
  .des {
    font-size: .24rem;
    color: $color-gray-c;
    letter-spacing: 0;
    line-height: .36rem;
    padding-top: .3rem;
    .blacka {
      color:$color-gray-a;
    }
    .red {
      color:$color-red;
    }
  }
}
</style>
