<template>
  <div class="result">
    <div class="head">
      <ul class="time-vertical">
        <li class="item item-ok">
          <i class="border-start"/>
          <i class="border-bgc"/>
          <common-icon
            slot="icon"
            class="custom-ico"
            name="success1"
            size=".64rem"
            style="color:#4d7bfe"
          />
          <div class="txt">
            <p class="txt-title">{{ typeStr }} Successfully</p>
            <p class="txt-des">{{ createdDate }}</p>
          </div>
        </li>
        <li
          :class="{ 'item-ok': dataObj.status >= 2 }"
          class="item">
          <i class="border-bgc"/>
          <common-icon
            slot="icon"
            :class="{ 'iconOk': dataObj.status >= 2 }"
            class="custom-ico"
            name="success1"
            size=".64rem"
          />
          <div class="txt">
            <p class="txt-title">Bank Processing</p>
            <p class="txt-des">{{ modifiedDate }}</p>
          </div>
        </li>
        <li
          :class="{ 'item-ok': dataObj.status >= 3 }"
          class="item">
          <i class="border-end"/>
          <i class="border-bgc"/>
          <common-icon
            slot="icon"
            :class="{ 'iconOk': dataObj.status >= 3 }"
            class="custom-ico rotat"
            name="eae"
            size=".52rem"
          />
          <div class="txt">
            <p class="txt-title">{{ typeStr }} Sucess</p>
            <p class="txt-des">{{ successTime }}</p>
          </div>
        </li>
      </ul>
    </div>
    <ul class="list">
      <li class="item">
        <span class="key">{{ typeStr }} Amount</span>
        <span>฿ {{ dataObj.amount }}</span>
      </li>
      <li class="item">
        <span class="key">Payee Name</span>
        <span>{{ dataObj.payeeName }}</span>
      </li>
      <li class="item">
        <span class="key">Payee Bank Account</span>
        <span>{{ bankWithName }}</span>
      </li>
      <li class="item">
        <span class="key">Transaction No.</span>
        <span>{{ dataObj.transOrderNo }}</span>
      </li>
    </ul>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="handleClick">{{ $t('DONE') }}</common-button>
    </div>
  </div>
</template>
<script>

import bankWithName4 from '@/mixins/bankWithName4'

export default {
  name: 'ProcessResult',
  mixins: [bankWithName4],
  props: {
    typeStr: {
      type: String,
      default: ''
    },
    dataObj: {
      type: [Object, Array],
      default: () => {}
    }
  },
  computed: {
    createdDate() {
      return this.dataObj && this.dataObj.createdDate ? new Date(this.dataObj.createdDate).format("dd-MM-yyyy hh:mm:ss") : "";
    },
    modifiedDate() {
      return this.dataObj && this.dataObj.modifiedDate ? new Date(this.dataObj.modifiedDate).format("dd-MM-yyyy hh:mm:ss") : "";
    },
    successTime() {
      return this.dataObj && this.dataObj.successTime ? new Date(this.dataObj.successTime).format("dd-MM-yyyy hh:mm:ss") : "";
    }
  },
  methods: {
    handleClick() {
      this.$emit('click')
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.result {
  font-size: .28rem;
  height: 100%;
  background-color: #f6f6f6;
  .head {
    .time-vertical {
      height: 4.33rem;
      box-sizing: border-box;
      background-color: #fff;
      padding: .36rem .4rem;
      padding-left: 1.09rem;
      .item {
        height: 1.13rem;
        line-height: 1.13rem;
        border-left: .02rem solid #d6d5d5;
        position: relative;
        .custom-ico {
          position: absolute;
          left: 0;
          top: 0;
          left: -0.3rem;
          z-index: 2;
          color: #d6d5d5;
        }
        .iconOk {
          color: #4d7bfe;
        }
        .rotat {
          transform:rotateY(180deg);
          left: -0.27rem;
        }
        .border-start {
          width: .02rem;
          height: 0.4rem;
          background-color: #fff;
          position: absolute;
          left: 0;
          top: 0;
          top: 0em;
          z-index: 1;
          left: -0.01rem;
        }
        .border-bgc {
          width: .02rem;
          height: 0.4rem;
          background-color: #fff;
          position: absolute;
          left: 0;
          top: 0;
          top: 1.3em;
          z-index: 1;
          left: -0.01rem;
        }
        .border-end {
          width: .02rem;
          height: 0.4rem;
          background-color: #fff;
          position: absolute;
          left: 0;
          bottom: 0;
          z-index: 1;
          left: -0.01rem;
        }
        .txt {
          line-height: initial;
          text-indent: .41rem;
          .txt-title {
            padding-top: .37rem;
            font-size: .32rem;
            color: $color-gray-a;
          }
          .txt-des {
            padding-top: .06rem;
            font-size: .20rem;
            color: $color-gray-c;
          }
        }
      }

      .item-ok {
        color: #4d7bfe;
        border-left: .02rem solid #4d7bfe;
      }
      .item.not {
        border-color: #d6d5d5;
      }
    }
  }
  .list {
    background-color: #fff;
    padding: .3rem .4rem;
    margin-top: .2rem;
    .item {
      display: flex;
      justify-content: space-between;
      height: .9rem;
      font-size: .28rem;
      color: #302B2B;
      text-align: right;
      line-height: .52rem;
      .key {
        color: #838080;
      }
    }
  }
  .btn-wraper {
    margin-top: .8rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
}
</style>
