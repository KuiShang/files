<template>
  <common-popup
    v-model="show"
    position="bottom"
    style="width:100%"
  >
    <div class="select-bank-account">
      <div class="title">
        <span>Select a Bank Account</span>
        <common-icon
          class="custom-ico"
          name="close"
          size=".5rem"
          @click="close()"
        />
      </div>
      <div class="item">
        <common-item
          v-for="(item, index) in list"
          :key="index"
          :title="item.bankName"
          :label="bankNameAndNum(item)"
          icon-color="#4D7BFE"
          @click="$emit('selectBank', index)"
        >
          <img
            slot="img"
            :src="item.h5Logo"
            class="img"
          >
          <common-icon
            v-if="currentIndex === index"
            slot="icon"
            class="custom-ico"
            name="selected"
            size=".5rem"
            style="color:#4D7BFE"
          />
        </common-item>
        <common-item
          v-if="showAnother"
          title=" To Other Bank Account"
          @click="$emit('goOtherBankAccount')"
        >
          <img
            slot="img"
            class="img"
            src="@/assets/images/blance/success.png">
          <common-icon
            slot="icon"
            name="more"
            size=".3rem"
          />
        </common-item>
      </div>
    </div>
  </common-popup>
</template>
<script>
export default {
  name: 'SelectBankAccount',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    showAnother: {
      type: Boolean,
      default: true
    },
    list: {
      type: Array,
      default: () => []
    },
    currentIndex: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
    }
  },
  computed: {
    show: {
      get() {
        return this.visible
      },
      set(val) {
        this.$emit('update:visible', val)
      }
    }
  },
  watch: {
  },
  methods: {
    close() {
      this.$emit('update:visible', false)
    },
    handleClick() {
      console.log('click')
    },
    bankNameAndNum(item) {
      const num4 = item.accountNo ? item.accountNo.substring(0, 4) : 0
      return item.accountNo ? `${item.bankName}(${num4} )` : ''
    }
  }
}
</script>
<style lang="scss" scoped>
.select-bank-account {
  font-size: .32rem;
  height: 10rem;
  .title {
    height: 1.2rem;
    line-height: 1.2rem;
    text-align: center;
    box-sizing: border-box;
    border-bottom: 1px solid #ddd;
    position: relative;
    .custom-ico {
      position: absolute;
      right: .34rem;
    }
  }
  .item {
    padding: 0 .4rem 0 .4rem;
  }
}
</style>

