<template>
  <div class="blance-withdraw">
    <p class="little-txt">Money withdraw will be successed within <span class="red">1</span> working day</p>
    <div class="account-wraper">
      <common-item
        v-if="currentBank.accountName"
        :title=" currentBank.accountName"
        :label="bankNameAndNum"
        icon-color="#4D7BFE"
        @click="changeBank"
      >
        <i
          slot="img"
          :style="{backgroundImage: 'url(' + currentBank.bankIconUrl + ')'}"
          class="img"
        />
        <common-icon
          slot="icon"
          class="custom-ico"
          name="selected"
          size=".5rem"
          style="color:#4D7BFE"
        />
      </common-item>
      <common-item
        v-else
        title="No bank account available"
        label="please enter the amount and press the button to add new"
        icon-color="#4D7BFE"
        @click="goOtherBankAccount"
      >
        <img
          slot="img"
          src="@/assets/images/blance/ic_account_balance.png"
          class="img"
        >
      </common-item>
    </div>
    <moneyInput
      v-model="amount"
      :limit-money="balanceAmount"
      title="Withdraw Amount"
      btn-text="Withdraw All"
    />
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">WITHDRAW</common-button>
    </div>
    <selectBankAccount
      :visible.sync="selectBankAccountVisible"
      :list = "dataObj.bankAccountInfoList"
      :current-index="currentIndex"
      @selectBank = "selectBank"
      @goOtherBankAccount="goOtherBankAccount"
    />
    <feeConfirm
      :visible.sync="feeConfirmVisible"
      :money="amount"
      :fee="fee"
      @confirm="confirm"
    />
  </div>
</template>
<script>
import selectBankAccount from '@/pages/balance/common/selectBankAccount'
import feeConfirm from '@/pages/balance/common/feeConfirm'
import moneyInput from '@/pages/balance/common/moneyInput'
import { withdrawBegin, withdrawPage, withdrawPwd, withdrawOtp } from '@/api'
import { enumCurrency, ENUM_ERRORCODE } from '@/utils/const'
import handlInitData from '@/mixins/handlInitData'

export default {
  name: 'Withdraw',
  components: { selectBankAccount, feeConfirm, moneyInput },
  mixins: [handlInitData],
  data() {
    return {
      amount: '',
      selectBankAccountVisible: false,
      feeConfirmVisible: false,
      currentIndex: 0,
      transactionNo: '',
      transOrderNo: ''
    }
  },
  computed: {
    fee() {
      return this.dataObj.fee
    },
    balanceAmount() {
      return String(this.dataObj.balanceAmount)
    },
    btnok() {
      return (Number(this.amount) <= this.balanceAmount) && this.amount.length > 0 && this.dataObj.bankAccountInfoList.length > 0
    },
    currentBank() {
      if (this.dataObj && this.dataObj.bankAccountInfoList && this.dataObj.bankAccountInfoList[this.currentIndex]) {
        return this.dataObj.bankAccountInfoList[this.currentIndex]
      }
      return {}
    },
    bankNameAndNum() {
      const num4 = this.currentBank.accountNo ? this.currentBank.accountNo.substring(this.currentBank.accountNo.length - 4) : 0
      return this.currentBank.accountNo ? `${this.currentBank.bankName}(${num4} )` : ''
    }
  },
  created() {
    this.initData()
  },
  methods: {
    async initData() {
      const res = await withdrawPage({
        version: this.$DeviceInfo.appVersion
      })
      this.handlInitData(res)
    },
    handleClick() {
      console.log('click')
      this.feeConfirmVisible = true
    },
    changeBank() {
      console.log('changeBank')
      this.selectBankAccountVisible = true
    },
    selectBank(idx) {
      this.selectBankAccountVisible = false
      console.log(idx)
      this.currentIndex = idx
    },
    async confirm() {
      const res = await withdrawBegin({
        version: this.$DeviceInfo.appVersion,
        amount: this.amount,
        currency: enumCurrency.THB,
        cardId: this.currentBank.cardId,
        fee: this.dataObj.fee
      })
      if (res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        const ret = await this.$SDK.goNativeAction(res.data.actionData)
        console.log('输入密码后结果：', ret)
        const pwdret = await withdrawPwd({
          version: this.$DeviceInfo.appVersion,
          transOrderNo: this.transOrderNo,
          securityId: ret.outData.csSNNumber,
          riskId: ret.outData.riskId,
          validateType: ret.outData.validateType,
          sence: ret.outData.scene,
          deviceMsg: JSON.stringify(this.$DeviceInfo)
        })
        console.log(pwdret)
        if (pwdret.data.resultCode === 1) {
          if (pwdret.data.actionData) {
            // 其他接口都是resultCode = 0 時候 在判断errcode情况 在特定的情况跳转actiondata
            // 此接口特殊处理 在1 的时候返回是需要加验 所以通过是否有actiondata 来判断是否要跳转
            const afterpwdret = await this.$SDK.goNativeAction(pwdret.data.actionData)
            console.log('afterpwdret', afterpwdret)
            const otpret = await withdrawOtp({
              version: this.$DeviceInfo.appVersion,
              transOrderNo: this.transOrderNo,
              securityId: afterpwdret.outData.csSNNumber,
              riskId: afterpwdret.outData.riskId,
              validateType: afterpwdret.outData.validateType,
              sence: afterpwdret.outData.scene,
              deviceMsg: JSON.stringify(this.$DeviceInfo)
            })
            if (otpret.data.resultCode === 1) {
              this.$router.push({ name: 'withdrawResult', query: { transOrderNo: res.data.resultData.transOrderNo } })
            } else {
              // this.$messagebox('提示', otpret.data.errorData.msg)
              this.$toast({
                message: otpret.data.errorData.msg,
                position: 'middle',
                duration: 5000
              })
            }
          } else {
            this.$router.push({ name: 'withdrawResult', query: { transOrderNo: res.data.resultData.transOrderNo } })
            console.log('轉賬成功')
          }
        } else if (pwdret.data.resultCode === 0) {
          // this.$messagebox('提示', pwdret.data.errorData.msg)
          this.$toast({
            message: pwdret.data.errorData.msg,
            position: 'middle',
            duration: 5000
          })
        }
      } else if (res.data.resultCode === 0) {
        if (ENUM_ERRORCODE.NO_KYC === res.data.errorData.code) {
          await this.$SDK.goNativeAction(res.data.actionData)
        } else {
          // this.$messagebox('提示', res.data.errorData.msg)
          this.$toast({
            message: res.data.errorData.msg,
            position: 'middle',
            duration: 5000
          })
        }
      }
    },
    goOtherBankAccount() {
      this.$SDK.goNativeActionAddCard()
      console.log('跳转绑卡')
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.blance-withdraw {
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-e;
  .little-txt {
    padding: 0 .3rem;
    line-height: .72rem;
    background: #F6F6F6;
    .red {
      color: #FC3438;
    }
  }
  .account-wraper {
    background-color: #fff;
    padding: 0 .4rem;
    margin-bottom: .2rem;
  }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}
</style>
