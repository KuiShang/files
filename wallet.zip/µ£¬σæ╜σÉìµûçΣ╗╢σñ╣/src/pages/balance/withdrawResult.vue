<template>
  <processResult
    :data-obj = "dataObj"
    type-str = "Withdraw"
    @click="handleClick"
  />
</template>
<script>
import processResult from '@/pages/balance/common/processResult'
import { withdrawResult } from '@/api'
import handlInitData from '@/mixins/handlInitData'

export default {
  name: 'WithdrawResult',
  components: { processResult },
  mixins: [handlInitData],
  created() {
    this.initData()
  },
  methods: {
    async initData() {
      const res = await withdrawResult({
        version: this.$DeviceInfo.appVersion,
        transOrderNo: this.$route.query.transOrderNo
      })
      this.handlInitData(res)
    },
    handleClick() {
      console.log('click')
      this.$router.push({ name: 'balance' })
    }
  }
}
</script>
