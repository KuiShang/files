<template>
  <div class="topup-wrapper">
    <div class="card-wraper">
      <moneyInput
        ref="moneyInput"
        v-model="amount"
        :busi-scenarios="BUSI_SCENARIOS.TOPUP"
        channel-type="top up"
        :title="$t('Top Up Amount')"
        @moneyFlag="receiveMoneyFlag"
      />
    </div>
    <div class="btn-wraper">
      <common-button
        :disabled="!moneyFlag"
        type="danger"
        @click.native="handleClick">{{ $t('topup') }}</common-button>
    </div>
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :transaction-no = "transactionNo"
      :trans-order-no = "transOrderNo"
      :current-busi-type= "ALL_BUSI_TYPE.TOPUP"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import { topUpBegin } from '@/api'
import { BUSI_SCENARIOS, ALL_BUSI_TYPE } from '@/utils/const'
import moneyInput from '@/pages/balance/common/moneyInput'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/topup'

export default {
  name: 'Topup',
  components: { simpleCashier, moneyInput },
  mixins: [hasPayError],
  data() {
    return {
      amount: '',
      cashierVisible: false,
      transactionNo: '',
      transOrderNo: '',
      BUSI_SCENARIOS,
      ALL_BUSI_TYPE,
      showErrorTip: false,
      moneyFlag: false
    }
  },
  created() {
    // this.initData()
    this.$SDK.setTitle({
      title: this.$t('balancetopup'),
      mHeaderTitle: {
        showEnd: 0
      }
    })
    if (this.$utils.getSysType('isAndroid')) {
      this.$nextTick(() => {
        this.$refs.moneyInput.$el.querySelector('input').focus()
      })
    }
    TRANSFER_BURRY.TOP_UP_ENTER()
  },
  watch: {
    cashierVisible(value) {
      if (value === false) { // 关闭收银台 报进入
        TRANSFER_BURRY.TOP_UP_ENTER()
      }
    }
  },
  destroyed() {
  },
  methods: {
    async handleClick() {
      TRANSFER_BURRY.TOPUP_TOPUP(this.amount)
      const res = await topUpBegin({
        version: this.$DeviceInfo.appVersion,
        amount: this.amount,
        currency: 'THB',
        deviceMsg: JSON.stringify(this.$DeviceInfo),
        transferChannel: 0
      })
      if (res && res.data && res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        TRANSFER_BURRY.TOP_UP_LEAVE()
        this.cashierVisible = true
      } else if (res && res.data && res.data.resultCode === 0) {
        this.hasPayError(res)
      }
    },
    getMin1() {
      let ret = ''
      this.dataObj.forEach((item) => {
        if (item.type === 'topup') {
          ret = item.min
        }
      })
      return ret
      // return this.dataObj.map(item => item.type === 'topup').min
    },
    getMax1() {
      let ret = ''
      this.dataObj.forEach((item) => {
        if (item.type === 'topup') {
          ret = item.max
        }
      })
      return ret
      // return this.dataObj.map(item => item.type === 'topup').max
    },
    paynow() {
      this.$router.push({ name: 'topupResult', query: { transOrderNo: this.transOrderNo } })
    },
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.topup-wrapper {
  font-size: .28rem;
  overflow: hidden;
  position: relative;
  height: 100%;
  .card-wraper {
    box-sizing: border-box;
  }
  .btn-wraper {
    position: absolute;
    font-family: The1Official_Bold !important;
    top: 4rem;
    display: flex;
    box-sizing: border-box;
    margin-left: 50%;
    transform: translateX(-50%)
  }
}

</style>
