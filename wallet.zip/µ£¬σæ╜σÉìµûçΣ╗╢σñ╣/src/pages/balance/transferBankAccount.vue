<template>
<!-- 转账到银行账户 -->
  <div class="transfer-tobank">
    <div class="transfer-notice">
      <!-- {{ this.$t('transferNnotice') }} -->
      <template
        v-if="this._i18n.locale=='en'"
      >
        Money transfered will be succeed within <span> 1 </span> working day
      </template>
      <template
        v-else
      >
        การโอนเงินจะสำเร็จภายใน <span> 1 </span> วันทำการ
      </template>
    </div >
    <div
      v-if="this.$route.query.type == 'history'"
      @click="getReceiver"
      class="recent-transfer">
      <div class="left">
        <img
          :src="bankIconUrl"
          class="bank-logo"
          alt=""
        >
        <div
          @click="reChoose"
          class="content-wrapper">
          <div class="bank-no">
            {{ accountNo | fixStars }}
          </div>
          <div class="bank-name">
            {{ bankName }}
          </div>
        </div>
      </div>
      <common-icon
        class="custom-ico"
        name="more"
        size=".4rem"
      />
    </div>
    <div
      v-else
      class="transfer-info">
      <div
        :class="{pd40: this.$route.query.refer == 'bankList', chooseColor: this.$route.query.refer == 'bankList'}"
        class="choose-bank"
        @click="chooseBank"
      >
        <template
          v-if="this.$route.query.refer == 'bankList'"
        >
          <img
            :src="selectBankInfo.h5Logo"
            class="bank-icon"
          >
          {{ selectBankInfo.bankName }}
        </template>
        <template v-else>
          {{ this.$t('ChooseBank') }}
        </template>
        <common-icon
          class="custom-ico"
          name="more"
          size=".4rem"
      />
      </div>
      <div class="choose-account">
        <common-input
          ref="commonInput"
          v-model="number"
          :border="false"
          :maxlength="10"
          :is-active.sync="isActive"
          :show-suggest="false"
          :style-obj='{right: 0}'
          type="tel"
          :holder="this.$t('AccountNumber')"
          class="phone-input"
          @blur="phoneblur"
          @focus="inputFocus"
          @handleClear="handlePhoneClear"
          @input="phoneInput"
        />
        <img
          v-show="showContractEntry && isShowIcon"
          class="custom-ico"
          src="@/assets/images/common/listing@3x.png"
          @click="getReceiver"
        >
      </div>

    </div>
    <moneyInput
      ref="moneyInput"
      v-model="amount"
      :notes-entry="false"
      :transfer-channel="TRANSFER_CHANNELS.BANK_ACOUNT"
      :busi-scenarios="BUSI_SCENARIOS.TRANSFER"
      :has-fee="true"
      :fee="fee"
      @moneyFlag="receiveMoneyFlag"
      @moneyLimitOk="moneyLimitOk"
      @input="inputMoney"
    />
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">{{ this.$t('transfer') }}</common-button>
    </div>
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :current-busi-type= "ALL_BUSI_TYPE.TRANSFER_BANKACCOUNT"
      :transaction-no = "transactionNo"
      :trans-order-no = "transOrderNo"
      @paynow = "paynow"
    />
    <toast
      :show-cancle="true"
      :title-position="0"
      v-if="showDialog"
      @cancle="cancle"
      @closeDialog="closeDialog"
      >
      <div slot="content">
        <p class="tit">{{ this.$t('TransferAmount') }}</p>
        <p class="amount"><span>฿</span>{{ -(-amount-fee) | tofloat | thousandBitSeparator }}</p>
        <p class="text">{{ this.$t('Receiverwillreceive') }} <span>฿ {{ amount | tofloat | thousandBitSeparator }}</span></p> 
        <p class="text">{{ this.$t('Servicefee') }} <span>฿ {{ fee | tofloat | thousandBitSeparator }}</span></p>
      </div>
      <p slot="cancle">{{ this.$t('CANCEL') }}</p>
      <p slot="confirm">{{ this.$t('OK') }}</p>
    </toast>
  </div>
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import { mapGetters, mapMutations } from 'vuex'
import { BUSI_SCENARIOS, TRANSFER_CHANNELS, ALL_BUSI_TYPE, TRANSFER_TYPE } from '@/utils/const'
import { transferPage, createTransfer, transBankAccountList } from '@/api'
import moneyInput from '@/pages/balance/common/moneyInput'
import hasPayError from '@/mixins/hasPayError'
import toast from '@/pages/balance/common/dialog'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'TransferBankAccount',
  components: { moneyInput, simpleCashier, toast },
  mixins: [hasPayError],
  data() {
    return {
      showDialog: false,
      showContractEntry: true,
      amount: '',
      isChoosing: false,
      BUSI_SCENARIOS,
      ALL_BUSI_TYPE,
      TRANSFER_CHANNELS,
      fee: '', // 息费
      moneyFlag: false,
      number: '',
      cashierVisible: false,
      transactionNo: '',
      transOrderNo: '',
      isActive: false,
      cardId: '', // 通过绑定卡或者近期记录选择银行卡时唯一字段
      accountNo: '',
      accountName: '',
      bankIconUrl: '',
      bindBankAccountList: [],
      transBankAccountRecordList: []
    }
  },
  computed: {
    isShowIcon () {
      const {bindBankAccountList, transBankAccountRecordList} = this;
      return [bindBankAccountList, transBankAccountRecordList].filter(i => i.length > 0).length
    },
    btnok: {
      get() {
        if (this.$route.query.type === 'history') {
          return this.moneyFlag
        }
        return this.moneyFlag && this.number.length == 10 && this.selectBankInfo.bankCode !== ''
      }
    },
    ...mapGetters([ 'selectBankInfo'])
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.Transfer_ToBankAccount_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.Transfer_ToBankAccount_LEAVE()
    next()
  },
  async created() {
    console.log('进入bankacount')
    this.$SDK.setTitle({
      title: this.$t('toBankAcount'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress( () => {
      this.$router.push({ name: 'transfer'})
    })
    // 如果第一次进来先清storage
    if (this.$route.query.type === 'new') {
      await this.$SDK.removeCache({
          key: 'number',
          cacheMode: 2
      })
      await this.$SDK.removeCache({
          key: 'amount',
          cacheMode: 2
      })
    } else if (this.$route.query.type === 'history') { // 从近期转账历史进来
      const temp = await this.$SDK.getCache({
        key: 'transfer_hisory_account',
        cacheMode: 2
      })
      const transferHisoryMsg = JSON.parse(temp);
      const { bankName, accountNo, accountName, bankIconUrl, cardId } = transferHisoryMsg
      this.bankName = bankName
      this.accountNo = accountNo
      this.accountName = accountName
      this.bankIconUrl = bankIconUrl
      this.cardId = cardId
    } else if (this.$route.query.refer === 'bankList') { // 选择完银行卡之后
      const temp2 = await this.$SDK.getCache({
        key: 'number',
        cacheMode: 2
      })
      if (temp2 && temp2 !== 'undefined' ) {
        this.isActive = true;
        this.$nextTick(async ()=>{
          const temp3 = await this.$SDK.getCache({
            key: 'number',
            cacheMode: 2
          })
          this.$refs.commonInput.currentValue = temp3 || '';
        })
      }
    }
    // 如果有息费直接取，没有则请求并存储到storage
    const temp4 = await this.$SDK.getCache({
      key: 'bankAcountFee',
      cacheMode: 2
    })
    if (temp4 && temp4 !== 'undefined') {
      this.fee = temp4
      console.log(this.fee)
    } else {
      const res = await transferPage({
        busiScenarios: BUSI_SCENARIOS.TRANSFER,
        transferChannel: TRANSFER_CHANNELS.BANK_ACOUNT
      })
      if (res && res.data && res.data.resultCode === 1) {
        await this.$SDK.putCache({
          key: 'bankAcountFee',
          cacheMode: 2,
          value: res.data.resultData.fee
        })
        
        this.fee = res.data.resultData.fee
      } else if (res && res.data && res.data.resultCode === 0) {
        this.hasPayError(res)
      }
    }
    
    // 先查是否有转账记录 决定是否有icon
    const res = await transBankAccountList()
    if (res && res.data && res.data.resultCode === 1) {
      const {bindBankAccountList, transBankAccountRecordList} = res.data.resultData
      this.bindBankAccountList = bindBankAccountList
      this.transBankAccountRecordList = transBankAccountRecordList
    } else if (res && res.data && res.data.resultCode === 0) {
      this.hasPayError(res)
    }
  },
  methods: {
    cancle() {
      this.showDialog = false;
    },
    closeDialog() {
      this.showDialog = false;
      this.init()
    },
    phoneblur() {
      this.showContractEntry = true;
    },
    inputFocus() {
      TRANSFER_BURRY.Transfer_ToBankAccount_BANKACCOUNT()
      this.showContractEntry = false;
    },
    handlePhoneClear() {
    },
    reChoose() {
      // this.$router.push({ name: 'transferBankAccount', query: { type: 'new' } })
    },
    // 创建转账业务单
    handleClick() {
      if(this.fee == 0) {
        this.init()
      } else {
        this.showDialog = true;
      }
    },
    async init() {
      const res = await createTransfer({
        amount: this.amount,
        fee: this.fee,
        currency: 'THB',
        deviceMsg: JSON.stringify(this.$DeviceInfo),
        transferChannel: TRANSFER_CHANNELS.BANK_ACOUNT,
        bankAccount: this.number,
        bankName: this.$route.query.type === 'history' ? this.accountName : this.selectBankInfo.bankName,
        cardId: this.cardId,
        busiType: TRANSFER_TYPE.NORMAL
      })
      if (res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
        TRANSFER_BURRY.Transfer_ToBankAccount_TRANSFER(null, this.amount)
      } else if (res.data.resultCode === 0) {
        const errorMsg = {
          code: res.data.errorData && res.data.errorData.code || '',
          msg: res.data.errorData && res.data.errorData.msg || ''
        }
        TRANSFER_BURRY.Transfer_ToBankAccount_TRANSFER(errorMsg, this.amount)
        this.hasPayError(res)
      }
    },
    // 支付成功后回调
    paynow() {
      console.log('pay now')
      this.$router.push({ name: 'transferTh1Result', query: { transOrderNo: this.transOrderNo, transactionNo: this.transactionNo } })
    },
    // phone输入框input事件
    phoneInput() {
      this.$SDK.putCache({
        key: 'number',
        value: this.number,
        cacheMode: 2
      })
    },
    // money输入框input事件
    inputMoney() {
      this.$SDK.putCache({
        key: 'amount',
        value: this.amount,
        cacheMode: 2
      })
    },
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    },
    // 选择银行
    chooseBank() {
      TRANSFER_BURRY.Transfer_ToBankAccount_BANKTYPE()
      this.$router.push({ name: 'chooseBank' })
    },
    async moneyLimitOk() {
      if (this.$route.query.refer === 'bankList') {
        const temp = await this.$SDK.getCache({
          key: 'amount',
          cacheMode: 2
        })
        if (temp && temp !== 'undefined') {
          this.$refs.moneyInput.amount = temp
        } else {
          this.$refs.moneyInput.amount = ''
        }
      }
    },
    // 选择银行卡号
    getReceiver() {
      const {bindBankAccountList, transBankAccountRecordList } = this
      TRANSFER_BURRY.Transfer_ToBankAccount_RELATEDBANKACCOUNT()
      this.$router.push({ name: 'chooseReceiver', params: {
        bindBankAccountList,
        transBankAccountRecordList
      } })
    }
  },
  watch: {
    cashierVisible(value) {
      if(value == false) { // 关闭收银台 报进入
        TRANSFER_BURRY.Transfer_ToBankAccount_ENTRY()
      } else {
        TRANSFER_BURRY.Transfer_ToBankAccount_LEAVE()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.transfer-tobank{
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  .transfer-notice{
    span{
      color: $color-red;
    }
    height: 0.8rem;
    line-height: 0.8rem;
    text-align: left;
    margin-left: 0.4rem;
    font-size: 0.24rem;
    color: $color-gray-f;
  }
  .transfer-info{
    padding: 0.3rem 0.4rem;
    height: 3.3rem;
    background-color: #fff;
    margin-bottom: 0.2rem;
    .choose-account{
      margin-top: .3rem;
      position: relative;
      .phone-input{
        border-bottom: 1px solid $color-gray-f;
      }
      .custom-ico {
        position: absolute;
        top: 0.46rem;
        right: 0;
        width: .6rem;
      }
    }
    .pd40{
      padding-left: 0.8rem;
    }
    .chooseColor{
      color: $color-gray-g !important;
    }
    .choose-bank{
      position: relative;
      font-size: 0.4rem;
      margin-top: 0.3rem;
      border-bottom: 1px solid $color-gray-f;
      height: 1rem;
      line-height: 1rem;
      color: $color-gray-f;
      letter-spacing: 0;
      text-align: left;
      .custom-ico{
        float: right;
      }
      .bank-icon{
        position: absolute;
        top: 0.2rem;
        left: 0rem;
        height: 0.6rem;
        width: 0.6rem;
      }
    }
  }
  .recent-transfer{
    display: flex;
    align-items: center;
    position: relative;
    align-items: center;
    height: 1.4rem;
    justify-content: space-between;
    padding: 0 .2rem 0 .4rem;
    background-color: #fff;
    margin-bottom: 0.2rem;
    .left{
      display: flex;
      align-items: center;
      .content-wrapper{
        margin-left: 0.22rem;
        .bank-no{
          height: 0.6rem;
          line-height: 0.6rem;
          font-size: 0.36rem;;
          color: $color-gray-g;
          letter-spacing: 0;
          text-align: left;
        }
        .bank-name{
          height: 0.42rem;
          line-height: 0.42rem;
          font-size: 0.28rem;
          color: $color-gray-f;
          letter-spacing: 0;
          text-align: left;
        }
      }
      .bank-logo{
        height: 0.6rem;
        width: 0.6rem;
      }
    }
  }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}


</style>
