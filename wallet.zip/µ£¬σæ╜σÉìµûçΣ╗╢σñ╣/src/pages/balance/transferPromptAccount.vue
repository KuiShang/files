<template>
<!-- tag 30 商家 tag29 个人码 -->
  <div class="blance-transfer-prompt">
    <div class="transfer-notice">
      {{this.$t('transferNotice')}}
    </div >
    <div class="input-wraper">
      <common-input
        v-show="true"
        ref="commonInput"
        v-model="number"
        :border="false"
        :show-suggest="true"
        :fetch-suggestions="querySearch"
        :before-icontype="beforeIcontype"
        :disabled="disabled"
        :style-obj="{right: '.4rem'}"
        :maxlength="18"
        type="tel"
        :holder="this.$t('TransferTo')"
        @blur="phoneblur"
        @focus="inputFocus"
        @handleClear="handlePhoneClear"
      />
      <img
        v-show="showContractEntry"
        class="custom-ico"
        src="@/assets/images/blance/the1/contact@3x.png"
        @click="gotoPhoneList"
      >
    </div>
    <moneyInput
      ref="moneyInput"
      v-model="amount"
      :notes-entry="true"
      :readonly="readonly"
      :transfer-channel="TRANSFER_CHANNELS.PROMPTPAY"
      :busi-scenarios="BUSI_SCENARIOS.TRANSFER"
      @addNotes="receiveNotes"
      @moneyFlag="receiveMoneyFlag"
      @moneyLimitOk="moneyLimitOk"
    />
    <div class="btn-wraper">
      <common-button
        :disabled="!btnok"
        type="danger"
        @click.native="handleClick">{{ this.$t('transfer') }}</common-button>
    </div>
    <!-- <toast
      v-show="showInvalidToast"
      @closeDialog="closeDialog1"
    >
      <p slot="title">{{ this.$t('InvalidID') }}</p>
      <p slot="content">{{ this.$t('ReTry') }}</p>
      <p slot="confirm">{{ this.$t('ReEnter') }}</p>
    </toast> -->
  </div>
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import feeConfirm from '@/pages/balance/common/feeConfirm'
import moneyInput from '@/pages/balance/common/moneyInput'
import { transferPage, promptReviewDetail } from '@/api'
import { TRANSFER_TYPE, BUSI_SCENARIOS, TRANSFER_CHANNELS } from '@/utils/const'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'TransferPromptAccount',
  components: { simpleCashier, feeConfirm, moneyInput },
  mixins: [hasPayError],
  data() {
    return {
      amount: '',
      feeConfirmVisible: false,
      BUSI_SCENARIOS,
      number: '',
      TRANSFER_CHANNELS,
      customerObj: '',
      remark: '',
      moneyFlag: false,
      fee: '',
      readonly: false,
      disabled: false,
      showContractEntry: true, // 展示调原生通讯录的icon
      notRegistered: false,
      showInvalidToast: false, // 无效账户的toast
      beforeIcontype: '', // 前置icon图片类型
      promptAccountType: '', // prompt账户类型
      promptLookupId: '',
      promptLookupRef: '',
      receiverName: ''
    }
  },
  computed: {
    btnok() {
      if (this.$route.query.type === 'scan') {
        return this.moneyFlag
      }
      return this.moneyFlag && this.beforeIcontype
    },
    busiType() {
      if (this.$route.query.type === 'scan') {
        return BUSI_SCENARIOS.PROMPTPAY
      }
      return BUSI_SCENARIOS.TRANSFER
    },
    busiScenarios() {
      if (this.$route.query.type === 'scan') {
        return BUSI_SCENARIOS.PROMPTPAY
      }
      return BUSI_SCENARIOS.TRANSFER
    }
  },
  watch: {
    number(val) {
      this.$refs.commonInput.currentValue = this.sortNum(val)
      const value = val.replace(/[^\d]/g, '')
      if ((value.length === 10 && value.slice(0, 1) === '0')) {
        this.beforeIcontype = 'mobile'
        this.promptAccountType = 'MSISDN'
      } else if (value.length === 13) {
        this.beforeIcontype = 'id'
        this.promptAccountType = 'NATID'
      } else if (value.length === 15) {
        this.beforeIcontype = 'ewallet'
        this.promptAccountType = 'EWALLETID'
      } else {
        this.beforeIcontype = ''
        this.promptAccountType = ''
      }
    }
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_LEAVE()
    next()
  },
  async created() {
    TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_ENTRY()
    this.$SDK.onBackPress(() => {
      this.$router.push({ name: 'transfer'})
    })
    this.$SDK.setTitle({
      title: this.$t('ToPromptPayAccount'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    // 如果是通过scan
    if (this.$route.query.type === 'scan') {
      const paramsObj = this.$route.query 
      this.getBeforeIconType(paramsObj.promptAccountType)
      this.disabled = true;
      this.number = paramsObj.number
      this.promptAccountType = paramsObj.promptAccountType
      if (paramsObj.amount && parseFloat(paramsObj.amount) > 0) {
        this.amount = paramsObj.amount || ''
        this.readonly = true;
      }
    }
    // 根据历史转账获取账户类型
    if (this.$route.query.type === 'history') {
      const temp = await this.$SDK.getCache({
        key: 'transfer_hisory_account',
        cacheMode: 2
      })
      this.customerObj = JSON.parse(temp || '')
      this.$nextTick().then(() => {
        this.$refs.commonInput.currentValue = this.sortNum(this.customerObj.promptAccountNo)
        this.promptAccountType = this.customerObj.PromptAccountType // 账户类型
        this.getBeforeIconType(this.customerObj.PromptAccountType) // 拿到前置的icon
      })
    }
    // 如果有息费直接取，没有则请求并存储到storage
     const temppromptFee = await this.$SDK.getCache({
        key: 'promptFee',
        cacheMode: 2
      })
    if (temppromptFee && temppromptFee !== 'undefined') {
        const tempfee = await this.$SDK.getCache({
        key: 'promptFee',
        cacheMode: 2
      })
      this.fee = tempfee
      console.log(this.fee)
    } else {
      const res = await transferPage({
        busiScenarios: this.busiScenarios,
        transferChannel: TRANSFER_CHANNELS.PROMPTPAY
      })
      if (res && res.data && res.data.resultCode === 1) {
        await this.$SDK.putCache({
          key: 'promptFee',
          value: res.data.resultData.fee,
          cacheMode: 2
        })
        this.fee = res.data.resultData.fee
      } else if (res && res.data && res.data.resultCode === 0) {
        this.hasPayError(res)
      }
    }
  },
  mounted() {
    console.log(this.$data)
  },
  methods: {
    async handleClick() {
      this.$indicator.open({
        text: this.$t('Loading'),
        spinnerType: 'fading-circle'
      })
      TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_REVIEW_DETAIL()
      const postData = {
        version: this.$DeviceInfo.appVersion,
        amount: this.amount,
        currency: 'THB',
        fee: this.fee,
        promptAccountNo: this.number.replace(/[^\d]/g, ''), // prompt账户号
        promptAccountType: this.promptAccountType, // prompt账户类型
        deviceMsg: JSON.stringify(this.$DeviceInfo),
        transferChannel: TRANSFER_CHANNELS.PROMPTPAY,
        busiType: this.busiType,
        remark: this.remark
      }
      const res = await promptReviewDetail(postData)
      this.$indicator.close()
      if (res && res.data && res.data.resultCode === 1) {
        // 将返回的数据揉在一起存储到下一个路由
        this.promptLookupId = res.data.resultData.promptLookupId
        this.promptLookupRef = res.data.resultData.promptLookupRef
        this.receiverName = res.data.resultData.receiverName
        const promptPayInfo = Object.assign(postData, {
          promptLookupId: this.promptLookupId,
          promptLookupRef: this.promptLookupRef,
          receiverName: this.receiverName })
         await this.$SDK.putCache({
          key: 'promptPayInfo',
          value: JSON.stringify(promptPayInfo),
          cacheMode: 2
        })
        this.$router.push({ name: 'transferPromptConfirm' })
      } else if (res && res.data && res.data.resultCode === 0) {
        // if (res.data.errorData.code === 'TWL2200003') {
        //    this.showInvalidToast = true; // 暂没有具体的码值代表卡号有误
        // }
        this.hasPayError(res)
      }
    },
    // 唤起原生通讯录
    async gotoPhoneList() {
      // 扫码过来通讯录不可点
      if (this.$route.query.type === 'scan') {
        return 
      }
      TRANSFER_BURRY.TRANSFER_TOPROMPTPAY_CONTACT()
      console.log('gotoPhoneList')
      const phoneObj = await this.$SDK.goNativeCustomContact()
      console.log(phoneObj)
      if (phoneObj.status === 0) {
        console.log('未选择任何联系人')
        return
      }
      this.customerObj = ''
      if (String(phoneObj.outData.phone).length > 10) {
        this.$refs.commonInput.currentValue = String(phoneObj.outData.phone).substring(0, 10)
      } else {
        this.$refs.commonInput.currentValue = phoneObj.outData.phone
      }
      this.notRegistered = false
      // this.$nextTick(() => {
      //   this.$refs.commonInput.$el.querySelector('input').focus()
      // })
      this.phoneblur()
    },
    showCommonInput() {
      this.customerObj = ''
      this.notRegistered = false
      console.log(this.$refs.commonInput.$el.querySelector('input'))
      this.$nextTick(() => {
        this.$refs.commonInput.$el.querySelector('input').focus()
      })
    },
    sortNum(val) {
      return val.toString().replace(/(\d{4})(?=\d)/g, '$1 ')
    },
    moneyLimitOk() {
      this.$refs.moneyInput.amount = this.amount
    },
    getBeforeIconType(val) {
      if (val === 'MSISDN') {
        // 电话号码（9位或10位)
        this.beforeIcontype = 'mobile'
      } else if (val === 'NATID') {
        // 身份证号（13位）
        this.beforeIcontype = 'id'
      } else {
        // E-wallet Number(15位)
        this.beforeIcontype = 'ewallet'
      }
    },
    // 转账人输入框blur
    phoneblur() {
      console.log('blur')
      this.$nextTick(() => {
        this.showContractEntry = true
      })
    },
    // 获取写入的notes
    receiveNotes(notes) {
      this.remark = notes
    },
    // 接受到金额是否可用
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    },
    // 获取焦点时 通讯录icon隐藏
    inputFocus() {
      this.showContractEntry = false
    },
    // closeDialog1() {
    //   this.showInvalidToast = false;
    // },
    async querySearch(queryString, cb) {
      if (queryString.length > 2) {
        const phoneList = await this.$SDK.getPhonesByNumber(queryString)
        console.log('phonelist:', phoneList)
        cb(phoneList)
      } else {
        cb([])
      }
    },
    handlePhoneClear() {
      this.notRegistered = false
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.blance-transfer-prompt {
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  position: relative;
    .padtop {
      padding-top: .2rem;
    }
    .transfer-notice{
      height: 0.8rem;
      line-height: 0.8rem;
      text-align: left;
      margin-left: 0.4rem;
      font-size: 0.24rem;
      color: $color-gray-f;
    }
    .input-wraper {
      height: 1.4rem;
      background-color: #fff;
      margin-bottom: .2rem;
      padding-left: .4rem;
      position: relative;
      .custom-ico {
        position: absolute;
        top: 0.46rem;
        right: 0.48rem;
        width: .6rem;
      }
      .phone-result-wrapper {
        position: relative;
        .tit {
          position: absolute;
          left: 0;
          -webkit-transition: 0.3s linear;
          transition: 0.3s linear;
          z-index: 2;
          top: 0.25rem;
          font-size: .28rem;
          color: $color-gray-f;
        }
        .phone {
          height: 0.8rem;
          padding-top: 0.5rem;
          width: 100%;
          display: block;
          border: 0;
          outline: none;
          font-size: .4rem;
          z-index: 2;
          background: transparent;
          line-height: .8rem;
          .img {
            width: .4rem;
            height: .4rem;
            border-radius: 50%;
            vertical-align: middle;
            top: -0.04rem;
            position: relative;
          }
          .gray {
            color: $color-gray-c;
          }
          .not-registed {
            color: $color-red;
            font-size: .36rem;
          }
        }
      }
      .phone-result-wrapper2 {
         position: absolute;
         height: 1.4rem;
         top: 0;
         right: 1rem;
         left: 0;
        .not-registed {
          color: $color-red;
          font-size: .28rem;
          position: relative;
          top: .75rem;
          left: 3.2rem;
        }
      }
    }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}
</style>

