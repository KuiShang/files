<template>
  <div class="blance-wraper">
    <p class="money">฿ {{ balanceAmount }}</p>
    <p class="detail">
      <span @click="goDetail">{{ $t('blance_detail') }}</span>
      <common-icon
        slot="icon"
        class="custom-ico"
        name="more"
        size=".30rem"
        style="color:#302B2B"
      />
    </p>
    <div class="content">
      <div
        class="topup item"
        @click="gotopup"
      >
        <i class="bg"/>
        <p class="txt">
          <span>{{ $t('topup') }} </span>
          <common-icon
            slot="icon"
            class="custom-ico"
            name="more"
            size=".25rem"
            style="color:#302B2B"
          />
        </p>
      </div>
      <div
        class="withdraw item"
        @click="gowithdraw"
      >
        <i class="bg"/>
        <p class="txt">
          <span> {{ $t('withdraw') }} </span>
          <common-icon
            slot="icon"
            class="custom-ico"
            name="more"
            size=".25rem"
            style="color:#302B2B"
          />
        </p>
      </div>
    </div>
    <div
      v-if="false"
      class="foot"
    >
      <p class="blue">Contract customer service </p>
      <p class="gray">for any question</p>
    </div>
  </div>
</template>
<script>
import { getMainPage } from '@/api'
// import { ENUM_ERRORCODE } from '@/utils/const'
import handlInitData from '@/mixins/handlInitData'

export default {
  name: 'Blance',
  mixins: [handlInitData],
  computed: {
    balanceAmount() {
      return this.dataObj ? this.dataObj.balanceAmount : 0
    }
  },
  created() {
    this.setTitle()
    this.initData()
  },
  methods: {
    async initData() {
      const res = await getMainPage({
        version: this.$DeviceInfo.appVersion
      })
      console.log('----------')
      console.log(res)
      this.handlInitData(res)
    },
    gotopup() {
      this.$router.replace({ name: 'topup' })
    },
    gowithdraw() {
      this.$router.push({ name: 'withdraw' })
    },
    setTitle() {
      this.$SDK.setTitle({
        title: this.$t('blance_title')
      })
    },
    async goDetail() {
      console.log('godetail')
      const ret = await this.$SDK.goNativeActionTransDetail()
      console.log(ret)
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";
.blance-wraper {
  font-size: .28rem;
  height: 100%;
  background-image: url('../../assets/images/blance/balance_bg.png');
  background-size: contain;
  .money {
    padding-top: 1.14rem;
    padding-left: .75rem;
    font-size: .80rem;
    color: $color-red;
    text-shadow: 0 20px 20px rgba(255,36,36,0.20);
  }
  .detail {
    font-size: .28rem;
    color: $color-gray-a;
    padding-top: 0.28rem;
    padding-left: .79rem;
  }
  .content {
    padding-top: 0.95rem;
    padding-left: .40rem;
    padding-right: .4rem;
    display: flex;
    justify-content: space-between;
    .item {
      .bg {
        display: block;
        width: 3.25rem;
        height: 3.8rem;
      }
      .txt {
        height: 1.2rem;
        padding-top: .4rem;
        padding-left: 1.77rem;
        box-shadow: 0 60px 100px 0 rgba(0,0,0,0.08);
      }
    }
    .topup {
      .bg {
        background-image: url('../../assets/images/blance/topup.png');
        background-size: contain;
      }
    }
    .withdraw {
      .bg {
        background-image: url('../../assets/images/blance/withdraw.png');
        background-size: contain;
      }
    }
  }
  .foot {
    text-align: center;
    padding-top: 2.28rem;
    .blue {
      color:$color-blue;
    }
    .gray {
      color:$color-gray-c;
      padding-top: .1rem;
    }
  }
}
</style>
