<template>
  <div class="transfer-tobank-receiver">
    <template v-if="bindBankAccountList.length>0">
      <div class="linked-title">
        {{ this.$t('LinkedAccounts') }}
      </div>
      <div class="linked-accounts-content">
        <ul>
          <li
            v-for="(item,index) in bindBankAccountList"
            :key="index"
            @click="chooseReceiver(item)"
          >
            <img
              :src="item.bankIconUrl"
              alt=""
            >
            <div>
              <div class="phone-number">
                {{ item.accountNo | fixStars }}
              </div>
              <div class="account-name">
                {{ item.bankName }}
              </div>
            </div>
          </li>
        </ul>
      </div>
    </template>
    <template v-if="transBankAccountRecordList.length>0">
      <div class="linked-title">
        {{ this.$t('RecentRecords') }}
      </div>
      <div class="linked-accounts-content">
        <ul>
          <li
            v-for="(item,index) in transBankAccountRecordList"
            :key="index"
            @click="chooseReceiver(item)"
          >
            <img
              :src="item.bankIconUrl"
              alt=""
            >
            <div>
              <div class="phone-number">
                {{ item.accountNo | fixStars }}
              </div>
              <div class="account-name">
                {{ item.bankName }}
              </div>
            </div>
          </li>
        </ul>
      </div>
    </template>
  </div>
</template>
<script>
import storeage from 'storejs'
import { mapMutations, mapGetters } from 'vuex'
import { transBankAccountList } from '@/api/index'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'ChooseReceiver',
  mixins: [hasPayError],
  data() {
    return {
      bindBankAccountList: [],
      transBankAccountRecordList: []
    }
  },
  async created() {
    this.$SDK.setTitle({
      title: this.$t('TransferTo'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    this.$SDK.onBackPress( () => {
      this.$router.go(-1)
    })
    //  从上一页取bindBankAccountList、transBankAccountRecordList 刷新则发请求去取
    if(this.$route.params.bindBankAccountList && this.$route.params.transBankAccountRecordList) {
      const {bindBankAccountList, transBankAccountRecordList} = this.$route.params
      this.bindBankAccountList = bindBankAccountList;
      this.transBankAccountRecordList = transBankAccountRecordList;
    } else {
      const res = await transBankAccountList()
      if (res && res.data && res.data.resultCode === 1) {
        const {bindBankAccountList, transBankAccountRecordList} = res.data.resultData
        this.bindBankAccountList = bindBankAccountList
        this.transBankAccountRecordList = transBankAccountRecordList
      } else if (res && res.data && res.data.resultCode === 0) {
        this.hasPayError(res)
      }
    }
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.Transfer_TRANSFER_TOBANKACCOUNT_RELATEDBANKACCOUNT_LEAVE()
    next()
  },
  methods: {
    async chooseReceiver(data) {
      console.log(data)
      await this.$SDK.putCache({
        key: 'transfer_hisory_account',
        value: JSON.stringify(data),
        cacheMode: 2
      })
      this.$router.push({ name: 'transferBankAccount', query: { type: 'history' } })
    }
  }
}
</script>
<style lang="scss" scoped>
@import '@/assets/css/var.scss';
.transfer-tobank-receiver{
  font-size: .24rem;
  height: 100%;
  background-color: $color-gray-i;
  position: relative;
  .linked-title{
    height: 0.72rem;
    line-height: 0.72rem;
    padding: 0 0.3rem;
    background: $color-gray-i;
    font-size: 0.28rem;
    color: $color-gray-h;
    letter-spacing: 0;
    text-align: left;
  }
  .linked-accounts-content{
    background: #FFFFFF;
    padding: 0 0.4rem;
    ul{
      width: 100%;
      li{
        height: 1.4rem;
        display: flex;
        align-items: center;
        img{
          float: left;
          height: 0.6rem;
          width: 0.6rem;
          margin-right: 0.2rem;
        }
        .phone-number{
          height: 0.54rem;
          line-height: 0.54rem;
          font-size: 0.36rem;
          color: $color-gray-g;
          letter-spacing: 0;
          text-align: left;
        }
        .account-name{
          height: 0.48rem;
          line-height: 0.48rem;
          font-size: 0.28rem;
          color: $color-gray-f;
          letter-spacing: 0;
          text-align: left;
        }
      }
    }
  }
}
</style>
