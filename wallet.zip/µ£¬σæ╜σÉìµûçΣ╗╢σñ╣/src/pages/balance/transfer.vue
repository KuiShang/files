<template>
<!-- 转账方式列表入口 -->
  <div class="transfer-wraper">
    <div class="padtop"/>
    <div class="change">
      <common-item
        :border="true"
        :title="this.$t('ToDolfin')"
        :padding-left=".4"
        :padding-right=".4"
        icon-color="#4D7BFE"
        @click="toThe1"
      >
        <img
          slot="img"
          class="img"
          src="@/assets/images/blance/the1/Dolfin@3x.png">
        <common-icon
          slot="icon"
          class="custom-ico"
          name="more"
          size=".5rem"
        />
      </common-item>
      <common-item
        v-if="dataObj.whiteListSwitch == 'off' || (dataObj.whiteListSwitch=='on' && isPromptWhiteList)"
        :border="true"
        :padding-left=".4"
        :padding-right=".4"
        :title="this.$t('TOpromptpayAccount')"
        icon-color="#4D7BFE"
        @click="toPrompt"
      >
        <img
          slot="img"
          class="img"
          src="@/assets/images/blance/promptPay/promptpay@3x.png">
        <common-icon
          slot="icon"
          class="custom-ico"
          name="more"
          size=".5rem"
        />
      </common-item>
      <!-- <common-item
        :border="false"
        :title="this.$t('ToBankAccount')"
        icon-color="#4D7BFE"
        :padding-left=".4"
        :padding-right=".4"
        @click="toBank"
      >
        <img
          slot="img"
          class="img"
          src="@/assets/images/blance/promptPay/bank@3x.png">
        <common-icon
          slot="icon"
          class="custom-ico"
          name="more"
          size=".5rem"
        />
      </common-item> -->
    </div>
    <p
      v-show="hasDataObj.length>0"
      class="recend-title"
    >{{ this.$t('RecentTransferRecords')}}</p>
    <div class="list">
      <section
        v-for="(item, idx) in hasDataObj"
        :key="idx"
        class="item-wraper"
      >
        <!-- bank Account -->
       <common-item
          v-if="item.transferChannel=='2'"
          :border="false"
          :padding-left=".4"
          :padding-right=".4"
          :title="getCryptAccount(item)"
          :label="item.bankName"
          icon-color="#4D7BFE"
          @click="clickHistory(item)"
        >
          <img
            slot="img"
            :src="item.bankIconUrl"
            class="img"
          >
          <common-icon
            slot="icon"
            class="custom-ico hide"
            name="more"
            size=".3rem"
          />
        </common-item>

        <!-- prompt pay -->
        <common-item
          v-if="item.transferChannel=='3'"
          :border="false"
          :padding-left=".4"
          :padding-right=".4"
          :title="item.promptReciverName"
          :label="getPromptTypeAndNum(item)"
          icon-color="#4D7BFE"
          @click="clickHistory(item)"
        >
          <img
            slot="img"
            :src="item.promptIconUrl"
            class="img"
          >
          <common-icon
            slot="icon"
            class="custom-ico hide"
            name="more"
            size=".3rem"
          />
        </common-item>

        <!-- the 1 fin -->
        <common-item
          v-else
          :border="false"
          :padding-left=".4"
          :padding-right=".4"
          :title="item.customerName"
          :label="item.phone | crypto"
          icon-color="#4D7BFE"
          @click="clickHistory(item)"
        >
          <img
            slot="img"
            :src="item.iconUrl"
            class="img"
          >
          <common-icon
            slot="icon"
            class="custom-ico hide"
            name="more"
            size=".3rem"
          />
        </common-item>
      </section>
    </div>
  </div>
</template>
<script>
import handlInitData from '@/mixins/handlInitData'
import { transferRecord } from '@/api'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

export default {
  name: 'Transfer',
  filters: {
    crypto(num) {
      const str = String(num)
      return `${str.substring(0, 2)} **** ${str.substr(-3)}`
    }
  },
  mixins: [handlInitData],
  computed: {
    hasDataObj() {
      // 产品张雅琪1.3的需求 隐藏历史记录，故做数据过滤掉 item.transferChannel === 2的数据
      let hasDataObj = this.dataObj.transRecordResList ? this.dataObj.transRecordResList : [];
      hasDataObj = hasDataObj.filter(item => item.transferChannel != 2)
      return hasDataObj;
    },
    isPromptWhiteList() {
      if (this.dataObj.productStyle.constructor === Array) {
        return this.dataObj.productStyle.includes(1)
      }
      if (typeof this.dataObj.productStyle === 'string') {
        const arr = JSON.parse(this.dataObj.productStyle) || []
        return arr.includes(1)
      }
      return true
    }
  },
  created() {
    this.$SDK.setTitle({
      title: this.$t('transfer'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    }),
    // 测试反馈弱网情况下，安卓端需点击两次才能返回 故注释 测试验证不行 有死循环
    this.$SDK.onBackPress( () => {
      this.$SDK.closeWebView()
    })
    this.$indicator.close() // 下一个页面未等有返回结果时返回 清除loading
    this.initData()
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.TRANSFER_MAINPAGE_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.TRANSFER_MAINPAGE_LEAVE()
    next()
  },
  methods: {
    async initData() {
      const res = await transferRecord({
        version: this.$DeviceInfo.appVersion,
        customerId: '',
        transOrderNo: '',
        pageSize: ''
      })
      console.log(res)
      // console.log(typeof JSON.parse(res.data.resultData.productStyle))
      this.handlInitData(res)
    },
    toBank() {
      console.log('tobank')
      TRANSFER_BURRY.TRANSFER_MAINPAGE_TOBANKACCOUNT()
      this.$router.push({ name: 'transferBankAccount', query: { type: 'new' } })
    },
    toThe1() {
      console.log('toThe1')
      TRANSFER_BURRY.TRANSFER_MAINPAGE_TOONEFIN()
      this.$router.push({ name: 'transferThe1Account', query: { type: 'new' } })
    },
    toPrompt() {
      console.log('prompt')
      TRANSFER_BURRY.TRANSFER_MAINPAGE_TOPROMPTPAY()
      this.$router.push({ name: 'transferPromptAccount', query: { type: 'new' } })
    },
    // getBankNameAndNum(item) {
    //   return `${item.accountName} (${item.accountNo.substring(0, 4)}) `
    // },
    getPromptTypeAndNum(item) {
      if (item.promptAccountType === 'NATID') {
        // 身份证号（13位
        return `Citizen ID (****${(item.promptAccountNo).slice(-4)})`
      } else if (item.promptAccountType === 'MSISDN') {
        // 电话号码（9位或10位
        return `Mobile (****${(item.promptAccountNo).slice(-4)})`
      }
      // EWALLETID E-wallet Number(15位)
      return `E-wallet (****${(item.promptAccountNo).slice(-4)})`
    },
    getCryptAccount(item) {
      return item.customerName ? `******${item.accountNo}(${item.customerName})` : `******${item.accountNo}`
    },
    async clickHistory(item) {
      TRANSFER_BURRY.TRANSFER_MAINPAGE_RECENTHISTORY({transferChannel: item.transferChannel})
      if (item.transferChannel === '2') {
        this.$router.push({ name: 'transferBankAccount', query: { type: 'history' } })
      } else if (item.transferChannel === '3') {
        this.$router.push({ name: 'transferPromptAccount', query: { type: 'history' } })
      } else {
        this.$router.push({ name: 'transferThe1Account', query: { type: 'history' } })
      }
      await this.$SDK.putCache({
        key: 'transfer_hisory_account',
        value: JSON.stringify(item),
        cacheMode: 2
      })
    }
  }
}
</script>
<style lang="scss" scoped>
 @import "@/assets/css/var.scss";

 .custom-ico {
   font-weight: bold;
   color: $color-gray-f;
 }
 .hide {
   display: none;
 }
.transfer-wraper {
  height: 100%;
  background-color: $color-gray-i;
  font-size: .28rem;
  .padtop {
    padding-top: .2rem;
  }
  .change {
    background-color: #fff;
  }
  .recend-title {
    line-height: .72rem;
    padding-left: .3rem;
    color: $color-gray-h;
    padding-top: .25rem;
  }
  .list {
    background-color: #fff;
    .item-wraper {
      padding-top: .1rem;
      padding-bottom: .1rem;
      border-bottom: .02rem solid $color-gray-e;
    }
  }
}
</style>
