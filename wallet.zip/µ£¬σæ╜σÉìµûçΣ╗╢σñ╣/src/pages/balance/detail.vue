<template>
  <div class="result">
    <div class="head">
      <div class="fle-container">
        <img
          class="img"
          src="@/assets/images/blance/success.png"
          alt="duigou">
        <span class="txt-title">Balance Top up</span>
      </div>
      <p class="txt-money"> {{ dataObj.amount }}</p>
      <p class="txt-des"> payment success</p>
    </div>
    <ul class="list">
      <li class="item">
        <span class="key">PAYEE NAME</span>
        <span>lucy **</span>
      </li>
      <li class="item">
        <span class="key">PAYEE NAAME</span>
        <span>lucy **</span>
      </li>
      <li class="item">
        <span class="key">PAYEE NAMAAE</span>
        <span>ife is like a bAD  S</span>
      </li>
      <li class="item">
        <span class="key">PANAME</span>
        <span>lucy **</span>
      </li>
    </ul>
  </div>
</template>
<script>
import { queryTransionDetail } from '@/api'

export default {
  name: 'BlanceDetail',
  data() {
    return {
      dataObj: ''
    }
  },
  created() {
    this.initData()
  },
  methods: {
    async initData() {
      const res = await queryTransionDetail({
        version: this.$DeviceInfo.appVersion,
        serviceOddNo: this.$route.query.transOrderNo || '',
        inOutFlag: this.$route.query.inOutFlag || ''
      })
      this.dataObj = res.data.resultData
    }
  }
}
</script>
<style lang="scss" scoped>
.result {
  height: 100%;
  background-color: #f6f6f6;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-top: .61rem;
    .fle-container {
      display: flex;
      justify-content: center;
      align-items: center;
      .img {
        width: 0.4rem;
        height: .4rem;
      }
      .txt-title {
        text-align: center;
        font-size: .28rem;
        color: #838080;
        padding-left: .2rem;
      }
    }
    .txt-money {
      padding-top: .68rem;
      font-size: .92rem;
      color: #302B2B;
      text-align: center;
      line-height: .52rem;
    }
    .txt-des {
      padding-top: .22rem;
      font-size: .24rem;
      color: #D6D5D5;
      line-height: .52rem;
      padding-bottom: .61rem;
    }
  }
  .list {
    background-color: #fff;
    padding: 0 .4rem;
    margin-top: .2rem;
    .item {
      display: flex;
      justify-content: space-between;
      height: .9rem;
      line-height: .9rem;
      font-size: .28rem;
      color: #302B2B;
      text-align: right;
      line-height: .52rem;
      .key {
        color: #838080;
      }
      span {
        line-height: .9rem;
      }
    }
  }
}
</style>
