<template>
  <div class="jm-protocol">
    <p class="graphCxSpFirst">
      <b></b>
    </p>
    <p class="txt-title">
        <span>เมื่อท่านผูกสมาชิก</span>
        <span>The</span>
        <span>1 ของท่านกับดอลฟินวอลเลท</span>
    </p>
    <p class="graphCxSpMiddle">
      <b></b>
    </p>
    <p class="graphCxSpMiddle">
      <span>·</span>
      <span>นอกจากคะแนนสะสม</span>
      <span>The1</span>
      <span>ที่ท่านมีสิทธิได้รับตามข้อตกลงและเงื่อนไขของ บริษัท เดอะวันเซ็นทรัล จำกัด แล้ว ท่านยังจะได้รับคะแนนสะสม</span>
      <span>The1</span>
      <span>เพิ่มอีก</span>
      <span>1</span>
      <span>คะแนน ทุกๆ การใช้จ่าย</span>
      <span>100</span>
      <span>บาท ในแต่ละรายการชำระเงินผ่าน ดอลฟินวอลเลท</span>
    </p>
    <p class="graphCxSpMiddle">
      <span>·</span>
      <span>ท่านสามารถตรวจสอบยอดคะแนนสะสม</span>
      <span>The1</span>
      <span>ผ่านดอลฟินวอลเลทได้</span>
    </p>
    <p class="graphCxSpLast">
      <span>·</span>
      <span>ท่านตกลงว่าเราอาจเปลี่ยนแปลงข้อตกลงและเงื่อนไขสำหรับการผูกสมาชิก</span>
      <span>The1</span>
      <span>กับดอลฟินวอลเลท</span>
      <span>(</span>
      <span>รวมถึงอัตราการได้รับคะแนนสะสม</span>
      <span>The1)</span>
      <span>ได้โดยไม่ต้องแจ้งให้ท่านทราบล่วงหน้า</span>
    </p>
    <p class="pb20"></p>
  </div>
</template>
<style lang="scss" scoped>
ul {
  padding-left: 0.2rem;
  padding-top: 0.2rem;

  b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
  }
}

/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}

.jm-protocol {
     .txt-title {
    text-align: center;
    font-size: 24px;
    padding-bottom: .48rem;
  }
  strong,
  b span {
    font-weight: bold;
    font-family: The1Official_Bold;
  }

  font-size: 14px;
   color: #141E50;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}

.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}

.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}

.jm-protocol ol,
.jm-protocol ul {
  list-style-type: none;
  list-style-image: none;
}

.jm-protocol li {
  list-style: none;
}

.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
}

.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}

.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}

.jm-protocol a {
  text-decoration: none;

}

.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}

.jm-protocol a:focus {
  outline: dotted 1px;
}

.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}

.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}

.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

