<template>
  <div class="jm-protocol">
    <p class="txt-title">
      <span>Once you link your The</span>
      <span>1 membership with your Dolfin Wallet:</span>
      </p>
      
      <p class="graphCxSpMiddle"><span>・</span>
      <span>In addition to The</span>
      <span>1 points that you are entitled to earn in accordance with The 1 Central Limited’s terms and conditions, <b>every THB 100 (One Hundred Baht) spending made via Dolfin Wallet in each transaction, you will earn 1 (one) The1 point.</b></span></p><p class="graphCxSpMiddle"><span>・</span><span>You can check your The</span><span>1 points balance via your Dolfin Wallet. </span></p><p class="graphCxSpMiddle"><span>・</span><span>You agree that we may adjust the terms and conditions for linking The</span><span>1 membership with Dolfin Wallet (including The</span><span>1 point earning rate) without requiring to inform you in advance. </span></p><p class="pb20"></p><p class="pb20"></p><p class="pb20"></p></div>
</template>
<style lang="scss" scoped>
ul {
  padding-left: 0.2rem;
  padding-top: 0.2rem;

  b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
  }
}

/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}

.jm-protocol {
     .txt-title {
    text-align: center;
    font-size: 24px;
    padding-bottom: .48rem;
  }
  strong,
  b span {
    font-weight: bold;
    font-family: The1Official_Bold;
  }

  font-size: 14px;
 color: #141E50;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}

.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}

.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}

.jm-protocol ol,
.jm-protocol ul {
  list-style-type: none;
  list-style-image: none;
}

.jm-protocol li {
  list-style: none;
}

.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
}

.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}

.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}

.jm-protocol a {
  text-decoration: none;

}

.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}

.jm-protocol a:focus {
  outline: dotted 1px;
}

.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}

.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}

.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

