<template>
  <div class="jm-protocol">
    <p class="normal" align="center">
        <p class="txt-title">Personal Data Management Policy</p>
    </p>
    <p class="normal">
      <span>
        Central JD Money Co., Ltd. (the "<b>Company</b>", "<b>We</b>",
      </span>
      <span>"<b>Us</b>", "<b>Our</b>"
      </span>
      <span>
        ) always recognises the importance of the protection of Personal Data for users of our services ('<b>Services</b>'). We use state-of-the art technology that offers high security for the safekeeping of Personal Data. Only
      </span>
      <span>authorised officers of the Company or responsible persons will be granted an access to Personal Data. In addition, we put in place a system to strictly verify access to and use of Personal Data.</span>
      <span>System used in storing and safekeeping Personal Data will be regularly updated and improved to ensure reliable and accurate storage of Personal Data and to prevent leakage of Personal</span>
      <span>Data, unauthorised amendment to and misuse of Personal Data. This policy aims to explain types of Personal Data to be collected and the purpose of the Personal Data collection for use or disclosure, types of persons or agencies to which the disclosure of Personal Data collected by us is permitted, the rights of Personal Data subjects and for how long the data can be kept including such other information relating to our Personal Data management.</span>
    </p>
    <p class="normal">
      <span>This policy forms part of the Terms and Conditions applicable to our Services. We may revise, improve, supplement or change this policy by informing you and obtaining your consent in compliance with the law on personal data protection.</span>
    </p>
    <p class="normal">
      <b>
        <span>1. Data subject to this Policy</span>
      </b>
    </p>
    <p class="normal">
      <b></b>
      <span>
        This policy applies to any information that relates to an individual who can be identified either directly or indirectly by such information (the "<b>Personal Data</b>") that you have given to us or our access to which has been authorised by you. It shall also include the following information:
      </span>
    </p>
    <p class="graphCxSpFirst">
      <span>(a)</span>
      <span>Personal information such as name, family name, date of birth, number of national identity card, address, telephone number, mobile number, email address, photocopy of national identity card (both front and back), laser number on the back of national identity card, your photograph, biometrics and sensitive Personal Data received by us upon our verification to ensure compliance with relevant laws and regulations or such other personal information which may be used to identify you; and</span>
    </p>
    <p class="graphCxSpLast">
      <span>(b)</span>
      <span>Information relating to financial status, income, spending, debt repayments, consumption behaviour, your location upon use of our Services and/or your interest, which may be used in combination with other information to identify the Personal Data subject.</span>
    </p>
    <p class="normal">
      <b>
        <span>2. Collection and Receipt of Your Personal Data</span>
      </b>
    </p>
    <p class="normal">
      <span>We may collect Personal Data directly from you and/or may obtain your Personal Data using publicly available sources. If you give us Personal Data of other persons, e.g. their name, family name and telephone number for emergency contact, you certify that the relevant subject of such Personal Data has already been informed that we may disclose and store their Personal Data, and the Personal Data subject has already given you consent to the storage, use and disclosure of their Personal Data in accordance with this policy.</span>
    </p>
    <p class="normal">
      <span>We may access data relating to your interest and/or preference and/or information on your web browsing by using our website cookies and applications which will store your data to be accessed by us to allow us to offer Services that best meet your needs.</span>
    </p>
    <p class="normal">
      <span>During your communication with us by telephone, emails, our applications, communication applications, customer service centre or otherwise, we may record data relating to such communication for</span>
      <span>certain purposes such as for use as an evidence, development of and improvement to our Services, our review of your satisfaction, personnel training and evaluation, data analysis and our system development.</span>
    </p>
    <p class="normal">
      <b>
        <span>3. Purposes of Collection, Use, Processing, Transmission or Disclosure of Personal Data</span>
      </b>
    </p>
    <p class="normal">
      <b></b>
      <span>We may collect, use, process, transmit or disclose your Personal Data for the following purposes:</span>
    </p>
    <ul>
      <li>
        <p class="graphCxSpFirst">
          <span>To provide our Services to you;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To research, follow up on, process and analyse your data to improve and adjust our products and/or Services or to allow us or our business partners to develop and launch new products and/or Services that are suitable to your needs;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To manage relevant risks;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To comply with applicable laws and regulations including guidelines or requirements of relevant regulatory agencies that supervise our operations;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To allow us to enforce our contractual or legal rights in relation to you;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To comply with our and our affiliates¡¯ internal policies;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>To carry out or promote marketing and promotional activities including publicity of products and services of the Company or our affiliates or other persons;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpLast">
          <span>To follow up on, inspect and evaluate our Services and to manage our relationship with you</span>
        </p>
      </li>
    </ul>
    <p class="normal">
      <b>
        <span>4. Persons to whom we may disclose your Personal Data</span>
      </b>
    </p>
    <p class="normal">
      <span>We may disclose your Personal Data to the following persons:</span>
    </p>
    <p class="normal">
      <span>
        4.1
        <u>Our affiliates and shareholders</u>
      </span>
    </p>
    <p class="normal">
      <span>
        We may disclose your Personal Data to our affiliates and shareholders (both domestically and internationally), particularly to our affiliate, Central JD Fintech Co., Ltd. ("<b>Central JD Fintech</b>"), which will process such Personal Data for us, and may use, process and analyse your Personal Data for its own benefit. The use, processing and disclosure of Personal Data by Central JD Fintech will be in accordance with the objectives listed under Clause 3 above and the disclosure of the Personal Data may only be made to persons listed under this Clause 4.
      </span>
    </p>
    <p class="normal">
      <span>
        4.2
        <u>Our service providers</u>
      </span>
    </p>
    <p class="normal">
      <span>We may be required to disclose your Personal Data to our service providers including government agencies that we rely on for their services. Example of service providers is listed below. These service providers will only use your Personal Data to the extent that we permit and in accordance with this policy. The disclosure of your Personal Data to these service providers will be exclusively on the need-to-know basis.</span>
    </p>
    <ul>
      <li>
        <p class="graphCxSpFirst">
          <span>Professional advisers such as financial advisers, legal advisers, auditors;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of infrastructure and information technology services;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of data collection services including cloud service providers;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of marketing services including services relating to data and statistic preparation;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of advertisement services, public relations and communication services;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of services relating to payment systems and networks;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Providers of services relating to personal verification including Dip Chip services for national identity cards;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Payment agents;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>Financial institutions and other third parties whose services are used by us in order to provide you with our Services;</span>
        </p>
      </li>
      <li>
        <p class="graphCxSpLast">
          <span>Data verification service providers such as Netbay and the Department of Provincial Administration</span>
        </p>
      </li>
    </ul>

    <p class="normal">
      <span>
        4.3
        <u>Our partners</u>
      </span>
    </p>
    <p class="normal">
      <span>We may disclose your Personal Data to other persons such as financial institutions, insurance companies, securities companies, asset management companies who are parties to partnership agreements with us.</span>
    </p>
    <p class="normal">
      <span>
        4.4
        <u>Associations</u>
      </span>
    </p>
    <p class="normal">
      <span>We may disclose your Personal Data to associations of which we are a member such as Thailand E-Payment Trade Association (TEPA). The disclosure of your Personal Data will be exclusively on a need-to-know basis.</span>
    </p>
    <p class="normal">
      <span>
        4.5
        <u>Other persons required by law</u>
      </span>
    </p>
    <p class="normal">
      <span>We may need to disclose your Personal Data to such persons as may be required by the laws, rules, regulations, orders of government agencies, regulatory authorities or judiciary orders.</span>
    </p>
    <p class="normal">
      <span>
        4.6
        <u>Our assignees of rights and/or duties</u>
      </span>
    </p>
    <p class="normal">
      <span>In the case of an assignment of rights and duties contemplated by us including either partial or entire transfer of business, merger and acquisition and restructure of our shareholding, we may be required to disclose your Personal Data to the assignees (including the potential assignees). The rights and duties of such assignees in relation to your Personal Data will also be governed by this policy.</span>
    </p>
    <p class="normal">
      <span>The disclosure of your Personal Data under Clause 4.1 ¨C 4.6 may be made in Thailand or abroad.</span>
    </p>
    <p class="normal">
      <b>
        <span>5. Your rights as a Personal Data subject</span>
      </b>
    </p>
    <p class="normal">
      <b></b>
      <span>
        5.1
        <u>Right to Consent</u>
      </span>
    </p>
    <p class="normal">
      <span>You have the right to give us the requested Personal Data and consent to our storage, use and disclosure of such Personal Data. You acknowledge that if you do not give us full and complete Personal Data that we may request from you, or opt to refuse us your consent to the storage, use and disclosure of your Personal Data your rights to use certain Services may be restricted or we may be unable to provide you with any Services if such Personal Data is necessary in order for us to provide you with the Services.</span>
    </p>
    <p class="normal">
      <span>
        5.2
        <u>Access to Personal Data</u>
      </span>
    </p>
    <p class="normal">
      <span>You have the right to request for an access to your Personal Data kept with us and obtain a copy thereof, or may require us to send such Personal Data to the relevant subject or other person who may have the control over the Personal Data (to the extent possible in relation to such form of the Personal Data). You may also require us to disclose information as to how your Personal Data has been obtained if you have not consented to the storage of such Personal Data.</span>
    </p>
    <p class="normal">
      <span>
        5.3
        <u>Right to Objection</u>
      </span>
    </p>
    <p class="normal">
      <span>You may object to the storage, use and disclosure of Personal Data relating to you if such Personal Data may be collected by us without your consent or in the case of Personal Data that is collected, used or disclosed for the purpose of direct marketing or for research purposes.</span>
    </p>
    <p class="normal">
      <span>
        5.4
        <u>Deletion, Destruction or Suspension of Use</u>
      </span>
    </p>
    <p class="normal">
      <span>You have the right to require us to delete, destroy or suspend the use of your Personal Data kept with us or to render such Personal Data impossible to be used in identifying its subjects upon your withdrawal of consent or upon your objection to the use and disclosure of Personal Data relating to you, or when the storage, use or disclosure of Personal Data according to objectives consented earlier by you becomes unnecessary or when we have failed to comply with the law relating to personal data protection.</span>
    </p>
    <p class="normal">
      <span>5.5</span>
      <u>
        <span>Updating Personal Data</span>
      </u>
    </p>
    <p class="normal">
      <span>You have the right to require us to update and correct your Personal Data kept with us to ensure it is complete and not misleading.</span>
    </p>
    <p class="normal">
      <span>
        5.6
        <u>Withdrawal of Consent</u>
      </span>
    </p>
    <p class="normal">
      <span>You have the right to withdraw your consent to the collection, use and disclosure of your Personal Data without prejudice to the collection, use or disclosure of your Personal Data consented earlier by you. You acknowledge that withdrawal of your consent may cause us to be unable to continue providing you with our Services.</span>
    </p>
    <p class="normal">
      <span>In the exercise of your rights under Clause 5.1 ¨C 5.6 above, you are aware that these are rights that are subject to limitations under relevant laws and that we may deny the exercise of such rights if we have the legal grounds to do so.</span>
    </p>
    <p class="normal">
      <b>
        <span>6. How long do we keep your Personal Data</span>
      </b>
    </p>
    <p class="normal">
      <span>We keep your Personal Data for the minimum period required by relevant laws which is currently at least for 10 years after our relationship with you as our customer has been terminated. However, we may continue to keep your Personal Data beyond expiration of such regulatory period if we consider that it is necessary for us to use the Personal Data in accordance with the objectives for which it has been collected or for other purposes as we deem necessary such as to enforce our legal or contractual rights.</span>
    </p>
    <p class="normal">
      <b>
        <span>7. Our contact details</span>
      </b>
    </p>
    <p class="normal">
      <b></b>
      <span>If you wish to contact us to exercise the rights relating to your Personal Data or if you have any queries about your Personal Data, please contact us at:</span>
    </p>
    <ul>
      <li>
        <p class="graphCxSpFirst">
          <span>By email at:</span>
          <span>
            <a href="mailto:Thitiwat.wi@cjdfintech.com">
              <span>Thitiwat.wi@cjdfintech.com</span>
            </a>
          </span>
        </p>
      </li>
      <li>
        <p class="graphCxSpMiddle">
          <span>By post at:</span>
        </p>
      </li>
    </ul>
    <p class="graphCxSpMiddle">
      <span>Mr. Thitiwat Wisarat</span>
    </p>
    <p class="graphCxSpMiddle">
      <span>Head of Legal and Compliance</span>
    </p>
    <p class="graphCxSpLast">
      <span>
        87/2 CRC Tower All Seasons Place, 32
        <sup>nd</sup> floor and 48
        <sup>th</sup> floor, Wireless Road, Lumphini Sub-District, Pathumwan District, Bangkok 10330.
      </span>
    </p>
    <p class="normal">
      <span>You may also contact Central JD Fintech Co., Ltd. at the same address specified above.</span>
    </p>
  </div>
</template>

<style lang="scss" scoped>
ul {
  padding-left: 0.2rem;
  padding-top: 0.2rem;

  b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
  }
}

.custom-margin {
  height: 0.5rem;
}
/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}
.jm-protocol {
       .txt-title {
    text-align: center;
    font-size: 24px;
    padding-bottom: .48rem;
  }
  font-size: 14px;
  color: #141E50;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  font-family: "helvetica neue", tahoma, "hiragino sans gb", stheiti,
    "wenquanyi micro hei", \5fae\8f6f\96c5\9ed1, \5b8b\4f53, sans-serif;
    a {
      color: #141E50;
    }
}
.jm-protocol b {
  font-weight: bold;
  color: #000;
}
.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}
.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}
.jm-protocol ol,
.jm-protocol ul {
  list-style-type: disc;
  list-style-image: none;
}
.jm-protocol li {
  list-style: none;
  list-style-type: disc;
  margin-left: 16px;
}
.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
}
.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}
.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}
.jm-protocol a {
  text-decoration: none;

}
.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}
.jm-protocol a:focus {
  outline: dotted 1px;
}
.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}
.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}
.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

