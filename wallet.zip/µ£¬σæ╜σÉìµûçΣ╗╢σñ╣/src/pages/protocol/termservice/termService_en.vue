<template>
  <!-- 钱包用户注册使用协议 -->
  <div class="jm-protocol">
        <p class="txt-title">Terms and Conditions of Use</p>
    <p class="normal">
      <span>Dolfin Wallet is an electronic wallet service provided by Central JD Money Co., Ltd. (the “</span>
      <b>
        <span>Company</span>
      </b>
      <span>”) which is regulated by the Bank of Thailand. You can use electronic money, which the value is</span>
      <span>recorded in Dolfin Wallet Account as you have topped up money</span>
      <span>into the Dolfin Wallet</span>
      <b></b>
      <span>Account in advance</span>
      <span>, for making payment or for balance transfer. Dolfin Wallet is also a platform that allows you to link/bind bank accounts, credit cards, debit cards or other types of source of fund permitted by the Company to make payments and/or other services offered by the Company in</span>
      <b></b>
      <span>the application of Dolfin Wallet</span>
      <span>(the “</span>
      <b>
        <span>Dolfin Application</span>
      </b>
      <span>”).</span>
    </p>
    <p class="normal">
      <span class="Aucun">
        <b></b>
      </span>
    </p>
    <p class="normal">
      <span class="Aucun">
        <span>In using Dolfin Wallet, you are required to accept this Terms and Conditions of Use otherwise the Company will not be able to provide you with Dolfin Wallet services.</span>
      </span>
    </p>
    <p class="normal">
      <span class="Aucun"></span>
    </p>
    <p class="normal">
      <span class="Aucun">
        <span>When referring to this</span>
      </span>
      <span>“</span>
      <span class="Aucun">
        <span>Terms and Conditions of Use”, it shall mean this Terms and Conditions of Use as may be amended, modified, and/or varied from time to time, including terms and conditions for using any function of the Dolfin Wallet as well as the Company’s privacy policy.</span>
      </span>
    </p>
    <p class="normal">
      <span class="Aucun"></span>
    </p>
    <p class="pb20"></p>
    <h3>
      <span class="3">
        <span>1.</span>
      </span>
      <span class="3">
        <span>DOLFIN WALLET ACCOUNT REGISTRATION</span>
      </span>
    </h3>
    <p class="normal">
      <b>
        <span>1</span>
      </b>
      <b>
        <span>.</span>
      </b>
      <b>
        <span>1</span>
      </b>
      <b></b>
      <span>To use Dolfin Wallet, you must</span>
      <span>register</span>
      <span>for opening Dolfin Wallet Account (the “</span>
      <b>
        <span>Dolfin Wallet Account</span>
      </b>
      <span>”)</span>
      <span>with</span>
      <b></b>
      <span>the Company</span>
      <span>through the Dolfin Application that has been downloaded to your electronic device with correct, true and most updated information. In this regard, you will be required to verify your identity in accordance with the procedures prescribed by the Company. The approval for your Dolfin Wallet Account registration shall be in accordance with</span>
      <b></b>
      <span>the Company’s internal</span>
      <b></b>
      <span>rules and policy.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>1.2</span>
      </b>
      <b></b>
      <a name="_Hlk535916640">
        <span>If you have any problem in the account registration process, you can contact the Company at 0-2255-5959. In such event, the Company may request you to provide additional required documents such as</span>
      </a>
      <span>your latest photograph and</span>
      <span>/</span>
      <span>or a copy of your valid identity document
        <b></b>in order to identify yourself.
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>1.3</span>
      </b>
      <span>In the registration of Dolfin Wallet Account, you will be required to choose your own password for logging in Dolfin Wallet Account. You must not disclose such password to any third party because any instruction sent through your Dolfin Wallet Account shall be deemed an instruction from you.</span>
    </p>
    <p class="pb20"></p>
    <h3>
      <span class="3">
        <span>2.</span>
      </span>
      <span>USE OF YOUR DOLFIN WALLET FEATURES</span>
    </h3>
    <p class="normal">
      <span>In using Dolfin Wallet, you will be able to top-up, make payment and transfer balance as per details and conditions specified in this Clause 2. If you would like to transfer balance, receive balance transfer or make payment via PromptPay system, the Company will need to request you to complete additional identity verification process such as verification of your identity with the database of the Company’s partner bank which you previously used its services or any other prescribed methods.</span>
    </p>
    <h3></h3>
    <h3></h3>
    <h3></h3>
    <h3>
      <b>
        <span>2.1</span>
      </b>
      <span>
        <u>Top-up</u>
      </span>
    </h3>
    <h3>
      <span class="Aucun"></span>
    </h3>
    <h4>
      <span class="Aucun">
        <span>(a) You may top-up your Dolfin Wallet Account through various platforms as follows (i) a direct bank transfer through bank accounts opened with certain banks cooperating with the Company, (ii) a debit card (iii) designated payment counter and (iv) other types of source of fund permitted by the Company. Please note that certain fees may be charged to you.</span>
      </span>
    </h4>
    <h4>
      <span class="Aucun">
        <span>(b) You acknowledge that your Dolfin Wallet Account to which your money is deposited is not a bank account within the meaning of laws and regulations on banking and not subject to protection program provided by Deposit Protection Agency Act B.E.2551 (as amended) and/or any law in relation to the depositing money with the bank. The Company is not a bank and therefore, our services are not banking services.</span>
      </span>
    </h4>
    <h4>
      <span class="Aucun">
        <span>(c)</span>
      </span>
      <span>If you</span>
      <span>wish to refund the remaining amount in your Dolfin Wallet Account, you can choose to use our balance transfer service per Clause 2.3 or choose to close your account in accordance with procedures set out in Clause 5.2(a).</span>
    </h4>
    <h4>
      <span class="Aucun"></span>
    </h4>
    <h3>
      <span class="Aucun">
        <b>
          <span>2.2</span>
        </b>
      </span>
      <span class="Aucun">
        <span>
          <u>Payment</u>
        </span>
      </span>
    </h3>
    <h3></h3>
    <h4>
      <span>(a) You can use the Dolfin Wallet for making payment for products or services to the merchants that have entered into a cooperation agreement with the Company by using the balance in your Dolfin Wallet Account or through the linked source of fund. The payment details and evidence of such payment will be recorded in the transaction history page in Dolfin Application. In this respect, you can check the list of such merchants in your Dolfin Application and such list will be updated from time to time. In addition, you can use Dolfin Wallet for making payment for products or services to any merchant which accepts the payment via PromptPay system.</span>
    </h4>
    <h4>
      <span>(b)</span>
      <span class="Aucun"></span>
      <span>If you choose to make payment by using the balance in your Dolfin Wallet Account, the Company’s system will verify the request and check your Dolfin Wallet Account balance. If there is sufficient balance, the balance in the Dolfin Wallet Account will be deducted.</span>
    </h4>
    <h4>
      <span>(c) If you choose to make payment by using a linked/bound bank account or debit card,
        <a
          name="_Hlk535929021"
        >the Company’s system will connect with the bank system to check if there is sufficient fund available in such account or such debit card. If there is sufficient fund, the system will send the deduction request to the bank account or debit card to proceed with the payment transaction.</a>
      </span>
    </h4>
    <h4>
      <span>(d) If you choose to make payment by using a linked credit card, the Company’s system will connect with the credit card issuer’s system to check if there is sufficient limit available in such credit card. If there is sufficient limit, the system will send the charge request to the credit card issuer’s system to proceed with the payment transaction.</span>
    </h4>
    <h4>
      <span>(e)
        <a
          name="_Hlk536624560"
        >In the event that the amount to be paid via Dolfin Wallet Account is higher than the transaction limit indicated by you, you will be required to insert your password before making such payment.</a>
      </span>
    </h4>
    <h4></h4>
    <h4>
      <b>
        <span>2.3</span>
      </b>
      <u>
        <span>Balance Transfer</span>
      </u>
    </h4>
    <h4></h4>
    <h4>
      <span>You can transfer balance stored in your Dolfin Wallet Account to another Dolfin Wallet Account or e-wallet account or bank account. The Company’s system will verify the request and check your Dolfin Wallet Account balance. If there is sufficient fund, the balance in your Dolfin Wallet Account will be transferred to another Dolfin Wallet Account or e-wallet account or bank account as per your request.</span>
      <span>The transfer details made by you and the transfer evidence will be recorded in the transaction history page in Dolfin Application.
        <span>In the event that the amount to be transferred via Dolfin Wallet Account is higher than the transaction limit indicated by you, you will be required to insert your password before making such balance transfer.</span>
      </span>
    </h4>
    <p class="normal">
      <a name="_cp_text_1_33">
        <span>The timeline for processing the balance transfer will be as follows:</span>
      </a>
    </p>
    <p class="pb20"></p>
    <p class="graph">
      <span>(a) Balance Transfer between Dolfin Wallet Accounts –</span>
      <span>immediate</span>
      <span>effect</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(b) Balance Transfer from Dolfin Wallet Account to bank account
        <a name="_Hlk536624700">which registered with PromptPay system</a> or another e-wallet account which registered with PrompPay system –
      </span>
      <span>immediate</span>
      <span>effect</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(c) Balance Transfer from Dolfin Wallet Account to bank account which has not registered with PromptPay system– effect within 2 working days</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>2.4</span>
      </b>
      <span>
        <u>Benefits</u>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>Benefits from the use of Dolfin Wallet such as The</span>
      <span>1 points shall be in accordance with conditions that the Company announces or indicates.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>2.5</span>
      </b>
      <span>
        <u>Limits</u>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(a) In using Dolfin Wallet, you are subject to the amount limits as indicated in the table below. However, the Company may change such limits by informing you in advance.</span>
    </p>
    <p class="pb20"></p>
    <table cellspacing="1" cellpadding="1">
      <tbody>
        <tr>
          <td rowspan="2" valign="top">
            <p class="normal" align="center">
              <b>
                <span>Usage</span>
              </b>
            </p>
          </td>
          <td colspan="2" valign="top">
            <p class="normal" align="center">
              <b>
                <span>Limits</span>
              </b>
              <b></b>
              <b>
                <span>(THB)</span>
              </b>
            </p>
          </td>
        </tr>
        <tr>
          <td valign="top">
            <p class="normal" align="center">
              <span>Per day</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>Per month</span>
            </p>
          </td>
        </tr>
        <tr>
          <td valign="top">
            <p class="normal">
              <span>Top-up</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>100,000</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>200,000</span>
            </p>
          </td>
        </tr>
        <tr>
          <td valign="top">
            <p class="normal">
              <span>Payment</span>
              <span>(Bill Payment)</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>100,000</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>200,000</span>
            </p>
          </td>
        </tr>
        <tr>
          <td valign="top">
            <p class="normal">
              <span>Payment for products/services</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>100,000</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>200,000</span>
            </p>
          </td>
        </tr>
        <tr>
          <td valign="top">
            <p class="normal">
              <span>Balance transfer</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>100,000</span>
            </p>
          </td>
          <td valign="top">
            <p class="normal" align="center">
              <span>200,000</span>
            </p>
          </td>
        </tr>
      </tbody>
    </table>
    <p class="pb20"></p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(b) At any time, the remaining balance in the Dolfin Wallet Account shall not be higher than THB 100,000.</span>
    </p>
    <p class="pb20"></p>
    <h3>
      <span>3.</span>
      <span>DATA MANAGEMENT</span>
    </h3>
    <p class="normal">
      <b>
        <span>3</span>
      </b>
      <b>
        <span>.</span>
      </b>
      <b>
        <span>1</span>
      </b>
      <span>By registering</span>
      <span>the Dolfin Wallet</span>
      <span>Account</span>
      <span>and using the Dolfin Wallet, you acknowledge and agree that we may need to collect, use and process information derived from your use of Dolfin Wallet and your personal information (the “
        <b>Data</b>”). You also give consent to the Company to disclose (whether onshore disclosure or transferring to offshore) the Data to the Company’s affiliates, the Company’s business partners, any third party engages with the Company or provides services to the Company or the relevant government authorities. The Company will collect, use, process and/or disclose the Data for managing and improving the services of Dolfin Wallet so that you have best experience in using Dolfin Wallet services, for marketing activities and/or prom
      </span>
      <span>oting any product and service (regardless whether such products and services belong to the Company or other persons), for processing and analyzing Dolfin Wallet</span>
      <span>usage behavior</span>
      <span>and/or for any other purposes as the Company deems appropriate. The Company will use its best effort to ensure that the use of Data will be in accordance with such purposes and that there will be no unauthorized disclosure of such Data.</span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>3.2</span>
      </b>
      <span>You may decide whether you will allow us to take actions as stated in Clause 3.1 above or not. However, if you decide not to provide us will all requested information or do not allow us to take such actions, you may be restricted from using certain services in Dolfin Wallet or the Company may not be able to provide Dolfin Wallet services to you.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>3.3</span>
      </b>
      <span>You undertake to provide or ensure that the information provided to the Company is accurate, complete and updated. If you change any important information provided to the Company such as your e-mail address</span>
      <span>and</span>
      <span>telephone number, you must immediately update your information through Dolfin Application or other means as notified by the Company.</span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>3.4</span>
      </b>
      <span>You acknowledge and agree that the Company is entitled to examine your Dolfin Wallet usage to ensure</span>
      <span>the compliance</span>
      <span>with the applicable law and the Company’s internal policy.</span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <h3>
      <span>4. REPRESENTATIONS AND UNDERTAKING OF THE USER</span>
    </h3>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>4.1</span>
      </b>
      <span>In using Dolfin Wallet, you represent and confirm that you are an individual with legal capacity or legally permitted to enter into a binding agreement under the laws of Thailand.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>4.2</span>
      </b>
      <span>You will use Dolfin Wallet strictly in accordance with this Terms and Conditions of Use as well as relevant laws and regulations.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>4.3</span>
      </b>
      <span>You must set the passcode for accessing your electronic device and regularly change such passcode in order to protect an unauthorized access to your Dolfin Wallet Account. If your electronic device or your log-in information is lost, stolen or hacked, you must immediately inform the Company.</span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>4.4</span>
      </b>
      <span>You acknowledge that Dolfin Wallet is an intermediary for making transactions which operate as per your instruction. Therefore, each transaction is directly made between you and the merchant or the recipient. In the event that there is any dispute in relation to such transaction, the Company will consider investigating and/or coordinating as the Company deems appropriate.</span>
    </p>
    <p class="pb20"></p>
    <h3>
      <span>5. ACCOUNT BLOCKING AND ACCOUNT CLOSING</span>
    </h3>
    <p class="normal">
      <b>
        <span>5.1</span>
      </b>
      <u>
        <span>Account Blocking</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>The Company may consider blocking the use of your Dolfin Wallet Account as per your request or if the Company views that it is necessary to do so upon the occurrence of any event which may affect the use of your Dolfin Wallet Account. Such events include the followings</span>
      <span>:</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(a)
        <a
          name="_Hlk536014426"
        >The use of Dolfin Wallet Account or services in the Dolfin Wallet is in a manner contrary to or reasonably suspect to be in contrary to this Terms and Conditions of Use or the money laundering law or law with respect to fraud or any other prevailing law.</a>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(b) There is the loss</span>
      <span>/</span>
      <span>theft</span>
      <span>/</span>
      <span>hacking of your electronic device or log</span>
      <span>-</span>
      <span>in details.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>(c) There is an instruction from government authority, the Bank of Thailand, financial institution or court.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span class="Aucun">
        <span>Once the Company views that the event which is the cause of the account blocking no longer exists, the Company will cancel the account blocking and inform you accordingly</span>
      </span>
      <span class="Aucun">
        <span>.</span>
      </span>
    </p>
    <h3>
      <b></b>
    </h3>
    <h3>
      <b>
        <span>5.2</span>
      </b>
      <u>
        <span>Account Closing</span>
      </u>
    </h3>
    <h3></h3>
    <h4>
      <span>(a)</span>
      <span>In the event that you would like to close Dolfin Wallet Account, you will be required to contact our customer service center at</span>
      <span>0-2255-5959</span>
      <span>or process to close your account by other means as permitted by the Company. After the payment of any outstanding fees or outstanding debts (if any), the Company will refund in full the remaining balance in your Dolfin Wallet Account to you by the redemption method agreed to between the parties unless there is any event or circumstance which the Company considers to be or might be detrimental to the Company or any other party that requires the Company to retain certain amount of your Dolfin Wallet balance, for example, due to reasonable belief that it is associated to or resulted from fraud.</span>
    </h4>
    <p class="normal">
      <b></b>
      <span>(b) The Company may terminate this agreement and close your Dolfin Wallet Account if there is the use of Dolfin Wallet Account or services in Dolfin Wallet which is in a manner contrary to or reasonably suspect to be
        <a
          name="_Hlk536016347"
        >in contrary to this Terms and Conditions of Use or the money laundering law or law with respect to fraud or any other prevailing law, including the use of Dolfin Wallet Account which is not in line with the Company’s internal policy.</a>
      </span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>5.3</span>
      </b>
      <u>
        <span>Liability of the User</span>
      </u>
      <b></b>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b></b>
      <span>In using Dolfin Wallet, if your usage is in contrary to the Terms and Conditions of Use or any</span>
      <span>applicable law and the Company suffers any damage therefrom, you agree to be liable to the Company for such damage.</span>
    </p>
    <p class="pb20"></p>
    <h3>
      <span>6. RESERVATIONS</span>
    </h3>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>6</span>
      </b>
      <b>
        <span>.</span>
      </b>
      <b>
        <span>1</span>
      </b>
      <span>In the event of any discrepancy between the data and the balance and</span>
      <span>/</span>
      <span>or transactions history indicated in your Dolfin Wallet Account and the data and the balance and</span>
      <span>/</span>
      <span>or transactions history held and managed by the Company, the data and the balance and</span>
      <span>/</span>
      <span>or transactions history held and managed by the Company will be deemed conclusive evidence and binding upon both parties</span>
      <span>.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>6</span>
      </b>
      <b>
        <span>.</span>
      </b>
      <b>
        <span>2</span>
      </b>
      <span>You acknowledge that no system can completely protect the penetration, viruses, bugs, errors or system interruption. If any of such events happens, the Company will use the best effort to solve the problems and ensure that you can use the Dolfin Wallet continuously and safely.</span>
    </p>
    <p class="graph">
      <span class="Aucun"></span>
    </p>
    <h3>
      <span>7. MISCELLANEOUS</span>
    </h3>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.1</span>
      </b>
      <u>
        <span>Questions, Requests and Complaints</span>
      </u>
    </p>
    <p class="normal">
      <u>
        <span></span>
      </u>
    </p>
    <p class="normal">
      <span>If you have any question, request or complaint about the Dolfin Wallet, please call the Company at 0-2255-5959. The Company will investigate and provide updates to
        <a name="_cp_text_1_38">you</a>and explain the steps for this as well as inform the timeline for resolution of the complaint as soon as possible but no later than seven (7) days after receiving the complaint.
        <span
          class="Aucun"
        >To respond to your questions, requests, or complaints, the Company needs to check and verify your identity in accordance with the Company’s policy before responding to you</span>
      </span>
      <span class="Aucun">
        <span>.</span>
      </span>
      <span class="Aucun">
        <span>The Company is entitled to refuse to process your questions, requests, or complaints if your data does not match the data stored in the Company’s system</span>
      </span>
      <span class="Aucun">
        <span>.</span>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.2</span>
      </b>
      <u>
        <span>Service Fees</span>
      </u>
      <b></b>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>The Company has the right to charge you certain service fees</span>
      <span>and</span>
      <span>the Company is also entitled to formulate and adjust the service fees</span>
      <span>. You can check the rate of the service fees at the Company’s official website</span>
      <span>(</span>
      <span>www.dolfinwallet.com).</span>
      <span>If there is any change which negatively impact you, the Company will notify you via the Company’s official website or other methods at least 30 days prior to the implementation of such changes</span>
      <span>.</span>
      <span>You agree that the Company may deduct above service fees from the funds that you allow the Company to collect or to pay or from remaining balance of your Dolfin Wallet Account</span>
      <span>.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.3</span>
      </b>
      <u>
        <span>Force Majeure</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>The Company’s services may be interrupted due to certain events or causes beyond our power and ability to control</span>
      <span>(</span>
      <span>hereinafter, the “
        <span class="Aucun">
          <b>Force Majeure</b>”
        </span>
      </span>
      <span>)</span>
      <span>, including but not limited to natural disasters, electrical disturbances, telecommunications disruptions, government policy, and other causes beyond our power and ability to control</span>
      <span>.</span>
      <span>You therefore agree to release us from any claims whatsoever if we are unable to follow your instructions in the Dolfin Wallet Account either partially or wholly due to Force Majeure</span>
      <span>.</span>
      <span>If a Force Majeure condition continues for more than 3</span>
      <span>(</span>
      <span>three</span>
      <span>)</span>
      <span>months consecutively, we may terminate this agreement and close your Dolfin Wallet Account.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.4</span>
      </b>
      <u>
        <span>Intellectual Property</span>
      </u>
    </p>
    <p class="normal">
      <u>
        <span></span>
      </u>
    </p>
    <p class="normal">
      <span>Dolfin Wallet, including its name and logo, codes, designs, technology, business model, is protected by copyright, trademark, and other intellectual property rights provided under the laws. The Company (and its licensees, if applicable) own and retain all rights, title, and interest in and to Dolfin Wallet, including all associated intellectual property rights. These Terms and Conditions of Use are not in any way be treated as our permission for you to use any of our intellectual property assets above.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.5</span>
      </b>
      <u>
        <span>No Waiver</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>Any waiver or forbearance or failure to claim a breach of any provision of these Terms and Conditions of Use or to exercise any right provided by these Terms and Conditions of Use or the applicable law shall not be deemed to constitute a waiver with respect to any subsequent breach of any provision hereof</span>
      <span>.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.6</span>
      </b>
      <u>
        <span>Language</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>These Terms and Conditions of Use are drawn up in both the English and the Thai languages, both of which versions are binding on you and the Company</span>
      <span>.</span>
      <span>In the event of any inconsistency between the Thai language version and the English language version, the Thai language version will prevail</span>
      <span>.</span>
    </p>
    <p class="normal">
      <b>
        <span>7.7</span>
      </b>
      <u>
        <span>Assignment</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>You cannot transfer or assign your rights under these Terms and Conditions of Use. The Company may assign our rights under these Terms and Conditions of Use to a third party at our sole and absolute discretion.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span class="Aucun">
        <b>
          <span>7.8</span>
        </b>
      </span>
      <u>
        <span>Transferability</span>
      </u>
      <span class="Aucun"></span>
    </p>
    <p class="normal">
      <span class="Aucun"></span>
    </p>
    <p class="normal">
      <span class="Aucun">
        <span>While the balance of your Dolfin Wallet can be transferred to any third parties, your Dolfin Wallet Account is non</span>
      </span>
      <span class="Aucun">
        <span>-</span>
      </span>
      <span class="Aucun">
        <span>transferrable to any third parties</span>
      </span>
      <span class="Aucun">
        <span>.</span>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.9</span>
      </b>
      <u>
        <span>Severability</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>If any term under these Terms and Conditions of Use is held to be illegal, invalid, or unenforceable, in whole or in part, under any enactment or rule of law, the term or part of it will, to that extent, be deemed not to form part of these Terms and Conditions of Use,</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>but the legality, validity, or enforceability of the remainder of these Terms and Conditions of Use will not be affected</span>
      <span>.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.10</span>
      </b>
      <u>
        <span>Governing Law</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>These Terms and Conditions of Use are governed by and to be construed under the laws of Thailand.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.11</span>
      </b>
      <u>
        <span>Amendment</span>
      </u>
    </p>
    <p class="normal">
      <u>
        <span></span>
      </u>
    </p>
    <p class="normal">
      <span>These Terms and Conditions of Use, partly or wholly, including any features or services offered in the Dolfin Wallet Account, may be modified, varied, or otherwise changed from time to time at our sole discretion, and the Company will notify you of such modification, variation, and</span>
      <span>/</span>
      <span>or change in a timely manner by announcement and other means as specified in Clause 7.14 below</span>
      <span>.</span>
      <span>If there are changes which negatively impact you, the Company will notify you at least 30 days prior to the implementation of such changes</span>
      <span>.</span>
      <span>You are required to accept the modification, variation, and</span>
      <span>/</span>
      <span>or change before continuing using Dolfin Wallet</span>
      <span>.</span>
      <span>The continued use of Dolfin Wallet after any modification, variation and</span>
      <span>/</span>
      <span>or change to the Terms and Conditions of Use will constitute your consent to and acceptance of the modification, variation, and</span>
      <span>/</span>
      <span>or change</span>
      <span>.</span>
      <span>Therefore, if you do not agree with the modification, variation, and</span>
      <span>/</span>
      <span>or change, please cease using Dolfin Wallet</span>
      <span>.</span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.12</span>
      </b>
      <u>
        <span>Privacy Policy</span>
      </u>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <span>Your personal data and information are maintained in accordance with the Company’s privacy policy</span>
      <span>.</span>
      <span>The privacy policy constitutes an integral part of these Terms and Conditions of Use and your acceptance to these Terms and Conditions of Use constitutes your acceptance of our privacy policy</span>
      <span>.</span>
      <span>The privacy policy is available on the Company’s official website (www.dolfinwallet.com)</span>
      <span>and in the Dolfin Application</span>
      <span>.</span>
    </p>
    <p class="graph">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>7.13</span>
      </b>
      <u>
        <span>Entirety of Agreement</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>These Terms and Conditions of Use are legal agreement between</span>
      <span>the Company</span>
      <span>and you and shall constitute an integral part of the terms and conditions and relevant rules published on our official website</span>
      <span>(www.dolfinwallet.com)</span>
      <span>from time to time</span>
      <span>.</span>
      <span>In case any matter is specified in the terms and conditions and relevant rules announced on www.dolfinwallet.com website but not specified in these Terms and Conditions of Use, the terms and conditions and relevant rules specified in www.dolfinwallet.com website shall prevail as to such matter</span>
      <span>.</span>
    </p>
    <p class="normal">
      <b></b>
    </p>
    <p class="normal">
      <b>
        <span>7.14</span>
      </b>
      <u>
        <span>Notices</span>
      </u>
    </p>
    <p class="normal">
      <span class="Aucun"></span>
    </p>
    <p class="normal">
      <span class="Aucun">
        <span>The Company may give notice by means of a general notice on the Dolfin Application, or
          <a name="_Hlk533626579">by electronic mail to your e</a>
        </span>
      </span>
      <span class="Aucun">
        <span>-</span>
      </span>
      <span class="Aucun">
        <span>mail</span>
      </span>
      <span class="Aucun">
        <span>address in our records, or by written communication sent by registered mail or pre</span>
      </span>
      <span class="Aucun">
        <span>-</span>
      </span>
      <span class="Aucun">
        <span>paid post to your address in the Company’s record</span>
      </span>
      <span class="Aucun">
        <span>.</span>
      </span>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <b>
        <span>7.15</span>
      </b>
      <u>
        <span>Term</span>
      </u>
    </p>
    <p class="pb20"></p>
    <p class="normal">
      <span>These Terms and Conditions of Use shall become effective upon acceptance of the Terms and Conditions of Use by the User and for an unspecified period.</span>
    </p>
  </div>
</template>
<style lang="scss" scoped>
ul {
  padding-left: 0.2rem;
  padding-top: 0.2rem;

  b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
  }
}

/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}

.jm-protocol {
   .txt-title {
    text-align: center;
    font-size: 24px;
    padding-bottom: .48rem;
  }
  strong,
  b span {
    font-weight: bold;
    font-family: The1Official_Bold;
  }

  font-size: 14px;
   color: #141E50;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
    a {
      color: #141E50;
    }
}

.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}

.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}

.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}

.jm-protocol ol,
.jm-protocol ul {
  list-style-type: none;
  list-style-image: none;
}

.jm-protocol li {
  list-style: none;
}

.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
  border-collapse: initial;
  border-spacing: 1px;

}

.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}

.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}

.jm-protocol a {
  text-decoration: none;
}

.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}

.jm-protocol a:focus {
  outline: dotted 1px;
}

.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}

.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}

.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

