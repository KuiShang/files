<template>
  <component :is="currentTabComponent"/>
</template>
<script>
import EN from './privacy/en'
import TH from './privacy/th'
export default {
  components: { EN, TH },
  data() {
    return {
      currentTabComponent: 'EN'
    }
  },
  created() {
     this.$SDK.setTitle({
      title: '', 
      mHeaderTitle: {
      showEnd: 0,
        showBack: 1
      }
    })
    const deviceinfo = this.$DeviceInfo || {}
    if (deviceinfo.language === 'en_US') {
      this.currentTabComponent = 'EN'
    } else {
      this.currentTabComponent = 'TH'
    }
  }
}
</script>
