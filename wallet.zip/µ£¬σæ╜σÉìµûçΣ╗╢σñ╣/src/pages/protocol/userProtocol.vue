<template>
     <div class="jm-protocol">

          <div class="jm-protocol">
    <h1><span>Terms and conditions of the service & Privacy policy</span></h1>
    <p class="pb20"></p>
    <p class=normal><b><span>Important Note</span></b><span> – These Terms of Use (as defined below) govern the terms
        and conditions of use of the CJD Wallet (as defined below) and CJD Wallet Account (as defined below) published
        and provided by <a name="_cp_text_1_4">Central JD Money Co., Ltd</a>. The Terms of Use constitute a legal
        agreement, so please read these Terms of Use carefully before registering your CJD Wallet Account. By using the
        CJD Wallet Services (as defined below), you agree that you have read, understood, accepted and agreed with the
        Terms of Use. You further agree to the representations made by yourself below. If you do not agree to or fall
        within these Terms of Use and wish to discontinue using the CJD Wallet Services, please do not continue using
        the CJD Application (as defined below) or the CJD Wallet Services. The Terms of Use are accessible at any time
        on the ###### website or from the CJD Application. The Terms of Use shall apply to all <a name="_cp_text_1_6">Users
        </a>(as defined below).</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1 GENERAL TERMS</span></b></p>
    <p class=normal><b><span>1.1 CJD Application</span></b><span> is a software application accessible by a Smartphone
        that serves as a means used by customer to buy goods or services provided by third parties (such as ######
        merchants), who use the application as a forum to provide their goods or services, which may be provided from
        time to time through this application.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.2 CJD Wallet</span></b><span> is an electronic money issued by Central JD Money Co.,
        Ltd. which is registered and recorded with its issuer and regulated by the Bank of Thailand, having the same
        function as cash money to be used as a valid payment tool, of which value is equivalent to the cash money
        deposited in advance to the CJD Wallet Account.<a name="_cp_text_1_7"> CJD Wallet is also a platform that
          allows customers to link/bind bank accounts, credit cards, debit cards or The 1 Point accounts in order to
          make Payments.</a></span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.3 CJD Wallet Account </span></b><span>is the account for which every CJD Wallet User is
        given at the time of registration. This account will be set up according to your information details that you
        have provided us when making the registration.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.4 Central JD Money Co., Ltd., “us”, “we”, or “our”</span></b><span> is a limited
        liability company duly established and operated under the laws of Thailand and domiciled in Thailand, which
        facilitates any payment transaction between customers using CJD Wallet and merchants.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.5 Smartphone</span></b><span> is a mobile cellular phone with Android, iOS, and/or other
        operating systems that are compatible to run the CJD Application and CJD Wallet.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.6 Top-Up</span></b><span> is the account balance top-up service for the CJD Wallet
        Account which can be performed via ###### website or CJD Application, by various means stipulated in Clause 3.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.7 Payment</span></b><span> is a payment made through or facilitated by CJD Wallet for
        paying transaction bills to merchants who offer their services and for paying other bills as may be made
        possible by CJD Wallet from time to time. In the case where the Payment is made through the balance in the CJD
        Wallet Account, each Payment will automatically reduce the balance shown in your CJD Wallet Account by the
        corresponding amount. In the case where the Payment is made by using the balance in a linked/bound bank account
        or The 1 Point, each Payment will automatically reduce the balance shown in the linked/bound bank account or
        The 1 Point account by the corresponding amount. In the case where the Payment is made by using credit card or
        debit card, each Payment will charge to the credit card or debit card by the corresponding amount. </span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.8 User, “you”, or “your”</span></b><span> is a party who has registered him/herself in
        the CJD Wallet Account and makes a Top-Up <a name="_cp_text_1_9">or links other types of source of fund
          permitted by us, </a>and therefore can use CJD Wallet in a manner described herein and agrees to these Terms
        of Use.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.9 Terms of Use</span></b><span> are these terms and conditions of use of the CJD Wallet
        and CJD Wallet Account as may be amended, modified, and/or varied from time to time by us and notified to you
        in a manner described in Clause 11.13.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.10 Balance Transfer</span></b><span> is a service offered by CJD Wallet to transfer <a
          name="_cp_text_1_11">account balance stored in the User's CJD Wallet Account </a>to another CJD Wallet <a
          name="_cp_text_1_13">Account </a>or bank account.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>1.11 CJD Wallet Services</span></b><span> are services provided by CJD Wallet which
        consist of:</span></p>
    <p class=normal><span>1. Top-Up;</span></p>
    <p class=normal><span>2. Payment;</span></p>
    <p class=normal><span>3. Balance Transfer; and/or</span></p>
    <p class=normal><span>4. Other services that we may add from time to time as approved by Bank of Thailand, or other
        relevant authorities.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>2 ACCOUNT REGISTRATION</span></b></p>
    <p class=normal><span>2.1 To use CJD Wallet, you must do the registration with Central JD Money Co., Ltd., which
        may be completed through the CJD Application that has been downloaded to your Smartphones. You are under
        obligation to provide the correct, true and most up-dated information details of yourself.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>2.2 For the purpose of registering your CJD Wallet Account and/or using certain services
        under the CJD Wallet Services, we may, at our sole discretion, ask you to submit additional documents or
        information, such as your latest photograph and/or a copy of your valid identity document (e.g.,###). You may
        send us the documents electronically or directly to our office, subject to our specific instructions on this.
        We will verify your submitted documentation and determine your eligibility based on the submitted documents. We
        may also require further information from you and may need to meet you in person (or through our agent) if
        needed. </span></p>
    <p class=normal><span>You agree that we have the right to terminate our services to you if you are deemed to have
        failed to comply with any of the additional requirements in the manner and within the timeline set out in our
        notice to you in this regard, or we found out that your information details set out in these additional
        documents are not consistent with those you provided when registering the CJD Wallet Account. By making those
        documents available to us, you are deemed to consent to the collection, use, processing, and disclosure by us
        of your personal information as indicated in the documents you provide to us, in accordance with the prevailing
        laws and regulations. For the purpose of processing your Application or any other purposes we deem appropriate,
        you agree that we may disclose your personal information which is given in the course of your account
        registration application to any third parties, including governmental and monetary authorities and third-party
        processors, to the extent permitted by the prevailing laws and regulations.</span></p>
    <p class="pb20"></p>
    <p class=normal><span> In addition, you undertake to provide accurate and complete information, keep the
        information up to date and agree to provide us whatever proof of identity we may reasonably ask for. If any of
        the personal information that you have provided to us changes, for example, if you change your e-mail address
        or telephone number, you must immediately update your details through the system provided. We will, to the best
        of our liabilities, effect such changes as requested immediately. We will not be liable for any loss you may
        suffer due to your failure to update your details through the relevant system.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>2.3 For the account registration through CJD Application, you will choose your own password
        and other login details necessary to identify you. You are strictly prohibited from disclosing your log-in
        details to any third parties, except as required by the prevailing laws and regulations (which in this case,
        you will notify us in writing of such disclosure immediately). We or our officers will never ask for your
        password in any communications between you and us (except to log-in to your CJD Wallet Account or to use your
        CJD Wallet Account to make any payment transaction in the CJD Application using your Smartphone). You agree to
        bear any risks associated with the disclosure of your log-in details to any third parties and are fully
        responsible for any consequences related thereto.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>2.4 You represent and warrant that you are an individual legally entitled to enter into a
        binding agreement under the laws of Thailand, in particular the Terms of Use, to use CJD Wallet and that you
        are at least 20 (twenty) years old or are married and not under guardianship. If you do not satisfy any of
        these requirements but still access the CJD Wallet, you represent and warrant that your account opening and
        other activities in CJD Wallet have been approved and/or consented to by your parents/legal guardian. You waive
        any right that the law may provide you to cancel or revoke any and all of your consents given under these Terms
        of Use by the time you are by law deemed mature. You fully release and hold harmless us and our officers from
        any consequences related thereto.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>2.5 Please make sure that any orders made through the CJD Application using your CJD Wallet
        Account are made strictly only by you. DO NOT ASK OR ALLOW OTHERS TO MAKE AN ORDER USING YOUR CJD <a name="_cp_text_1_15">WALLET
        </a>ACCOUNT. You hereby acknowledge that, while we do our best to implement our business, it is not an easy
        task to make sure who actually is behind the screen. Therefore, you agree that any order made through your CJD
        Wallet Account will be deemed a valid order made by you as if the order were actually made by you. You further
        represent and warrant that you have the right, authority and capacity to use CJD Wallet and to abide by these
        Terms of Use.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>3 TOP-UP AND LIMIT</span></b></p>
    <p class=normal><span>3.1 You may Top-Up your CJD Wallet Account from time to time according to your need by
        following the instructions set out in your CJD Wallet Account. Note that your CJD Wallet Account to which your
        virtual money is deposited is not a saving within the meaning of laws and regulations on banking and not
        subject to protection program provided by the ###. Accordingly, your CJD Wallet Account may not be entitled to
        any features that are usually attached to bank accounts (such as interests, etc.). Also, Central JD Money Co.,
        Ltd. is not a bank and therefore, our services should not be understood as banking services.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>3.2 You may Top-Up your account through various means, platforms, or institutions that may be
        determined from time to time by <a name="_cp_text_1_17">us</a>, including but not limited to (i) a direct bank
        transfer through bank accounts <a name="_cp_text_1_18">opened </a>with certain banks cooperating with us, (ii)
        a credit card, a debit card, The 1 point, and (iii) other types of <a name="_cp_text_1_21">source of fund
          permitted by us</a>. For (i), certain fees may be charged by the relevant banks.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>3.3 The maximum amount of an individual's CJD Wallet balance account is Baht 100,000.<a name="_cp_text_1_22"></a></span></p>
    <p class="pb20"></p>
    <p class=normal><span>3.4 If your CJD Wallet Account exceeds the limit set out in Clause 3.3 above, we are entitled
        to verify your CJD Wallet Account before we take any further action (such as to return the excess amount). In
        making the decision, we will determine, among other things, whether the funds came from a legal source (for
        example, not come from illegal activities/criminal acts). If, for example, we find that the source of the funds
        is illegal, you agree that we have the right to take any action necessary to comply with any regulatory
        requirements, including but not limited to reporting the event to the relevant government institution.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>4 USE OF YOUR CJD <a name="_cp_text_1_24">WALLET </a>FEATURES</span></b></p>
    <p class=normal><span>4.1 CJD Wallet can only be used for the CJD Wallet Services provided in the CJD Application.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>4.2 You can use the CJD Wallet Services as long as you have sufficient funds in your CJD
        Wallet Account and the transactions are made with the merchants that have entered into a cooperation agreement
        with us and/or our affiliated companies. The list of the merchants is available and will be updated from time
        to time (depending on our agreement with each of the merchants), in your CJD Application, or in the case of
        offline merchants, as notified to you from time to time. Alternatively, you can also <a name="_cp_text_1_26">use
          the </a>CJD Wallet Services <a name="_cp_text_1_27">to complete your transaction </a>by a direct calling
        transaction from the source of funds which you have linked with your CJD Wallet Account; e.g. a bank account, a
        credit card, a debit card, The 1 point, or other <a name="_cp_text_1_30">types of source of fund </a>permitted
        by <a name="_cp_text_1_32">us</a>. </span></p>
    <p class="pb20"></p>
    <p class=normal><span>4.3 In the case where Payment is made through the balance in the CJD Wallet Account, upon
        receiving your request for Payment, our system will verify the request and check your CJD Wallet Account
        balance. If a sufficient fund is available, the balance in the relevant CJD Wallet Account will be deducted.
        You may be required to confirm the amount to be paid by CJW Wallet Account if such amount is higher than the
        transaction limit indicated by you in the CJD Application. </span></p>
    <p class="pb20"></p>
    <p class=normal><span>In the case where Payment is made using a linked/bound bank account or debit card, upon
        receiving your request for Payment, the CJD system will connect with the bank system to check if there are
        sufficient funds available in the such account or the account to which the debit card is linked (as the case
        may be). If the funds in the relevant account are sufficient for the payment, the CJD system will send the
        deduction request to the bank account to proceed with the Payment transaction. </span></p>
    <p class="pb20"></p>
    <p class=normal><span>In case where Payment is made using the The1 point, upon receiving your request for Payment,
        the CJD system will connect with the The1 point system to check if there are sufficient The1 points available
        in such account. If there are sufficient The1 points in the account, the CJD system will send the deduction
        request to The1point system to proceed with the payment transaction.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>In case where Payment is made using credit card, upon receiving your request for Payment, the
        CJD system will connect with the credit card issuer’s system to check if there is sufficient available credit.
        If there is sufficient available credit, the CJD system will send the charge request to the credit card
        issuer’s system to proceed with the payment transaction.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>In all cases mentioned above, once transaction is completed, the transaction cannot be
        cancelled. It is within our sole discretion to review and determine the cancellation or chargeback request on
        case per case basis.<a name="_cp_text_1_33"></a></span></p>
    <p class="pb20"></p>
    <p class=normal><span>4.4 Your use of your CJD Wallet Account and/or the CJD Wallet Services is subject to the
        terms of use of the CJD Application, the applicable terms and conditions of other features provided in the CJD
        Application, these Terms of Use, the privacy policy and any other applicable prevailing laws and regulations in
        ###.The use of your CJD Wallet Account and/or the CJD Wallet Services is your sole responsibility and we are
        not and cannot be held liable for any losses, damages, or claims arise due to your use of CJD Wallet Account
        and/or the CJD Wallet Services that is not in compliance with any applicable terms and conditions or prevailing
        laws and regulations.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>5 ACCOUNT BLOCKING</span></b></p>
    <p class=normal><span>5.1 We may, at our sole discretion or at your request, block your CJD Wallet Account and the
        use of the CJD Wallet Services upon the occurrence of any event or circumstance which we consider to be
        detrimental to either you or us. These events or circumstances include (but are not limited to) the following:</span></p>
    <p class=normal><span>a. the use of the CJD Wallet Account and/or the CJD Wallet Services either by you or any
        other third parties (misusing your account) in a manner contrary to these Terms of Use, our terms and
        conditions for each product featured in the CJD Application, our privacy policy or the prevailing laws and
        regulations, including but not limited to for the purpose of anti-money laundering and countering terrorism and
        proliferation of weapons of mass destruction financing, criminal activities, fraud or any activities that may
        be detrimental to the public and/or any other party;</span></p>
    <p class=normal><span>b. the loss/theft/hacking of your Smartphone or log-in details that you have reported to us;</span></p>
    <p class=normal><span>c. an instruction to block issued by any relevant government or monetary institution or under
        a court ruling issued in accordance with the prevailing laws and regulations; and/or</span></p>
    <p class=normal><span>d. any other reasons we deem necessary.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>In such an event, we will notify you with or without providing details of the reason for the
        blocking. Subject to the provisions hereof, the blocking will not be unreasonably continued once we determine
        that the event or circumstance giving rise to the blocking has ended.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>5.2 If your CJD Wallet Account is blocked while you have strong evidence that no suspicious
        event or circumstance has occurred, you may file a complaint in the manner described in Clause 6.7. Upon
        reviewing your complaint, we may, at our discretion, decide whether to end or continue the account blocking.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>6 ISSUES AND COMPLAINTS</span></b></p>
    <p class=normal><span>6.1 Discrepancies. Your transactions using CJD Wallet are saved electronically in our server.
        You acknowledge that we have made our best effort to maintain the security of the system. However, unless an
        error is caused directly by us, in the event of any discrepancy between the data and the balance and/or
        transactions history indicated in your CJD Wallet Account and the data and the balance and/or transactions
        history held and managed by us, the data and the balance and/or transactions history held and managed by us
        will be deemed conclusive evidence and binding upon both parties.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>6.2 Dormant Account. If you do not use your CJD Wallet Account for a minimum of consecutive 6
        (six) months, we may block your CJD Wallet Account. To reactivate the relevant <a name="_cp_text_1_35">CJD
          Wallet Account</a>, you may file a complaint in the manner described in Clause 6.7. Upon verification of your
        personal information, we may, at our discretion, decide whether to end or continue the account blocking.
        Certain fees may be imposed with respect to the dormant account which may be determined from time to time by us
        and notified to you in the manner described in Clause 11.13.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>6.3 Personal Data. You understand that when using your CJD Wallet Account (including
        commenting on our services in the User's reviews), certain of your personal data may be collected, used,
        processed, and/or disclosed by us so that you can enjoy the CJD Wallet Services to the fullest extent of its
        functionality. For the purpose of operating the CJD Wallet Account and/or any other purposes we deem
        appropriate, you hereby consent to the collection, use, processing, and disclosure of any and all of your
        personal data by us and you are also fully aware that some of your data or information will be accessible to
        the third party whose services you use (such as the merchants) through our Application. For avoidance of
        doubts, you also allow us to disclose your personal data to any third parties we engage with, or to any
        authority (including judicial authority) in accordance with the prevailing laws and regulations. We will not be
        liable for any loss you may suffer due to any misuse by the third party of your data or information that has
        been disclosed according to this Clause. You also acknowledge that we may be required to disclose your personal
        data to any authority (including a judicial or monetary authority) under the prevailing laws and regulations.</span></p>
    <p class="pb20"></p>
    <p class="pb20"></p>
    <p class=normal><span>6.4 Viruses, Errors, Bugs, and Other Forms of System Interruption. Your online safety and
        security is of the utmost importance for us. We employ reasonable security measures to safeguard your data in
        transit, while stored and your use of the CJD Wallet Account and/or CJD Wallet Services. However, we would like
        to highlight that no system is impenetrable, and this may result in increased risk exposures of your
        information and use of the CJD Wallet Account and/or CJD Wallet Services. Therefore, without limiting the
        generality of Clause 10, to the extent permissible under the prevailing laws and regulations, you agree to
        release us from any claims arising out of or in connection with the viruses, errors, bugs, or other forms of
        system interruption, including unauthorized access by third parties. We encourage you to notify us immediately
        if you encounter any system interruptions above so that we can make an effort to fix the problems.</span></p>
    <p class="pb20"></p>
    <p class=normal><span> In addition, you undertake not to harm, tweak or modify your CJD Wallet Account or attempt
        to harm, tweak or modify it in any way whatsoever. We will not be liable if you do not have a compatible device
        or if you have downloaded the wrong version of CJD Wallet to your device. We reserve the right to prohibit you
        from using CJD Wallet and/or CJD Wallet Services further if you use the aforesaid with an incompatible or
        unauthorized device or for purposes other than those for which the CJD Wallet and/or CJD Wallet Services are
        intended to be used. For the avoidance of doubt, no system interruption will limit your obligation to make
        Payment in full through either a Top-Up or in cash.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>6.5 Errors with Your Bank's System. As a Top-Up, transfer and credit card/debit card Top-up
        will each involve a transaction using your bank account, in the event of any error in or related to your bank’s
        system, you agree to settle the problem directly with the bank, with or without our assistance. We will not be
        liable for this problem in any of the above scenarios.<a name="_cp_text_1_36"></a></span></p>
    <p class="pb20"></p>
    <p class=normal><span>6.6 Loss/Theft/Hack of Your Smartphone or Log-in Details. If your Smartphone or log-in
        details are lost, theft, and/or hacked, please let us know without delay through complaint mechanism below. If
        any delay occurs between the events and your notification of such events and there is any transaction entered
        into by your account, you agree that once executed, the Payment for such transaction will be deemed a valid
        payment.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>6.7 Questions, Requests and Complaints. If you have any questions, requests or complaints
        about the CJD Wallet features, please send us an e-mail at***** or call us at *****.We will investigate and
        provide updates to <a name="_cp_text_1_38">you </a>and also explain the steps for this as well as inform them
        of the timeline for resolution of the complaint within seven days after receiving the complaint.</span></p>
    <p class="pb20"></p>
    <p class=normal><span> To respond to your questions, requests, or complaints, we will first verify your data. We
        are entitled to refuse to process your questions, requests, or complaints if your data does not match the data
        stored in our system.</span></p>
    <p class="pb20"></p>
    <p class=normal><span> We will check or verify your complaint and respond to you promptly in accordance with the
        policies and procedures applicable in our company after receiving a complete complaint submission from you.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>7 ACCOUNT CLOSING</span></b></p>
    <p class=normal><span>7.1 A CJD Wallet Account may be closed due to the following:</span></p>
    <p class=normal><span>a. a request by you;</span></p>
    <p class=normal><span>b. our policy in accordance with the prevailing laws and regulations;</span></p>
    <p class=normal><span>c. a Force Majeure (as defined below) condition which continues for more than 3 (three)
        months consecutively as stipulated in Clause 11.2 below; and/or</span></p>
    <p class=normal><span>d. reasons related to the account blocking as set out in Clause 5.1.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>7.2 In the event of an account closing, we will refund in full the remaining balance in your
        CJD Wallet Account to you by the redemption method agreed to between the parties, after the payment of any
        outstanding fees (if any), unless there exists any event or circumstance which we consider to be or might be
        detrimental to us or any other party that requires us to retain certain amount of your CJD Wallet balance, for
        example, due to reasonable belief that it is associated to or resulted from fraud.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>8 USER’S RESPONSIBILITIES</span></b></p>
    <p class=normal><span>8.1 The responsibilities specified in this Clause 8 are in addition to any responsibilities
        imposed elsewhere under these Terms of Use.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>8.2 You are responsible for the security of your Smartphone and log-in details which is used
        to access your CJD Wallet Account by properly maintaining and making available sufficient storage to prevent
        any failure/error in any process of the CJD Wallet Services due to a non-functioning Smartphone.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>8.3 You are responsible for every transaction you enter into. Therefore, you must be careful
        when using the CJD Wallet Account and/or CJD Wallet Services and/or CJD Application, including but not limited
        to when choosing from the transaction menu, the purpose of payment, entering any value in the transaction, etc.
        Save for errors caused by Central JD Money Co., Ltd., any loss and/or damage caused by your mistake when using
        the CJD Wallet Services or CJD Application described above will be at your own risk, responsibility, and
        liability. You must carefully follow every direction for using the CJD Wallet Services and/or CJD Application
        or for entering into any transactions.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>8.4 You are fully responsible for any loss or claim arising from the misuse of and/or a
        violation and/or crime committed using your CJD Wallet Account and/or CJD Wallet Services, including but not
        limited to any damage arising from any mistake, incautious act or recklessness or any misuse of the CJD Wallet
        Account and/or CJD Wallet Services by you or any third party using your CJD Wallet Account.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>9 LIMITATION OF OUR LIABILITY</span></b></p>
    <p class=normal><span>9.1 Any claim brought against us by you either based on these Terms of Use or otherwise will
        in any event be limited to the aggregate amount of all amounts actually paid by and/or due from you when using
        your CJD Wallet during the event giving rise to the claim. In no event will we be liable to you or anyone for
        costs, interests, damages, or losses of any type or kind (including personal injury, emotional distress, and
        loss of data, goods, revenue, profits, use or other economic advantage), save for direct losses, arising out
        of, or in any way connected with the CJD Wallet Account and/or CJD Wallet Services, as long as they can be
        proven to occur solely due to our gross negligence and breach of these Terms of Use. In any case, our liability
        will only be limited to the latest balance of your CJD Wallet recorded in our system or ###, whichever is
        lower.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>10 INDEMNIFICATION</span></b></p>
    <p class=normal><span>10.1 By registering for and using of a CJD Wallet Account and using the CJD Wallet Services,
        you agree that you will defend, indemnify, and hold us, our licensors, affiliates, and each of our officers,
        directors, commissioners, employees, attorneys, and agents, harmless from and against any and all claims,
        costs, damages, losses, liabilities, and expenses (including attorneys’ fees and costs) arising out of or in
        connection with:</span></p>
    <p class=normal><span>a. your violation or breach of any of these Terms of Use or any applicable laws or
        regulations, whether or not referenced herein, or</span></p>
    <p class=normal><span>b. your violation of any right of any third party related to the CJD Wallet and/or CJD Wallet
        Services, or</span></p>
    <p class=normal><span>c. any use or misuse of the CJD Wallet and/or CJD Wallet Services by you or any party through
        your account, or</span></p>
    <p class=normal><span>d. the blocking of your CJD Wallet Account for reasons set out in Clause 5 above.</span></p>
    <p class="pb20"></p>
    <p class=normal><span>This defense and indemnification obligation will survive these Terms of Use and your use of
        our official website, regardless of the closing of your CJD Wallet Account.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11 MISCELLANEOUS</span></b></p>
    <p class=normal><b><span>11.1 Service Fees</span></b><span> During your use of CJD Wallet services, we have the
        right to charge from you certain service fees. We have the right to formulate and adjust the service fees. If
        there are changes which negatively impact you, we will notify you at least 30 days prior to the implementation
        of such changes. Please refer to the notice on Website when you use the ### services or any other agreement you
        have entered into with us for specific service fee standard. Unless otherwise specified, you agree that we have
        the right to deduct above service fees from the funds that you entrusted the us to collect or to pay or from
        residual balance of any of your CJD Wallet Account.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.2 Force Majeure. </span></b><span>Our services may be interrupted due to certain events
        or causes beyond our power and ability to control (hereinafter, the Force Majeure), including but not limited
        to natural disasters, electrical disturbances, telecommunications disruptions, government policy, and other
        causes beyond our power and ability to control. You therefore agree to release us from any claims whatsoever if
        we are unable to follow your instructions in the CJD Wallet Account either partially or wholly due to Force
        Majeure. If a Force Majeure condition continues for more than 3 (three) months consecutively, we may close your
        CJD Wallet Account in accordance with Clause 7 above.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.3 Intellectual Property. </span></b><span>CJD Wallet, including its name and logo,
        codes, designs, technology, business model, is protected by copyright, trademark, and other intellectual
        property rights provided under the laws of ###. We (and our licensees, if applicable) exclusively own and
        retain all rights, title, and interest in and to CJD Wallet, including all associated intellectual property
        rights. These Terms of Use are not in any way be treated as our permission for you to use any of our
        intellectual property assets above.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.4 No Waiver. </span></b><span>Our waiver or forbearance or failure to claim a breach of
        any provision of these Terms of Use or to exercise any right provided by these Terms of Use or the applicable
        law, may not be deemed to constitute a waiver with respect to any subsequent breach of any provision hereof.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.5 Language. </span></b><span>These Terms of Use are drawn up in both the English and
        the Thai languages, both of which versions are binding on you and us. In the event of any inconsistency between
        the Thai language version and the English language version, the Thai language version will prevail.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.6 Assignment. </span></b><span>You may not transfer or assign your rights under these
        Terms of Use, without our prior written approval. We may assign our rights under these Terms of Use to a third
        party at our sole and absolute discretion.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.7 Transferability. </span></b><span>While the balance of your CJD Wallet can be
        transferred to any third parties, your CJD Wallet Account is non-transferrable to any third parties.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.8 Severability. </span></b><span>If any term under these Terms of Use is held to be
        illegal, invalid, or unenforceable, in whole or in part, under any enactment or rule of law, the term or part
        of it will, to that extent, be deemed not to form part of these Terms of Use, but the legality, validity, or
        enforceability of the remainder of these Terms of Use will not be affected.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.9 Governing Law. </span></b><span>These Terms of Use are governed by and to be
        construed under the laws of ###. Any and all disputes arising out of, or in connection to the use of our
        services herein will be settled through amicable negotiation between the User and us. If such amicable
        negotiation fails to reach an agreement, the dispute will be subject to the exclusive jurisdiction of the
        competent court located in the domicile of Central JD Money Limited, which has the jurisdiction for such
        dispute resolution. The parties hereto agree to continue to perform their obligations under these Terms of Use
        during the dispute resolution process.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.10 Amendments. </span></b><span>These Terms of Use, partly or wholly, including any
        features or services offered in the CJD Wallet Account, may be modified, varied, or otherwise changed from time
        to time at our sole discretion, and we will notify you of such modification, variation, and/or change in a
        timely manner by announcement and other means obvious to you as specified in Clause 11.13 below. If there are
        changes which negatively impact you, we will notify you at least 30 days prior to the implementation of such
        changes. You are required to accept the modification, variation, and/or change before continuing using CJD
        Wallet. The continued use of CJD Wallet after any modification, variation and/or change to the Terms of Use
        will constitute your consent to and acceptance of the modification, variation, and/or change. Therefore, IF YOU
        DO NOT AGREE WITH THE MODIFICATION, VARIATION, AND/OR CHANGE, PLEASE CEASE USING CJD <a name="_cp_text_1_40">WALLET</a>.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.11 Privacy Policy.</span></b><span> Your personal data and information are maintained
        in accordance with our privacy policy. The privacy policy constitutes an integral part of these Terms of Use
        and your consent to these Terms of Use constitutes your acceptance of our privacy policy. Our privacy policy is
        available from our official website (<a href="https://www.id.id" target="_self"><span>###</span></a>) and the
        CJD Application.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.12 Entirety of Agreement. </span></b><span>These Terms of Use are legal agreement
        between Central JD Money Limited and the User and shall constitute an integral part of the terms and conditions
        and relevant rules published on our official website (https://www.######) from time to time. In case any matter
        is specified in the terms and conditions and relevant rules of the ###### website but not specified in these
        Terms of Use, the terms and conditions and relevant rules specified in the ###### website shall prevail as to
        such matter. </span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.13 Notices.</span></b><span> We may give notice by means of a general notice on the CJD
        Application, or by electronic mail to your e-mail address in our records, or by written communication sent by
        registered mail or pre-paid post to your address in our record. Such notice shall be deemed to have been given
        upon the expiration of 48 (forty-eight) hours after mailing or posting (if sent by registered mail or pre-paid
        post) or 1 (one) hour after sending (if sent by e-mail).You may give notice to us (such notice shall be deemed
        given when received by us) by letter sent by courier or registered mail using the contact details as provided
        in the CJD Application.</span></p>
    <p class="pb20"></p>
    <p class=normal><b><span>11.14 Term.</span></b><span> These Terms of Use shall become effective upon acceptance of
        the Terms of Use by the User and for an unspecified period.</span></p>
    <p class="pb20"></p>
    <p class="pb20"></p>
  </div>



    <h1><span>Privacy policy</span></h1>
    <br>

    <p class=normal><b><span>Personal Information Protection Policy</span></b></p>

    <p class=normal><span> We, Central JD Money Co., Ltd. (“CJD”), are aware of the importance of the protection of the
Personal Information (to be defined hereinafter) of the CDJ Waller’s users. We chose the updated and
highly secured technology for the storage of the Personal Information, and we’ve limited the access to
the Personal Information for our responsible staffs or other relevant person only. We will strictly
monitor the access and use of the Personal Information, and also procure the continuously development
of the storage system, so that it will be accurate and reliable, and it is capable of preventing the leakage
of the Personal Information, the change of the Personal Information by the irrelevant person, or the
wrong use of the Personal Information.</span></p>







    <p class=normal><b><span>Collection of the Personal Information</span></b></p>

    <p class=normal><span> Upon your application for our CJD Wallet, we will request you to provide us your personal
information, including but not limited to, name, last name, date of birth, national ID number, address,
mobile number, e-mail, photo of your national ID card (front and back), your photo, and/or other
information necessary for the identification of your identity (“Personal Information”). It is up to your
sole discretion to provide us the Personal Information and to consent us to keep, use, and disclose the
Personal Information, however, if you decide to not provide us the Personal Information, we may have
to limit you the use our CJD Wallet or we may not be able to service you. In addition, we will keep the
information related to your use of our services in our storage system.

<br>

In order to ensure that the Personal Information is accurately kept and reliable, you shall update
your information provided to us that they are accurate, complete, and up-to-date at all time. Wrong
confirmation on the Personal Information may result in certain limitation or prohibition of the use of CJD
Wallet.


</span></p>







    <p class=normal><b><span>Storage and use of the Personal Information</span></b></p>

    <p class=normal><span> We will keep your Personal Information during the period when you are using our CJD Wallet
and after such period for a period necessary and related to the contractual obligations under our
agreement or for the period required by the applicable laws. We assure you that we shall keep and store
your Personal Information with the highly updated and secured technology and we will have the access
conditions to the Personal Information.
<br>


Your Personal Information will be used to identify and authenticate your identity, to service you
the CJD Wallet, to analyze and develop our services, to check and monitor the security of our service, to
contact you, to comply by the applicable laws, and to allow us to take any necessary action related to
the service of CJD Wallet.

<br>

We may use your Personal Information for our analysis, matching, comparison, research so that
our affiliate or business partner can offer you its products or services or special promotion which is
according to your need.
<br>



The Personal Information Protection Policy is an integral part of the users’ terms and conditions
of the CJD Wallet. Upon your acceptance of our users’ terms and conditions of the CJD Wallet, it shall be
deemed that you have also accepted our Personal Information Protection Policy as well.

<br>

</span></p>









    <p class=normal><b><span>Disclosure to a third party</span></b></p>

    <p class=normal><span> We shall explicitly require you to consent for the disclosure of your Personal Information by us in the
terms and conditions for the CJD Wallet, and we shall not disclose your Personal Information for any
other purpose than the purposed which have been consented for by you, except the following:

<br>

<ul>
<li><b>1.</b>  A disclosure for the legal investigation or court proceeding;</li>
<li><b>2. </b> A disclosure to our auditor;</li>
<li><b>3. </b> A disclosure for the compliance with the applicable laws;</li>
<li><b>4. </b> A disclosure for the supervision the payment system by the Bank of Thailand;</li>
<li><b>5. </b> Any other disclosure which the applicable allows to do so without obtaining prior consent from
the owner of the Personal Information.</li>
</ul>

</span></p>


  </div>
</template>
<style lang="scss" scoped>
ul {
    padding-left: .2rem;
    padding-top: .2rem;

    b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
}
}

/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}

.jm-protocol {

  strong, b  span{
    font-weight: bold;
    font-family: The1Official_Bold;
  }

  font-size: 14px;
  color: #666;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}

.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}

.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}

.jm-protocol ol,
.jm-protocol ul {
  list-style-type: none;
  list-style-image: none;
}

.jm-protocol li {
  list-style: none;
}

.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
}

.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}

.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}

.jm-protocol a {
  text-decoration: none;
  color: #333;
}

.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}

.jm-protocol a:focus {
  outline: dotted 1px;
}

.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}

.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}

.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

