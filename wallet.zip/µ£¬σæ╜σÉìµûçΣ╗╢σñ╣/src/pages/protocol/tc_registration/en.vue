<template>
 <div class="jm-protocol">
   <p class="normal">
     <p class="txt-title">Terms &amp; Conditions for member of The 1 </p>
     </p>
     <p class="normal"><span>To obtain a membership number and be a membership of The 1 (“<b>Membership</b>”), I acknowledge and agree to the following terms and conditions</span><span>:</span></p><p class="graphCxSpFirst"><span>1.</span><span>I hereby request The 1 Central Limited </span><span>(</span><span>the </span><span>“</span><b><span>Company</span></b><span>”) </span><span>to accept my application until I cancel the Membership by written notice</span><span>.</span></p><p class="graphCxSpMiddle"><span>2.</span><span>I agree and consent that all personal data provided herein and all information arising from my subsequent transaction</span><span>(</span><span>s</span><span>) </span><span>using the Membership </span><span>(“</span><b><span>Data</span></b><span>”) </span><span>are the property of the Company to the extent permitted by laws</span><span>.</span></p><p class="graphCxSpMiddle"><span>3.</span><span>I acknowledge that the purpose of Data collecting conducted by the Company shall aim for: 1. Processing the Data for accumulating, redeeming and transferring points with partners of the Company; 2. Communicating on promotion, privilege and activities of the Company and its partners; 3. Conducting public relation on products and services of partners of the Company, including but not limited to financial products, life and non-life insurance which partners of the Company have hired the Company to promote such products and services;</span><span> 4. </span><span>Processing the Data in order to analyze behavior of members for promotional activities and improvement of business of the Company and/or companies in Central Group and/or the Company’s affiliates and/or the Company’s partners; and</span><span> 5. </span><span>Developing products and services of partners’ stores of the Company that join any project. The Company will use such Data in accordance with the specified purposes which shall benefit me. </span></p><p class="graphCxSpMiddle"><span>4.</span><span>I agree and consent for the Company to disclose, use or exchange the Data with other persons to the extent that permissible by law and beneficial to me</span><span>.</span></p><p class="graphCxSpMiddle"><span>5.</span><span>I acknowledge that</span><span>the accumulated points will be valid for two (2) years counting from the year of earning such points.</span></p><p class="graphCxSpMiddle"><span>6.</span><span>In case of dispute regarding points earned, I agree and consent that the Company has the sole right to investigate and adjust the points for no more than six (6) months retroactively</span><span>. </span><span>The Company</span><span>’</span><span>s decision making is final</span><span>.</span></p><p class="graphCxSpMiddle"><span>7.</span><span>I acknowledge that any marketing</span><span>-</span><span>related offers can vary from one member to another in which these targeted offers depend on purchase history of each member, promotional program of each product and</span><span>/</span><span>or marketing policy of the Company</span><span>.</span></p><p class="graphCxSpMiddle"><span>8.</span><span>I agree and accept the conditions that should I return any purchased item to any retailer I have to reimburse the earned points and the redemption rewards OR pay the same cash value to the Company</span><span>.</span></p><p class="graphCxSpMiddle"><span>9.</span><span>I acknowledge and agree that the Company has the right to decline this application or cancel the Membership without obligation to give reason</span><span>.</span></p><p class="graphCxSpMiddle"><span>10.</span><span>I accept to abide by the terms and conditions of the Membership</span><span>’</span><span>s agreement specified by the Company at the time submitting this application and as amended from time to time without prior notice</span><span>.</span></p><p class="graphCxSpMiddle"><span>11.</span><span>I agree and accept that the Company has the sole right to make any changes to Membership conditions, reward earning, reward redemption and any other rights provided to the members without prior notice</span><span>.</span></p><p class="graphCxSpMiddle"><span>12.</span><span>Should any dispute arise in relation to this Membership, the Company</span><span>’</span><span>s decision is final</span><span>.</span></p><p class="graphCxSpMiddle"><span>13.</span><span>The Company reserves the right to cancel the Membership and modify privileges without prior notice</span><span>.</span></p><p class="graphCxSpMiddle"><span>14.</span><span>I acknowledge that CentaraThe1 membership will get exclusive member privileges within three (3) days after the Membership registration process is fully completed</span><span>.</span></p><p class="graphCxSpLast"><span>15.</span><span>I hereby consent the Company to use and disclose the Data such as my name, surname and contact information as well as spending information <a name="_Hlk534804705">to companies in Central Group and/or the Company’s affiliates and/or the Company’s partners (other persons)</a> for: 1. Processing the Data for accumulating, redeeming and transferring points with partners of the Company; 2. Communicating on promotion, privilege and activities of the Company and its partners; 3. Conducting public relation on products and services of partners of the Company, including but not limited to financial products, life and non-life insurance which partners of the Company have hired the Company to promote such products and services;</span><span> 4. </span><span>Processing the Data in order to analyze behavior of members for promotional activities and improvement of business of the Company and/or companies in Central Group and/or the Company’s affiliates and/or the Company’s partners; and</span><span> 5.</span><span>Developing products and services of partners’ stores of the Company that join any project.</span><span>In such cases, the Company shall direct such other persons to carefully use my information in the same manner as the Company and only for the purposes prescribed. </span></p><p class="pb20"></p><p class="pb20"></p><p class="pb20"></p></div>
</template>
<style lang="scss" scoped>
ul {
  padding-left: 0.2rem;
  padding-top: 0.2rem;

  b {
    font-weight: bold;
    font-size: 17px;
    color: #000;
  }
}

/* @update: 2018-3-22 19:55:55 */
body {
  margin: 0;
  padding: 0;
}

.jm-protocol {
   .txt-title {
    text-align: center;
    font-size: 24px;
    padding-bottom: .48rem;
  }
  strong,
  b span {
    font-weight: bold;
    font-family: The1Official_Bold;
  }

  font-size: 14px;
   color: #141E50;
  line-height: 1.6;
  padding: 20px 16px;
  background: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.jm-protocol dd,
.jm-protocol div,
.jm-protocol dl,
.jm-protocol dt,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol li,
.jm-protocol ol,
.jm-protocol p,
.jm-protocol ul {
  margin: 0;
  padding: 0;
}

.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6 {
  font-weight: 400;
}

.jm-protocol div,
.jm-protocol h1,
.jm-protocol h2,
.jm-protocol h3,
.jm-protocol h4,
.jm-protocol h5,
.jm-protocol h6,
.jm-protocol p {
  -webkit-text-size-adjust: none;
}

.jm-protocol ol,
.jm-protocol ul {
  list-style-type: none;
  list-style-image: none;
}

.jm-protocol li {
  list-style: none;
}

.jm-protocol table {
  font-size: 14px;
  background-color: #333;
  width: 100%;
}

.jm-protocol table td {
  vertical-align: middle;
  background-color: #fff;
}

.jm-protocol a,
.jm-protocol img {
  -webkit-touch-callout: none;
}

.jm-protocol a {
  text-decoration: none;
 
}

.jm-protocol a:active,
.jm-protocol a:hover {
  outline: 0;
}

.jm-protocol a:focus {
  outline: dotted 1px;
}

.jm-protocol .title {
  text-align: center;
  font-size: 18px;
  padding: 0 0 15px;
}

.jm-protocol .graph,
.jm-protocol .normal {
  margin-bottom: 5px;
}

.jm-protocol .pb20 {
  padding-bottom: 20px;
}
</style>

