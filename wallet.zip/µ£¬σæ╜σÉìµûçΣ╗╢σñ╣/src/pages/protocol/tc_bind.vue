<template>
  <component :is="currentTabComponent"/>
</template>
<script>
import EN from './tc_bind/en'
import TH from './tc_bind/th'
export default {
  components: { EN, TH },
  data() {
    return {
      currentTabComponent: 'EN'
    }
  },
  created() {
     this.$SDK.setTitle({
      title: '', 
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    const deviceinfo = this.$DeviceInfo || {}
    if (deviceinfo.language === 'en_US') {
      this.currentTabComponent = 'EN'
    } else {
      this.currentTabComponent = 'TH'
    }
  }
}
</script>
