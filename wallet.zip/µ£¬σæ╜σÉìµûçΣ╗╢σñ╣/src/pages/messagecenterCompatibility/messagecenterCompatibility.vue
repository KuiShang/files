<template>
  <div class="wrapper">
    <toast
      v-if="showGroupGetCouponDialog"
      :title-position= "0.3"
      :font-size= "0.36"
      :show-cancle= "true"
      @closeDialog="getGroup"
      @cancle="cancleGroupDialog"
    >
      <p slot="title">{{ $t('Update Required') }}</p>
      <p slot="content" >{{ $t('Please update your app to get the best Dolfin experience and latest features.') }}</p>
      <p
        slot="ok"
        style="color: #FF3E5B;"
        @click="cancleGroupDialog">{{ $t('OK') }}</p>
    </toast>
  </div>
</template>
<script>
import Toast from '@/pages/balance/common/dialog2';
import { Base64 } from 'js-base64';

export default {
  name: 'MessageCenterCompatibility',
  components: {
    Toast
  },
  data() {
    return {
      showGroupGetCouponDialog: false, // 弹窗boolean值
      Value1: '', // 地址栏targetVersion
      path: '' // 需跳转路径
    };
  },
  async mounted() {
    const Url = Base64.decode(location.href.split('?')[1].replace('%3D', '=')).split('&');
    const version = Url[1].split('=')[1];
    this.path = JSON.parse(Url[0].split('=')[1]); // 获取需跳转路由
    this.Value1 = this.$utils.DistinguishedVersionNumber(version);
    if (this.Value1 === true) {
      const ret = await this.$SDK.goNativeAction(this.path)
      console.log('登录后结果ret', ret)
      if (ret) {
        this.$SDK.closeWebView()
      }
    } else {
      this.showGroupGetCouponDialog = true;
    }
  },
  methods: {
    // LATER
    cancleGroupDialog() {
      this.showGroupGetCouponDialog = false;
      this.$SDK.closeWebView();
    },
    // UPDATE NOW
    getGroup() {
      this.showGroupGetCouponDialog = false;
      const AnOrIos = this.$utils.DistinguishingAndroidfromiOS();
      if (AnOrIos === 'android') {
        window.location.href = 'https://play.google.com/store/apps/details?id=com.cjdfintech.wallet'
      } else {
        window.location.href = 'https://apps.apple.com/us/app/dolfin-wallet/id1447478566?l=zh&ls=1'
      }
    }
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.wrapper {
  .title {
    padding: 0 0.4rem 0;
    margin-top: 0.54rem;
    margin-bottom: 0.3rem;
    .title1 {
      font-family: The1Official_Bold;
      font-size: 0.4rem;
      line-height: 0.6rem;
      color: #141e50;
      letter-spacing: 0;
    }
    .title2 {
      margin-top: 0.1rem;
      font-size: 0.28rem;
      line-height: 0.4rem;
      color: #141E50;
    }
  }
  .content {
    height: 5.4rem;
    overflow: hidden;
    ul {
      display: flex;
      flex-direction: row;
      margin-bottom: -0.14rem;
      li {
        margin-right: 0.2rem;
        width: 3.24rem;
        height: 4.72rem;
        margin-bottom: 0.2rem;
        &:first-child {
          margin-left: 0.4rem;
        }
        &:last-child {
          margin-right: 0.4rem;
        }
      }
    }
  }
}
</style>

