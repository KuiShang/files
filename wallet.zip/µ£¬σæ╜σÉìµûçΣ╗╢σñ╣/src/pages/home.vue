<template>
  <div class="hom">
    <input
      type="text"
      placeholder="lai dawoya">
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="scanedResult">scanedResult</common-button>
      <common-button
        type="danger"
        @click.native="goblance">blance</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="gobill">billpayment 123</common-button>

    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="gotrans">transfer</common-button>
      <common-button
        type="danger"
        @click.native="gotransDetail">交易明细</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="gotransp2pWithMoney">p2p</common-button>
      <common-button
        type="danger"
        @click.native="goblancedetail">余额详情</common-button>
      <common-button
        type="danger"
        @click.native="gocashier">收銀台</common-button>
    </div>

    <div class="btn-wraper">
      <input
        :placeholder="url"
        v-model="url"
        type="text"
      >
      <common-button
        type="danger"
        @click.native="gowebview">跳轉到一個新的webview</common-button>
    </div>

    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="beisaocashier">被扫收银台测试2</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goPromotionTab()">promotionTab</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goPromotionTabView(35)">promotionTab预览</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goPromotionTab(52)">discovery</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goPromotionTab(35)">the 1 zone</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="transferTh1Result">transferTh1Result</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goResult">跳转到结果页9</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goProtocol">跳转到协议页privacy</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goProtocol2">跳转到协议页term service</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="couponUseDetail">myCouponDetail</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="discoveryCouponDetail">discoveryCouponDetail</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="GroupdiscoveryCouponDetail">group discoveryCouponDetail</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="requestToPay">requestToPay</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="bindcardandpay">绑卡并支付</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="tc_registion">注册协议</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="tcBind">tcBind协议</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="checkInstall">检测app</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="jumpapp">跳转app</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="goPromoTransactionDetail">goPromoTransactionDetail</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="AddBankAccountResult">绑卡邦账户结果也</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="gateway">gateway</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"

        @click.native="invitation">invitation</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="noInternet">No internet</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="newUsersJoin">newUsersJoin</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="getMessagecenterCompatibility">getMessagecenterCompatibility</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="MissionDolfin">MissionDolfin</common-button>
    </div>
    <div class="btn-wraper">
      <common-button
        type="danger"
        @click.native="MissionGuide">MissionGuide</common-button>
    </div>
  </div>
</template>
<script>
/* eslint-disable */
export default {
  name: 'Home',
  data() {
    return {
      testshow: false,
      url: 'http://jd.com:8080'
    }
  },
  created() {
    // this.$toast({
    //   message: '提示',
    //   position: 'middle',
    //   duration: 5000
    // })
  },
  methods: {
    trans(index = 0) {
      const queryData = [
        { name: 'msgCenterTransationDetail', query: { tranNo: '20180810102425TRAN82123071', tranType: 1, bizSystem: 1, customerId: '0066002000012953', tranAmount: 12 } },
        { name: 'msgCenterTransationDetail', query: { tranNo: '20180619150006TRAN85660837', tranType: 2, bizSystem: 1, customerId: '0066002000012953' } },

        { name: 'transationDetail', query: { tranNo: '20180619155506TRAN59578655', tranType: 3, bizSystem: 1, customerId: '0066002000012953' } },
        { name: 'transationDetail', query: { tranNo: '20180619161015TRAN74366268', tranType: 3, bizSystem: 1, customerId: '0066002000012953' } },
        { name: 'transationDetail', query: { tranNo: '20180619165622TRAN30721788', tranType: 3, bizSystem: 1, customerId: '0066002000012953' } },
        { name: 'transationDetail', query: { tranNo: '20180619182924TRAN75848131', tranType: 3, bizSystem: 1, customerId: '0066002000012953' } },
        { name: 'transationDetail', query: { tranNo: '20180619183703TRAN14399934', tranType: 3, bizSystem: 1, customerId: '0066002000012953' } }
      ];
      this.$router.push(queryData[index])
    },
    scanedResult() {
      this.$router.push(
        { name: 'scanedResult',  query: { transactionNo: '20190724100140000000109196961481'} }
        )
    },
    goResult() {
      this.$router.push({ name: 'transferTh1Result', query: {transOrderNo: '20181031152425TRAN11936417',version: '1.0.1'} })
    },
    gobill() {
      this.$router.push({ name: 'billPayment' })
    },
    goblance() {
      this.$router.push({ name: 'balance' })
    },
    gotrans() {
      this.$router.push({ name: 'transfer' })
    },
    gotransDetail() {
      // this.$router.push({ name: 'transationDetail', query: { tranNo: '20181029132226TRAN53406065', tranType: '3', bizSystem: '1' } })
      // this.$router.push({ name: 'msgCenterTransationDetail', query: { tranNo: '20180619155506TRAN59578655', tranType: '3', bizSystem: '1', customerId: '0062001000005583' } })
      this.$router.push({ name: 'transationDetail', query: {"tranNo":"201902251631182061411-3441759660","tranType":"6","bizSystem":"2","customerId":"0066002000194444"}})
    },
    gotransp2pWithMoney() {
      // this.$router.push({ name: 'p2p', query: { token: 'd4OUHPWRpluMPmfjmKWjmA==' } })
      // this.$router.push({ name: 'p2p', query: { token: 'M/Qt8CZ/Jxgr9YHWLMtBFw==' } })
      this.$router.push({ name: 'p2p', query: { token: 'C0NbMS472Yg6rtpaYyCXig==' } })
    },
    goblancedetail() {
      this.$router.push({ name: 'balanceDetail', query: { serviceOddNo: 'serviceOddNo', inOutFlag: 'inOutFlag' } })
    },
    gocashier() {
      this.$router.push({ name: 'wraperSimpleCashier', query: { transactionNo: '20190428214917503805171771590206', paymentToken: '4564', paymentMethod: 'cpp', busiType: 'scaned' } })
      // this.$router.push({ name: 'wraperSimpleCashier', query: { transactionNo: '20180930151100093015105311454941' } })
    },
    gowebview() {
      const json = { url: this.url };
      window.wallet.platform.openWebView(json, (resp) => {
        console.log(JSON.stringify(resp))
      })
    },
    goPromotionTab(val) {
      let pageId = 33;
      if (val) {
        pageId = val;
      }
      if (this.$utils.getSysType('isJdApp')) {
        const json = {
          type: 'native',
          address: '/webview/web',
          params: {
            url: encodeURIComponent(`${window.location.origin}/#/promotionTabList?pageId=${pageId}`)
          }
        };
        this.$SDK.goNativeAction(json);
      } else {
        this.$router.push(
          {
            name: 'promotionTabList'
          }
        );
      }
    },
    goPromotionTabView(val) {
      let pageId = 33;
      if (val) {
        pageId = val;
      }
      if (this.$utils.getSysType('isJdApp')) {
        const json = {
          type: 'native',
          address: '/webview/web',
          params: {
            url: encodeURIComponent(`${window.location.origin}/#/promotionTabList?pageId=${pageId}&display=1`)
          }
        };
        this.$SDK.goNativeAction(json);
      } else {
        this.$router.push(
          {
            name: 'promotionTabList'
          }
        );
      }
    },
    beisaocashier() {
      this.$router.push({ name: 'testbeisaoCashier' })
    },
    transferTh1Result() {
      this.$router.push({ name: 'transferTh1Result', query: {transOrderNo: '20181031152425TRAN11936417',version: '1.0.1'} })
    },
    goProtocol() {
      this.$router.push({ name: 'privacy' })
    },
    couponUseDetail() {
      this.$router.push({ name: 'myCouponDetail', query: { couponId: 'iAJTWoxM2c4nNEH__K2-wCY4uZwYV_e1UTkO4SiGgD0' } })
    },
    discoveryCouponDetail() {
      this.$router.push({ name: 'discoveryCouponDetail', query: { activityId: 'zf-n-6K7g1YK0AN9VyE40zfNbxSoQ007YES0HTX86Jg', batchId:'DAkcVTaKMKlTGd7MSqbYJMfYgxYPG4qXEalCOF9yLpE' } })
    },
    GroupdiscoveryCouponDetail() {
      this.$router.push({ name: 'groupDiscoveryCouponDetail', query: { activityId: '-eGPaAwCJLuwFN9eMB1OLMfYgxYPG4qXEalCOF9yLpE', batchId:'LSiriV0d6VrGOiMFNOc4Z5SrTbC5ghYiFd6VxgaewWk', groupId: '154908584160514048' } })
    },
    requestToPay() {
      this.$router.push({ name: 'requestToPay' })
    },
    goProtocol2() {
      this.$router.push({ name: 'termService' })
    },
    goPromoTransactionDetail() {
      this.$router.push({ name: 'promoTransactionDetail', query: {serialNo: 2019010800000000000013415546} })
    },
    bindcardandpay() {
      this.$router.push({ name: 'cdcp', query: { transactionNo: '20190820145036753260032073396702' }})  //    20190107154232AN7934146128765802
    },
    tc_registion() {
      this.$router.push({ name: 'tcRegistion' })
    },
    tcBind() {
      this.$router.push({ name: 'tcBind' })
    },
    async checkInstall() {
      const platformInfo = this.$utils.getSysType()
      const isAndroid = platformInfo.isAndroid
      const isIOS = platformInfo.isIOS
      let json = ''
      if (isAndroid) {
        json = {
          packages: ['com.tencent.mm']
        }
      } else if(isIOS) {
        json = {
          scheme: ['iosamap://']
        }
      }
      // let ret = await this.$SDK.checkInstallApps(json)
      let ret = await this.$SDK.checkInstallKplus()
      console.log('ret;;;', ret)
      alert(ret)
    },
    async jumpapp() {
      let str = 'kbank.kplus://cjd.payment?tokenId=KMBJDC000000000BBAD8358560C4937BFDCE5F46DDE6CA4PMT'
      let ret = await this.$SDK.goOtherNativeAPP(str)
      alert(JSON.stringify(ret))
    },
    AddBankAccountResult() {
      this.$router.push({ name: 'addBankAccountResult', query: {result: 0,type: 'CARD'} })
    },
    gateway() {
      this.$router.push({ name: 'gatewayInit', query: {} })
    },

    invitation() {
      this.$router.push({
        name: 'invitationFriends',
        query: {
          pageName:'INVITE_F',
          entrance:'1'//页面入口标识
        } 
      })
    },
    noInternet() {
      this.$router.push({ name: 'noInternet', query: {} })
    },
    newUsersJoin() {
      this.$router.push({
        name: 'newUsersJoin',
        query: {
          // invitation: 'xm6%2F8w%2F%2BUTiHK%2BWrXaQUNIws7KBTpRQ1gC378AmgX0%2FlVK3qO%2F4DYdYm76lSqxY3hCjsrlKtEDCBLOirTP5NZNsmu%2FgJ%2BEdq2nD7%2FATpV3yIKw%3D%3D',
          invitation: '',
          firstName: 'default'
        }
      })
    },
    getMessagecenterCompatibility() {
      this.$router.push({         
        path : 'messagecenterCompatibility?dGFyZ2V0Um91dGU9eyJhZGRyZXNzIjoiL2t5Yy9sZXZlbDJBdWRpdEZhaWwiLCJwYXJhbXMiOnt9LCJ0eXBlIjoibmF0aXZlIn0mdGFyZ2V0VmVyc2lvbj0xLjMuMA=='
        })
    },
    MissionDolfin() {
      this.$router.push({ name: 'MissionDolfin' })
    },
    MissionGuide() {
      this.$router.push({ name: 'MissionGuide' })
    }
  }
}
</script>
<style lang="scss" scoped>
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
</style>
