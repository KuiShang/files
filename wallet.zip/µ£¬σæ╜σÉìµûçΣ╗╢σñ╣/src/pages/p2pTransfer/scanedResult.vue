<template>
  <div class="container-result">
    <div
      v-if="showSuccess"
      class="result">
      <div class="head">
        <img
          class="img"
          src="@/assets/images/blance/the1/success_big@3x.png">
        <p class="txt-title">{{$t('PaymentSuccessfully') }}!</p>
        <p class="txt-des"> <span class="money">฿ {{ dataObj.orderAmount | tofloat | thousandBitSeparator }}</span></p>
      </div>
      <!--  增加相应支付券场景-->
      <div
        v-if="couponDetail !== 'null' || couponDetail !== '{}'"
        class="couponDiv">
        <ul>
          <li :style="{height:flag!==true?'1.2rem':'auto'}">
            <img 
              :src="couponDetail.logo"
              alt="">
              <span class="imgcouponValue">{{ $t('Save') }}{{ couponDetail.couponName }}</span>
              <span 
                class="hide-detail"
                @click="toggle"> {{ toggleTxt }}</span>
              <common-icon
                class="custom-ico botX"
                name="less"
                size=".3rem"
                v-if='flag'
                slot="img"
                @click="toggle"
              />
              <common-icon
                v-else
                slot="img"
                class="custom-ico botX"
                name="moreunfold"
                size=".3rem"
                @click="toggle"
              />
                <div 
                  v-if="flag" style="float：left;margin-left: .4rem;">
                  <p class="coupOnC">{{ couponDetaildescribe }}</p>
                  <div class="borderXian"></div>
                  <div class="list" style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.29rem;">
                        <span class="key">Subtotal</span>
                        <span>฿{{ couponDetail.orderAmount }}</span>
                      </li>
                       <li
                        class="item"
                        style="padding: 0;min-height:.425rem;padding-top:.28rem;padding-bottom:.28rem;">
                        <span class="key">Discount Coupon</span>
                        <span>-฿{{ couponDetail.discountAmount }}</span>
                      </li>
                    </ul>
                  </div>
                  <div class="borderXian"></div>
                  <div class="list"  style="padding: .3rem .4rem 0 0;">
                    <ul>
                       <li
                        class="item"
                        style="padding-bottom: 0;min-height:.8rem;padding-top:.28rem;">
                        <span class="key">Total</span>
                        <span style="font-weight:bold;">฿{{ couponDetail.actualPaymentAmount }}</span>
                      </li>
                    </ul>
                  </div>
                </div>
          </li>
        </ul>
        
      </div>
      <div style="clear: both;"></div>
      <p
        v-if="dataObj.remark"
        class="notes">{{$t('Notes')}}: {{ dataObj.remark }}</p>
      <ul class="list">
        <li class="item">
          <span class="key">{{ $t('ReceiverName') }}</span>
          <span class="value">{{ dataObj.merchantName }}</span>
        </li>
        <li class="item">
          <span class="key">{{ $t('PaymentMethod') }}</span>
          <span class="value">{{ getDisplayName(dataObj) }}</span>
        </li>
      </ul>
      <div
        v-show="false"
        class="btn-wraper">
        <common-button
          type="danger"
          @click.native="handleClick">|0123|DONE
        </common-button>
      </div>
      <!-- 营销笔笔返 -->
      <SuccReturnPromo />
      <!-- 引导开通指纹人脸支付 -->
      <guideFingerprintPay v-if="$route.query.from === 'cashier'"/>
    </div>
    <resultFail
      v-else
      :type-str="$t('Paymentfailed')"
      :showTxt="false"
      @click="tryAgain"/>

  </div>

</template>
<script>
import { scanedResultQuery, queryOrderDetail  } from '@/api'
import handlInitData from '@/mixins/handlInitData'
import resultFail from '@/pages/balance/common/resultFail'
import { CASHIER_PAYMENT_METHODS, enumPayMethodCodeFirst } from '@/utils/const'
import SuccReturnPromo from '@/pages/promotion/common/SuccReturnPromo'
import guideFingerprintPay from '@/pages/balance/common/guideFingerprintPay'
import * as CASHIER_BURRY from '@/pages/burry/cashier'
export default {
  name: 'ScanedResult', // 被扫成功页
  components: { resultFail, SuccReturnPromo, guideFingerprintPay },
  mixins: [handlInitData],
  data() {
    return {
      showSuccess: true,
      titleRightMsg: {
        text: this.$t('DONE'),
        show: 1,
        textSize: 18,
        textColor: '#FF3E5B'
      },
      flag: false,//Show hide Detail
      couponDetail: {},// 优惠券详情
      couponDetaildescribe: '',// 优惠券描述
      deviceInfo: {}// 设备信息
    }
  },
  computed: {
    toggleTxt() {
      if (this.flag) {
        return this.$t('Hide Detail')
      }
      return this.$t('Show Detail')
    }
  },
  created() {
    this.initData()
    this.$SDK.setTitle({
      title: this.$t('payment'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })
    this.$SDK.setTitleRight(this.titleRightMsg, () => {
      this.$SDK.closeWebViewAndSendResult()
    })
  },
  methods: {
    async initData() {
      if (this.$route.name === 'p2pFail') {
        this.showSuccess = false
        return
      }
      // 如果没有 transactionNo 则为失败
      if (!this.$route.query.transactionNo) {
        this.showSuccess = false
        return
      }
      const res = await scanedResultQuery({
        transactionNo: this.$route.query.transactionNo
      })
      if (this.$DeviceInfo.os === 'Android') {
        this.deviceInfo = {
          'os': this.$DeviceInfo.os,
          'androidUuid': this.$DeviceInfo.androidUuid
        }
      } else {
        this.deviceInfo = {
          'os': this.$DeviceInfo.os,
          'iosUuid': this.$DeviceInfo.iosUuid
        }
      }
      const rea = await queryOrderDetail({
        transOrderNo: this.$route.query.transactionNo,
        deviceInfo: this.deviceInfo
      })
      if (JSON.stringify(rea.data.resultData) !== '{}') {
        this.couponDetail = rea.data.resultData.promoBean ? rea.data.resultData.promoBean : {};
      } else {
        this.couponDetail = {};
      }
      const deviceinfo = this.$DeviceInfo || {}
      if (deviceinfo.language === 'en_US') {
        this.couponDetaildescribe = this.couponDetail.shortDesicriptionMapcurentLang ? this.couponDetail.shortDesicriptionMapcurentLang[en_US] :'';
      } else {
        this.couponDetaildescribe = this.couponDetail.shortDesicriptionMapcurentLang ? this.couponDetail.shortDesicriptionMapcurentLang[th_TH] : '';
      }
      this.handlInitData(rea, () => {
        if (!this.dataObj.orderAmount) {
          this.showSuccess = false
        } else {
          let from = 'pay-pass' // 免密
          if (this.$route.query.from) {
            from = 'pin'  // 非免密
          }
          CASHIER_BURRY.QRPay_Success(
            {
            revenueAamount: this.dataObj.orderAmount,
            businessType: from,
            paymentMethod1: this.dataObj.payResultModel.payMethodCodeFirst,
            paymentMethod2: this.dataObj.payResultModel.payMethodCodeSecond
            }
          )
        }
      })
    },
    handleClick() {
      console.log('click')
      this.$SDK.closeWebViewAndSendResult()
    },
    // TODO： 跳转去哪里待定
    tryAgain() {
      // this.$router.push({ name: 'transfer' })
      this.$SDK.closeWebView()
    },
    getDisplayName(dataObj) {
      // const key = dataObj && dataObj.payResultModel && dataObj.payResultModel.displayName
      // return CASHIER_PAYMENT_METHODS[key]
      if (!dataObj.payResultModel) {
        return ''
      }
      const payMethodCodeFirst = dataObj && dataObj.payResultModel && dataObj.payResultModel.payMethodCodeFirst
      const displayName = dataObj.payResultModel && dataObj.payResultModel.displayName
      if (payMethodCodeFirst === enumPayMethodCodeFirst.ODD) {
        const last4Num = this.dataObj.payResultModel.maskedNo? String(this.dataObj.payResultModel.maskedNo).slice(-4) : ''
        // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])} (${last4Num})`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.BALA) {
        // return this.dataObj.payMethodCodeFirst
        // return 'Balance'
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])}`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.OFLN) {
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])}`
      } else if (payMethodCodeFirst === enumPayMethodCodeFirst.CCP) {
        const last4Num = this.dataObj.payResultModel.maskedNo? String(this.dataObj.payResultModel.maskedNo).slice(-4) : ''
        return `${this.$t(CASHIER_PAYMENT_METHODS[displayName])} (${last4Num})`
      }
      return ''
    },
    //切换showDetail
    toggle() {
      this.flag = !this.flag;
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.container-result {
  height: 100%;
  background-color: $color-gray-i;
  .head {
    background-color: #fff;
    box-sizing: border-box;
    text-align: center;
    padding-top: .4rem;
    .img {
      width: 1.4rem;
    }
    .txt-title {
      font-family: The1Official_Bold;
      font-size: .36rem;
      color: $color-gray-g;
      text-align: center;
      padding-top: .2rem;
    }
    .txt-des {
      padding-top: .2rem;
      font-size: .32rem;
      padding-bottom: .8rem;
      color: $color-gray-h;
      text-align: center;
      .money {
        font-size: .32rem;
        color: $color-red;
        text-align: center;
        line-height: .38rem;
      }
    }
    .hide {
      opacity: 0;
    }
  }
  .notes {
    margin-top: .2rem;
    background: #Fff;
    height: 1.2rem;
    font-size: .28rem;
    color: $color-gray-h;
    line-height: .36rem;
    padding: .33rem .35rem .33rem .35rem;
    box-sizing: border-box;
  }
  .list {
    background-color: #fff;
    padding: .3rem .4rem;
    margin-top: .2rem;
    .item {
      display: flex;
      justify-content: space-between;
      font-size: .28rem;
      color: $color-gray-g;
      text-align: right;
      padding: .2rem 0 .2rem 0;
      line-height: .45rem;
      .key {
        color: $color-gray-h;
      }
      .value {
        max-width: 50%;
      }
    }
  }
  .btn-wraper {
    margin-top: .4rem;
    display: flex;
    justify-content: center;
    position: relative;
    box-sizing: border-box;
  }
  .couponDiv {
    background-color: #fff;
    margin-top: .2rem;
    margin-bottom: .2rem;
    height: auto;
    width: 100%;
    li {
      float: left;
      min-height: 1.2rem;
      width: 100%;
      background-color: #fff;
      img {
        width: .6rem;
        height: .6rem;
        float: left;
        margin-left: .4rem;
        margin-top: .3rem;
      }
      .imgcouponValue {
        font-family: The1Official-Bold;
        font-size: .28rem;
        color: #141E50;
        letter-spacing: 0;
        text-align: left;
        float: left;
        margin-left: .2rem;
        line-height: 1.2rem;
        font-weight: bold;
        width: 2.62rem;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .hide-detail {
        font-family: The1Official-Regular;
        font-size: .28rem;
        color: #FF3E5B;
        letter-spacing: 0;
        float: left;
        margin-left: 1.4rem;
        line-height: 1.2rem;
      }
      .botX {
        color: #FF3E5B;
        float: left;
        margin-left: .1rem;
        line-height: 1.2rem;
      }
      .coupOnC {
        font-family: The1Official-Regular;
        font-size: .28rem;
        color: #141E50;
        letter-spacing: 0;
        text-align: left;
        float: left;
        width: 6.7rem;
        margin:0 0 .29rem 0;
        line-height: .42rem;
      }
      .borderXian {
        width: 6.7rem;
        border-top: .02rem dashed#A1A5B9;
        height: .02rem;
        float: left;
      }
    }
  }
}
</style>
