<template>
<!-- 扫码转账 -->
  <div class="p2p-wrapper">
    <div class="card-msg">
      <div class="card">
        <!-- 卡片信息 -->
        <div class="avator">
          <p class="pay-money">{{ $t('Pay Money to') }}</p>
          <p class="img-name">{{ dataObj.customerName || 'Dear Customer' }}</p>
        </div>
        <img
          :src="iconUrl"
          class="img"
          alt=" ">
      </div>
       <div class="collect-code">
         <section v-if="dataObj.promptAccountNo && dataObj.promptAccountNo !== ''">
          <span>{{ this.$t('EwalletPromptPay') }}</span>
          <span class="no">{{ dataObj.promptAccountNo }}</span>
         </section>
      </div>
    </div>
   
   
    <moneyInput
      ref="moneyInput"
      v-model="amount"
      :title="moneyInputTitle"
      :notes-entry="true"
      :readonly= "readonly"
      :transfer-channel="TRANSFER_CHANNELS.ONT_FIN"
      :busi-scenarios="BUSI_SCENARIOS.P2P"
      @addNotes="receiveNotes"
      @moneyFlag="receiveMoneyFlag"
      @moneyLimitOk="moneyLimitOk"
    />
    <div class="btn-wraper">
      <common-button
        :disabled="!moneyFlag"
        type="danger"
        @click.native="handleClick">{{ $t('Confirm') }}</common-button>
    </div>
    <simpleCashier
      v-if="cashierVisible"
      :cashier-visible.sync="cashierVisible"
      :transaction-no = "transactionNo"
      @paynow = "paynow"
    />
  </div>
</template>
<script>
import simpleCashier from '@/pages/cashier/simple-cashier'
import { parseCode, createTransfer, cancelTransfer } from '@/api'
import moneyInput from '@/pages/balance/common/moneyInput'
import { ENUM_ERRORCODE, TRANSFER_TYPE, BUSI_SCENARIOS, TRANSFER_CHANNELS } from '@/utils/const'
import handlInitData from '@/mixins/handlInitData'
import hasPayError from '@/mixins/hasPayError'
import * as TRANSFER_BURRY from '@/pages/burry/transfer.js'

const imgsrc = require('@/assets/images/blance/the1/user030@3x.png')

export default {
  name: 'P2p',
  components: { simpleCashier, moneyInput },
  mixins: [handlInitData, hasPayError],
  data() {
    return {
      amount: '',
      cashierVisible: false,
      selectBankAccountVisible: false,
      transactionNo: '',
      transOrderNo: '',
      readonly: false,
      remark: '',
      BUSI_SCENARIOS,
      TRANSFER_CHANNELS,
      moneyFlag: false,
      moneyInputTitle: this.$t('Transfer Amount'),
      requestToPayNo: '',
      codeType: ''
    }
  },
  computed: {
    iconUrl() {
      return this.dataObj.iconUrl ? this.dataObj.iconUrl : imgsrc
    }
  },
  beforeRouteEnter (to, from, next) {
    TRANSFER_BURRY.Transfer_ToCollect_ENTRY()
    next()
  },
  beforeRouteLeave (to, from, next) {
    TRANSFER_BURRY.Transfer_ToCollect_LEAVE()
    next()
  },
  async created() {
    // this.initData() 需要等待初始化查询到限额之后才可以去调用 initData
    this.listenBackPress()
    this.$SDK.setTitle({
      title: this.$t('pay'),
      mHeaderTitle: {
        showEnd: 0
      }
    })
  },
  watch: {
    cashierVisible(value) {
      if (value === false) { 
        this.listenBackPress()
        TRANSFER_BURRY.Transfer_ToCollect_ENTRY()
      }
    }
  },
  destroyed() {
    console.log('p2p destory')
  },
  methods: {
    async initData() {
      const res = await parseCode({
        token: encodeURIComponent(this.$route.query.token)
      })
      this.handlInitData(res, () => {
        if (res.data.resultData.amount) {
          const value = typeof res.data.resultData.amount === 'number' ? String(res.data.resultData.amount) : res.data.resultData.amount
          this.$refs.moneyInput.amount = value
          this.readonly = true
          if (res.data.resultData.remark) {
            this.moneyInputTitle = res.data.resultData.remark
          }
        }
        this.codeType = res.data.resultData.codeType
        this.requestToPayNo = res.data.resultData.requestToPayNo || '';
      })
    },
    listenBackPress () {
      console.log('p2p页面监听返回键')
      this.$SDK.onBackPress( async () => {
        console.log('p2p按下了返回键')
        await cancelTransfer({
          recipientAccountNo: this.dataObj.customerId
        })
        this.$SDK.closeWebView()
      })
    },
    moneyLimitOk() {
      this.initData()
    },
    async handleClick() {
      let postData = {};
      if (this.codeType.toString() === '1') {
        // 收款码
        postData = {
          version: this.$DeviceInfo.appVersion,
          amount: this.amount,
          currency: 'THB',
          recipientAccountNo: this.dataObj.customerId,
          deviceMsg: JSON.stringify(this.$DeviceInfo),
          remark: this.remark,
          busiType: BUSI_SCENARIOS.P2P,
          transferChannel:TRANSFER_CHANNELS.ONT_FIN,
          payeeReason: this.dataObj.payeeReason
        }
      } else {
        // request to pay码
        postData = {
          version: this.$DeviceInfo.appVersion,
          amount: this.amount,
          currency: 'THB',
          recipientAccountNo: this.dataObj.customerId,
          deviceMsg: JSON.stringify(this.$DeviceInfo),
          remark: this.remark,
          transferChannel:TRANSFER_CHANNELS.ONT_FIN,
          busiType: BUSI_SCENARIOS.REQUESR2PAY,
          requestToPayNo: this.requestToPayNo
        }
      }
      if (this.dataObj.promptAccountNo && this.dataObj.promptAccountNo !== '') {
        // 二码合一
        postData = Object.assign(postData, {
          "promptAccountNo": this.dataObj.promptAccountNo
        });
      } else {
        // 与服务端沟通 不是就传Null
        postData = Object.assign(postData, {
          "promptAccountNo": null
        });
      }
      const res = await createTransfer(postData)
      if (res && res.data && res.data.resultCode === 1) {
        this.transactionNo = res.data.resultData.transactionNo
        this.transOrderNo = res.data.resultData.transOrderNo
        this.cashierVisible = true
        TRANSFER_BURRY.Transfer_ToCollect_LEAVE()
        if (this.codeType.toString() === '1') { // 收款码
          TRANSFER_BURRY.Transfer_ToCollect_CONFIRM(null, this.amount, postData.busiType)
        }
      } else if (res && res.data && res.data.resultCode === 0) {
        // 埋点开始
        const errorMsg = {
          code: res.data.errorData && res.data.errorData.code || '',
          msg: res.data.errorData && res.data.errorData.msg || ''
        }
        if (this.codeType.toString() === '1') { // 收款码
          TRANSFER_BURRY.Transfer_ToCollect_CONFIRM(errorMsg, this.amount, postData.busiType)
        }
        // 埋点结束
        this.hasPayError(res)
      }
    },
    changeBank() {
      console.log('changeBank')
      this.selectBankAccountVisible = true
    },
    selectBank() {
      this.selectBankAccountVisible = false;
      console.log('selectBank')
    },
    paynow() {
      console.log('pay')
      // this.$router.push({ name: 'p2pResult', query: { transOrderNo: this.transOrderNo } })
      this.$router.push({ name: 'transferTh1Result', query: { transOrderNo: this.transOrderNo } })
    },
    receiveNotes(notes) {
      this.remark = notes
    },
    receiveMoneyFlag(flag) {
      this.moneyFlag = flag
    }
  }
}
</script>
<style lang="scss" scoped>
@import "@/assets/css/var.scss";
.p2p-wrapper {
  height: 100%;
  background-color: $color-gray-i;
  padding-top: .02rem;
  .collect-code {
    background-color: $color-white;
    margin-bottom: .2rem;
    padding: 0 .4rem;
    section {
      border-top: 1px dashed $color-gray-e;
      font-size: 0.28rem;
      line-height: 0.46rem;
      color: $color-gray-f;
      padding: 0.28rem 0;
      .no {
        color: $color-gray-h;
      }
    }
  }
  .card {
    background-color: $color-white;
    height: 1.4rem;;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 .4rem 0 .4rem;
    .avator {
      font-size: .28rem;
      .pay-money {
        color: $color-gray-g;
      }
      .img-name {
       color: $color-gray-f;
       padding-top: .15rem;
      }

    }
    .img {
      width: .6rem;
      height: .6rem;
      border-radius: 50%;
    }
  }
  .btn-wraper {
    margin-top: .3rem;
    display: flex;
    justify-content: center;
    box-sizing: border-box;
  }
}

</style>
