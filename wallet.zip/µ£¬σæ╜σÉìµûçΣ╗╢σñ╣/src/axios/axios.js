/*eslint-disable*/
import axios from 'axios'
import Vue from 'vue'
import { ENUM_ERRORCODE } from '@/utils/const'
// 全局超时时间
axios.defaults.timeout = 150000
axios.defaults.baseURL = ''
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
// axios.defaults.headers.common['Authorization'] = 'AUTH_TOKEN';
if (process.env.NODE_ENV !== 'production') {
  // axios.defaults.headers.common['ticket'] = '0c613a00-fbe5-46cd-8144-82d66768b60c';
  axios.defaults.headers.common['ticket'] = '4de458b6-e563-4c59-82d2-2ff1ee670693';
  // axios.defaults.headers.common.deviceInfo = JSON.stringify({"deviceModel":"OS105","deviceType":"APP","language":"en_US"});
}
// 添加请求拦截器
axios.interceptors.request.use((config) => {
  if (config.method == 'get') {
    config.data = true
    config.headers['Content-Type'] = 'application/json'
  }
  // Vue.$indicator.open({
  //   text: 'Loading...',
  //   spinnerType: 'fading-circle'
  // })
  // 在发送请求之前做些什么
  if (config.method === 'post') {
    console.log(`入参${config.url} :`, config.method, config.data)
  } else {
    console.log(`入参${config.url} :`, config.method, config.params)
  }
  // config.url = `/api${config.url}`
  return config
}, (error) => {
  // 对请求错误做些什么
  console.log('request error', error)
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  // console.log(JSON.stringify(response))
  // Vue.$indicator.close()
  // 对响应数据做点什么
  // if (response.status !== 200) {
  //   router.push({ name: 'error' })
  // }

  console.log(`返回${response.config.url} :`, response.data)
  response.data.resultCode = Number(response.data.resultCode)
  if (response.data.errorData && response.data.errorData.code === ENUM_ERRORCODE.NOT_LOGIN) {
    // return Vue.$SDK.goNativeAction(response.data.actionData)
    // 不能在此处统一处理未登录， 因为具体的业务页面跳转到登录页 登陆后 在跳转回来的时候 需要在具体的页面在调用相应的初始化方法 
  }
  return response
}, function (error) {
  // 对响应错误做点什么
  let strObj = ''
  let str = ''
  if (Vue.$DeviceInfo.language) {
    if (Vue.$DeviceInfo.language === 'en_US') {
      strObj = {
        k40: 'No internet connection, please try again',
        k50: 'System error'
      }
    } else {
      strObj = {
        k40: 'ไม่สามารถเชื่อมต่ออินเทอร์เน็ตได้ กรุณาลองใหม่อีกครั้ง',
        k50: 'ระบบผิดพลาด'
      }
    }
  } else {
    strObj = {
      k40: 'No internet connection, please try again',
      k50: 'System error'
    }
  }
  if (error.response) {
    if (error.response.status.toString().match(/^50/)) {
      str = strObj.k50
      // router.push({ name: 'netError' })
    } else if (error.response.status.toString().match(/^40/)) {
      str = strObj.k40
    } else {
      str = strObj.k40
    }
  } else [
    str = strObj.k40
  ]
  if (!window.vue.$store.state.payLooping) {
    Vue.$toast({
      message: str,
      position: 'bottom',
      duration: 2000
    })
  }
  console.log('error', error)
  return error
})
export default axios
