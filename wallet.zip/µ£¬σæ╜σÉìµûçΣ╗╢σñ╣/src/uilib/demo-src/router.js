import Vue from 'vue'
import Router from 'vue-router'
import Home from './components/Home'
import popup from './components/popup'

Vue.use(Router)
const routes = [{
  path: '/',
  name: 'Home',
  component: Home
}, {
  path: '/popup',
  name: 'popup',
  component: popup
}]

export default new Router({
  routes: routes
})
