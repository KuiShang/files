<template>
  <div class="page has-navbar">
    <div class="page-content">
      <!-- Basic -->
      <h3>基础</h3>
      <ul class="list-ios hl-list-borderless">
        <router-link tag="li" class="item-icon-right" :to="{ name: 'popup'}">
          POPUP <span class="item-note">POPUP</span>
          <i class="icon ion-ios-arrow-right"></i>
        </router-link>
      </ul>


    </div>
    <router-view></router-view>
  </div>
</template>
<style scoped>

.footer {
  height: 40px;
}
li {
  height: 40px;
  line-height: 40px;
  padding-left: 10px;
  text-align: left;
  background-color: #fff;
  margin-bottom: 10px;
  box-shadow: 0 0 5px rgba(0,0,0,.26);
  border-radius: 4px;
}
</style>
<script>
export default {
  data() {
    return {
      sidebar: undefined,
      sidebarRight: undefined
    };
  },

  mounted() {},

  destroyed() {},

  methods: {}
};
</script>
