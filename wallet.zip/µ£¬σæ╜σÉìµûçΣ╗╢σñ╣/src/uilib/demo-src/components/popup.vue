<template>
  <div class="demo demo-button">
  <button @click="popupVisible  =true">click me </button>
    <mt-popup v-model="popupVisible" position="bottom" class="mint-popup-4">
      <div>123123</div>
    </mt-popup>
  </div>
</template>

<script>
export default {
   name: "HelloWorld",
  data() {
    return {
      msg: "Welcome to Your Vue.js App",
      popupVisible: false,
      popupVisible2: false,
      popupVisible3: false,
      ani: false,
      popupVisible4: false
    };
  }
}
</script>

<style lang="scss">

</style>
