
import './fonts/iconfont.css'

import Popup from '../packages/popup/index.js'
import Button from '../packages/button/index.js'
import Header from '../packages/header/index.js'
import Icon from '../packages/icon/index.js'
import field from '../packages/field/index.js'
import cell from '../packages/cell/index.js'
import item from '../packages/item/index.js'
import MessageBox from '../packages/message-box/index.js'
import input from '../packages/input/index.js'
import spinner from '../packages/spinner/index.js'
import indicator from '../packages/indicator/index.js'
import toast from '../packages/toast/index.js'
import form from '../packages/form/index.js'
import formItem from '../packages/form-item/index.js'
import picker from '../packages/picker/index.js'
import datetimePicker from '../packages/datetime-picker/index.js'
import mSwitch from '../packages/switch/index.js'

const components = [
  Popup,
  Button,
  Header,
  Icon,
  field,
  cell,
  item,
  MessageBox,
  input,
  indicator,
  spinner,
  toast,
  form,
  formItem,
  picker,
  datetimePicker,
  mSwitch
]

const install = (Vue, opts = {}) => {
  components.map(component => {
    if (component.confirm || component.open) {
      // console.log('特殊处理：', component)
      Vue.use(component)
    } else {
      Vue.component(component.name, component)
    }
  })
}

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

const common_uilib = {
  version: '1.0.0',
  install,
  Popup,
  Button,
  Header,
  Icon,
  field,
  cell,
  item,
  MessageBox,
  toast,
  input,
  indicator,
  spinner,
  form,
  formItem,
  picker,
  datetimePicker,
  mSwitch
}

export default common_uilib
