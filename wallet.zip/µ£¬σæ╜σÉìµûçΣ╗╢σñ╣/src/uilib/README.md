# common-ui

> 基于vue的ui组件通用基础框架

## Build Setup

``` bash
# install dependencies
npm install

# run doc-server at localhost:9527
npm run doc

# run demo at localhost:8080
npm run dev:demo

# build all components
npm run build:start 

# build demo-src 
npm run build:demo 

# run all tests
npm test
```


## 组件扩展

* 在packages中新建文件夹 名称建议统一采用大驼峰命名法则 ex: CommonButton
* 在文件夹中必须新建index.js
* 在components.json中声明组件
* 如果添加了新组件 入口文件 index.js 可以通过 执行命令 npm run build:file 来自动生成

## 其他注意事项

* 引用时候所有组件 可以通过  common-button 来引用
* 当本项目源码作为子项目放在其他目录下时候  不可以通过npm i 来 安装 node-modules ，否则外部项目会报错
* 当本项目源码作为子项目放在其他目录下时候  如果添加了新组件 入口文件 index.js  需要手动编写，原因同上
## LICENSE
GPL


