### THANKS TO:

[*代码结构组织:* https://github.com/ElemeFE/element] (https://github.com/ElemeFE/element)

[*docs:* https://github.com/wangdahoo/vonic] (https://github.com/wangdahoo/vonic)

[*demo:* https://github.com/wangdahoo/vonic] (https://github.com/wangdahoo/vonic)

[*基础组件逻辑:* https://github.com/youzan/vant] (https://github.com/youzan/vant)

[*样式组织1:* https://github.com/wangdahoo/vonic] (https://github.com/wangdahoo/vonic) 

[*样式组织2:* https://github.com/youzan/vant] (https://github.com/youzan/vant) 

[*样式组织3:* https://github.com/ElemeFE/element]  (https://github.com/ElemeFE/element)
