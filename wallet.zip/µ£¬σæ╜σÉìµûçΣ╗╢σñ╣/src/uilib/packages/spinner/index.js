import spinier from './src/spinier'

/* istanbul ignore next */
spinier.install = Vue => {
  Vue.component(spinier.name, spinier)
}

export default spinier
