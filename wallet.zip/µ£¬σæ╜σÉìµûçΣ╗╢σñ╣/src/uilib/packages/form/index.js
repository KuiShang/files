import CommonForm from './src/form';

/* istanbul ignore next */
CommonForm.install = function(Vue) {
  Vue.component(CommonForm.name, CommonForm);
};

export default CommonForm;
