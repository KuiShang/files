<template>
  <div class="common-input-wraper">
    <div class="input-container">
      <input
        :class="['input', { 'warn-input': !valid, 'no-border': !border, 'befor-icon':beforeIcontype }]"
        :type="type"
        ref="input"
        v-model="currentValue"
        :disabled="disabled"
        :readonly="readonly"
        :maxlength="maxlength"
        autocomplete="off"
        @blur="check"
        @input="handleInput"
        @focus="inputFocus('number')"
      >
      <img
        v-if="this.currentValue&&beforeIcontype=='ewallet'"
        src="./ewallet@3x.png"
        class="before-img"
      >
      <img
        v-else-if="this.currentValue&&beforeIcontype=='mobile'"
        src="./mobile@3x.png"
        class="before-img"
      >
      <img v-else-if="this.currentValue&&beforeIcontype=='id'" src="./ID@3x.png" class="before-img">
      <img
        v-if="isFocus"
        src="./cross_small@3x.png"
        class="custom-ico"
        :style="styleObj"
        @click="clear"
      >
    </div>
    <span
      :class="['input-tip', { 'input-tip-focus': active, 'warn-msg': !valid }]"
      @click="clickinput"
    >{{ holder }}</span>
    <ul v-if="showSuggest" class="phone-list" v-clickoutside="doCloseActive">
      <li
        v-for="(item, idx) in suggestions"
        :key="idx"
        class="phone-item"
        @click="clickItem(item.number)"
      >
        <span class="phone-num">{{ item.number }}</span>
        <span class="phone-name">{{ item.name }}</span>
      </li>
    </ul>
  </div>
</template>
<script>
import icon from "../../icon/src/icon";
import Clickoutside from "../../../src/utils/clickoutside";
import emitter from "../../../src/mixins/emitter";
export default {
  name: "CommonInput",
  components: { icon },
  data() {
    return {
      currentValue: this.value,
      valid: true,
      active: this.isActive,
      isFocus: false,
      suggestions: [],
      beforeIconUrl: ""
    };
  },
  mixins: [emitter],
  directives: {
    Clickoutside
  },
  props: {
    isActive: {
      type: Boolean,
      default: false
    },
    disabled: Boolean,
    readonly: Boolean,
    holder: {
      type: String,
      default: ""
    },
    beforeIcontype: {
      default: "",
      type: String
    },
    border: {
      type: Boolean,
      default: true
    },
    validateEvent: {
      type: Boolean,
      default: true
    },
    maxlength: Number,
    showSuggest: Boolean,
    fetchSuggestions: Function,
    type: {
      type: String,
      default: "text"
    },
    styleObj: {
      type: Object
    },
    addBlank: {
      type: Boolean,
      default: false
    },
    validateType: {
      type: String,
      default: ""
    },
    value: [String, Number]
  },
  methods: {
    check() {
      // console.log('check')
      setTimeout(() => {
        this.isFocus = false
        this.$emit('blur');
        let val = String(this.currentValue)
        if (val.trim().length === 0) {
          this.active = false
        }
        if (this.validateEvent) {
          this.dispatch('CommonFormItem', 'common.form.blur', [this.currentValue]);
        }
      }, 200);
    },
    inputFocus() {
      // console.log('inputFocus')
      this.isFocus = true;
      this.active = true;
      this.$emit("focus");
    },
    clickinput() {
      this.$refs.input.focus();
    },
    handleInput(evt) {
      if (this.type == "tel" || this.type == "number") {
        let val = evt.target.value;
        // val = val.replace(/[^\d]/g, ""); //清除“数字”以外的字符
        if (this.addBlank) {
          //获取当前光标的位置
          // debugger
          var caret = evt.target.selectionStart;
          //获取当前的value
          var value = val;
          //从左边沿到坐标之间的空格数
          var sp = (value.slice(0, caret).match(/\s/g) || []).length;
          //去掉所有空格
          var nospace = value.replace(/\s/g, "");
          //重新插入空格
          var curVal = evt.target.value = this.currentValue = val.replace(/\s/g, "").replace(/(\d{4})(?=\d)/g, "$1 ");

          //从左边沿到原坐标之间的空格数
          var curSp = (curVal.slice(0, caret).match(/\s/g) || []).length;
          //修正光标位置
          evt.target.selectionEnd = evt.target.selectionStart = caret + curSp - sp;
        } else {
          this.currentValue = val;
        }
      } else {
        if (this.validateType === "name") {
          let val = evt.target.value;
          this.currentValue = val.replace(/[^A-Za-z-_,'.&\s]/g, "");
        } else {
          this.currentValue = evt.target.value;
        }
      }
      this.debouncedGetData(evt.target.value.replace(/[^\d]/g, ""));
    },
    getData(queryString) {
      if (!this.showSuggest) {
        return;
      }
      this.fetchSuggestions(queryString, suggestions => {
        if (Array.isArray(suggestions)) {
          this.suggestions = suggestions;
        } else {
          console.error("[Error][Autocomplete] suggestions must be an array");
        }
      });
    },
    clear() {
      this.currentValue = "";
      this.$emit("input", "");
      this.active = false;
      this.$emit("handleClear");
    },
    clickItem(val) {
      if (val.length > 10) {
        val = val.substring(0, 10);
      }
      this.currentValue = val;
      this.$emit("input", val);
      this.$emit("chooseItem", val);
      this.$nextTick(_ => {
        this.suggestions = [];
      });
    },
    doCloseActive() {
      this.suggestions = [];
    }
  },
  mounted() {
    this.debouncedGetData = this.getData;
    if (String(this.value).length > 0) {
      this.active = true;
    }
  },
  watch: {
    value(val) {
      this.currentValue = val;
    },

    currentValue(val) {
      this.$emit("input", val);
      console.log(val);
      if (val) {
        console.log("active");
        this.active = true;
      }
    },
    // 只能watch两个data，active用计算属性set(val)时focus有问题
    isActive(val) {
      this.active = val;
    },
    active(val) {
      this.$emit("update:isActive", val);
    }
  }
};
</script>
<style lang="scss" scoped>
input {
  font:1px The1Official_Regular;
  font-family: The1Official_Regular ;
  color: initial;
}

.common-input-wraper {
  position: relative;
  .input-container {
    position: relative;
    .befor-icon {
      padding-left: 0.66rem;
    }
    .input {
      height: 0.8rem;
      padding-top: 0.5rem;
      width: 80%;
      display: block;
      border: 0;
      outline: none;
      border-bottom: 1px solid #e5e5e5;
      font-size: 0.4rem;
      z-index: 2;
      color: #141e50;
      background: transparent;
    }
    .no-border {
      border: none;
    }
    .before-img {
      width: 0.6rem;
      height: 0.6rem;
      position: absolute;
      top: 0.6rem;
      left: 0;
    }
    .custom-ico {
      padding: 0.2rem;
      width: 0.28rem;
      height: 0.28rem;
      position: absolute;
      top: 0.45rem;
    }
  }
  .input-tip {
    position: absolute;
    left: 0;
    top: 0.5rem;
    font-size: 0.4rem;
    color: #a1a5b9;
    transition: 0.3s linear;
    // z-index: 2;
  }
  .input-tip-focus {
    top: 0.25rem;
    font-size: 0.28rem;
    color: #a1a5b9;
  }
  .warn-msg {
    color: #f41935;
  }
  .phone-list {
    box-shadow: 0 60px 100px 0 rgba(0, 0, 0, 0.08);
    background-color: #fff;
    position: absolute;
    border-top: 1px solid #e7e8ed;
    z-index: 10;
    top: 1.41rem;
    left: -0.4rem;
    right: 0;
    transition: all 0.3s;
    max-height: 5.5rem;
    overflow-y: scroll;
    .phone-item {
      height: 1rem;
      display: flex;
      padding: 0 0.4rem;
      justify-content: space-between;
      align-items: center;
      font-size: 0.32rem;
      .phone-num {
        color: #302b2b;
      }
      .phone-name {
        color: #e7e8ed;
      }
    }
  }
}
</style>
