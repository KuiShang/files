import input from './src/input'

/* istanbul ignore next */
input.install = Vue => {
  Vue.component(input.name, input)
}

export default input
