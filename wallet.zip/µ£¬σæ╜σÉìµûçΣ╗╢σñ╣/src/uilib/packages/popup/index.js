import popup from './src/popup'

/* istanbul ignore next */
popup.install = Vue => {
  Vue.component(popup.name, popup)
}

export default popup
