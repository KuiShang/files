import field from './src/field'

/* istanbul ignore next */
field.install = Vue => {
  Vue.component(field.name, field)
}

export default field
