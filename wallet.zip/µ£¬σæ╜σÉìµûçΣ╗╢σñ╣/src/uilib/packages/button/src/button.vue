<template>
  <button
    :type="nativeType"
    class="common-button"
    :class="['common-button--' + type, 'common-button--' + size, {
      'is-disabled': disabled,
      'is-plain': plain
    }]"
    :style="{height:height }"
    @click="handleClick"
    :disabled="disabled">
    <div v-if="false" class="button-indicator-container">
      <spinner  class="mint-indicator-spin" type="snake" :size="32" color="white"></spinner>
    </div>
    <template v-else>
      <span class="common-button-icon" v-if="icon || $slots.icon">
        <icon :name="icon" :color="color" size=".4rem"/>
      </span>
      <label class="common-button-text"><slot></slot></label>
    </template>
 
  </button>
</template>

<script>
/**
 * header
 * @module components/button
 * @desc 按钮
 * @param {string} [type=default] - 显示类型，接受 default, primary, danger
 * @param {boolean} [disabled=false] - 禁用
 * @param {boolean} [plain=false] - 幽灵按钮
 * @param {string} [size=normal] - 尺寸，接受 normal, small, large
 * @param {string} [native-type] - 原生 type 属性
 * @param {string} [icon] - 图标，提供 more, back，或者自定义的图标（传入不带前缀的图标类名，最后拼接成 .commonui-xxx）
 * @param {slot} - 显示文本
 * @param {slot} [icon] 显示图标
 *
 * @example
 * <common-button size="large" icon="back" type="primary">按钮</common-button>
 */
import icon from '../../icon/src/icon'
import Spinner from '../../spinner/index.js';
export default {
  name: 'CommonButton',

  methods: {
    handleClick(evt) {
      this.$emit('click', evt);
    }
  },
  components: { icon, Spinner },
  props: {
    icon: String,
    disabled: Boolean,
    nativeType: String,
    plain: Boolean,
    type: {
      type: String,
      default: 'default',
      validator(value) {
        return [
          'default',
          'danger',
          'primary'
        ].indexOf(value) > -1;
      }
    },
    size: {
      type: String,
      default: 'normal',
      validator(value) {
        return [
          'small',
          'normal',
          'large'
        ].indexOf(value) > -1;
      }
    },
    color: {
      type: String,
      default: 'white',
      validator(value) {
        return [
          'black',
          'white',
        ].indexOf(value) > -1;
      }
    },
    height: {
      type: String,
      default: '1.12rem'
    }
  }
};
</script>

<style lang="scss" >
@import "../../../src/style/var.scss";
.button-indicator-container {
  display: flex;
    justify-content: center;
    align-items: center;
}
  .common-button {
    line-height: 1rem;
    appearance: none;
    border-radius: 4px;
    border: 0;
    box-sizing: border-box;
    color: inherit;
    display: block;
    font-size: 18px;
    height: 41px;
    outline: 0;
    overflow: hidden;
    position: relative;
    text-align: center;
    border-radius: 100px;
    width: 6.7rem;
    height: 1.12rem;
}
.common-button-text {
  font-size: .36rem;
  font-family: The1Official_Bold;
}
.common-button::after {
    background-color: #000;
    content: " ";
    opacity: 0;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    position: absolute
}
.common-button:not(.is-disabled):active::after {
    opacity: .4
}
.common-button.is-disabled {
    opacity: .6
}
.common-button-icon {
    // vertical-align: middle;
    display: block;
    padding-right: .2rem;
}
.common-button--default {
    color: #656b79;
    background-color: #f6f8fa;
    box-shadow: 0 0 1px #b8bbbf
}
.common-button--default.is-plain {
    border: 1px solid #5a5a5a;
    background-color: transparent;
    box-shadow: none;
    color: #5a5a5a
}
.common-button--primary {
    color: #fff;
    background-color: #26a2ff
}
.common-button--primary.is-plain {
    border: 1px solid #26a2ff;
    background-color: transparent;
    color: #26a2ff
}
.common-button--danger {
    color: #fff;
    background-color: $color-red;
}
.common-button--danger.is-plain {
    border: 1px solid #ef4f4f;
    background-color: transparent;
    color: $color-red;
}
.common-button--large {
    display: block;
    width: 100%
}
.common-button--normal {
    display: block;
    padding: 0 12px
}
.common-button--small {
    display: block;
    font-size: 14px;
    padding: 0 12px;
    height: 33px
}

</style>
