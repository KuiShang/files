import button from './src/button'

/* istanbul ignore next */
button.install = (Vue) => {
  Vue.component(button.name, button)
}

export default button
