
<template>
  <header
    class="common-header"
    :class="{ 'is-fixed': fixed }"
		:style="`backgroundColor:${bgcolor};color:${color}`"
		>
    <div class="common-header-button is-left">
      <slot name="left"></slot>
    </div>
    <h1 class="common-header-title" v-text="title"></h1>
    <div class="common-header-button is-right">
      <slot name="right"></slot>
    </div>
  </header>
</template>
<script>
/**
 * mt-header
 * @module components/header
 * @desc 顶部导航
 * @param {boolean} [fixed=false] - 固定顶部
 * @param {string} [title] - 标题
 * @param {slot} [left] - 显示在左侧区域
 * @param {slot} [right] - 显示在右侧区域
 *
 * @example
 * <mt-header title="我是标题" fixed>
 *   <mt-button slot="left" icon="back" @click="handleBack">返回</mt-button>
 *   <mt-button slot="right" icon="more"></mt-button>
 * </mt-header>
 */
export default {
  name: 'CommonHeader',

  props: {
    fixed: Boolean,
		title: String,
    color: {
      type: String,
      default: 'black',
      validator(value) {
        return [
          'black',
          'white',
        ].indexOf(value) > -1;
      }
		},
		bgcolor: {
      type: String,
      default: 'white',
      validator(value) {
        return [
          'black',
          'white',
        ].indexOf(value) > -1;
      }
    },
  }
};
</script>

<style  scoped>
.common-header {
	align-items: center;
	background-color: #fff;
	box-sizing: border-box;
	color: #000;
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	font-size: 14px;
	height: .88rem;
	line-height: 1;
	padding: 0 10px;
	position: relative;
	text-align: center;
	white-space: nowrap;
}
.common-header .common-button {
	background-color: transparent;
	border: 0;
	box-shadow: none;
	color: inherit;
	display: inline-block;
	padding: 0;
	font-size: inherit
}
.common-header .common-button::after {
  content: none;
}
.common-header.is-fixed {
    top: 0;
    right: 0;
    left: 0;
    position: fixed;
    z-index: 1;
}
.common-header-button {
  flex: .5;
}
.common-header-button > a {
    color: inherit;
}
.common-header-button.is-right {
    text-align: right;
}
.common-header-button.is-left {
    text-align: left;
}
.common-header-title {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: inherit;
    font-weight: 400;
    flex: 1;
}

</style>


