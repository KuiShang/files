import header from './src/header'

/* istanbul ignore next */
header.install = Vue => {
  Vue.component(header.name, header)
}

export default header
