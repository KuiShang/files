import icon from './src/icon'

/* istanbul ignore next */
icon.install = Vue => {
  Vue.component(icon.name, icon)
}

export default icon
