<template>
  <i class="common-icon" :class="`icon jdfinace  finace-icon-${name} icon-${color} ` " @click="handleClick" :style="`fontSize:${size}`">
    <slot />
    <div v-if="info" class="finace-icon__info">{{ info }}</div>
  </i>
</template>

<script>
export default {
  name: 'CommonIcon',
  props: {
    name: String,
    info: String,
    color: {
      type: String,
      default: '',
      validator(value) {
        return [
          'black',
          'white',
          ''
        ].indexOf(value) > -1;
      }
    },
    size: {
      type: String,
      default: '',
    }
  },
  methods: {
    handleClick(evt) {
      this.$emit('click', evt);
    }
  },
}
</script>
<style>
.icon-black {
  color: #000;
}
.icon-white {
  color: #fff;
}
.finace-icon__info {
  color: #fff;
  left: 50%;
  top: -.5em;
  font-size: .5em;
  margin-left: .8em;
  padding: 0 .3em;
  text-align: center;
  min-width: 1.2em;
  line-height: 1.2;
  position: absolute;
  border-radius: .6em;
  box-sizing: border-box;
  font-family: PingFang SC, Helvetica Neue, Arial, sans-serif;
}

</style>

