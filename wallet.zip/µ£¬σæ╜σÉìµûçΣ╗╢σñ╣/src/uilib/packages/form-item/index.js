import CommonFormItem from '../form/src/form-item';

/* istanbul ignore next */
CommonFormItem.install = function(Vue) {
  Vue.component(CommonFormItem.name, CommonFormItem);
};

export default CommonFormItem;
