<template>
  <div
    class="common-list-item-wraper"
    :class="{isborder: border}"
    :style="`paddingRight:${paddingRight}rem; paddingLeft:${paddingLeft}rem`"
    @click="$emit('click')">
    <!-- <i class="img"/> -->
    <slot name="img"/>
    <div class="cont">
      <span class="bank-title" v-text="title"/>
      <span v-if="label" class="des" v-text="label"/>
    </div>
    <slot name="icon"/>
    <!-- <common-icon
      v-if="icon"
      class="custom-ico"
      :name="icon"
      size=".5rem"
    /> -->
  </div>
</template>
<script>
export default {
  name: 'CommonItem',
  props: {
    title: String,
    label: String,
    icon: String,
    logo: String,
    paddingLeft: {
      type: Number,
      default: 0
    },
    paddingRight: {
      type: Number,
      default: 0
    },
    border: {
      type: Boolean,
      default: true
    }
  }
}
</script>
<style lang="scss" scoped>
 .common-list-item-wraper {
    box-sizing: border-box;
    height: 1.4rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .img {
      display: inline-block;
      width: .6rem;
      height: .6rem;
      border-radius: 50%;
      background-color: #4D7BFE;
    }
    .cont {
      height:  1.4rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding-left: .2rem;
      flex: 1;
      .bank-title {
        font-size: .36rem;
        color: #141E50;
      }
      .des {
        padding-top: .16rem;
        font-size: .24rem;
        color: #A1A5B9;
      }
    }
    // .custom-ico {
    //   color: #4D7BFE;
    // }
  }
  .isborder {
    border-bottom: 1px solid #E4E4E4;
  }
</style>


