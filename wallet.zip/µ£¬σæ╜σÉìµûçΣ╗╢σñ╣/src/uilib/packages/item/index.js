import item from './src/item'

/* istanbul ignore next */
item.install = Vue => {
  Vue.component(item.name, item)
}

export default item
