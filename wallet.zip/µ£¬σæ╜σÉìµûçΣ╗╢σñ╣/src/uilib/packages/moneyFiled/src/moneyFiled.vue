<template>
  <x-cell
    :title="label"
    :isBordorBootom = 'isBordorBootom'
    v-clickoutside="doCloseActive"
    :class="[{
      'is-textarea': type === 'textarea',
      'is-nolabel': !label
    }]">
    <div class="mint-field">
      <textarea
        @change="$emit('change', currentValue)"
        ref="textarea"
        class="mint-field-core"
        :placeholder="placeholder"
        v-if="type === 'textarea'"
        :rows="rows"
        :disabled="disabled"
        :readonly="readonly"
        v-model="currentValue">
      </textarea>
      <div class="input-waper" v-else >
        <div class="prefix">
          <slot name="prefix"></slot>
        </div>
        <input
          @change="$emit('change', currentValue)"
          ref="input"
          class="mint-field-core"
          :placeholder="placeholder"
          :number="type === 'number'"
          :type="type"
          :style="`font-size:${fontSize};paddingLeft:${paddingLeft}`"
          @focus="focus"
          @blur="$emit('blur')"
          :disabled="disabled"
          :readonly="readonly"
          :value="currentValue"
          @input="handleInput">
        <div
        @click="handleClear"
        class="mint-field-clear"
        v-if="!disableClear"
        v-show="currentValue && type !== 'textarea' && active">
        <!-- <i class="mintui mintui-field-error"></i> -->
              <icon
                name= 'delete_fill'
                size=".9rem"/>
      </div>
      </div>

  </div>
  </x-cell>
</template>

<script>
import XCell from '../../cell/src/cell';
import Clickoutside from '../../../src/utils/clickoutside';
import icon from '../../icon/src/icon'

/**
 * mt-field
 * @desc 编辑器，依赖 cell
 * @module components/field
 *
 * @param {string} [type=text] - field 类型，接受 text, textarea 等
 * @param {string} [label] - 标签
 * @param {string} [rows] - textarea 的 rows
 * @param {string} [placeholder] - placeholder
 * @param {string} [disabled] - disabled
 * @param {string} [readonly] - readonly
 * @param {string} [state] - 表单校验状态样式，接受 error, warning, success
 *
 * @example
 * <mt-field v-model="value" label="用户名"></mt-field>
 * <mt-field v-model="value" label="密码" placeholder="请输入密码"></mt-field>
 * <mt-field v-model="value" label="自我介绍" placeholder="自我介绍" type="textarea" rows="4"></mt-field>
 * <mt-field v-model="value" label="邮箱" placeholder="成功状态" state="success"></mt-field>
 */
export default {
  name: 'CommonMoneyFiled',
  data() {
    return {
      active: false,
      currentValue: this.value
    };
  },

  directives: {
    Clickoutside
  },

  props: {
    type: {
      type: String,
      default: 'text'
    },
    rows: String,
    label: String,
    placeholder: String,
    readonly: Boolean,
    disabled: Boolean,
    disableClear: Boolean,
    state: {
      type: String,
      default: 'default'
    },
    value: {},
    attr: Object,
    isBordorBootom: {
      type: Boolean,
      default: false
    },
    fontSize: String,
    paddingLeft: String
  },

  components: { XCell, icon },

  methods: {
    doCloseActive() {
      this.active = false;
    },

    handleInput(evt) {
      this.currentValue = evt.target.value;
    },

    handleClear() {
      if (this.disabled || this.readonly) return;
      this.currentValue = '';
    },
    focus() {
      this.active = true
      this.$emit('focus')
    }
  }, 
  computed: {
    iconState() {
      if (this.state === 'default') {
        return ''
      } else if (this.state === 'error') {
        return ''
      } else if (this.state === 'warning') {
        return ''
      } else if (this.state === 'success') {
        return ''
      } else {
        return ''
      }
    }
  },
  watch: {
    value(val) {
      this.currentValue = val;
    },

    currentValue(val) {
      this.$emit('input', val);
    },

    attr: {
      immediate: true,
      handler(attrs) {
        this.$nextTick(() => {
          const target = [this.$refs.input, this.$refs.textarea];
          target.forEach(el => {
            if (!el || !attrs) return;
            Object.keys(attrs).map(name => el.setAttribute(name, attrs[name]));
          });
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.mint-field {
  width: 100%;
}

.mint-field.is-textarea {
    -webkit-box-align: inherit;
        -ms-flex-align: inherit;
            align-items: inherit;
}
.input-waper {
  // height: 1.1rem;
  // padding: .28rem 0rem .27rem 0rem;
  position: relative;
  box-sizing: border-box;
  .mint-field-core {
    border: 0;
    padding: 0;
    display: block;
    width: 100%;
    resize: none;
    box-sizing: border-box;
    font-size: .46rem;
    outline:none;
    padding: .28rem 0.6rem .27rem 0rem;
    border-bottom: 1px solid #EEEEEE;

  }

  .prefix {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    display: flex;
    padding-top: .28rem;
    padding-bottom: .27rem;
  }
  .mint-field-core:focus {
    border-bottom: 2px solid #4D7BFE;
  }
  ::-webkit-input-placeholder { /* WebKit browsers */
    color: #D6D5D5;
  }
  :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color: #D6D5D5;
  }
  ::-moz-placeholder { /* Mozilla Firefox 19+ */
    color: #D6D5D5;
  }
  :-ms-input-placeholder { /* Internet Explorer 10+ */
    color: #D6D5D5;
  }
}


.mint-field-clear {
    opacity: .2;
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: center;
    align-items: center;
}
.mint-field-state {
    color: inherit;
    margin-left: 20px;
}
.mint-field-state .mintui {
    font-size: 20px;
}
.mint-field-state.is-default {
    margin-left: 0;
}
.mint-field-state.is-success {
    color: #4caf50;
}
.mint-field-state.is-warning {
    color: #ffc107;
}
.mint-field-state.is-error {
    color: #f44336;
}
.mint-field-other {
    top: 0;
    right: 0;
    position: relative;
}
</style>
