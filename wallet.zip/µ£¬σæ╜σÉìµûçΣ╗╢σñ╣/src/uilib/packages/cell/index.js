import cell from './src/cell'

/* istanbul ignore next */
cell.install = Vue => {
  Vue.component(popup.name, popup)
}

export default cell
