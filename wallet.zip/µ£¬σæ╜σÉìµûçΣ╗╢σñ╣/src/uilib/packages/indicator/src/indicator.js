import Vue from 'vue'
import IndicatorVue from './indicator.vue'

var IndicatorConstructor = Vue.extend(IndicatorVue)

let instance
let indicator = function () {
}
indicator.open = function (options = {}) {
  if (!instance) {
    instance = new IndicatorConstructor({
      el: document.createElement('div')
    })
  }
  if (instance.visible) return
  instance.text = typeof options === 'string' ? options : options.text || ''
  instance.spinnerType = options.spinnerType || 'snake'
  document.body.appendChild(instance.$el)

  Vue.nextTick(() => {
    instance.visible = true
  })
}

indicator.close = function () {
  if (instance) {
    instance.visible = false
  }
}

indicator.install = function (Vue) {
  Vue.component(IndicatorVue.name, IndicatorVue)
}

// var indicator = {
//   open (options = {}) {
//     if (!instance) {
//       instance = new IndicatorConstructor({
//         el: document.createElement('div')
//       })
//     }
//     if (instance.visible) return
//     instance.text = typeof options === 'string' ? options : options.text || ''
//     instance.spinnerType = options.spinnerType || 'snake'
//     document.body.appendChild(instance.$el)

//     Vue.nextTick(() => {
//       instance.visible = true
//     })
//   },

//   close () {
//     if (instance) {
//       instance.visible = false
//     }
//   },
//   install (Vue) {
//     Vue.component(IndicatorVue.name, IndicatorVue)
//   }
// }

Vue.$indicator = Vue.prototype.$indicator = indicator

export default indicator

// IndicatorVue.install = Vue => {
//   Vue.component(IndicatorVue.name, IndicatorVue)
// }

// export default IndicatorVue
