export { default } from './src/indicator.js';
