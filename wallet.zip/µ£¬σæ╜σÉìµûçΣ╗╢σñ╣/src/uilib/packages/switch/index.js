import mSwitch from './src/switch'

/* istanbul ignore next */
mSwitch.install = Vue => {
  Vue.component(mSwitch.name, mSwitch)
}

export default mSwitch
