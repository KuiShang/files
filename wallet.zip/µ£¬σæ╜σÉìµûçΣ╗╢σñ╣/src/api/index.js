import Vue from 'vue'
import * as SDK from '@/sdk/wrapper'
import { Base64 } from 'js-base64';
import { safeFlag } from '../config'

import axios from '../axios/axios'

const TYPES = {
  GET: 'GET',
  POST: 'POST'
}
// 是否完成判断当前使用哪个fetch， 默认为假，在初始化完成之后为真
// let initFinish = false
// 是否使用客户端request开关，  默认为true true:表示使用客户端发送请求    false：表示使用h5请求

function fetchAxiox(types, url, data) {
  if (types === TYPES.GET) {
    return axios.get(url, {
      params: data
    })
  } else if (types === TYPES.POST) {
    return axios.post(url, data)
  }
  console.error('没有添加这种类型', types)
  return false
}
// type: 1- post  2- get
function fetchApp(types, url, data, timeout) {
  /*eslint-disable*/
  let type = 1
  if (types === TYPES.GET) {
    type = 2
  } else {
    type = 1
  }
  const urlAll = window.location.origin + url
  if (!!timeout) {
    var json = {
      url: urlAll,
      httpType: type,
      parameters: JSON.stringify(data),
      postMediaType: 'application/json',
      headerParameters: {
        t1w: 't1w',
        deviceinfo: '{"deviceType":"APP"}',
        ticket: 'ec731a86-2052-4ac1-981a-20b71297ea14'
      },
      timeout: timeout
    }
  } else {
    var json = {
      url: urlAll,
      httpType: type,
      parameters: JSON.stringify(data),
      postMediaType: 'application/json',
      headerParameters: {
        t1w: 't1w',
        deviceinfo: '{"deviceType":"APP"}',
        ticket: 'ec731a86-2052-4ac1-981a-20b71297ea14'
      }
    }
  }
  
  console.log('请求数据', json)
  const su = function su(ret) {
    console.log('原声app成功的ret', ret)
    const retResloved = decodeURIComponent(ret.data)
    console.log('原声app成功的ret 解析后：', JSON.parse(retResloved))
  }
  return new Promise((reslove, reject) => {
    SDK.request(json, (ret) => {
      console.log('原声app成功的ret', ret)
      console.log('Base64.decode', Base64.decode)

      let strObj = ''
      let str = ''
      if (Vue.$DeviceInfo.language) {
        if (Vue.$DeviceInfo.language === 'en_US') {
          strObj = {
            k40: 'No internet connection, please try again',
            k50: 'System error'
          }
        } else {
          strObj = {
            k40: 'ไม่สามารถเชื่อมต่ออินเทอร์เน็ตได้ กรุณาลองใหม่อีกครั้ง',
            k50: 'ระบบผิดพลาด'
          }
        }
      } else {
        strObj = {
          k40: 'No internet connection, please try again',
          k50: 'System error'
        }
      }

      function getSuccess() {
        const retResloved = JSON.parse(Base64.decode(ret.data))
        console.log('原声app成功的ret 解析后：', retResloved)
        if (retResloved.status === 200) {
          retResloved.data = JSON.parse(retResloved.data)
          retResloved.data.resultCode = Number(retResloved.data.resultCode)
          console.log('最终解析完成的结果：', retResloved)
          reslove(retResloved)
        } else if (retResloved.status.toString().match(/^50/)) {
          str = strObj.k50
          !window.vue.$store.state.payLooping && Vue.$toast({
            message: str,
            position: 'bottom',
            duration: 2000
          })
          // router.push({ name: 'netError' })
          reslove(retResloved)
        } else if (retResloved.status.toString().match(/^40/)) {
          str = strObj.k40
          !window.vue.$store.state.payLooping && Vue.$toast({
            message: str,
            position: 'bottom',
            duration: 2000
          })
          reslove(retResloved)
        } else {
          str = strObj.k40
          !window.vue.$store.state.payLooping && Vue.$toast({
            message: str,
            position: 'bottom',
            duration: 2000
          })
          reslove(retResloved)
        }
      }
      if (ret.code === 1) {
        getSuccess()
      } else if (ret.code === -1) {
        console.log('入参出错', ret)
        str = strObj.k50
        
        !window.vue.$store.state.payLooping && Vue.$toast({
          message: str,
          position: 'bottom',
          duration: 2000
        })
      } else if (ret.code === -3) {
        console.log('NativeError', ret)
        str = strObj.k50
        !window.vue.$store.state.payLooping && Vue.$toast({
          message: str,
          position: 'bottom',
          duration: 2000
        })
      } else if (ret.code === -2) {
        console.log('网络错误', ret)
        str = strObj.k40
        !window.vue.$store.state.payLooping && Vue.$toast({
          message: str,
          position: 'bottom',
          duration: 2000
        })
        reslove({
          code: -2,
          des: '本机断网'
        })
      }
    })
  })
}

let fetch = async function d(a, b, c) {
  const hasRequest = await SDK.checkHasAppRequest()
  if (safeFlag && hasRequest) {
    fetch = fetchApp
  } else {
    fetch = fetchAxiox
  }
  console.log('当前的fetch：', fetch)
  return fetch(a, b, c)
}

// async function switchFetch() {
//   const hasRequest = await SDK.checkHasAppRequest()
//   if (safeFlag && hasRequest) {
//     fetch = fetchApp
//   } else {
//     fetch = fetchAxiox
//   }
//   initFinish = true
//   return fetch
// }
// switchFetch()

// console.log('当前的fetch：', fetch)

export function getMainPage(data) {
  return fetch(TYPES.POST, '/th/wallet/balancemain/mainPage', data)
}

export function queryTransionDetail(data) {
  return fetch(TYPES.POST, '/th/wallet/record/queryDetail', data)
}
// 查询交易明细
export function queryTradeDetail(data) {
  return fetch(TYPES.POST, '/th/trade_center/detail', data)
}
// 查询交易明细
export function queryTradeDetail2(data) {
  return fetch(TYPES.POST, '/th/trade_center/detail2', data)
}
// 查询交易明细（消息中心）
export function queryMsgCenterTradeDetail(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/tradeDetail', data)
}

export function queryOnceLimit(data) {
  return fetch(TYPES.POST, '/th/wallet/topup/queryOnceLimit', data)
}

export function topUpBegin(data) {
  return fetch(TYPES.POST, '/th/wallet/topup/topUpBegin', data)
}
/**
 * 获取收银台数据
 */
export function getCashierData(data) {
  return fetch(TYPES.POST, '/th/cashier/query/method/list', data)
}
/**
 * 收银台余额支付
 */
export function balancePay(data) {
  return fetch(TYPES.POST, '/th/cashier/pay/balance', data, 20).then(res => res).catch(error => error)
}
/**
 * 收银台银行账户支付
 */
export function oddPay(data) {
  return fetch(TYPES.POST, '/th/cashier/pay/odd', data, 20).then(res => res).catch(error => error)
}
/**
 * withdraw
 */
export function withdrawBegin(data) {
  return fetch(TYPES.POST, '/th/wallet/withdraw/withdrawBegin', data)
}
/**
 * withdraw
 */
export function withdrawPage(data) {
  return fetch(TYPES.POST, '/th/wallet/withdraw/withdrawPage', data)
}
/**
 * transfer
 */
export function transferPage(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/transferPage', data)
}
/**
 * transfer
 */
export function createTransfer(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/createTransfer', data)
}

/**
 * transfer
 */
export function queryByPhone(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/queryByPhone', data)
}

/**
 * withdrawResult
 */
export function withdrawResult(data) {
  return fetch(TYPES.POST, '/th/wallet/withdraw/withdrawResult', data)
}
/**
 * transferResult
 */
export function transferResult(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/transferResult', data)
}

/**
 * topUpSucc
 */
export function topUpSucc(data) {
  return fetch(TYPES.POST, '/th/wallet/topup/topUpSucc', data)
}
/**
 * queryBankList
 */
export function queryBankList(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/queryBankList', data)
}

/**
 * 校验支付密码验证结果
 */
export function withdrawPwd(data) {
  return fetch(TYPES.POST, '/th/wallet/withdraw/withdrawPwd', data)
}
/**
 * 校验支付密码验证结果
 */
export function withdrawOtp(data) {
  return fetch(TYPES.POST, '/th/wallet/withdraw/withdrawOtp', data)
}
/**
 * p2p扫码转账
 */
export function parseCode(data) {
  return fetch(TYPES.POST, '/th/wallet/collect/parseCode', data)
}

/**
 * 取消p2p扫码转账
 */
export function cancelTransfer(data) {
  return fetch(TYPES.POST, '/th/wallet/collect/cancelTransfer', data)
}

/**
 * 转账历史
 */
export function transferRecord(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/transferRecord', data)
}

/**
 * 配置H5接口
 */
export function appConfigH5(data) {
  return fetch(TYPES.POST, '/th/app_config/getH5CfgData', data)
}

export function allPromotionItem(data) {
  return fetch(TYPES.POST, '/th/app_config/h5CmptList', data)
}

export function queryT1PDetail(data) {
  return fetch(TYPES.POST, '/t1p/queryT1PDetail', data)
}

/**
 * 转到银行账户 查询可转银行账户列表
 */
export function transBankAccountList(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/transBankAccountList', data)
}

/**
 *转到prompt  查看prompt详情
 */
export function promptReviewDetail(data) {
  return fetch(TYPES.POST, '/th/wallet/transfer/promptReviewDetail', data)
}
/*
 * 被扫支付结果页
 */
export function scanedResultQuery(data) {
  return fetch(TYPES.POST, '/th/cashier/result/query', data)
}

/**
 * 收银台卡支付
 */
export function ccpPay(data) {
  return fetch(TYPES.POST, '/th/cashier/pay/ccp', data, 20)
}

/**
 * 收银台结果页查询支付结果信息;
 */
export function cardOrgQuery(data) {
  return fetch(TYPES.POST, '/th/cashier/card/org/query', data)
}

/**
 * 收银台便利店支付
 */
export function cspPay(data) {
  return fetch(TYPES.POST, '/th/cashier/pay/csp', data, 20).then(res => res).catch(error => error)
}
/**
 * 收银台deeplink支付
 */
export function deliPay(data) {
  return fetch(TYPES.POST, '/th/cashier/pay/deeplink', data, 20).then(res => res).catch(error => error)
}

/* 笔笔返查看营销资格
*/
export function SuccReturnPromoMarkingQuer(data) {
  return fetch(TYPES.POST, '/th/promo/queryHitInfo', data, 30)
}

/**
 * 笔笔返营销命中
 */
export function SuccReturnPromoHit(data) {
  return fetch(TYPES.POST, '/th/promo/queryRewardInfo', data)
}

/* mycoupon->券详情
*/
export function couponUseDetail(data) {
  return fetch(TYPES.POST, '/th/coupon/detailByCouponId', data)
}

/* discovery券详情 领券
*/
export function DiscoveryCouponDetail(data) {
  return fetch(TYPES.POST, '/th/coupon/withoutLogin/detailByBatchId', data)
}
/* group discovery券详情 领券
*/
export function GroupDiscoveryCouponDetail(data) {
  return fetch(TYPES.POST, '/th/coupon/withoutLogin/groupBatchDetail', data)
}

/* discovery券详情 领券
*/
export function DiscoverygetCoupon(data) {
  return fetch(TYPES.POST, '/th/coupon/got', data)
}

/* coupon group列表状态
*/
export function GroupCouponStatus(data) {
  return fetch(TYPES.POST, '/th/coupon/withoutLogin/groupStatus', data)
}

/* group discovery券详情 领券
*/
export function GroupDiscoverygetCoupon(data) {
  return fetch(TYPES.POST, '/th/coupon/groupGot', data)
}

/* 发起requestToPay
*/
export function requestToPayInit(data) {
  return fetch(TYPES.POST, '/th/RequestToPay/init', data)
}

/* prompt tag30 扫描后跳转H5页面后 获取页面数据接口
*/
export function queryPromptTag30Info(data) {
  return fetch(TYPES.POST, '/th/wallet/collect/getPromptTag30Info', data)
}
/* promptTag30查询详情页面 数据保存
*/
export function promptTag30ReviewDetail(data) {
  return fetch(TYPES.POST, '/th/wallet/promptTag30/promptTag30ReviewDetail', data)
}
/* promptTag30 promptTag30CreateOrder 点击转账，创建转账业务单
*/
export function promptTag30CreateOrder(data) {
  return fetch(TYPES.POST, '/th/wallet/promptTag30/promptTag30CreateOrder', data)
}

/* open_api 的  gateway

注意: 此处需要用fetchAxiox 而非 fetch
理由
1 fetch 一般是客户端请求发送，都是走aks加密的
2 这个接口不支持aks目前。
3 由产品确认，此接口可以明文调用，安全扫描时候可以参考此产品prd
*/
export function openApiGateway(data) {
  return fetchAxiox(TYPES.POST, '/open_api/wallet_payment', data)
}

/* 跳转到商户APP的参数签名
*/
export function signQuery(data) {
  return fetch(TYPES.POST, '/th/cashier/result/transaction/sign/query', data)
}

export function GetKycLevel(data) {
  return fetch(TYPES.POST, '/th/RequestToPay/kyc', data)
}

// 检查钱包是否登陆
export function checkLogin(data) {
  return fetch(TYPES.POST, '/th/check/login', data)
}
export function CheckKycLevel(data) {
  return fetch(TYPES.POST, '/th/RequestToPay/kycCheck', data)
}
//邀请用户(老带新)
export function InvitationFriendsData(data) {
  return fetch(TYPES.POST, '/invitation/getLandingPage', data)
}
export function HistoryData(data) {
  return fetch(TYPES.POST, '/invitation/getFriends', data)
}
export function GetSharing(data) {
  return fetch(TYPES.POST, '/invitation/getSharing', data)
}
export function JoinInvitation(data) {
  return fetch(TYPES.POST, '/invitation/join', data)
}
// 优惠券领券上报信息
export function GroupDiscoverygetCoupoReportinformation(data) {
  return fetch(TYPES.POST, '/th/coupon/mark', data)
}
// 结果页查询优惠券

export function queryOrderDetail(data) {
  return fetch(TYPES.POST, '/setting/queryOrderDetail', data)
}
// 进入Mission页面初始化数据
export function MeetTheScallop(data) {
  return fetch(TYPES.POST, '/scallop/meetTheScallop', data)
}
// 打开扇贝抽奖

export function OpenScallop(data) {
  return fetch(TYPES.POST, '/scallop/openScallop', data)
}