import en from './en'
import th from './th'

const message = {
  en,
  th
}
export default message
