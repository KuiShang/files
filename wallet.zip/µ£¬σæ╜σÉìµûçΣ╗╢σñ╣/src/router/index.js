import Vue from 'vue'
import Router from 'vue-router'
/*eslint-disable*/
const transationDetail = r => require.ensure([], () => r(require('@/pages/transactionDetail/transactionDetail')), 'transationDetail')

const billPayment = r => require.ensure([], () => r(require('@/pages/billPayment/billPayment')), 'billPayment')
const billDetail = r => require.ensure([], () => r(require('@/pages/billPayment/billDetail')), 'billDetail')
const billCompany = r => require.ensure([], () => r(require('@/pages/billPayment/billCompany')), 'billCompany')
const billKeyin = r => require.ensure([], () => r(require('@/pages/billPayment/billKeyin')), 'billKeyin')
const billScanOlny = r => require.ensure([], () => r(require('@/pages/billPayment/billScanOnly')), 'billScanOlny')
const topup = r => require.ensure([], () => r(require('@/pages/balance/topup')), 'topup')
const topupResult = r => require.ensure([], () => r(require('@/pages/balance/topupResult')), 'topupResult')
const withdraw = r => require.ensure([], () => r(require('@/pages/balance/withdraw')), 'withdraw')
const withdrawResult = r => require.ensure([], () => r(require('@/pages/balance/withdrawResult')), 'withdrawResult')
const transfer = r => require.ensure([], () => r(require('@/pages/balance/transfer')), 'transfer')
const transferBankAccount = r => require.ensure([], () => r(require('@/pages/balance/transferBankAccount')), 'transferBankAccount')
const transferThe1Account = r => require.ensure([], () => r(require('@/pages/balance/transferThe1Account')), 'transferThe1Account')
const transferPromptAccount = r => require.ensure([], () => r(require('@/pages/balance/transferPromptAccount'), 'transferPromptAccount'))
const reviewDetail = r => require.ensure([], () => r(require('@/pages/balance/reviewDetail'), 'reviewDetail'))
const chooseBank = r => require.ensure([], () => r(require('@/pages/balance/chooseBank'), 'chooseBank'))
const chooseReceiver = r => require.ensure([], () => r(require('@/pages/balance/chooseReceiver'), 'chooseReceiver'))
const balance = r => require.ensure([], () => r(require('@/pages/balance/balance')), 'balance')
const balanceDetail = r => require.ensure([], () => r(require('@/pages/balance/detail')), 'balanceDetail')
const addAnotherBankAccount = r => require.ensure([], () => r(require('@/pages/balance/addAnotherBankAccount')), 'addAnotherBankAccount')
const p2p = r => require.ensure([], () => r(require('@/pages/p2pTransfer/p2p')), 'p2p')
const scanedResult = r => require.ensure([], () => r(require('@/pages/p2pTransfer/scanedResult')), 'scanedResult')
let home = r => require.ensure([], () => r(require('@/pages/home')), 'home')

const transferTh1Result = r => require.ensure([], () => r(require('@/pages/balance/transferTh1Result')), 'transferTh1Result')
const transferPromptConfirm = r => require.ensure([], () => r(require('@/pages/balance/transferPromptConfirm')), 'transferPromptConfirm')
const error = r => require.ensure([], () => r(require('@/pages/error/Error')), 'error')
const netError = r => require.ensure([], () => r(require('@/pages/error/netError')), 'netError')
const wraperSimpleCashier = r => require.ensure([], () => r(require('@/pages/cashier/wraperSimpleCashier')), 'wraperSimpleCashier')
const cdcp = r => require.ensure([], () => r(require('@/pages/cashier/paymethods/cdcp')), 'cdcp')
const addBankAccountResult = r => require.ensure([], () => r(require('@/pages/balance/common/addBankAccountResult')), 'addBankAccountResult')

const promotionTabList = r => require.ensure([], () => r(require('@/pages/promotionTab//promotionTabList')), 'promotionTabList')
const pageCreator = r => require.ensure([], () => r(require('@/pages/promotionTab//pageCreator')), 'pageCreator')
const promoTransactionDetail = r => require.ensure([], () => r(require('@/pages/promotionTab/promoTransactionDetail')), 'promoTransactionDetail')
const transferPromptTag30 = r => require.ensure([], () => r(require('@/pages/balance/transferPromptTag30/transferPromptTag30')), 'transferPromptTag30')
const transferPromptTag30Confirm = r => require.ensure([], () => r(require('@/pages/balance/transferPromptTag30/transferPromptTag30Confirm')), 'transferPromptTag30Confirm')




const rdt = r => require.ensure([], () => r(require('@/pages/cashier/ridrect/ridrect')), 'ridrect')

const tcRegistion = r => require.ensure([], () => r(require('@/pages/protocol/tc_registration')), 'tcRegistion')
const tcBind = r => require.ensure([], () => r(require('@/pages/protocol/tc_bind')), 'tcBind')
const privacy = r => require.ensure([], () => r(require('@/pages/protocol/privacy')), 'privacy')
const termService = r => require.ensure([], () => r(require('@/pages/protocol/termService')), 'termService')
// 要删没删
const userProtocol = r => require.ensure([], () => r(require('@/pages/protocol/userProtocol')), 'userProtocol')
const myCouponDetail = r => require.ensure([], () => r(require('@/pages/coupon/myCouponDetail')), 'myCouponDetail')
const discoveryCouponDetail = r => require.ensure([], () => r(require('@/pages/coupon/discoveryCouponDetail')), 'discoveryCouponDetail')
const groupDiscoveryCouponDetail = r => require.ensure([], () => r(require('@/pages/coupon/group/discoveryCouponDetail')), 'GroupDiscoveryCouponDetail')
const requestToPay = r => require.ensure([], () => r(require('@/pages/request2pay/requestToPay')), 'requestToPay')

const gatewayInit = r => require.ensure([], () => r(require('@/pages/gateway/init')), 'gatewayInit')
const gatewayResult = r => require.ensure([], () => r(require('@/pages/gateway/result')), 'gatewayResult')

//邀请分享
const invitationFriends = r => require.ensure([], () => r(require('@/pages/invitation/friends')), 'invitationFriends')
const invitationHistory = r => require.ensure([], () => r(require('@/pages/invitation/history')), 'invitationHistory')
const noInternet = r => require.ensure([], () => r(require('@/pages/invitation/noInternet')), 'noInternet')
const newUsersJoin = r => require.ensure([], () => r(require('@/pages/invitation/newUsersJoin')), 'newUsersJoin')


const refundUnusual = r => require.ensure([], () => r(require('@/pages/transactionDetail/refundUnusual')), 'refundUnusual')

const cardPayFail = r => require.ensure([], () => r(require('@/pages/cashier/modules/cardPayFail')), 'cardPayFail')

const collectCVV = r => require.ensure([], () => r(require('@/pages/cashier/modules/collectCVV')), 'collectCVV')
// lnwang  增加消息通知 （兼容性）
const messagecenterCompatibility = r => require.ensure([], () => r(require('@/pages/messagecenterCompatibility/messagecenterCompatibility')), 'messagecenterCompatibility')
//Mission
const MissionDolfin = r => require.ensure([], () => r(require('@/pages/mission/missionDolfin')), 'MissionDolfin')
const MissionGuide = r => require.ensure([], () => r(require('@/pages/mission/missionGuide')), 'MissionGuide')
const MissionGuidePageFirst = r => require.ensure([], () => r(require('@/pages/mission/guidePageFirst')), 'MissionGuidePageFirst')
const MissionGuidePageTwo = r => require.ensure([], () => r(require('@/pages/mission/guidePageTwo')), 'MissionGuidePageTwo')
const MissionGuidePageThree = r => require.ensure([], () => r(require('@/pages/mission/guidePageThree')), 'MissionGuidePageThree')


if (process.env.NODE_ENV === 'production') {
	home = error
} 
Vue.use(Router)

const routes = [
	{
		path: '/',
		component: home
	},
	{
		path: '/transationDetail',
		name: 'transationDetail',
		component: transationDetail
	},
	{
		path: '/msgCenter/transationDetail',
		name: 'msgCenterTransationDetail',
		props: {
			redirectFrom: "center"
		},
		component: transationDetail
	},
	{
		path: '/wraperSimpleCashier',
		name: 'wraperSimpleCashier',
		component: wraperSimpleCashier
	},
	{
		path: '/billPayment',
		name: 'billPayment',
		component: billPayment
	},
	{
		path: '/billDetail',
		name: 'billDetail',
		component: billDetail
	},
	{
		path: '/billCompany',
		name: 'billCompany',
		component: billCompany
	},
	{
		path: '/billKeyin',
		name: 'billKeyin',
		component: billKeyin
	},
	{
		path: '/billScanOlny',
		name: 'billScanOlny',
		component: billScanOlny
	},
	{
		path: '/balance/topup',
		name: 'topup',
		component: topup
	},
	{
		path: '/topupResult',
		name: 'topupResult',
		component: topupResult
	},
	{
		path: '/withdraw',
		name: 'withdraw',
		component: withdraw
	},
	{
		path: '/withdrawResult',
		name: 'withdrawResult',
		component: withdrawResult
	},
	{
		path: '/transferTh1Result',
		name: 'transferTh1Result',
		component: transferTh1Result
	},
	{
		path: '/transferPromptAccount',
		name: 'transferPromptAccount',
		component: transferPromptAccount
	},
	{
		path: '/transferPromptConfirm',
		name: 'transferPromptConfirm',
		component: transferPromptConfirm
	},
	{
		path: '/reviewDetail',
		name: 'reviewDetail',
		component: reviewDetail
	},
	{
		path: '/chooseBank',
		name: 'chooseBank',
		component: chooseBank
	},
	{
		path: '/chooseReceiver',
		name: 'chooseReceiver',
		component: chooseReceiver
	},
	{
		path: '/transfer',
		name: 'transfer',
		component: transfer
	},
	{
		path: '/transferBankAccount',
		name: 'transferBankAccount',
		component: transferBankAccount
	},
	{
		path: '/transferThe1Account',
		name: 'transferThe1Account',
		component: transferThe1Account
	},
	{
		path: '/balance/',
		name: 'balance',
		component: balance
	},
	{
		path: '/balance/detail',
		name: 'balanceDetail',
		component: balanceDetail
	},
	{
		path: '/transfer/addAnotherBankAccount',
		name: 'addAnotherBankAccount',
		component: addAnotherBankAccount
	},
	{
		path: '/p2p',
		name: 'p2p',
		component: p2p
	},
	{
		path: '/scanedResult',
		name: 'scanedResult',
		component: scanedResult
	},
	{
		path: '/cashier/cdcp',
		name: 'cdcp',
		component: cdcp
	},
	{
		path: '/addBankAccountResult',
		name: 'addBankAccountResult',
		component: addBankAccountResult
	},
	{
		path: '/error',
		name: 'error',
		component: error
	},
	{
		path: '/cashier/rdt/success',
		name: 'ridrectSuccess',
		component: rdt
	},
	{
		path: '/cashier/rdt/fail',
		name: 'ridrectFail',
		component: rdt
	},
	{
		path: '/cashier/rdt/error',
		name: 'ridrectError',
		component: rdt
	},
	{
		path: '/promotionTabList',
		name: 'promotionTabList',
		component: promotionTabList
	},
	{
		path: '/pageCreator',
		name: 'pageCreator',
		component: pageCreator
	},
	{
		path: '/promoTransactionDetail',
		name: 'promoTransactionDetail',
		component: promoTransactionDetail
	},
	{
		path: '/myCouponDetail',
		name: 'myCouponDetail',
		component: myCouponDetail
	},
	{
		path: '/discoveryCouponDetail',
		name: 'discoveryCouponDetail',
		component: discoveryCouponDetail
	},
	{
		path: '/group/discoveryCouponDetail',
		name: 'groupDiscoveryCouponDetail',
		component: groupDiscoveryCouponDetail
	},
	{
		path: '/requestToPay',
		name: 'requestToPay',
		component: requestToPay
	},
	{
		path: '*',
		name: '404',
		component: error
	},
	{
		path: '/protocol/termService',
		name: 'termService',
		component: termService
	},
	{
		path: '/userProtocol',
		name: 'userProtocol',
		component: userProtocol
	},
	{
		path: '/protocol/privacy',
		name: 'privacy',
		component: privacy
	},
	{
		path: '/protocol/tcRegistion',
		name: 'tcRegistion',
		component: tcRegistion
	},
	{
		path: '/protocol/tcBind',
		name: 'tcBind',
		component: tcBind
	},
	{
		path: '/netError',
		name: 'netError',
		component: netError
	},
	{
		path: '/transferPromptTag30',
		name: 'transferPromptTag30',
		component: transferPromptTag30
	},
	{
		path: '/transferPromptTag30Confirm',
		name: 'transferPromptTag30Confirm',
		component: transferPromptTag30Confirm
	},
	{
		path: '/gateway/init',
		name: 'gatewayInit',
		component: gatewayInit
	},
	{
		path: '/gateway/result',
		name: 'gatewayResult',
		component: gatewayResult
	},
	{
		path: '/invitation/friends',
		name: 'invitationFriends',
		component: invitationFriends
	},
	{
		path: '/invitation/history',
		name: 'invitationHistory',
		component: invitationHistory
	},
	{
		path: '/invitation/noInternet',
		name: 'noInternet',
		component: noInternet
	},
	{
		path: '/invitation/newUsersJoin',
		name: 'newUsersJoin',
		component: newUsersJoin
	},
	{
		path: '/refundUnusual',
		name: 'refundUnusual',
		component: refundUnusual
	},
	{
		path: '/cardPayFail',
		name: 'cardPayFail',
		component: cardPayFail
	},
	{
		path: '/collectCVV',
		name: 'collectCVV',
		component: collectCVV
	},
	{//消息中心
		path: '/messagecenterCompatibility',
		name: 'messagecenterCompatibility',
		component: messagecenterCompatibility  
	},
	{//Mission
		path: 'mission/missionDolfin',
		name: 'MissionDolfin',
		component: MissionDolfin
	},
	{//Mission
		path: 'mission/MissionGuide',
		name: 'MissionGuide',
		component: MissionGuide
	},
	{//Mission
		path: 'mission/MissionGuidePageFirst',
		name: 'MissionGuidePageFirst',
		component: MissionGuidePageFirst
	},
	{//Mission
		path: 'mission/MissionGuidePageTwo',
		name: 'MissionGuidePageTwo',
		component: MissionGuidePageTwo
	},
	{//Mission
		path: 'mission/MissionGuidePageThree',
		name: 'MissionGuidePageThree',
		component: MissionGuidePageThree
	}
]
const pathes = routes.map(i => i.path)
const router = new Router({
	routes
})
export {pathes,	router}
