// import '@/assets/fonts/iconfont.css'
import Vue from 'vue'
// 注入懒加载插件
import VueLazyLoad from 'vue-lazyload'
import 'babel-polyfill'
import VueI18n from 'vue-i18n'
// import FastClick from 'fastclick'
import VueAxios from 'vue-axios'
// import Vant from 'vant';
// import 'vant/lib/index.css';
// import commonUI from 'commonUI'
// import 'commonUI/lib/static/css/style.css'
import * as utils from '@/utils/utils'
import commonUI from './uilib/src/index'
import App from './App'
import { router } from './router'
import store from './store'
import axios from './axios/axios'
import * as SDK from './sdk/wrapper'
import messages from './i18n'
import { mockFlag } from './config'

Vue.use(VueI18n)
Vue.config.productionTip = false
Vue.use(commonUI)
Vue.use(VueAxios, axios)
// Vue.use(Vant)
Vue.use(VueLazyLoad, {
  loading: require('@/assets/images/promotionTab/loading.jpg'),
  error: require('@/assets/images/promotionTab/loading.jpg')
})

if (mockFlag) {
  if (process.env.NODE_ENV !== 'production') {
    require('./mock/index.js')
  }
}

const conStr = `
  -------------------------------------

  **提交代码前注意事项**

  1 提交代码前 main.js 文件的 mock开关 如果打开了 提交时候要关闭

  2 提交代码前 index.html vconsole 如果打开了  提交时要关闭

  3 jsBridge_common 不要全局覆盖

  -------------------------------------
`
// 在ios手机输入金额的时候有延迟，发现去掉这个库，延迟消失20190627
// FastClick.attach(document.body);
// sdk
const platformInfo = utils.getSysType()
console.log(platformInfo)
const isAndroid = platformInfo.isAndroid
const isIOS = platformInfo.isIOS
const isJDAPP = platformInfo.isJdApp

// ------   js桥 通过require方式引入的在ios下无效，所以修改为通过index.html文件通过script标签引入  20180831  ------

// if (isAndroid && isJDAPP) {
//   require('./sdk/android/_template-1.0.0.js')
//   require('./sdk/android/jsBridge-1.0.0.js')
// } else if (isIOS && isJDAPP) {
//   require('./sdk/android/_template-1.0.0.js')
//   // require('./sdk/ios/jsBridge-1.0.0.js')
//   require('./sdk/jsBridge_common.js')
// }
// require('./sdk/sdk-platform.js')

const i18n = new VueI18n({
  locale: 'en', // 语言标识
  messages
})

async function initAppData() {
  if (isJDAPP) {
    const ret = await SDK.getCommonInfo()
    console.log('公用設備信息:', ret)
    // utils.setCookie('DeviceInfo', JSON.stringify(ret.data))
    // axios.defaults.headers.common.deviceInfo = JSON.stringify(ret);
    axios.defaults.headers.common.deviceInfo = '{"deviceType":"APP"}'
    Vue.$DeviceInfo = ret
    Vue.prototype.$DeviceInfo = ret
    if (ret.language === 'en_US') {
      i18n.locale = 'en'
    } else {
      i18n.locale = 'th'
    }
  } else {
    // 兼容处理 防止在h5页调试的时候 页面会报错
    Vue.$DeviceInfo = {
      androidUuid: 'AndroidUuid',
      appChannel: 'AppChannel',
      appVersion: 'AppVersion'
    }
    Vue.prototype.$DeviceInfo = {
      androidUuid: 'AndroidUuid',
      appChannel: 'AppChannel',
      appVersion: 'AppVersion'
    }
  }
  /* eslint-disable no-new */
  window.vue = new Vue({
    el: '#app',
    router,
    store,
    i18n,
    components: { App },
    template: '<App/>'
  })
}
let source = ''
if (isAndroid) {
  source = 'ANDROID'
} else if (isIOS) {
  source = 'IOS'
}

Vue.$ClientInfo = {
  lang: 'UTF-8',
  source
}
Vue.prototype.$ClientInfo = {
  lang: 'UTF-8',
  source
}

console.log('ua:', navigator.userAgent)
Vue.mixin({
})


Vue.$SDK = SDK
Vue.prototype.$SDK = SDK
Vue.$utils = utils
Vue.prototype.$utils = utils

Vue.filter('fixStars', val => `****** ${val}`)
Vue.filter('tofloat', (value = 0) => utils.returnFloat2(value))
Vue.filter('thousandBitSeparator', (value = 0) => utils.thousandBitSeparator(value))

Vue.config.errorHandler = (err, vm, info) => {
  console.log(err, err)
  console.log(err, vm)
  console.log(err, info)
  Vue.$toast({
    message: err,
    position: 'middle',
    duration: 5000
  })
  SDK.sendEx({
    tag: `---Vue捕捉到错误--- ${Date.now()}`,
    ex: `err:${err}, info: ${info}`
  })
}
window.onerror = function a(message) {
  console.log('捕捉到错误：', message)
  SDK.sendEx({
    tag: `---window捕捉到错误--- ${Date.now()}`,
    ex: `message:${message}`
  })
}
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0);
})

initAppData()
