const enumCurrency = {
  THB: 'THB'
}
// 收银台 支付场景 一级支付方式 （不要轻易修改，此处非普通展示字符串,此处收银台展示列表逻辑用到了）
const enumPayMethodCodeFirst = {
  ODD: 'ODD', // 银行账户支付
  BALA: 'BALA', // 余额支付
  CCP: 'CCP', // 信用卡支付
  OFLN: 'OFLN', // 便利店支付
  DELI: 'DELI' // DeepLink支付
}

// 收银台 支付场景 二级支付方式
const enumPayMethodCodeSecond = {
  KBANK: 'KBANK',
  BBL: 'BBL',
  Visa: 'Visa',
  MasterCard: 'MasterCard',
  JCB: 'JCB',
  UnionPay: 'UnionPay',
  CENPAY: 'CENPAY',
  SPECIAL: 'SPECIAL'
}

const ENUM_ERRORCODE = {
  // 余额业务系统相关错误码
  SYSTEM_ERROR: 'TWL9900001',
  NO_KYC: 'TWA4400005',
  HAS_NULL_REQUEST_PARAMS: 'TWL1100001',
  ERR_REQUEST_PARAMS: 'TWL1100002',
  NO_BANK_ACCOUNT: 'TWA4400006',
  ERR_FEE: 'TWA4400007',
  PASS_BALANCE: 'TWA4400006',
  NOT_LOGIN: 'uc_sys_NO_LOGIN',
  CUSTOMER_NO_EXIT: 'TWA4400103',
  NOT_VERIFIED: 'TWA4400005',
  // 收银台相关错误码
  CASHIER_NOT_LOGIN: 'CSR3300001',
  RPC_NETWORK_TIMEOUT: 'CSR2200011',
  CASHIER_BALANCE_LACK: 'CSR4400005' // 收银台余额支付方式余额不足
}
const TRANSFER_TYPE = {
  SCAN: '32', // 收款码
  NORMAL: '31',
  REQUESR2PAY: '33'
}

// 转账渠道(transferChannel)
const TRANSFER_CHANNELS = {
  ONT_FIN: 1,
  BANK_ACOUNT: 2,
  PROMPTPAY: 3
}
// 充值提现转账业务场景
const BUSI_SCENARIOS = {
  TOPUP: '1',
  WITHDRAW: '2',
  TRANSFER: '31',
  P2P: '32', // 收款码
  REQUESR2PAY: '33', // request to pay（AA收款）
  PROMPTPAY: '34' // promptpay码（转到prompt）
}

// 收银台场景标题枚举, 此处的英文文案是 国际化的文案key
const CASHIER_SENSE = {
  WLT_CHARGE: 'topup', // 余额充值
  WLT_TRANSFER_BLE: 'transfer', // 转账到余额
  WLT_TRANSFER_BCD: 'transfer', // 转账到银行卡
  WLT_TRANSFER_BLE_SCAN: 'transfer', // 转账到余额(主扫)
  WLT_TRANSFER_PRO_CREDIT: 'transfer', // 转账到PromptPay(输入, tag29)
  WLT_TRANSFER_PRO_CREDIT_SCAN: 'transfer', // 转账到PromptPay(主扫, tag29)
  WLT_TRANSFER_PRO_BILL_SCAN: 'transfer', // 转账到PromptPay(主扫, tag29)
  WLT_WITHDRAW: 'Withdraw', // 余额提现
  WLT_REQTOPAY: 'Share Bill', // AA付款
  QRC_NEG_PAYMENT: 'payment', // 被扫付款
  APP_PAY_VIRTUAL_GOODS: 'payment' // gateway
}
// 收银台支付方式文案编码映射

// 收银台场景标题枚举, 此处的英文文案是 国际化的文案key
const CASHIER_PAYMENT_METHODS = {
  BALA: 'WalletBalance',
  'ODD.KBANK': 'KBankAccount',
  'ODD.SCB': 'SCBBankAccount',
  'ODD.BAY': 'BAYBankAccount',
  ODD: 'ODD', // 异常情况 没有返回二级支付方式的情况
  CCP: 'creditCard', // 异常情况 没有返回二级支付方式的情况
  'ODD.BBL': 'BBLbankaccount',
  'CCP.SPECIAL': 'creditCard',
  'CCP.Visa': 'creditCard',
  'CCP.MasterCard': 'creditCard',
  'CCP.JCB': 'creditCard',
  'CCP.UnionPay': 'creditCard',
  'OFLN.CENPAY': 'TopUpAtCenpayCounter',
  'DELI.KBANK': 'K Plus Apps',
  'DELI.BBL': 'BBL'
}

// 收银台加验类型
const CASHIER_CHECKTYPE = {
  PIN: 'C000001',
  PIN_OTP: 'C000009',
  '3DS': 'C000011'
}

// 目前介入需要过收银台的业务场景 （由前端内部定义）
const ALL_BUSI_TYPE = {
  TOPUP: 'TOPUP',
  TRANSFER_BANKACCOUNT: 'TRANSFER_BANKACCOUNT',
  TRANSFER_TH1: 'TRANSFER_TH1',
  TRANSFER_PROMOPY: 'TRANSFER_PROMOPY',
  P2P: 'P2P',
  SCANDED: 'SCANDED',
  BIND_AND_PAY: 'BIND_AND_PAY',
  APP_PAY_VIRTUAL_GOODS: 'APP_PAY_VIRTUAL_GOODS' // gateway支付
}

// 收银台支付状态
const CASHIER_TRANSATION_STATUS = {
  INIT: 'INIT',
  PEND: 'PEND',
  SUCC: 'SUCC',
  CLOSE: 'CLOSE'
}

export {
  enumPayMethodCodeFirst,
  enumCurrency,
  ENUM_ERRORCODE,
  TRANSFER_TYPE,
  BUSI_SCENARIOS,
  CASHIER_SENSE,
  TRANSFER_CHANNELS,
  CASHIER_PAYMENT_METHODS,
  CASHIER_CHECKTYPE,
  enumPayMethodCodeSecond,
  ALL_BUSI_TYPE,
  CASHIER_TRANSATION_STATUS
}
