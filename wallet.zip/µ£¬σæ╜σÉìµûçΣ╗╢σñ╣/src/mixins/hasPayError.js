import { ENUM_ERRORCODE } from '@/utils/const'

/**
 * topup && transferthe1 && request to pay的一些公用方法
 */
export default {
  methods: {
    async hasPayError(res) {
      if (res.data.errorData.code === ENUM_ERRORCODE.NOT_LOGIN || res.data.errorData.code === ENUM_ERRORCODE.NO_KYC || res.data.errorData.code === ENUM_ERRORCODE.CASHIER_NOT_LOGIN) {
        const ret = await this.$SDK.goNativeAction(res.data.actionData)
        console.log(ret)
      } else {
        const ErrorCodeObj = {
          'TWA4400015':this.$t('TWA4400015'),
            'TWL9900001':this.$t('TWL9900001'),
            'TWL1100004':this.$t('TWL1100004'),
            'TWA4400012':this.$t('TWA4400012'),
            'TWA4400116':this.$t('TWA4400116'),
            'TWA4400010':this.$t('TWA4400010'), 
            'TWA4400008':this.$t('TWA4400008'),
            'TWA4400009':this.$t('TWA4400009'), 
            'TWA4400126':this.$t('TWA4400126'),
            'TWL1100013':this.$t('TWL1100013'), 
            'TWA4400106':this.$t('TWA4400106'),
            'TWA4400101':this.$t('TWA4400101'),
            'TWA4400005':this.$t('TWA4400005'),
            'TWA4400011':this.$t('TWA4400011'), 
            'TWA4400013':this.$t('TWA4400013'),
            'TWA5500000':this.$t('TWA5500000'),
            'TWA4400108':this.$t('TWA4400108'),
            'TWL1100012':this.$t('TWL1100012'),
            'TWL1100003':this.$t('TWL1100003'),
            'TRA1100006':this.$t('TRA1100006'),
            'TWA4400109':this.$t('TWA4400109'),
            'TWA4400110':this.$t('TWA4400110'),
            'TWA4400112':this.$t('TWA4400112'),
            // errorCode结束
        }
        const errorMsg = ErrorCodeObj[res.data.errorData.code] || this.$t('TWL9900001')
        this.$toast({
          message: errorMsg,
          position: 'middle',
          duration: 3000
        })
      }
    }
  }
}
