import toast from '@/pages/balance/common/dialog'
export default {
  components: {toast},
  data() {
    return {
      showDialog: false,
      actionData: {
        "type": "native",
        "address": "/kyc/main",
        "params": {
          "businessName": "PAYMENT"
        }
      }
    }
  },
  methods:{
     // 没kyc认证的处理
    async closeDialog() {
      this.showDialog = false
      await this.$SDK.goNativeAction(this.actionData)
      this.initData()
    },
    cancle() {
      this.showDialog = false
      if (this.channelType == 'transfer') {
        this.$router.go(-1)
      } else {
        this.$SDK.closeWebView();
      }
    }
  }
}
