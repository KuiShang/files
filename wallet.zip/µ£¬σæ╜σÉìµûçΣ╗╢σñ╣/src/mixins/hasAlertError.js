import { ENUM_ERRORCODE } from '@/utils/const'

/**
 * request to pay的一些公用方法
 */
export default {
  methods: {
    async hasAlertError(res) {
      if (res.data.errorData.code === ENUM_ERRORCODE.NOT_LOGIN || res.data.errorData.code === ENUM_ERRORCODE.NO_KYC
        || res.data.errorData.code === ENUM_ERRORCODE.CASHIER_NOT_LOGIN) {
        const ret = await this.$SDK.goNativeAction(res.data.actionData);
        console.log(ret);
      } else {
        const ErrorCodeObj = {
          'TWL9900001': this.$t('TWL9900001'),
          'RTP999': this.$t('TWL9900001'),

          'RTP004': this.$t('somethingWentWrong'),
          'RTP005': this.$t('somethingWentWrong'),
          'RTP006': this.$t('somethingWentWrong'),
          'RTO007': this.$t('UnableToProceed'),
          'RTO008': this.$t('somethingWentWrong'),
          'RTP0009': this.$t('dailyLimit'),
          'RTP102': this.$t('accountCannotUse'),
          'RTP103': this.$t('ReceiverWallet'),
        };
        //const errorMsg = ErrorCodeObj[res.data.errorData.code] || this.$t('TWL9900001')
        const errorMsg = ErrorCodeObj[res.data.errorData.code] || res.data.errorData.msg;
        this.$messagebox({
          title: '',
          message: errorMsg,
          confirmButtonText: this.$t('OK')
        })
      }
    }
  }
}
