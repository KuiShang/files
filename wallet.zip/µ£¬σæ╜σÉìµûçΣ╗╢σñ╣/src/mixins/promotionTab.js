import { mapGetters, mapMutations } from 'vuex';
import { appConfigH5 } from '@/api';
// 标准组件
import PromotionTop from '@/pages/promotionTab/components/promotionTabTop';
import PromotionBottom from '@/pages/promotionTab/components/promotionTabBottom';
import ItemList2 from '@/pages/promotionTab/components/listItemWrapper';
import ImgWrapper from '@/pages/promotionTab/components/base/imgWrapper';
import ContentWrapper from '@/pages/promotionTab/components/base/content';
import ButtonWrapper from '@/pages/promotionTab/components/base/buttonWrapper';
import Thumbnail from '@/pages/promotionTab/components/base/thumbnail/thumbnail';
import SliderWrapper from '@/pages/promotionTab/components/sliderWrapper';
import TheOneInfo from '@/pages/promotionTab/components/the1Info/the1Info';
import CouponList from '@/pages/promotionTab/components/couponList';
import CouponGroup from '@/pages/promotionTab/components/couponGroup';
import BannerList from '@/pages/promotionTab/components/bannerList';
import PictureBanner from '@/pages/promotionTab/components/base/pictureBanner';
import handlInitData from '@/mixins/handlInitData';

// see all组件
import Scroll from '@/pages/promotionTab/components/base/scroll';
import TaskListAll from '@/pages/promotionTab/components/taskListAll';
import AllCoupon from '@/pages/promotionTab/components/allCoupon';


// 埋点util
import { PROMOTION_ENTER, PROMOTION_LEAVE } from '@/pages/burry/promo.js';

export default {
  mixins: [handlInitData],
  components: {
    PromotionTop,
    PromotionBottom,
    ImgWrapper,
    ContentWrapper,
    ButtonWrapper,
    Thumbnail,
    SliderWrapper,
    ItemList2,
    TheOneInfo,
    CouponList,
    CouponGroup,
    BannerList,
    Scroll,
    TaskListAll,
    AllCoupon,
    PictureBanner
  },
  data() {
    return {
      thumbnailStyle: {
        wrapper: {
          height: '6.08rem'
        },
        img: {
          width: '1rem',
          height: '1rem',
          left: '0.4rem',
          bottom: '0.38rem'
        },
        content: {
          'padding-left': '1.62rem',
          'padding-top': '0.08rem',
          'padding-right': '0.4rem',
          height: '1rem',
          'font-size': '0.36rem',
          'line-height': '0.6rem'
        }
      },
      resultData: {},
      scence: 0,
      titleRightMsg: {
        show: 1,
        textSize: 14,
        textColor: '#4F577C'
      },
      resolveData: {},
      completePullUpDate: true,
      hasNewData: true,
      seeAllList: [],
      params: {},
      currentPage: 0,
      tracePoint: '',
      isSetTrace: false,
      total: 0,
      currentAmount: 0
    }
  },
  created() {
    this.initData();
    this.$SDK.onBackPress(() => {
      if (this.tracePoint && this.isSetTrace) {
        PROMOTION_LEAVE(this.tracePoint);
        this.isSetTrace = !this.isSetTrace;
      }
      this.$SDK.closeWebView();
    });
    this.$SDK.onBackground(() => {
      if (this.tracePoint && this.isSetTrace) {
        PROMOTION_LEAVE(this.tracePoint);
        this.isSetTrace = !this.isSetTrace;
      }
    })
     this.$SDK.onForeground(() => {
      if (this.tracePoint && !this.isSetTrace) {
        PROMOTION_ENTER(this.tracePoint);
        this.isSetTrace = !this.isSetTrace;
      }
    });
  },
  beforeRouteLeave (to, from, next) {
    if (this.currentPage === 0) {
      this.$indicator.close();
    }
    next()
  },
  methods: {
    // 上拉加载组件
    async completeFn() {
      console.log(this.currentPage);
      this.completePullUpDate = false;
      if (this.currentAmount >= this.total) {
        this.completePullUpDate = true;
        this.hasNewData = false;
        this.$refs.scroll.scroll.closePullUp();
      } else {
        this.currentPage++;
        await this.initData();
        this.completePullUpDate = true;
      }
      this.$nextTick(() => {
        this.$refs.scroll.refresh();
      })
    },
    async initData() {
      this.params = {
        useLanguage: this.language,
        pageId: 33, // 35/48
        scence: 0,
        // customerId: '0066002000017307',
        currentPage: this.currentPage
      };
      this.params = Object.assign(this.params, this.$route.query);
      console.log(this.params);
      if (this.currentPage === 0) {
        this.$indicator.open({
          text: 'Loading...',
          spinnerType: 'fading-circle'
        })
      }
      const res = await appConfigH5(this.params);
      // 判断是否拉起登陆
      if (!(res && res.data && res.data.resultData) || !(res && res.data && res.data.resultData.loginStatus) && !(res && res.data && res.data.resultData.loginDowngrade)) {
        this.handlInitData(res);
        this.resolveData = this.dataObj;
      } else {
        this.resolveData = res.data.resultData;
      }
      if (this.currentPage === 0) {
        this.$indicator.close();
      }
      if (!this.resolveData || this.resolveData.length === 0) {
        return;
      }
      // scence决定页面展示类型 0:标准组件页面 1:see all页面
      this.scence = this.resolveData.scence;
      let resultData = this.resolveData.h5PageConfigContainer;
      console.log(1111111);
      console.log(resultData);
      console.log(1111111);
      if (!resultData || JSON.stringify(resultData) === '{}') {
        return;
      }
      this.tracePoint = resultData.tracePoint;
      this.setPromotionTracePoint(this.tracePoint);
      this.setPromotionPageId(resultData.pageId);
      if (this.tracePoint && !this.isSetTrace) {
        PROMOTION_ENTER(this.tracePoint);
        this.isSetTrace = !this.isSetTrace;
      }
      // 调用app方法设置顶部title 和 右侧图标或文案
      if (this.$utils.getSysType('isJdApp')) {
        this.$SDK.setTitle({
          title: resultData.pageTitle && resultData.pageTitle !== '{}' ?
            JSON.parse(resultData.pageTitle)[this.language] : '',
          mHeaderTitle: {
            showHead: 1,
            showBack: 1,
            showEnd: 0
          }
        })
        if (resultData.subTitleType) {
          if (resultData.subTitleType === 1) {
            this.titleRightMsg.text = resultData.subTitle && resultData.subTitle !== '{}' ?
              JSON.parse(resultData.subTitle)[this.language] : '';
          } else {
            this.titleRightMsg.iconUrl = resultData.titlePicUrl && resultData.titlePicUrl !== '{}' ?
              JSON.parse(resultData.titlePicUrl)[this.language] : '';
          }
          this.$SDK.setTitleRight(this.titleRightMsg, () => {
            if (resultData.hasJump) {
              const json = this.$utils.setJumpUrl(resultData);
              this.$SDK.goNativeAction(json);
            }
          })
        }
      }

      if (resultData && resultData.pageComponentContainers) {
        this.resultData = resultData.pageComponentContainers;
      }
      if (!this.resultData || this.resultData.length === 0) {
        return;
      }
      // 如果当前为分页加载页面
      if (this.scence) {
        this.seeAllList = this.seeAllList.concat(this.resultData[0].componentInfos);
        this.total = this.resultData[0].total;
        this.currentAmount = this.currentAmount + this.resultData[0].componentInfos.length;
      }
      console.log('currentAmount', this.currentAmount);
      console.log(this.resultData);
    },
    ...mapMutations({
      setPromotionTracePoint: 'SET_PROMOTION_TRACE_POINT',
      setPromotionPageId: 'SET_PROMOTION_PAGE_ID'
    })
  },
  computed: {
    ...mapGetters(['language'])
  }
};