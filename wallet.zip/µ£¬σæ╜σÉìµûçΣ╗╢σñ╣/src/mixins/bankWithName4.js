/**
 *  結果頁 取銀行卡名稱 加 卡號后四位
 */
import { enumPayMethodCodeFirst, CASHIER_PAYMENT_METHODS } from '@/utils/const'

export default {
  computed: {
    bankWithName() {
      // 如果状态为1 为处理中 接口无法获取支付方式
      if (this.dataObj.status === 1) {
        return ''
      }
      if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.ODD) {
        const last4Num = this.dataObj.bankAccount.slice(-4)
        // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
        return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])} (${last4Num})`
      } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.BALA) {
        // return this.dataObj.payMethodCodeFirst
        // return 'Balance'
        return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
      } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.OFLN) {
        return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
      } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.CCP) {
        const last4Num = this.dataObj.bankAccount.slice(-4)
        // return `${this.dataObj.payMethodCodeSecond} (${last4Num})`
        return `${this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])} (${last4Num})`
      } else if (this.dataObj.paymentMethod1 === enumPayMethodCodeFirst.DELI) {
        return this.$t(CASHIER_PAYMENT_METHODS[this.dataObj.displayName])
      }
      return ''
    }
  }
}

