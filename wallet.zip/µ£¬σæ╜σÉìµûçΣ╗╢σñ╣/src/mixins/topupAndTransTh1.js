const LIMIT_TYPE = {
  TIMES: 'TIMES',
  DAY: 'DAY'
}
/**
 * topup && transferthe1的一些公用方法
 */
export default {
  data() {
    return {
      LIMIT_TYPE,
      timeLimitAmount: 0,
      timeLowerAmount: 0,
      dayLimitAmount: 0,
      availableAmount: '',
      currentLimitType: ''
    }
  },
  methods: {
    /**
     * 计算 当前的限制类型是每日 还是每次，存储每日&每次的限额
     */
    computedCurrentLimitType() {
      const dayLimitAmount = (Number(this._Subtr(this.dataObj[0].dayAmountUpper, this.dataObj[0].totalAmount) || '0.00'))
      const timeLimitAmount = (Number(this.dataObj[0].onceAmountUpper || '0.00'))
      const timeLowerAmount = (Number(this.dataObj[0].onceAmountLower || '0.00'))
      const availableAmount = (Number(this.dataObj[0].availableAmount || '0.00'))
      this.dayLimitAmount = dayLimitAmount
      this.timeLimitAmount = timeLimitAmount
      this.timeLowerAmount = timeLowerAmount
      this.availableAmount = availableAmount
      if (dayLimitAmount < timeLimitAmount) {
        this.currentLimitType = LIMIT_TYPE.DAY
      } else {
        this.currentLimitType = LIMIT_TYPE.TIMES
      }
    },
    //减法 解决精度问题 0.1+ 0.2     100000-75110.71
    _Subtr(arg1,arg2){ 
      var r1,r2,m,n; 
      try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0} 
      try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0} 
      m=Math.pow(10,Math.max(r1,r2)); 
      n=(r1>=r2)?r1:r2; 
      return ((arg1*m-arg2*m)/m).toFixed(n); 
    }
  }
}
