import { ENUM_ERRORCODE } from '@/utils/const'
/*
 * 公用的对初始化方法返回值处理校验的方法，
 * 包括 返回结果为 未登录，跳转到登录
 * 其他报错 暂时用 弹窗提示
 * 注意 默认组件 组件必须声明有 [initData] 方法，且是组件的初始化方法
 */

 function handlInitDataDefaultErrorMethod (res, vue) {
    const ErrorCodeObj = {
      'TWA4400015':vue.$t('TWA4400015'),
      'TWL9900001':vue.$t('TWL9900001'),
      'TWL1100004':vue.$t('TWL1100004'),
      'TWA4400012':vue.$t('TWA4400012'),
      'TWA4400116':vue.$t('TWA4400116'),
      'TWA4400010':vue.$t('TWA4400010'), 
      'TWA4400008':vue.$t('TWA4400008'),
      'TWA4400009':vue.$t('TWA4400009'), 
      'TWA4400126':vue.$t('TWA4400126'),
      'TWL1100013':vue.$t('TWL1100013'), 
      'TWA4400106':vue.$t('TWA4400106'),
      'TWA4400101':vue.$t('TWA4400101'),
      'TWA4400005':vue.$t('TWA4400005'),
      'TWA4400011':vue.$t('TWA4400011'), 
      'TWA4400013':vue.$t('TWA4400013'),
      'TWA5500000':vue.$t('TWA5500000'),
      'TWA4400108':vue.$t('TWA4400108'),
      'TWL1100012':vue.$t('TWL1100012'),
      'TWL1100003':vue.$t('TWL1100003'),
      'TRA1100006':vue.$t('TRA1100006'),
      'TWA4400109':vue.$t('TWA4400109'),
      'TWA4400110':vue.$t('TWA4400110'),
      'TWA4400112':vue.$t('TWA4400112'),
    }
    const errorMsg = ErrorCodeObj[res.data.errorData.code] || vue.$t('TWL9900001')
    vue.$toast({
      message: errorMsg,
      position: 'middle',
      duration: 3000
    })
 }
export default {
  data() {
    return {
      dataObj: [],
      repeatInit: true
    }
  },
  methods: {
    async handlInitData(res, successFn = () => {}, errFn) {
      if (res && res.data && res.data.resultCode === 1) {
        this.dataObj = res.data.resultData
        successFn()
      } else if (res && res.data && res.data.resultCode === 0) {
        if (res.data.errorData.code === ENUM_ERRORCODE.NOT_LOGIN || res.data.errorData.code === ENUM_ERRORCODE.CASHIER_NOT_LOGIN) {
          // ENUM_ERRORCODE.NO_KYC 产品要求放kyc认证在每个转账方式里面
          const ret = await this.$SDK.goNativeAction(res.data.actionData)
          console.log('登录后结果ret', ret)
          // repeatInit: 是否需要重新拉取数据，默认需要
          if (ret.status === 1 && this.repeatInit) {
            this.hasInitData()
          } else {
            this.$SDK.closeWebView()
          }
        } else if (errFn) {
          errFn(handlInitDataDefaultErrorMethod)
        } else {
          handlInitDataDefaultErrorMethod(res, this)
        }
      }
    },
    hasInitData() {
      if (this.initData) {
        this.initData()
      } else {
        console.error('组件必须声明有 [initData] 方法，且是组件的初始化方法')
      }
    }
  }
}
