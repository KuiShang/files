// 是否使用客户端request开关，  默认为true true:表示使用客户端发送请求    false：表示使用h5请求
export const safeFlag = true
// 本地数据模拟server 开关  false true:表示使用本地数据模拟    false：表示bu使用本地数据模拟
export const mockFlag = false
