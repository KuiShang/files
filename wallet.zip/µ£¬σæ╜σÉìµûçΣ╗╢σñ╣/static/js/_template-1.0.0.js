/*eslint-disable*/
!function(){if("undefined"==typeof window.platform){window.platform={invoke:function(e,n,i){jsBridge&&jsBridge.invoke("platform",e,n,i)},on:function(e,n,i){jsBridge&&jsBridge.on("platform",e,n,i)},env:function(e){jsBridge&&jsBridge.env("platform",e)}};var e=document.createEvent("HTMLEvents");e.initEvent("platformReady",!1,!1);document.dispatchEvent(e)}}();

 console.log('temp injs');
