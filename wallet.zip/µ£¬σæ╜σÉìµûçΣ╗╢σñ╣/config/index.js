'use strict'
// Template version: 1.3.1
// see http://vuejs-templates.github.io/webpack for documentation.

const path = require('path')
console.log('process NODE_ENV:', process.env.NODE_ENV)
function getProxyTable() {
  if (process.env.NODE_ENV === 'local') {
    return {
      '/invitation': {
        target: 'http://10.222.114.227:8080',
        changeOrigin: true
      },
      '/scallop': {
        target: 'http://10.222.114.227:8082',
        changeOrigin: true
      },
      '/th/wallet': {
        target: 'http://172.24.8.102:8080',
        changeOrigin: true
      },
      '/th/cashier': {
        // target: 'http://cashierserver.cjdfintech.com',
        target: 'http://172.25.52.189:8080',
        changeOrigin: true
      },
      '/th/trade_center': {
        target: 'http://10.13.49.65:8081/wallet',
        changeOrigin: true
      },
      '/th/app_config': {
        target: 'http://172.24.8.102:80',
        changeOrigin: true
      },
      '/th/promo': {
        target: 'http://172.25.49.159:8080',
        changeOrigin: true
      },
      '/of-trade-promo-finish': {
        target: 'http://10.13.92.139:8080',
        changeOrigin: true
      },
      '/th/coupon': {
        // target: 'http://th-coupon.cjdfintech.com:8080',
        target: 'http://10.222.10.227:80',
        changeOrigin: true
      },
      '/th/RequestToPay': {
        target: 'http://172.24.8.94:80',
        changeOrigin: true
      },
      '/open_api/wallet_payment': {
        target: 'http://10.13.144.242:8082',
        changeOrigin: true
      },
      '/wallet-invite': {
        target: 'http://wallet-invite-gateway.jd.co.th:8080',
        changeOrigin: true
      },
      '/setting/queryOrderDetail': {
        target: 'http://172.24.8.100:80',
        changeOrigin: true
      }
    }
  } else  {
    return {
      '/th/wallet': {
        target: 'http://172.24.8.102:8080',
        changeOrigin: true
      },
      '/th/cashier': {
        // target: 'http://cashierserver.cjdfintech.com:8080',
        target: 'http://172.25.52.189:8080',
        changeOrigin: true
      },
      '/th/trade_center': {
        target: 'http://appservice.cjdfintech.com',
        changeOrigin: true
      },
      '/th/app_config': {
        target: 'http://172.24.8.102:80',
        // target: 'http://10.13.145.106:8080',
        changeOrigin: true
      },
      '/th/promo': {
        target: 'http://172.25.49.159:8080',
        changeOrigin: true
      },
      '/of-trade-promo-finish': {
        target: 'http://10.13.92.139:8080',
        changeOrigin: true
      },
      '/t1p': {
        // target: 'http://10.13.144.215:9080',
        // target: 'http://172.25.49.159:8080',
        target: 'http://172.25.49.159:80',
        changeOrigin: true
      },
      '/th/coupon': {
        target: 'http://10.222.10.227:80',
        // target: 'http://10.13.145.162:8080',
        changeOrigin: true
      },
      '/th/RequestToPay': {
        target: 'http://172.24.8.94:80',
        changeOrigin: true
      },
      '/open_api/wallet_payment': {
        target: 'http://10.13.144.242:8082',
        changeOrigin: true
      },
      '/invitation': {
        target: 'http://10.222.114.227:8080',
        changeOrigin: true
      },

      '/setting/queryOrderDetail':  {
        target: 'http://172.24.8.100:80',
        changeOrigin: true
      },
      '/scallop': {
        target: 'http://10.222.114.227:8082',
        changeOrigin: true
      },
    }
  }
}
console.log('ProxyTable:', getProxyTable())
module.exports = {
  dev: {
    // Paths
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: getProxyTable(),

    // Various Dev Server settings
    host: 'localhost', // can be overwritten by process.env.HOST
    port: 8080, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
    autoOpenBrowser: true,
    errorOverlay: true,
    notifyOnErrors: true,
    poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

    // Use Eslint Loader?
    // If true, your code will be linted during bundling and
    // linting errors and warnings will be shown in the console.
    useEslint: true,
    // If true, eslint errors and warnings will also be shown in the error overlay
    // in the browser.
    showEslintErrorsInOverlay: true,

    /**
     * Source Maps
     */

    // https://webpack.js.org/configuration/devtool/#development
    devtool: 'cheap-module-eval-source-map',

    // If you have problems debugging vue-files in devtools,
    // set this to false - it *may* help
    // https://vue-loader.vuejs.org/en/options.html#cachebusting
    cacheBusting: true,

    cssSourceMap: true
  },

  build: {
    // Template for index.html
    index: path.resolve(__dirname, '../dist/index.html'),

    // Paths
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',

    /**
     * Source Maps
     */

    productionSourceMap: false,
    // https://webpack.js.org/configuration/devtool/#production
    devtool: '#source-map',

    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],

    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report
  }
}
