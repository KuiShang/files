th_wallet
====
泰国钱包
======================
协议
1. The 1 绑定协议初稿（终稿在审定中）-Terms. For linking The 1 card   -  路由地址： /protocol/tcBind
2. The 1注册协议-TC The 1 registration -  路由地址： /protocol/tcRegistion
3. 钱包用户注册使用协议-terms and conditions of the service -  路由地址： /protocol/termService
4. privacy  路由地址：/protocol/privacy
5. Terms and conditions of the service & Privacy policy (过检前 紧急加的 搜否还需要？？)路由地址： /userProtocol
========
2019-08-08

新增安卓和ios的配置文件给native使用 kbank调试时用 的
