vb_fe_app
========================== 2019.8.23 start ==========================
重点： i18n文件命名规则：以UI设计图页面标号，从上到下，从左到右
1. 增加国际化文案 debug
项目添加步骤
1). sdk-platform.js 增加
  /**
    * 获取debug-i18n环境
    */
  getDevSettings: function(callback) {
    tools.invoke('platform', 'getDevSettings', {}, callback);
  }
2). wrapper.js 增加
  /**
  * 获取当前环境
  */
  export function getDevSettings(cb) {
    if (!isJDAPP) {
      return false
    }
    return window.wallet.platform.getDevSettings(cb);
  }
3. 入口文件增加
// ********* 设置环境变量 *********
// 获取当前Native的环境

isJDAPP && SDK.getDevSettings(function(nativeEnv) {
  if (nativeEnv.code == 1) {
    if (nativeEnv.data.language_debug) {
      window.language_debug = nativeEnv.data.language_debug;
      window.localeLanguage = 'debug-i18n';
    } else {
      getAppLang();
    }
  } else {
    getAppLang();
  }
});
4. 在国际化文件夹新增i18文件。 debug_i18n.js
5. 入口文件引入debug_i18n.js 并初始化loadLocales 服务时增  "debug-i18n": debugI18n 映射
========================== 2019.8.23 end ==========================
