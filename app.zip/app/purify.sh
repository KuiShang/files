#!/bin/bash
# Author: chaos

file_name="";
while getopts ":p:" opt
do
    case $opt in
        p)
        file_name=$OPTARG
        ;;
        ?)
        echo "Error parameter"
        echo "Usage:   -p [name]"
        exit 1;;
    esac
done

if [ ! -n "$file_name" ]; then 
    echo 'Error parameter';
    echo "Usage:   -p [name]"
    exit
fi

echo "Start to purify folders ****************";

echo "Removing the .DS_Store files ****************"
find ./build -name ".DS_Store*" -depth -exec rm {} \;

echo "Copying files to destination folder ****************"
cp -R build $file_name

echo "Compressing folder ****************"
zip -r -m $file_name.zip $file_name

echo "Removing the __MACOSX folder ****************"
zip -d $file_name.zip __MACOSX/\*

echo "Done ****************"
