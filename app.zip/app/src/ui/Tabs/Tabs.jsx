import React from 'react'
import classnames from 'classnames';
import PropTypes from 'prop-types'
import './style.scss'
class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentIdx : 0,
      lineStyle: {}
    };
    this.handleTabClick = this.handleTabClick.bind(this);
  }
  static defaultProps = {
    initialPage: 0
  }
  componentDidMount() {
    const { initialPage } = this.props
    if (initialPage) {
      this.setState({
        currentIdx: initialPage
      }, () => {
        this.setLine()
      })
    }
    this.setLine()
  }
   // update nav bar style
  setLine() {
    const currentTab = this.tabs[this.state.currentIdx]
    const width = currentTab.offsetWidth
    const left = currentTab.offsetLeft

    const lineStyle = {
      width: `${width}px`,
      transform: `translateX(${left}px)`
    };
    this.setState({
      lineStyle
    })
  }
  handleTabClick(idx, e) {
    this.setState({
      currentIdx: idx
    }, () => {
      const { onTabClick } = this.props;
      this.setLine()
      onTabClick && onTabClick(idx, e);
    })
  }
  render() {
    this.tabs = [];
    const {
      tabs,
      children
    } = this.props
    return (
      <div className="v-tabs">
        <div className="v-tabs-tab-bar-wrap" ref={this.tabWraper}>
          {
            tabs.map((item, idx) => 
              <div role="tab"
                className={classnames("am-tabs-default-bar-tab", {'am-tabs-default-bar-tab-active' : idx === this.state.currentIdx})}
                key={item.title}
                onClick={(e) => this.handleTabClick(idx, e)}
                ref={(tab) => tab && this.tabs.push(tab)}
              >
                {item.title}
              </div>
            )
          }
          <div className="am-tabs-default-bar-underline" style={this.state.lineStyle}></div>
        </div>
        <div className="am-tabs-content-wrap">
          {
            React.Children.toArray(children)[this.state.currentIdx]
          }
        </div>
      </div>
    )
  }

}

Tabs.propTypes = {
  tabs: PropTypes.array,
  onTabClick: PropTypes.func

}

export default Tabs