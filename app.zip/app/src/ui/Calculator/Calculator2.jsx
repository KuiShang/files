import React from 'react'

import './style.scss'

import Calc from './calcObj'

const bar = require('./img/Group@3x.png')
class Calculator extends React.Component {
    constructor(props) {
        super(props);
        this.canvasCals = React.createRef();
        // this.mybar = React.createRef();
    }
    state = {
        showWater: false
    }
    componentDidMount() {
        new Calc({
            el: this.canvasCals.current,
            data: this.props.data,
            // barSrc:  this.mybar.current,
            cb: this.props.cb
        })

    }

    render() {

        return (
            <div className='canvas-caculator-wraper'>

               <img id="mybar" className="mybar" src={bar} alt="" ref={this.mybar}  />

                <canvas id="mycals" className="mycals" width="324" height="200" ref={this.canvasCals} ></canvas>
            </div>
        )
    }

}


export default Calculator