import React from 'react'
import classnames from 'classnames';
import PropTypes from 'prop-types'
import echarts from 'echarts'
import './style.scss'
var handl = require('./Group@3x.png')
class Calculator extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        const myChart = echarts.init(document.getElementById('calculator'))
        var base = +new Date(2016, 9, 3);
        var oneDay = 24 * 3600 * 1000;
        var valueBase = Math.random() * 300;
        var valueBase2 = Math.random() * 50;
        var data = [];
        var data2 = [];
        var num = 0
        for (var i = 0; i < 10; i++) {
            var now = new Date(base += oneDay);
            var dayStr = [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('-');
            dayStr = num++
            valueBase = Math.round((Math.random() - 0.5) * 20 + valueBase);
            valueBase <= 0 && (valueBase = Math.random() * 300);
            valueBase = 3*num + 10
            data.push([dayStr, valueBase]);

            valueBase2 = Math.round((Math.random() - 0.5) * 20 + valueBase2);
            valueBase2 <= 0 && (valueBase2 = Math.random() * 50);
            valueBase2 = 2*num + 1
            data2.push([dayStr, valueBase2]);
        }
        console.info(data)
        console.info(data2)
        var option = {
            animation: true,
            tooltip: {
                alwaysShowContent: true,
                triggerOn: 'none',
                trigger: 'none',
                position: function (pt) {
                    return [pt[0], 130];
                },
                formatter(data) {
                    // console.info(data)
                    return '<p>Additional </p> <p>Interest Gained</p>'+ data[0].axisValueLabel
                },
                backgroundColor:' #2dc8d7'

            },
            xAxis: {
                type: 'value',
                // boundaryGap: [0, 0],
                offset: 30,
                axisPointer: {
                    value: '2',
                    snap: true,
                    lineStyle: {
                        color: '#004E52',
                        opacity: 0.5,
                        width: 2
                    },
                    label: {
                        show: false,
                        backgroundColor: '#004E52'
                    },
                    handle: {
                        show: true,
                        color: '#004E52',
                        margin: -30,
                        icon: `image://${handl}`,
                        size: ['44', '27']

                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                     type: 'dashed'
                    }
                }
            },
            yAxis: {
                show: false,
                type: 'value',
                axisTick: {
                    inside: true
                },
                splitLine: {
                    show: false
                },
                axisLabel: {
                    inside: true,
                    formatter: '{value}\n'
                },
                z: 10
            },
            grid: {
                top: 110,
                left: 15,
                right: 15,
                height: 160
            },
            dataZoom: [{
                type: 'inside',
                throttle: 50
            }],
            series: [
               
                {
                    name: 'Additional Interest Gained',
                    type: 'line',
                    smooth: true,
                    stack: 'a',
                    symbol: 'circle',
                    symbolSize: 5,
                    sampling: 'average',
                    itemStyle: {
                        normal: {
                            color: '#1dbdc4'
                        }
                    },
                    areaStyle: {
                        normal: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                offset: 0,
                                color: '#1dbdc4'
                            }, {
                                offset: 1,
                                color: '#fff'
                            }])
                        }
                    },
                    data: data
                },
                {
                    name: '模拟数据',
                    type: 'line',
                    smooth: true,
                    symbol: 'circle',
                    symbolSize: 5,
                    sampling: 'average',
                    itemStyle: {
                        normal: {
                            color: '#ccc',
                        },
                    },
                    lineStyle: {
                        type: 'dashed'
                    },
                    stack: 'a',
                    areaStyle: {
                        opacity: 0,
                    },
                    data: data2
                }

            ]
        };
        // 绘制图表
        myChart.setOption(option);
      setTimeout(() => {
        myChart.dispatchAction({
            type: 'showTip',
            // 系列的 index，在 tooltip 的 trigger 为 axis 的时候可选。
            x: 86,
            y: 150,
            position: [86, 130]
        })
      }, 1000);
    }
    render() {
        return (
            <div></div>
        )
    }

}


export default Calculator