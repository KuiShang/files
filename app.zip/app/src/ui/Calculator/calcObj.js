
import intl from 'utils/react-intl-universal';
const rate = 1

// 实际到 canvas 画布 宽度    
let realCanvasWidth


// 滑动bar宽度
let barWidth 

// 滑动bar 高度
let barHeight 

// 最大 canvas 宽度 相当于在 实际画布宽度 两侧各减去 bar的一半的宽度
let canvasWidth

// canvas 高度
let canvasHeight 


// 底部刻度 线条 高度
let bottomLineHeight 

// canvas 距离屏幕作边距
let canvasLeft

// canvas 距离屏幕作上边距
let canvastop


// 鼠标 按下时候的 x位置
let startPageX

// 鼠标 滑动的距离
let distX = 0

// 线条起始偏移的y坐标
let startlineY

// 当前滑动条位置的对应的金额对象信息
let currentMoneyObj = {}

// 是否允许滑动滑块
let moveReady = false

// 最后一次滑动滑块的滑块位置 第一次默认在中间位置, 不可直接赋值，只能通过下面 set get 方法来设置和获取
let lastTimeBarPosition 

var imgsc = require('./img/Group@3x.png')

var barSrc=new Image();

barSrc.src=imgsc;

function getLastTimeBarPosition() {
    // console.info(lastTimeBarPosition + distX )
    if (lastTimeBarPosition + distX < 0) {
        return 0
    }
    if (lastTimeBarPosition  + distX > canvasWidth) {
        return canvasWidth
    }
    return lastTimeBarPosition  + distX
}
function setLastTimeBarPosition(distX) {
    // debugger
    if (lastTimeBarPosition + distX < 0) {
        lastTimeBarPosition =  0
        distX = 0
    } else if (lastTimeBarPosition + distX > canvasWidth) {
        lastTimeBarPosition =  canvasWidth
        distX = 0
    } else {
        lastTimeBarPosition = lastTimeBarPosition + distX
    }

    // lastTimeBarPosition = lastTimeBarPosition + distX
    // console.info(lastTimeBarPosition)
    // console.info('-------')
    // console.info(getLastTimeBarPosition())
}

class Calc {
    constructor({
        el, // canvas对象
        data, // 初始化数据
        barSrc, // 滑动条的图片
        cb
    } = {}) {
        this.el = el;
        // this.barSrc = barSrc
        this.data = data
        this.cb = cb
        if (!el.getContext) return
        this.ctx = el.getContext("2d");
        realCanvasWidth = this.el.offsetWidth
       
        barWidth = realCanvasWidth * 44 / 324
        canvasLeft = ( this.el.offsetLeft + barWidth/2 ) 
        canvastop = this.el.offsetTop 

        canvasHeight = this.el.offsetHeight

       
        barHeight  = canvasHeight * 28 / 200

        canvasWidth = realCanvasWidth - barWidth/2 - barWidth/2
        canvasHeight = realCanvasWidth * 200/ 324
        bottomLineHeight = canvasHeight * 30 / 200
        startlineY = canvasHeight * 60 / 200
        lastTimeBarPosition =  canvasWidth / 2

        console.info('bottomLineHeight', bottomLineHeight)
        console.info('barHeight', barHeight)
        this.resetCoordinate()
        this.initDraw()
        this.initListener()

    }
    // 修改canvas默认坐标系 为啥数学直角坐标系 x轴线右边越来越大 y轴线上面越来越大
    resetCoordinate() {
        this.ctx.scale(1, -1);
        this.ctx.translate(barWidth/2, -canvasHeight);
    }
    initDraw() {
        // 初始化偏移bar的x轴线距离，为了 当滑动bar滑动到最左侧到时候 线条为最左侧，但是bar可以完整显示
        this.ctx.clearRect(-barWidth/2, 0, realCanvasWidth, canvasHeight)
        // console.info(lastTimeBarPosition)
        this.drawSplitLine()

        this.drawBottomLine()
        this.drawBlueLine()
        this.drawGrayLine()
        this.drawLinearGradient()
        this.computeMoney(getLastTimeBarPosition())
        this.drawVerticalLine(getLastTimeBarPosition())
        this.drawBar(getLastTimeBarPosition() - barWidth / 2)
        this.drawRect(getLastTimeBarPosition() )
        // this.drawBar(barStartPosition+ 20)

    }
    drawBottomLine() {
        this.ctx.save()

        this.ctx.beginPath()
        this.ctx.moveTo(0, bottomLineHeight)
        this.ctx.lineTo(canvasWidth, bottomLineHeight)
        this.ctx.strokeStyle = "#e6e7e8";
        this.ctx.lineWidth = 3
        this.ctx.stroke()

        this.ctx.restore()
    }
    //TODO: 需要根据服务端返回数组的数据以依次连结
    drawBlueLine() {
        this.ctx.save()

        this.ctx.beginPath()
        this.ctx.moveTo(0, startlineY)
        this.ctx.lineTo(canvasWidth, canvasHeight)
        this.ctx.strokeStyle = "#0bffd5";
        this.ctx.lineWidth = 2
        this.ctx.stroke()

        this.ctx.restore()

    }
    drawSplitLine() {
        this.ctx.save()
        // 存放刻度线的数组
        let scaleArr = this.data.list01.filter(item => item.scale_display_mark === 'Y')
        let unitLength = canvasWidth / (scaleArr.length - 1)

        this.ctx.beginPath()
        scaleArr.forEach((item, idx) => {
            if (idx === 0 || idx === scaleArr.length-1) {
                return
            }
            this.ctx.moveTo( idx * unitLength, bottomLineHeight + 10)
            this.ctx.lineTo(idx * unitLength, canvasHeight- 30)
            this.ctx.lineWidth = 1
            this.ctx.setLineDash([3]);
            this.ctx.strokeStyle = "#e6e7e8";
            this.ctx.stroke()
        })
        this.ctx.restore()
    }
    drawGrayLine() {
        this.ctx.save()

        this.ctx.beginPath()
        this.ctx.moveTo(0, startlineY)
        this.ctx.lineTo(canvasWidth, startlineY +10)
        this.ctx.strokeStyle = "#e6e7e8";
        this.ctx.lineWidth = 2
        this.ctx.setLineDash([5]);
        this.ctx.stroke()

        this.ctx.restore()
    }
    drawLinearGradient() {
        this.ctx.save()

        var lineGradient = this.ctx.createLinearGradient (canvasWidth/2 + 20, 0, canvasWidth/2 - 20, canvasHeight)
        lineGradient.addColorStop(0, 'rgba(68, 199, 211, 0)')
        lineGradient.addColorStop(1, 'rgba(11, 255, 213, 0.3)')

        this.ctx.globalAlpha=0.42;

        this.ctx.fillStyle = lineGradient;  
        this.ctx.beginPath()

        this.ctx.moveTo(0, startlineY)
        this.ctx.lineTo(canvasWidth, canvasHeight)
        this.ctx.lineTo(canvasWidth, startlineY)
        this.ctx.closePath()

        this.ctx.fill()

        this.ctx.restore()
    }
    drawBar(x) {
        // console.info(x)
        this.ctx.save()
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = "#0bffd5";
        // console.info(this.barSrc)
        // this.ctx.drawImage(this.barSrc, x, bottomLineHeight - barHeight / 2, barWidth, barHeight)
        this.ctx.drawImage(barSrc, x, bottomLineHeight - barHeight / 2, barWidth, barHeight)
        
        this.ctx.restore()

    }
    drawVerticalLine(x) {
        this.ctx.save()

        this.ctx.beginPath()
        this.ctx.strokeStyle = "#0bffd5";
        this.ctx.lineWidth = 2
        this.ctx.setLineDash([2])

        let y = this.getYposition(x)

        this.ctx.moveTo(x, barHeight)
        this.ctx.lineTo(x, y)
        this.ctx.stroke()

        this.ctx.restore()
    }
    drawRect(x) {
        let y = this.getYposition(x)

        if(x+ 100 >= canvasWidth) {
            x = canvasWidth - 100
        }
        if (y + 60 > canvasHeight) {
            y = canvasHeight - 60
        }
        fillRoundRect(this.ctx, x + 10, y - 10, 100 * rate, 60 * rate, 10, "#0bffd5")

        this.ctx.save()

        this.ctx.fillStyle = "#2e3d5d";
        // 变换坐标为y轴线正常坐标  否则文字是反方向
        this.ctx.scale(1, -1);

        
       
        this.ctx.beginPath()
       
        if (rate === 1) {
            this.ctx.font = "10px normal"
            this.ctx.fillText(intl.get('06.01.001-10') , x + 20, -y - 30);
            this.ctx.fillText(intl.get('06.01.001-11') , x + 20, -y - 15);
            this.ctx.font = "12px bold"
            this.ctx.fillText( `${Number(currentMoneyObj.month_add_inst).toFixed(2)} HKD` , x + 20, -y + 2);
        } else {
 
            this.ctx.font = `${10 * rate}px normal`
            this.ctx.fillText(intl.get('06.01.001-10') , x + 40, -y - 70);
            this.ctx.fillText(intl.get('06.01.001-11') , x + 40, -y - 40);
            this.ctx.font = "24px bold"
            this.ctx.fillText( `${Number(currentMoneyObj.month_add_inst).toFixed(2)} HKD` , x + 40, -y -6);
        }

  



        this.ctx.restore()
    }
    computeMoney(x) {
        // console.info(x)

        let rate = x / canvasWidth
        let index = Math.floor(rate * this.data.list01.length)
        // 当滑动到最大刻度到时候 rate =1  index为 数组长度，取数组最后一项到时候 需要减去1
        if (rate === 1) {
            index = index - 1
        }
        let currentMoneyObj = this.data.list01[index]
        // console.info(currentMoneyObj)
        this.setCurrentMoneyObj(currentMoneyObj)
    }
    setCurrentMoneyObj(data) {
        currentMoneyObj = data
        this.cb(data)
    }
    getYposition(x) {
        let k = (canvasHeight - startlineY) / (canvasWidth - 0) // 斜率
        let y = canvasHeight - k * (canvasWidth - x)
        return y
    }
    initListener() {
        let self = this
        document.getElementById("mycals").addEventListener("touchstart", function (e) {
            // console.info('touch start', e)
            self._touchStart(e)
        })
        document.getElementById("mycals").addEventListener("touchmove", function (e) {
            // console.info('touch move', e)
            self._touchMove(e)
        })
        document.getElementById("mycals").addEventListener("touchend", function (e) {
            // console.info('touch end', e)
            self._touchEnd(e)
        },)
    }
    _touchStart(event) {
        var self = this;
        let x = getPage(event, 'pageX') // 获取触摸目标在页面中的x坐标
        let y = getPage(event, 'pageY')
        let pointX = x-canvasLeft
        let pointY = y-canvastop
        let maxX = lastTimeBarPosition + distX + barWidth / 2
        let minX = lastTimeBarPosition + distX - barWidth / 2
        let minY = canvasHeight - (bottomLineHeight + barHeight / 2)
        let  maxY= canvasHeight - (bottomLineHeight - barHeight / 2)
        console.info('minX', minX)
        console.info('maxX', maxX)

        console.info('pointX', pointX)
        console.info('x', x)
        console.info('canvasLeft', canvasLeft)
        console.info('------------------')
        console.info('minY', minY)
        console.info('maxY', maxY)

        console.info('pointY', pointY)
        console.info('y', y)
        console.info('canvastop', canvastop)

        console.info('------------------')
        console.info('------------------')
        if (pointX < minX || pointX > maxX) {
            moveReady =false
            return
        }
        if (pointY < minY || pointY > maxY) {
            moveReady =false
            return
        }
        moveReady = true
        startPageX = x
       
    }
    _touchMove(event) {
        if (!moveReady) {
            return
        }
        var self = this;
        var pageX = getPage(event, 'pageX');
        distX = pageX - startPageX
        // console.info(distX)
        self.initDraw()
    }
    _touchEnd(event) {
        if (moveReady) {
            let pageX = getPage(event, 'pageX');
            let distX = pageX - startPageX
            // 记录上一次bar停止滑动的x位置
            // lastTimeBarPosition = lastTimeBarPosition + distX
            setLastTimeBarPosition(distX)
        }
        moveReady =false
        distX = 0

    }

}

// 获取触摸目标在页面中的坐标
function getPage(event, page) {
    return event.changedTouches[0][page]
}


function drawRoundRectPath(cxt, width, height, radius) {
    cxt.beginPath(0);
    //从右下角顺时针绘制，弧度从0到1/2PI  
    cxt.arc(width - radius, height - radius, radius, 0, Math.PI / 2);

    //矩形下边线  
    cxt.lineTo(radius, height);

    //左下角圆弧，弧度从1/2PI到PI  
    cxt.arc(radius, height - radius, radius, Math.PI / 2, Math.PI);

    //矩形左边线  
    cxt.lineTo(0, radius);

    //左上角圆弧，弧度从PI到3/2PI  
    cxt.arc(radius, radius, radius, Math.PI, Math.PI * 3 / 2);

    //上边线  
    cxt.lineTo(width - radius, 0);

    //右上角圆弧  
    cxt.arc(width - radius, radius, radius, Math.PI * 3 / 2, Math.PI * 2);

    //右边线  
    cxt.lineTo(width, height - radius);
    cxt.closePath();
}
/**该方法用来绘制一个有填充色的圆角矩形 
    *@param cxt:canvas的上下文环境 
    *@param x:左上角x轴坐标 
    *@param y:左上角y轴坐标 
    *@param width:矩形的宽度 
    *@param height:矩形的高度 
    *@param radius:圆的半径 
    *@param fillColor:填充颜色 
**/
function fillRoundRect(cxt, x, y, width, height, radius, /*optional*/ fillColor) {
    //圆的直径必然要小于矩形的宽高          
    if (2 * radius > width || 2 * radius > height) { return false; }

    cxt.save();
    cxt.translate(x, y);
    //绘制圆角矩形的各个边  
    drawRoundRectPath(cxt, width, height, radius);
    cxt.fillStyle = fillColor || "#000"; //若是给定了值就用给定的值否则给予默认值  
    cxt.fill();
    cxt.restore();
}

export default Calc;