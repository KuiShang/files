import React from 'react'
import classnames from 'classnames';
import PropTypes from 'prop-types'
import ReactSwipes from "react-swipes"
import { connect } from 'react-redux'
import {returnFloat2, thousandBitSeparator } from '@/pages/saving/utils'
import * as SDK from 'sdk/wrapper'
import './style.scss'
import intl from 'utils/react-intl-universal';

class Listview extends React.Component {
  componentDidMount() {
    // this.props.queryChannal4304({
    //   ccy_code: 'HKD',
    //   acct_no: this.props.acctno,
    //   page_start: '0',
    //   page_size: '2'
    // })

  }
  static defaultProps = {
    list: [
      {

      }
    ]
  }
  moneyFilter(num = 0, debit_credit) {
    const money = Number(num)
    let flg = ''
    if (money >= 0) {
      if (debit_credit === 'D') {
        flg = '-'
      } else if (debit_credit === 'C') {
        flg = '+'
      }
    } else {
      if (debit_credit === 'D') {
        flg = '+'
      } else if (debit_credit === 'C') {
        flg = '-'
      }

    }
    let absNum = Math.abs(money)
    return flg + thousandBitSeparator(returnFloat2(absNum))
  }
  goAlltranstion = () => {
    SDK.goNativeTradeList()
  }
  render() {
    return (
      <div className="list-view-card-wraper">
        <div className="list-view-card">
          <p className="title">{intl.get('06.01.002-6')}</p>
          <ul className="list-view">
            {this.props.channal4304.list01.map(item => (

              <li className="item" key={item.serial_no}>
                <div className="item-left">
                  
                  {/* <img src={item.trxn_record_type === 1 ? require("./icons-24-x-24-transaction-history@3x.png") : item.trxn_record_type === 2 ? require("./icons-24-x-24-transaction-history@3x.png") :  require("./icons-24-x-24-transaction-history@3x.png") } alt="" className="img-type" /> */}
                  <img src={item.picture_tag}/>
                 
                  <div className="item-left-txt">
                    <p>{item.summary_value_one} </p>
                    <p>{item.summary_value_two}</p>
                    <p className="times">{item.trxn_date}</p>
                  </div>
                </div>
                <div>{this.moneyFilter(item.trxn_amt, item.debit_credit )} {item.trxn_ccy}</div>
              </li>

            ))}
            {/* <li className="item">
              <div className="item-left">
                <img src={require("./icons-24-x-24-transaction-history@3x.png" )} alt="" className="img-type"/>
                <div className="item-left-txt">
                  <p>loan repayment </p>
                  <p>auto transfer</p>
                  <p className="times">14 jan 2019</p>
                </div>
              </div>
              <div>+3,435.00HKD</div>
            </li>
            <li className="item">
              <div className="item-left">
                <img src={require("./icons-24-x-24-transaction-history@3x.png" )} alt="" className="img-type"/>
                <div className="item-left-txt">
                  <p>loan repayment </p>
                  <p>auto transfer</p>
                  <p className="times">14 jan 2019</p>
                </div>
              </div>
              <div>+3,435.00HKD</div>
            </li> */}
          </ul>
          <p className="foot" onClick={this.goAlltranstion}>{intl.get('06.01.002-7')}</p>
        </div>
      </div>
    )
  }

}

Listview.propTypes = {
  list: PropTypes.array
}

const mapStateToProps = (state) => ({
  channal4304: state.saving.channal4304,
  acct_no: state.saving.acct_no
})

const mapDispatchToProps = (dispatch) => ({
  // 存款产品分层利率数组信息查询
  queryChannal4304: (payload) => {
    dispatch({
      payload,
      type: 'REQUEST_4304'
    })
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Listview)