
// var background = require('./img/Background@3x.png')
const x0 = 231 / 2 * 2  // 圆心坐标
const y0 = 231 / 2 * 2  // 圆心坐标
const r1 = (231 / 2 - 16) * 2  // 外圆半径
const startAng = 135  // 起始角度
const endAng = 405   // 终点角度

// var backgroundImg = new Image();
// backgroundImg.src = background

let ctx
class Arc {
    constructor({
        el, // canvas对象
        waterLevel // 水的等级
    } = {}) {
        this.el = el;
        this.waterLevel = waterLevel
        this.coumputeAng = ''
        if (!el.getContext) return
        ctx = el.getContext("2d");
        this.drawBg()
        this.drawWater()
    }
    drawBg = () => {
        ctx.beginPath();
        // ---------1 画大圆------------
        ctx.arc(x0, y0, r1, (Math.PI / 180) * startAng, (Math.PI / 180) * endAng, false);
        ctx.lineCap = "round";
        ctx.lineWidth = '32';
        ctx.strokeStyle = '#ebeff0';
        ctx.stroke();
       
        // ctx.drawImage(backgroundImg, 90, 40, 141 * 2, 175 * 2);
        // backgroundImg.onload = function () {
        //     ctx.drawImage(backgroundImg, 90, 40, 141 * 2, 175 * 2);
        // }
    }
    drawWater = () => {
        // 把1-100的水滴 换算成 135-405的角度
        const baseAng = endAng - startAng
        this.coumputeAng = baseAng / (100 / this.waterLevel) + startAng
        // 如果计算后的终点角度超过最大角度，
        if (this.coumputeAng > endAng) {
            this.coumputeAng = endAng
        }
        // 获取大圆上的点 与 边界圆交点
        let x1 = this.getPointX(r1, startAng)
        let y1 = this.getPointY(r1, startAng)
        ctx.moveTo(x1, y1)
        this.animDraw(ctx, startAng)
    }
   
    drawColorArc(ctx, endAng) {
        ctx.beginPath();
        ctx.arc(x0, y0, r1, (Math.PI / 180) * startAng, (Math.PI / 180) * endAng, false);
        ctx.lineCap = "round";
        ctx.lineWidth = '32';
        ctx.strokeStyle = '#08ffd5';
        ctx.stroke();
    }
    animDraw(ctx, endAng) {
        endAng++
        this.drawColorArc(ctx, endAng)

        if (endAng <= this.coumputeAng) {
            window.requestAnimationFrame(() => {
                return this.animDraw(ctx, endAng)
            });
        }
    }
    animBackDraw(end = endAng) {
        ctx.clearRect(0,0,462,390);
        this.drawBg()
        end--
        this.drawColorArc(ctx, end)

        if (end > 0 && end > startAng) {
            window.requestAnimationFrame(() => {
                return this.animBackDraw(end)
            });
        } else if (end === startAng) {
            this.drawBg()
        }
    }
    getPointX(r, ao) {
        return x0 + r * Math.cos(ao * Math.PI / 180)

    }
    getPointY(r, ao) {
        return y0 + r * Math.sin(ao * Math.PI / 180)
    }

}

export default Arc;