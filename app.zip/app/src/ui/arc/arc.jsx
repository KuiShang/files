import React from 'react'
import 'animate.css'
import Velocity from 'velocity-animate'
import classnames from 'classnames';
import intl from 'utils/react-intl-universal';

import './style.scss'
import ArcObj from './arcObj'
var kettle = require('./img/Kettle@1x.png')
var water = require('./img/b5 copy 25@2x.png')


let clickonce  = true //浇水按钮指点击一次
class Arc extends React.Component {
  constructor(props) {
    super(props);
    this.canvasRef = React.createRef();
  }
  state = {
    showWater: false,
    flower: ''
  }
  componentDidMount() {
    this.arcobj = new ArcObj({
      el: this.canvasRef.current,
      waterLevel: this.props.waterLevel
    })
    this.computeFlower()
  }
  computeFlower = () => {
    console.info('重新计算花的等级', this.props.flowerLevel)
    let flower = ''
    flower = require(`./img/flower/FlowerA-${this.props.flowerLevel}@2x.png`)
    this.setState({
      flower
    })
  }
  animat = () => {
    this.animateCSS('#myflower', 'pulse')
  }
  kettle = () => {
    if (!clickonce) {
      return
    }
    clickonce = false
    var kettle = document.querySelector('.kettle');

    
    // 水壶动画
    Velocity(kettle, {
      bottom: '115px',
      rotateZ: "-30deg",
      right: '60px'
    }, { duration: 2000 })
    // 显示水的动画
    setTimeout(() => {
      this.setState({
        showWater: true
      }, () => {
        setTimeout(() => {
          // 隐藏水
          this.setState({
            showWater: false
          }, () => {
            // 隐藏水壶
            Velocity(kettle, {
              opacity: '0',
            })
            // 更新花的等级
            // this.computeFlower()
            this.props.startWater && this.props.startWater( () => {
              this.computeFlower()
            })
            // canvas回收动画
            this.arcobj.animBackDraw()
          })
        }, 500);
      })

    }, 2100);
  }
  animateCSS(element, animationName, callback) {
    const node = document.querySelector(element)
    node.classList.add('animated', animationName)

    function handleAnimationEnd() {
      node.classList.remove('animated', animationName)
      node.removeEventListener('animationend', handleAnimationEnd)

      if (typeof callback === 'function') callback()
    }

    node.addEventListener('animationend', handleAnimationEnd)
  }

  render() {
    let { showWater } = this.state
    const waterCls = classnames('water', {
      show: showWater
    })

    return (
      <div className='canvas-wraper'>
        <img src={this.state.flower} className="flower" id="myflower" onClick={this.animat} />
        <canvas id="mycanvas" className="mycanvas" width="462" height="390" ref={this.canvasRef}></canvas>
       
        {this.props.waterLevel >=100  &&  <img src={kettle} className="kettle" />}
        {this.props.waterLevel >=100 &&  <div className="start-water"  onClick={this.kettle} >{intl.get('06.01.002-10')}</div> }
       

        <img src={water} className={waterCls} id="myWater" />
      </div>
    )
  }

}


export default Arc