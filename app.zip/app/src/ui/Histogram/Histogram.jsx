import React from 'react'
import PropTypes from 'prop-types'
import './style.scss'

const Histogram = (props) => {
  console.info(props)
  return (
    <ul className="histogram">
      <li className="tier tier1">
        <p className="txt txt1">0.2%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier6">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier2">
        <p className="txt txt1">0.3%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier6">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier3">
        <p className="txt txt1">0.3%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier6">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier4">
        <p className="txt txt1">0.3%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier6">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier5">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
      <li className="tier tier6">
        <p className="txt txt1">1.5%</p>
        <p className="color"></p>
        <p className="txt txt2">Tier 1</p>
        <p className="txt txt3">> 0</p>
      </li>
    </ul>
  )
}

Histogram.propTypes = {
  products: PropTypes.array,
  total: PropTypes.string,
  onCheckoutClicked: PropTypes.func
}

export default Histogram
