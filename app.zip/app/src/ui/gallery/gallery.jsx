import React from 'react'
import classnames from 'classnames';
import PropTypes from 'prop-types'
import ReactSwipes from "react-swipes"

import './style.scss'

class Button extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      curCard: 0
    }
  }
  componentDidMount() {
  }
  shouldComponentUpdate(nextProps, nextState) {
    if (nextState.curCard === this.state.curCard) {
      return false
    }
    return true;
  }
  render() {
    // swipes 的配置
    let opt = {
      distance: 3.41 * parseInt(document.documentElement.style.fontSize), // 每次移动的距离，卡片的真实宽度，需要计算
      currentPoint: 0, // 初始位置，默认从0即第一个元素开始
      autoPlay: false,
      loop: true,
      swTouchstart: ev => { },
      swTouchmove: ev => { },
      swTouchend: ev => {
        this.setState({
          curCard: ev.newPoint
        })
        console.info(ev.newPoint);
      }
    };
    const { curCard } = this.state;

    const imgList = [
      {
        title: 'smart saving',
        des: 'get higer interest with cbs daily accumalated reates',
        img: require('./illustration-promotion-saving@3x.png')
      }
    ]
    const styleObj = {
      width: imgList.length * document.body.clientWidth
    }
    return (
      <div className="card-swipe">
        <div className="flipsnap" style={styleObj}>
          <ReactSwipes className="card-slide" options={opt}>
            {
              imgList.map((item, index) => (
                <div key={index} className="item" >
                  <img src={item.img} alt="" className="bgImg"/>
                  <p className="title">{item.title}</p>
                  <p className="des">{item.des}</p>
                </div>
              ))
            }
          </ReactSwipes>
        </div>
        <div className='point-container'>
          <ul>
            {imgList.map((val, index) => {
              return (
                <li key={index} className={`${curCard == index ? 'active' : ''}`}></li>
              )
            })}
          </ul>
        </div>
      </div>
    )
  }

}

Button.propTypes = {
}

export default Button