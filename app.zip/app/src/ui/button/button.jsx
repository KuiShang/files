import React from 'react'
import classnames from 'classnames';
import TouchFeedback from 'rmc-feedback';
import PropTypes from 'prop-types'
import './style.scss'

class Button extends React.Component {
  static defaultProps = {
    prefixCls: 'v-button',
    size: 'large',
    inline: false,
    disabled: false,
    loading: false,
    activeStyle: {},
  }
  render() {
    const {
      className,
      prefixCls,
      type,
      disabled,
      activeStyle,
      activeClassName,
      onClick
    } = this.props
    const wrapCls = classnames(prefixCls, className, {
      [`${prefixCls}-primary`]: type === 'primary',
      [`${prefixCls}-disabled`]: disabled
    })
    return (
      <TouchFeedback
        activeClassName={
          activeClassName || (activeStyle ? `${prefixCls}-active` : undefined)}
        disabled={disabled}
        activeStyle={activeStyle}
      >
      {/* eslint-disable-next-line */}
      <a
        role="button"
        onClick={disabled ? undefined : onClick}
        className={wrapCls}>
        <span className="Button-Text">
          {this.props.children}
        </span>
      </a>
      </TouchFeedback>
    )
  }

}

Button.propTypes = {
  type: PropTypes.oneOf(['primary', 'warning'])
}

export default Button