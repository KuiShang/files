export const DO_REQUEST_MENUS = "REQUEST_MENUS";
export const DONE_REQUEST_MENUS = "DONE_REQUEST_MENUS";

export function doRequestMenusAction(params) {
    return {
        type: DO_REQUEST_MENUS,
        params
    }
}

export function doneRequestMenusAction(result) {
    return {
        type: DONE_REQUEST_MENUS,
        result
    }
}