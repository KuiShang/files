import { combineReducers } from 'redux';
import { doHandleMenuReducer } from './common';


export default combineReducers({
    doHandleMenuReducer
})