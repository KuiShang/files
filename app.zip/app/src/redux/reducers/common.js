import { DO_REQUEST_MENUS, DONE_REQUEST_MENUS } from '../actions/common';

export function doHandleMenuReducer(state = {}, action) {
    switch (action.type) {
        case DO_REQUEST_MENUS:
            return state;
        case DONE_REQUEST_MENUS:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}