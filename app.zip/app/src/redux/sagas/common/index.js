import { put, call } from 'redux-saga/effects';
import { doneRequestMenusAction } from 'redux/actions/common';
import { getMenus } from './api'

export function* doRequestMenus(action) {
    let result = {};
    try {
        const response = yield call(getMenus, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneRequestMenusAction(result));
}