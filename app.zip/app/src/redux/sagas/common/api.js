import FetchUtil from 'utils/FetchUtil';

export function getMenus(params) {
    return FetchUtil.get('/api/...', params);
}
