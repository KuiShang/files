import { takeLatest } from 'redux-saga/effects';
import { DO_REQUEST_MENUS } from 'redux/actions/common';
import { doRequestMenus } from './common'

export default function* index() {
    yield [
        takeLatest(DO_REQUEST_MENUS, doRequestMenus)
    ]
}