const proxy = require('http-proxy-middleware')

module.exports = function (app) {
  // 设置反向代理
  app.use( proxy(
    '/faq', {
      target: 'http://10.13.145.93:8900',
      changeOrigin: true
  })
  )
  app.use( proxy(
    '/saser', {
      target: 'http://10.13.145.14:8080',
      changeOrigin: true
  })
  )
  app.use( proxy( '/appse', { target: 'http://appgw.livibank.com', changeOrigin: true }) )
  app.use( proxy( '/cocgw', { target: 'http://appgw.livibank.com', changeOrigin: true }) )


 
}