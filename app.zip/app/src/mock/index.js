import mockDemo from './mockDemo'
import faq from './accountSetting/faq'
import protocol from './protocol/index'

const axios = require('axios')
const MockAdapter = require('axios-mock-adapter')
const mock = new MockAdapter(axios, {
  delayResponse: 1000
})

mockDemo(mock)
faq(mock)
protocol(mock)

export default mock