/*eslint-disable*/
/*
 * 接口命名规则
 * http(s)://{server.com}/{系统简码小写}/{模块名称}/{方法名称}
 * 正例：https://livibank.com/ekycs/account/openAccount
 * 
 */
// 入参 languare
export default function faq(mock) {
	mock.onPost('/accountSetting/faq/getData').reply(200,
		{
			"resultCode": 1,
			"resultData": {
				faqData: [
					{
						navBbj: {
							typegroup: true,
							title: 'Question',
							choiceIcon: '地址url1',
							noChoiceIcon: '地址url2',
							type: 1
						},
						list: [
							{
								id: "1", label: "问题分组1", children: [
									{ id: "11", label: "How do I apply for a loan?" },
									{ id: "12", label: "How long is the process?" },
									{ id: "13", label: "What documents do I need to provide?" }
								]
							},
							{
								id: "2", label: "问题分组1", children: [
									{ id: "21", label: "How do I apply for a loan?" },
									{ id: "22", label: "How long is the process?" },
									{ id: "23", label: "What documents do I need to provide?" }
								]
							}
						]
					},
					{
						navBbj: {
							typegroup: true,
							title: 'Question222',
							choiceIcon: '地址url1',
							noChoiceIcon: '地址url2',
							type: 4
						},
						list: [
							{
								id: "11", label: "问题分组21", children: [
									{ id: "112", label: "How do I apply for a loan?" },
									{ id: "122", label: "How long is the process?" },
									{ id: "132", label: "What documents do I need to provide?" }
								]
							},
							{
								id: "22", label: "问题分组21", children: [
									{ id: "212", label: "How do I apply for a loan?" },
									{ id: "222", label: "How long is the process?" },
									{ id: "232", label: "What documents do I need to provide?" }
								]
							}
						]
					},
					{
						navBbj: {
							typegroup: false,
							title: 'Saving',
							type: 2,
							choiceIcon: '地址url1',
							noChoiceIcon: '地址url2'
						},
						list: [
							{
								jumpMsg: 'aaadetail/a',
								title: '你的存款问题是什么？'
							}
						]
					},
					{
						navBbj: {
							typegroup: false,
							title: 'Loan',
							type: 3,
							choiceIcon: '地址url1',
							noChoiceIcon: '地址url2',
						},
						list: [
							{
								jumpMsg: 'aaadetail/a',
								title: '你的Load问题是什么？2222'
							}
						]
					},
				]
			},
			"errorData": null,
			"actionData": null
		})
}
