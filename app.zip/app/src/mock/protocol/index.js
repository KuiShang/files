// 入参 languare
export default function protocol(mock) {
	/**
	 * 查询已签约协议列表
	 */
	mock.onPost('/saser/agreement/queryUserAgreementList').reply(200,
		{
			"resultCode": 1,
			"resultData": {
				"pageNum": 1,
				"pageSize": 2,
				"total": 2,
				"pages": 1,
				"data": [
					{
						"userId": "1",
						"agreementNo": "AGM_REG",
						"agreementVersion": "001",
						"agreementTime": "2019-04-01T03:38:52.000+0000",
						"languageType": "zh-CN",
						"agreementName": "标题1",
						"agreementContent": null
						
					},
					{
						"userId": "1",
						"agreementNo": "AGM_REG",
						"agreementVersion": "001",
						"agreementTime": "2019-04-01T03:38:52.000+0000",
						"languageType": "zh-CN",
						"agreementName": "标题2",
						"agreementContent": null
					}
				]
			},
			"errorData": null
		}
	)

	/**
	 * 查询用户签订的某个协议
	 */
	mock.onPost('/saser/agreement/queryUserAgreementContent').reply(200,
		{
			"resultCode": 1,
			"resultData": {
				"agreementNo": "SME1",
				"agreementVersion": "1",
				"languageType": "zh-CN",
				"agreementName": "标题1",
				"agreementContent": "<div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div><div>aaaa111 a<b>aa</b>aa</div>"
			},
			"errorData": null
		}
	)
	/**
	 * 协议概要信息查询
	 */
	mock.onPost('/saser/agreement/queryAgreementModel').reply(200,
		{
			"resultCode": 1,
			"resultData": {
				"agreementNo": "SME1",
				"agreementVersion": "1",
				"languageType": "zh-CN",
				"agreementName": "标题1",
				"agreementContent": "<div>aa 222aaa<b>aa </b>aa </div>"
			},
			"errorData": null
		}
	)
}
// 协议详情
var json ={ 
	"resultCode": 1,
	"resultData": {
		"agreementNo": "AGM_REG",
		"agreementVersion": "001",
		"languageType": "zh-CN",
		"agreementName": "注册协议20190411",
		"agreementContent": "<body class=\"view\" contenteditable=\"true\" spellcheck=\"false\" style=\"overflow-y: hidden; cursor: text; height: 504px;\"><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><span style=\"color:navy\"><span style=\"font-weight: 600 !important;\">同心协力建设好家乡守护好边疆&nbsp; 努力创造更加美好的明天</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255);\">　　新华社北京4月11日电&nbsp; 中共中央总书记、国家主席、中央军委主席习近平10日给云南省贡山县独龙江乡群众回信，祝贺独龙族实现整族脱贫，勉励乡亲们为过上更加幸福美好的生活继续团结奋斗。</p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255);\">　　习近平表示，你们乡党委来信说，去年独龙族实现了整族脱贫，乡亲们日子越过越好。得知这个消息，我很高兴，向你们表示衷心的祝贺！</p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255);\">　　习近平指出，让各族群众都过上好日子，是我一直以来的心愿，也是我们共同奋斗的目标。新中国成立后，独龙族告别了刀耕火种的原始生活。进入新时代，独龙族摆脱了长期存在的贫困状况。这生动说明，有党的坚强领导，有广大人民群众的团结奋斗，人民追求幸福生活的梦想一定能够实现。</p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255);\">　　习近平强调，脱贫只是第一步，更好的日子还在后头。希望乡亲们再接再厉、奋发图强，同心协力建设好家乡、守护好边疆，努力创造独龙族更加美好的明天！</p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; color: rgb(64, 64, 64); font-family: &quot;PingFang SC&quot;, &quot;Lantinghei SC&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Microsoft YaHei&quot;, å¾®è½¯é›…é»‘, STHeitiSC-Light, simsun, å®‹ä½“, &quot;WenQuanYi Zen Hei&quot;, &quot;WenQuanYi Micro Hei&quot;, sans-serif; font-size: 18px; white-space: normal; background-color: rgb(255, 255, 255);\">　　独龙族是我国28个人口较少民族之一，也是新中国成立初期一个从原始社会末期直接过渡到社会主义社会的少数民族，主要聚居在云南省贡山县独龙江乡。当地地处深山峡谷，自然条件恶劣，一直是云南乃至全国最为贫穷的地区之一。2018年，独龙江乡6个行政村整体脱贫，独龙族实现整族脱贫，当地群众委托乡党委给习近平总书记写信，汇报独龙族实现整族脱贫的喜讯，表达了继续坚定信心跟党走、为建设好家乡同心奋斗的决心。</p><p>&#8203;<br></p></body>"
	},
	"errorData": null
} 