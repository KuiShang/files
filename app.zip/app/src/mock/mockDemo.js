/*eslint-disable*/
export default function mockDemo(mock) {
	// 测试demo mock
	mock.onPost('/vb/test').reply(200, {
		"resultCode": "1",
		"resultData": {
			"amount": 100
		},
		"errorData": null,
		"actionData": null,
		"resultMsg": "success"
	})
}
