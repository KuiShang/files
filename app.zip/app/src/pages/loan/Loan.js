import React from 'react';

export default class Loan extends React.Component{
    render(){
        return(
            <div>My loans</div>
        )
    }
}