import React from 'react';
import ReactDOM from 'react-dom';
import Loan from './Loan';
import * as serviceWorker from '../../serviceWorker';

ReactDOM.render(<Loan />, document.getElementById('root'));

serviceWorker.unregister();