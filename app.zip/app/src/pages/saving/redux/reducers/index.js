import { combineReducers } from 'redux'
import saving from './saving'



const defaultCommonState = {
  isFetching: false
}
const common = (state = defaultCommonState, action) => {
  switch (action.type) {
    case 'CHANGE_FETCHING':
      return { ...state, isFetching: action.isFetching }
    default:
      return state
  }
}


const reducer = combineReducers({
  saving,
  common
})
export default reducer
