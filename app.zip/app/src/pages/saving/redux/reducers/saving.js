import { debug } from "util";

const defaultState = {
    channal4302: {}, // 存款产品分层利率数组信息
    channal4301: {},// 存款产品利率信息
    channal4303: {
      list01: []
    },// 存款账户汇总折算余额查询
    channal4304: {
      list01: []
    },// 存款账户交易明细
    acct_no: ''
}
const articles = (state = defaultState, action) => {
  switch (action.type) {
    // 存储收款人列表
    case 'RECEIVE_4301':
    return {...state,  channal4301: action.channal4301}
    case 'RECEIVE_4302':
    return {...state,  channal4302: action.channal4302}
    case 'RECEIVE_4303':
    return {...state,  channal4303: action.channal4303}
    case 'RECEIVE_4304':
    return {...state,  channal4304: action.channal4304}
    case 'CHANGE_WATER_LEVEL':
    let channal4303 =  {...state.channal4303}
    let list01 = channal4303.list01.concat([])
    let obj = list01[0]
    let temp = {...obj, sum_round_inst: action.level }

    list01[0] = temp
    channal4303.list01 = list01
    return {...state,  channal4303:channal4303}

    case 'CHANGE_FLOWER_LEVEL':
    let channal4303a =  {...state.channal4303}
    let list01a = channal4303a.list01.concat([])
    let obja = list01a[0]
    let tempa = {...obja, stad_sum_round_inst: action.level }

    list01a[0] = tempa
    channal4303a.list01 = list01a
    return {...state,  channal4303:channal4303a}

    case 'RECEIVE_4401':
    return {...state,  acct_no: action.channal4401}
    default:
      return state
  }
}
export default articles
