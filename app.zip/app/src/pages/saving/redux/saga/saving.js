import { hashHistory } from 'react-router';
import { call, put, takeEvery } from 'redux-saga/effects'
import { channal4303, channal4302, channal4301, channal4304, channal4306, channal4401 } from 'pages/saving/api';
import Toast from '@/ui/toast'

/** -------------------存款产品利率信息查询----------------*/
function* yield4301(payload) {
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    let tempdata = {
        bizInfo: {
            ...payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now() + ''
        // }
       }
    const ret = yield call(channal4301, tempdata)
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    yield put({ type: 'RECEIVE_4301', channal4301: ret.data.resultData })
}

export function* watchYield4301() {
    yield takeEvery('REQUEST_4301', yield4301)
}

/** ------------------存款产品利率信息查询----------------*/




/** -------------------存款产品分层利率数组信息查询----------------*/
function* yield4302(payload) {
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
       }
    const ret = yield call(channal4302, tempdata)
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    if (ret.data.resultCode === 1) {
        yield put({ type: 'RECEIVE_4302', channal4302: ret.data.resultData })
    } else {
        Toast.info(JSON.stringify(ret.data.errorData))
    }
}

export function* watchYield4302() {
    yield takeEvery('REQUEST_4302', yield4302)
}

/** ------------------存款产品分层利率数组信息查询----------------*/




/** -------------------存款产品分层利率数组信息查询和 4301----------------*/
function* yield4302_4301(payload) {
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
       }

    const [data4302, data4301] = yield [call(channal4302, tempdata), call(channal4301, tempdata)]
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    yield put({ type: 'RECEIVE_4301', channal4301: data4301.data.resultData })
    yield put({ type: 'RECEIVE_4302', channal4302: data4302.data.resultData })
}

export function* watchYield4302_4301() {
    yield takeEvery('REQUEST_4302_4301', yield4302_4301)
}

/** ------------------存款产品分层利率数组信息查询和 4301----------------*/




/** -------------------存款账户汇总折算余额查询----------------*/
function* yield4303(payload) {
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
    }
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    const ret = yield call(channal4303, tempdata)
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    if (ret.data.resultCode === 1) {
        yield put({ type: 'RECEIVE_4303', channal4303: ret.data.resultData })
    } else {
        Toast.info(JSON.stringify(ret.data.errorData))
    }
    payload.cb && payload.cb()
}

export function* watchYield4303() {
    yield takeEvery('REQUEST_4303', yield4303)
}

/** ------------------存款账户汇总折算余额查询----------------*/





/** -------------------存款账户利息累计标准值减少接口（浇花）----------------*/
function* yield4306(payload) {
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
    }
    const ret = yield call(channal4306, tempdata)
    yield put({ type: 'CHANGE_WATER_LEVEL', level: 0 })
    yield put({ type: 'CHANGE_FLOWER_LEVEL', level: ret.data.resultData.inst_level_value })
    // console.info('----', payee)
    payload.cb && payload.cb()
    yield put({ type: 'RECEIVE_PAYEE', channal4306: ret.data.resultData.name_list })
}

export function* watchYield4306() {
    yield takeEvery('REQUEST_4306', yield4306)
}

/** ------------------存款账户利息累计标准值减少接口（浇花）----------------*/



/** -------------------存款账户交易明细接口查询----------------*/
function* yield4304(payload) {
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
    }
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    const ret = yield call(channal4304, tempdata)
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    yield put({ type: 'RECEIVE_4304', channal4304: ret.data.resultData })
}

export function* watchYield4304() {
    yield takeEvery('REQUEST_4304', yield4304)
}

/** ------------------存款账户交易明细接口查询----------------*/

/** -------------------开户查询----------------*/
function* yield4401(payload) {
    let tempdata = {
        bizInfo: {
            ...payload.payload
        },
        // deviceInfo: {
        //  "deviceModel": "iPhone8",
        //  "imei": "11111",
        //  "macAddress": "123123",
        //  "os": "Android",
        //  "uuid":  Date.now()+ ''
        // }
    }
    yield put({ type: 'CHANGE_FETCHING', isFetching: true })
    const ret = yield call(channal4401, tempdata)
    yield put({ type: 'CHANGE_FETCHING', isFetching: false })
    // console.info('----', payee)
    yield put({ type: 'RECEIVE_4401', channal4401: ret.data.resultData.list01[0].acct_no })
}

export function* watchYield4401() {
    yield takeEvery('REQUEST_4401', yield4401)
}

/** ------------------开户查询----------------*/






