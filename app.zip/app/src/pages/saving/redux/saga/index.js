import { all } from 'redux-saga/effects'
import { watchYield4301,
  watchYield4302,
  watchYield4303,
  watchYield4306,
  watchYield4302_4301,
  watchYield4304,
  watchYield4401
} from './saving'
export default function* rootSaga() {
  yield all([
    watchYield4301(),
    watchYield4302(),
    watchYield4303(),
    watchYield4306(),
    watchYield4302_4301(),
    watchYield4304(),
    watchYield4401()
  ])
}