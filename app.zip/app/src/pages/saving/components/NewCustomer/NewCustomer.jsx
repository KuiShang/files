import React from 'react'
import { connect } from 'react-redux'
import './style.scss'
import Button from '@/ui/button/button'
import Tabs from '@/ui/Tabs/Tabs'
import Gallery from '@/ui/gallery/gallery'
import Listview from '@/ui/listview/listview'
import {returnFloat2, thousandBitSeparator } from '@/pages/saving/utils'
import Arc from '@/ui/arc/arc'
import { hashHistory } from 'react-router';
import intl from 'utils/react-intl-universal';
var img_share = require('./share@3x.png')
var image_advert =  require('./Saving@3x.png')
class NewCustomer extends React.Component {
 
  componentDidMount() {
    this.initData()
 
    // 上报埋点
    window.$SDK.buriedPointEntry({
      pageName: 'CODAC_DEF_L3'
    })



    // window.$SDK.setTitle( {
    //     showEnd :0,
    //     showBack:0,
    //     showProTpye: 1,
    //     showHead: 1
    //   }, function(){})

    // window.$SDK.setTitleRight({
    //   show: 1,
    //   textSize: 14,
    //   textColor: '#4F577C',
    //   iconUrl: img_share,
    // }, () => {
    //   var json = {
    //     type: 'native',
    //     address: '/webview/web',
    //     params: {
    //       url: `${window.location.protocol}//promo.livibank.com/#/invite`,
    //       mHeaderTitle: {
    //         showHead: 1,
    //         showBack: 1,
    //         showEnd: 0,
    //         showProTpye: 1
    //       }
    //     }
    //   }
    //   window.$SDK.goNativeAction(json)
    // })
    window.$SDK.onForeground(() => {
      console.info('huidaoqiantai')
      // alert('huidaoqiantai')
      this.initData();

    })
  }

  componentWillUnmount() {
    window.$SDK.buriedPointLeave({
      pageName: 'CODAC_DEF_L3'
    });
  }
  initData = () => {
    this.props.queryChannal4303({
    }, ()  => {
      console.info(123333)
      this.props.queryChannal4304({
        ccy_code: 'HKD',
        acct_no: this.props.channal4303.acct_no,
        page_start: '0',
        page_size: '2'
      })
    })
  }
  moneyFilter(num = 0) {
    return thousandBitSeparator(returnFloat2(num))
  }
  deposit = () => {
    var json = {
      type: 'native',
      address: '/webview/web',
      params: {
        url: `${window.location.origin}/pay/deposit.html`,
        mHeaderTitle: {
          showHead: 1,
          showBack: 1,
          showEnd: 0,
          showProTpye: 1
        }
      }
    }
    window.$SDK.goNativeAction(json)
  }
  learnMore = () => {

  }
  goShare = () => {
    var json = {
      type: 'native',
      address: '/webview/web',
      params: {
        url: `${window.location.origin}/promo/#/invite`,
        mHeaderTitle: {
          showHead: 1,
          showBack: 1,
          showEnd: 0,
          showProTpye: 1
        }
      }
    }
    window.$SDK.goNativeAction(json)
  }
  startWater = (cb) => {
    this.props.queryChannal4306({
      acct_no: this.props.channal4303.acct_no,
      ccy_code: 'HKD',
      stad_value: 100
    }, cb)
  }
  render() {
    if ( typeof this.props.channal4303.conv_amt_sum !== 'number') {
      return null
    }
    return (
      <div className="NewCustomer">

        <section className="pd2">
          <p className="title">{intl.get('06.01.002-1')}  { this.props.channal4303 && this.props.channal4303.acct_no }</p>
          {/* <p className="aggregated_balance">aggregated balance {this.moneyFilter(this.props.channal4303.conv_amt_sum)} HKD</p> */}
          {/* {
            this.props.channal4303.conv_amt_sum === 0 &&   <div className="card">
            <p className="Lets-get-started">lets get started</p>
            <p className="Deposit-now-to-rise">Deposit now to rise up the interest tiers and earn up to 1.5% interest with your HKD savings account</p>
            <Button type="primary" onClick={this.deposit} >Deposit</Button>
            <p className="Learn-more-about-the" onClick={this.learnMore} >Learn more about the interest tiers</p>
          </div>
          } */}

          <div className="card">
            {/* <Tabs tabs={[
              { title: 'HKD' },
              { title: 'CNY' },
              ]}
              onTabClick={(tab, index) => { console.info('onTabClick', index, tab); }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff', fontSize:'12px' }}>
                Content of first tab
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff', fontSize:'12px' }}>
                Content of second tab
              </div>
            </Tabs> */}

            <div className="flower">
              <p className="money-cont">
                <span className="sum-money">{this.props.channal4303.list01 && this.moneyFilter(this.props.channal4303.list01[0].acct_bal)}&nbsp;</span>
                <span className="money-code">{this.props.channal4303.list01 && this.props.channal4303.list01[0].ccy_code} </span>
              </p>
              <Arc waterLevel={this.props.channal4303.list01[0].sum_round_inst} flowerLevel = {this.props.channal4303.list01[0].stad_sum_round_inst} startWater={this.startWater}></Arc>
              <p className="water-level" >{this.props.channal4303.list01[0].sum_round_inst}/100HKD</p>
              <div className="gain">

                <div className="item">
                  <p className="title">{intl.get('06.01.002-2')}</p>
                  <p className="money-wraper">
                    <span className="money">+ {this.props.channal4303.list01[0].last_date_instam == 0 ? 0 : Number(this.props.channal4303.list01[0].last_date_instam).toFixed(2)}&nbsp;</span>
                    <span className="currency">{this.props.channal4303.list01[0].ccy_code}</span>
                  </p>
                </div>

                <div className="item">
                  <p className="title">{intl.get('06.01.002-3')}</p>
                  <p className="money-wraper">
                    <span className="money">+ {this.props.channal4303.list01[0].year_sum_instam == 0 ? 0 : Number(this.props.channal4303.list01[0].year_sum_instam).toFixed(2)}&nbsp;</span>
                    <span className="currency">{this.props.channal4303.list01[0].ccy_code}</span>
                  </p>
                </div>

                <div className="item">
                  <p className="title">{intl.get('06.01.001-8')}</p>
                  <p className="money-wraper">
                    <span className="money">{this.props.channal4303.list01[0].acct_current_level_inrt}</span>
                    <span className="currency">%</span>
                  </p>
                </div>

              </div>
              { this.props.channal4303.conv_amt_sum === 0 && 
               <p className="Get-higher-interest">
               {intl.get('save more to gain more with livis high interest savings account')}
              </p>}
              
            </div>
            <Button type="primary" onClick={this.deposit} >{intl.get('06.01.002-5')}</Button>
          </div>
        </section>
        {
          this.props.channal4303.conv_amt_sum > 0 && <Listview acctno={this.props.channal4303.acct_no}/>
        }
        {/* <Gallery></Gallery> */}
        <div className="imageAdvertise-wraper">
          <div className="imageAdvertise">
            <img src={image_advert} alt="" className="bgImg"/>
            {/* <img src={img_share} alt="" className="img_share" onClick={this.goShare} /> */}
            <p className="title">{intl.get('06.01.001-1')}</p>
              <p className="des">{intl.get('06.01.002-9')}</p>
          </div>
        </div>
      
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  channal4303: state.saving.channal4303,
  acct_no: state.saving.acct_no
})

const mapDispatchToProps = (dispatch) => ({
  // 存款账户汇总折算余额查询
  queryChannal4303: (payload, cb) => {
    dispatch({
      payload,
      cb:cb,
      type: 'REQUEST_4303'
    })
  },
    // 存款产品分层利率数组信息查询
    queryChannal4304: (payload) => {
      dispatch({
        payload,
        type: 'REQUEST_4304'
      })
    },
    // （浇花
   queryChannal4306: (payload, cb) => {
      dispatch({
        payload,
        cb,
        type: 'REQUEST_4306'
      })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(NewCustomer)