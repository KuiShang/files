import React from 'react'
import { connect } from 'react-redux'
import Button from '@/ui/button/button'
import Histogram from '@/ui/Histogram/Histogram'
import Calculator from '@/ui/Calculator/Calculator2'
import { hashHistory } from 'react-router';
import intl from 'utils/react-intl-universal';
import './style.scss'
var img_share = require('./share@3x.png')

class DefaultCustomer extends React.Component {
  state = {
    inrt_level_amt: 0,
    inst_rate: 0,
    month_inst: 0
  }
  componentDidMount() {
    // window.$SDK.setTitle({
    //   title: 'Saving',
    //   mHeaderTitle: {
    //     showEnd: 0,
    //     showBack: 0,
    //   }
    // })

    window.$SDK.buriedPointEntry({
      pageName: 'CODAC_DEF_L1L2'
    })

 

   

 



    this.props.queryChannal4302({
      prod_id: 'CA01',
      ccy_code: 'HKD'
    })
  }

  componentWillUnmount() {
    window.$SDK.buriedPointLeave({
      pageName: 'CODAC_DEF_L1L2'
    });
  }


  getVbAccount = async () => {
    console.info('getVbAccount')
    const ret = await window.$SDK.goNativeKYC()
    console.info('goNativeKYC 返回,跳转l3', ret)
    if (ret.status === 1) {
      hashHistory.push('/l3')
    } else {
      console.info('goNativeKYC 返回,取消操作')
    }
  


  }
  goShare = () => {
    var json = {
      type: 'native',
      address: '/webview/web',
      params: {
        url: `${window.location.origin}/promo/#/invite`,
        mHeaderTitle: {
          showHead: 1,
          showBack: 1,
          showEnd: 0,
          showProTpye: 1
        }
      }
    }
    window.$SDK.goNativeAction(json)
  }
  Share = () => {
    window.$SDK.shareBySDK({
      text: '文案带提供'
    });
  }
  getCalcData = (obj) => {
    this.setState({
      inrt_level_amt: obj.inrt_level_amt,
      inst_rate: obj.inst_rate,
      month_inst: obj.month_inst
    })
  }
  moneyFormat = (num) => {
    return num > 1000 ? num / 1000 + intl.get('K') : num;
  }
  twoDecimal= (num) => {
    return Number(num).toFixed(2)
  }
  render() {
    if (!this.props.channal4302.prod_id) {
      return null
    }
    return (
      <div className="DefaultCustomer">
       {/* {
         this.props.level === '/l2' &&  <img src={img_share} alt="" className="img_share" onClick={this.goShare} />
       }  */}
        <section className="part1">
          <p className="title">{intl.get('06.01.001-1')}</p>
          <p className="We-offer-up-to-15">{intl.get('06.01.001-2')}</p>
          <p className="We-offer-up-to-15">{intl.get('06.01.001-3')}</p>
          <p className="We-offer-up-to-15">{intl.get('06.01.001-4')}</p>
          {/* <div className="gram">
            <p className="How-our-interest-tie">How our interest tiers work</p>
            <Histogram ></Histogram>
          </div> */}
          <div className="btn-wraper">
            <Button type="primary" onClick={this.getVbAccount} >{intl.get('06.01.001-5')}</Button>
          </div>
        </section>
        <section className="part2">
          {/* <p className="title">Let’s Try with Your Savings</p>
          <p className="content">
            Use the calculator to see how much interest you will gain with your allocated amount.
          </p> */}
          <div className="bg" id="calculator">
            <div className="calcator-before">

              <p className="Interest-calculator">{intl.get('06.01.001-6')}</p>
              <div className="annual-saving-container">
                <div>
                  <p className='Show-Balance-Copy-6'>{intl.get('06.01.001-7')}</p>
                  <p className='Show-Balance-Copy'>{this.state.inrt_level_amt}</p>
                </div>
                <div >
                  <p className="Show-Balance-Copy-6 ">{intl.get('06.01.001-8')}</p>
                  <p className="font12"><span className="Show-Balance-Copy ">{this.state.inst_rate}</span> <span className="Show-Balance-Copy-1">%</span></p>
                </div>
              </div>
              <div className='accum-annual-container'>
                <p className="Show-Balance-Copy-6">{intl.get('06.01.001-9')}</p>
                <p className='Show-Balance-Copy-2'>+{this.twoDecimal(this.state.month_inst)}</p>
              </div>

            </div>

            <Calculator data={this.props.channal4302} cb={this.getCalcData}></Calculator>

            <div className="calcator-after">
              <div className="width324">
                <ul className="inrt_level_amt_container">
                  {
                    this.props.channal4302.list01.map(item => {
                      return item.scale_display_mark === 'Y' ? <li key={item.inrt_level_amt}>{this.moneyFormat(item.inrt_level_amt)}</li> : ''
                    })
                  }

                </ul>
              </div>

              <div className="info_subheader-copy-container">
                <p className="info_subheader-copy gray ">{intl.get('06.01.001-12')}</p>
                <p className="info_subheader-copy blue">{intl.get('06.01.001-13')}</p>
              </div>
              <p className="As-of-29-January-20">{intl.get('06.01.001-14')}</p>
            </div>

          </div>

        </section>
        <section className="part3">
          <span className="Account-ready"></span>
          <p className="Title-here-title-her">{intl.get('06.01.001-15')}</p>
          <p className="description">
          {intl.get('06.01.001-16')}
          </p>
          <div className="btn-wraper">
            <Button type="primary" onClick={this.getVbAccount} >{intl.get('06.01.001-5')}</Button>
            <p className="pdt"></p>
            {/* <Button onClick={this.Share} >Share</Button> */}
          </div>
        </section>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  channal4302: state.saving.channal4302
})

const mapDispatchToProps = (dispatch) => ({
  // 存款产品分层利率数组信息查询
  queryChannal4302: (payload) => {
    dispatch({
      payload,
      type: 'REQUEST_4302'
    })
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DefaultCustomer)