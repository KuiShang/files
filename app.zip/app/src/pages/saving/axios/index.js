/*eslint-disable*/
import axios from 'axios'
// 全局超时时间
axios.defaults.timeout = 150000
axios.defaults.baseURL = ''
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
// axios.defaults.headers.common['Authorization'] = 'AUTH_TOKEN';
if (process.env.NODE_ENV !== 'production') {
  // axios.defaults.headers.common['ticket'] = '0c613a00-fbe5-46cd-8144-82d66768b60c';
  axios.defaults.headers.common['uuid'] = Date.now()+ '';
  axios.defaults.headers.common['cust_no'] = '100000002801';
  axios.defaults.headers.common['simpleDeviceInfo'] = JSON.stringify({"language":"zh-CN"});
  axios.defaults.headers.common['userId'] = 'UserId1';
  axios.defaults.headers.common['custNo'] = '100000002801';
  // axios.defaults.headers.common.deviceInfo = JSON.stringify({"deviceModel":"OS105","deviceType":"APP","language":"en_US"});
}
// 添加请求拦截器
axios.interceptors.request.use((config) => {
  if (config.method == 'get') {
    config.data = true
    config.headers['Content-Type'] = 'application/json'
  }

  // 在发送请求之前做些什么
  if (config.method === 'post') {
    console.info(`入参${config.url} :`, config.method, config.data)
  } else {
    console.info(`入参${config.url} :`, config.method, config.params)
  }
  // config.url = `/api${config.url}`
  return config
}, (error) => {
  // 对请求错误做些什么
  console.info('request error', error)
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
 
  // 对响应数据做点什么
  if (response.status !== 200) {
    console.info('router.push({ name: error })')
  }
  console.info(`返回response :`, response)
  console.info(`返回${response.config.url} :`, response.data)
  response.data.resultCode = Number(response.data.resultCode)
  if (response.data.errorData) {
    // return Vue.$SDK.goNativeAction(response.data.actionData)
    // 不能在此处统一处理未登录， 因为具体的业务页面跳转到登录页 登陆后 在跳转回来的时候 需要在具体的页面在调用相应的初始化方法 
  }
  return response
}, function (error) {
  console.info('error', error.response)
  return Promise.reject(error)
})
export default axios
