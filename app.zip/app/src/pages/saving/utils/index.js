/*eslint-disable*/


/*
* 获取系统信息
* getSysType(str)
* */
export function getSysType (str) {
    var ua = navigator.userAgent.toLowerCase();
    var isIOS = ua.indexOf('ipad') > -1 || ua.indexOf('iphone') > -1 || false;
    var isAndroid = ua.indexOf('android') > -1 || false;
    // var isJdApp = ua.indexOf('ijr') > -1 || false;
   
    if (isAndroid) {
      var debugI18n = ua.indexOf('language_debug') > -1 || false;
    } else if(isIOS) {
      var debugI18n = ua.indexOf('language_debug=1') > -1 || false;
    } else {
      var debugI18n = false;
    }
    
    var isJdApp = ua.indexOf('t1w') > -1 || false;
    var result = {
        isIOS: isIOS,
        isAndroid: isAndroid,
        isJdApp: isJdApp,
        debugI18n: debugI18n
    }
    return str ? result[str] : result;
  }
  
  /** 
   * 获取设备信息
  */
  export function getClineInfo (){
      var appCookieInfoStr = getCookie('jdidappinfo').replace(/%3A/g,':').replace(/%2C/g, ',').replace('{', '').replace('}', '');
      var deviceInfo = {};
      if(appCookieInfoStr) {
        var cookieArr = appCookieInfoStr.split(',"')
        var cookieJson = {}
    
        cookieArr.forEach(function(item, index){
          var _item = item.replace(/"/g,'')
          var itemArr = _item.split(':');
          cookieJson[itemArr[0]] = itemArr[1]
        })
    
        var channel = getSysType("isAndroid") ? '02' : getSysType("isIOS") ? '01' : '04';
        switch(channel){
          case "02":
            deviceInfo.deviceId = cookieJson.jdiduuid || '';
            break;
          case "01":
            deviceInfo.deviceId = cookieJson.jdididfa || '';
            break;
          default:
            deviceInfo.deviceId = '';
            break;
        }
        deviceInfo.deviceType = cookieJson.jdidos || ''; // 设备型号
        deviceInfo.osVersion = cookieJson.jdiddevice || '';
        deviceInfo.appChannel = ''; // 安装应用商店
        deviceInfo.appVersion = cookieJson.jdidappver || ''; // 应用版本信息
        deviceInfo.clientName = '';// 客户端类型
        deviceInfo.longitude = ''; // 经度
        deviceInfo.latitude = ''; // 纬度
        deviceInfo.imei = cookieJson.jdiduuid || '';
        deviceInfo.idfa = cookieJson.jdididfa || '';
        deviceInfo.idfv = cookieJson.jdididfv || ''; // ios设备信息idfv
        deviceInfo.traceIp = cookieJson.jdidip || ''; // 外网IP地址
        deviceInfo.macAddress = cookieJson.jdidmac || ''; // MAC地址
    
        return deviceInfo;
      } else{
        return {}
      }
    
  }
  
  //JS操作cookies方法!
  //写cookies
  export function setCookie(name,value) {
    var Days = 30;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days*24*60*60*1000);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
  }
  
  /**
   * 获取浏览器cookie
   * @param {*} name 
   * @param {*} defaultValue 
   */
  export function getCookie(c_name) {
    if (document.cookie.length > 0) {
      var c_start = document.cookie.indexOf(c_name + "=")
      if (c_start != -1) {
        c_start = c_start + c_name.length + 1
        var c_end = document.cookie.indexOf(";", c_start)
        if (c_end == -1) c_end = document.cookie.length
        return decodeURI(document.cookie.substring(c_start, c_end))
      }
    }
    return ""
  };
  
  /**
   * 
   * 7500 --> 7,500 钱千分位修改
   * 
   * @param {any} num 
   * @param {any} cent 
   * @param {any} isThousand 
   * @returns 
   */
  export function thousandBitSeparator (num, cent, isThousand) {
  if(Number(num) < 0){
          return 0;
      }
    if(num){
      num = num.toString().replace(/\$|\,/g,'');
      if(''==num || isNaN(num)){return 'Not a Number ! ';}
      var sign = num.indexOf("-")> 0 ? '-' : '';
      var cents = num.indexOf(".")> 0 ? num.substr(num.indexOf(".")) : '';
      cents = cents.length>1 ? cents : '' ;
      num = num.indexOf(".")>0 ? num.substring(0,(num.indexOf("."))) : num ;
      if('' == cents){ if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}
      else{if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}
      for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
          num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
      }
      return (sign + num + cents);    
    }else{
      return num;
    }
  }
  
  /**
   * 
   * 对数字 保留两位小数
   * @returns 
   */
  export function returnFloat(value1) {
    var value=Math.round(parseFloat(value1)*100)/100;
    var xsd=value.toString().split(".");
    if(xsd.length==1){
    value=value.toString()+".00";
    return value;
    }
    if(xsd.length>1){
    if(xsd[1].length<2){
    value=value.toString()+"0";
    }
    return value;
    }
  }
  
  /**
   * 
   * 对数字 保留两位小数 方法二
   * @returns 
   */
  export function returnFloat2(value) {
    return Number(value).toFixed(2)
  }
  
  /**
   * 
   * 输入框只允许输入纯数字和小数点
   * @returns 
   */
  export function onlyNum(value) {
    let val = value
    val = val.replace(/[^\d.]/g, '') //清除“数字”和“.”以外的字符
    val = val.replace(/\.{2,}/g, '.') //只保留第一个. 清除多余的 连续两个
    val = val.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.') //只保留第一个. 清除多余的 非连续两个
    val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3') //只能输入两个小数
    if(val.indexOf('.')< 0 && val != ''){ //以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
      val = parseFloat(val)
    }
    return val
  }
  
  /**
   * 
   * 从浏览器地址栏截取参数
   */
  export function getQueryString(name) {
    const reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    const locationHash = window.location.hash;
    const indexQuestion = locationHash.indexOf('?') + 1;
    const r = locationHash.substring(indexQuestion).match(reg);
    if(r!=null) return  decodeURIComponent(r[2]); return null;
  }
  
  /**
   * 
   * 设置跳转链接
   */
  export function setJumpUrl(data, jumpParams) {
    if (!data || JSON.stringify(data) === '{}') {
      return '';
    }
    if (data.jumpType === 0) {
      return '';
    }
    const query = JSON.parse(data.jumpDataTemplate);
    let querySearch = [];
    if (JSON.stringify(query) !== '{}') {
      for (const prop in query) {
        let searchStr = '';
        if (Object.prototype.hasOwnProperty.call(query, prop)) {
          searchStr += prop;
          searchStr += '=';
          searchStr += query[prop];
          querySearch.push(searchStr);
        }
      }
    }
    if (getSysType('isJdApp')) {
      if (data.jumpType === 1) {
        // 原生跳转
        return {
          type: 'native',
          address: data.nativeJumpUrl,
          params: JSON.parse(data.jumpDataTemplate)
        };
      } else if (data.jumpType === 2) {
        // H5跳转
        if (jumpParams) {
          return {
            type: 'native',
            address: '/webview/web',
            params: jumpParams
          };
        }
        
        return {
          type: 'native',
          address: '/webview/web',
          params: {
            url: encodeURIComponent(`${data.jumpUrl}?${querySearch.join('&')}`),
            textColor: '#141E50',
            mHeaderTitle: {
              showEnd: 0
            }
          }
        }
      } else {
        return '';
      }
    } else {
      if (data.jumpType === 2) {
        // H5跳转
        return encodeURIComponent(`${data.jumpUrl}?${querySearch.join('&')}`);
      } else {
        return '';
      }
    }
    
  }
  
  /**
   * 
   * 设置see all 跳转链接
   */
  export function linkToSeeAll(pageId, params) {
    if (!params || JSON.stringify(params) === '{}') {
      return;
    }
    let query = {
      pageId,
      scence: 1,
      componentId: params.componentId,
      layoutId: params.id
    }
    if (GetQueryStringHash('display')) {
      query.display = GetQueryStringHash('display');
    }
  
    let querySearch = [];
    let routerNameStr  = '';
    if (/#\/\w+\?/.test(window.location.hash)) {
      routerNameStr = window.location.hash.match(/#\/\w+\?/g)[0];
      routerNameStr = routerNameStr.substring(2, routerNameStr.length -1);
    } else {
      routerNameStr = window.location.hash.substring(2);
    }
    if (JSON.stringify(query) !== '{}') {
      for (const prop in query) {
        let searchStr = '';
        if (Object.prototype.hasOwnProperty.call(query, prop)) {
          searchStr += prop;
          searchStr += '=';
          searchStr += query[prop];
          querySearch.push(searchStr);
        }
      }
    }
    if (getSysType('isJdApp')) {
      return {
        type: 'native',
        address: '/webview/web',
        params: {
          url: encodeURIComponent(`${window.location.origin}/#/${routerNameStr}?${querySearch.join('&')}`),
          textColor: '#141E50',
          mHeaderTitle: {
            showEnd: 0
          }
        }
      }
    } else {
      return { name: routerNameStr, query };
    }
    // return query;
  }
  
  // 从router.query中获取值
  export function GetQueryStringHash(name, u) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    let reg1 = /#\/\w+\?/g;
    let hashStr = window.location.hash;
    if (reg1.test(window.location.hash)) {
      hashStr = hashStr.replace(reg1, '');
    } else {
      return null;
    }
    var r = hashStr.match(reg);
    if (u) r = (u.split('?')[1] || '').match(reg);
    if (r) return decodeURI(r[2]);
    return null;
  }
  