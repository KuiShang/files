import axios from '../../../axios/axios';
import * as SDK from 'sdk/wrapper';
import { Base64 } from 'js-base64';

const TYPES = {
  GET: 'GET',
  POST: 'POST'
}
// 是否完成判断当前使用哪个fetch， 默认为假，在初始化完成之后为真
let initFinish = false
// 是否使用客户端request开关， true:表示使用客户端发送请求    false：表示使用h5请求
const safeFlag = true



function fetchAxiox(types, url, data) {
  axios.defaults.headers.common['uuid'] = new Date().getTime();
  // axios.defaults.headers.common['simpleDeviceInfo'] = JSON.stringify({"language": 'zh-CN'});
  // axios.defaults.headers.common['User-Agent'] = 'SimpleDeviceInfo={"appChannel":"google","appTag":"vb","appVersion":"1.1.0","appVersionCode":25,"brand":"Xiaomi","clientName":"app","deviceModel":"MI 4LTE","deviceType":"APP","language":"zh-HK","os":"Android","osVersion":"6.0.1","webVersionCode":3}';
  // axios.defaults.headers.common['userId'] = 'UserId1';
  // axios.defaults.headers.common['custNo'] = 'CustNo1';
  // axios.defaults.headers.common['Cookie'] = 'customerId=100000008303;ticket=71f34ab9-b6a8-4caf-b152-664feb4b6d91';
  data = Object.assign(data, {
    deviceInfo: window.$DeviceInfo
  })
  if (types === TYPES.GET) {
    return axios.get(url, {
      params: data
    })
  } else if (types === TYPES.POST) {
    return axios.post(url, data)
  }
  console.error('没有添加这种类型', types)
  return false
}
// type: 1- post  2- get
function fetchApp(types, url, data) {
  let type = 1
  if (types === TYPES.GET) {
    type = 2
  } else {
    type = 1
  }
  const urlAll = 'http://appgw.livibank.com' + url;////window.location.origin + url
  data = Object.assign(data, {
    deviceInfo: window.$DeviceInfo
  })
  const json = {
    url: urlAll,
    httpType: type,
    parameters: JSON.stringify(data),
    postMediaType: 'application/json',
    headerParameters: {
      t1w: 't1w',
      // 'custNo': '100000002302',
      // cust_no: '100000002101',
      simpleDeviceInfo: JSON.stringify({"language": 'zh-CN'}),
      // simpleDeviceInfo: JSON.stringify({"language": window.$DeviceInfo.language}),  app包语言问题 所以先写死
      // userId: 'UserId1',
      // custNo: '100000002101',
      // uuid : new Date().getTime()
    }
  }
  console.info('请求数据', json)
  const su = function su(ret) {
    console.info('原声app成功的ret', ret)
    const retResloved = decodeURIComponent(ret.data)
    console.info('原声app成功的ret 解析后：', JSON.parse(retResloved))
  }
  return new Promise((reslove, reject) => {
    SDK.request(json, (ret) => {
      console.info('原声app成功的ret', ret)
      console.info('Base64.decode', Base64.decode)
      if (ret.code !== 1) {
        console.info('客户端返回0， 替换成h5 ajax 再次发送个请求', Base64.decode)
        return fetchAxiox(types, url, data).then(d => reslove(d))
      }
      const retResloved = JSON.parse(Base64.decode(ret.data))
      console.info('原声app成功的ret 解析后：', retResloved)

      let strObj = ''
      let str = ''
      strObj = {
        k50: 'No internet connection, please try again',
        k40: 'System error'
      }

      if (retResloved.status === 200) {
        retResloved.data = JSON.parse(retResloved.data)
        retResloved.data.resultCode = Number(retResloved.data.resultCode)
        console.info('最终解析完成的结果：', retResloved)
        reslove(retResloved)
      } else if (retResloved.status.toString().match(/^50/)) {
        str = strObj.k50
        // Vue.$toast({
        //   message: str,
        //   position: 'bottom',
        //   duration: 2000
        // })
        // router.push({ name: 'netError' })
        reject(retResloved)
      } else if (retResloved.status.toString().match(/^40/)) {
        str = strObj.k40
        // Vue.$toast({
        //   message: str,
        //   position: 'bottom',
        //   duration: 2000
        // })
        reject(retResloved)
      } else {
        str = strObj.k40
        // Vue.$toast({
        //   message: str,
        //   position: 'bottom',
        //   duration: 2000
        // })
        reject(retResloved)
      }
      return ''
    })
  })
  // window.wallet.platform.request(json, su, er)
}

let fetch = async function d(a, b, c) {
  if (!initFinish) {
    const hasRequest = await SDK.checkHasAppRequest()
    if (safeFlag && hasRequest) {
      fetch = fetchApp
    } else {
      fetch = fetchAxiox
    }
    return fetch(a, b, c)
  }
  return fetch(a, b, c)
}

async function switchFetch() {
  const hasRequest = await SDK.checkHasAppRequest()
  console.info(`hasRequest: ${hasRequest} + safeFlag: ${safeFlag}`)
  if (safeFlag && hasRequest) {
    fetch = fetchApp
  } else {
    fetch = fetchAxiox
  }
  initFinish = true
  return fetch
}
switchFetch()



// 存款账户汇总折算余额查询
export function channal4303(data) {
    return fetch(TYPES.POST, '/cocgw/4303', data)
}
// 存款产品分层利率数组信息查询
export function channal4302(data) {
  return fetch(TYPES.POST, '/cocgw/4302', data)
}

// 存款产品利率信息查询
export function channal4301(data) {
  return fetch(TYPES.POST, '/cocgw/4301', data)
}

// 存款账户利息累计标准值减少接口（浇花）
export function channal4306(data) {
  return fetch(TYPES.POST, '/cocgw/4306', data)
}

// 存款账户交易明细接口查询
export function channal4304(data) {
  return fetch(TYPES.POST, '/cocgw/4304', data)
}

// 获取开户状态
export function channal4401(data) {
  return fetch(TYPES.POST, '/cocgw/4401', data)
}






