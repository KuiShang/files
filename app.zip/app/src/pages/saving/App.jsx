import React from 'react'
import { connect } from 'react-redux'
import VConsole from 'vconsole';
import DefaultCustomer from './components/DefaultCustomer/DefaultCustomer'
import NewCustomer from './components/NewCustomer/NewCustomer'
import './style.scss'
import intl from 'utils/react-intl-universal';
import zhCN from './i18n/zh_CN';
import zhHK from './i18n/zh_HK';
import enHK from './i18n/en_HK';
import debugI18n from './i18n/debug_i18n';

import {getSysType} from './utils';
import * as SDK from 'sdk/wrapper'

window.localeLanguage = 'en-HK';

const platformInfo = getSysType();
const isJDAPP = platformInfo.isJdApp;
const debugI18nEnv = platformInfo.debugI18n || false;

async function getAppLang() {
  const ret = await SDK.getCommonInfo()
  if (ret && !!ret.language) {
    window.localeLanguage = ret.language;
  }
}
// ********* 设置环境变量 *********
// 获取当前Native的
(isJDAPP == true && debugI18nEnv) ?  window.localeLanguage = 'debug-i18n' : getAppLang();
if (debugI18nEnv) {
  var vConsole = new VConsole();
}

class App extends React.Component {
  constructor(props) {
		super(props)
		this.state = {
			initDone: false
		}
	}
  async componentDidMount() {
    this.loadLocales()
  }
  
  loadLocales() {
    intl.init({
    currentLocale: window.localeLanguage, // TODO: determine locale here
    locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK,
                "debug-i18n": debugI18n
            }
    })
    .then(() => {
        this.setState({initDone: true});
    });
}
  render() {
    console.info(this.props)
    let currentComponent = null
    if (this.props.route.path === '/l1' || this.props.route.path === '/l2'  || this.props.route.path === '/') {
      currentComponent = <DefaultCustomer level = {this.props.route.path}/>
    } else if (this.props.route.path === '/l3') {
      currentComponent = <NewCustomer level = {this.props.route.path} />
    }
    return (
      this.state.initDone && 
      <div className="saving">
        {currentComponent}
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  
})

const mapDispatchToProps = (dispatch) => ({
  // queryChannal4401: (payload) => {
  //   dispatch({
  //     payload,
  //     type: 'REQUEST_4401'
  //   })
  // },
 
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)
