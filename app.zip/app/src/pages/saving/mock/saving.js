export default function saving(mock) {
  // 存款账户汇总折算余额查询  没有存款
  mock.onPost('/cocgw/4303aaaaa').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      acct_no: "0258000008010",
      conv_amt_sum: 0,
      exchange_ccy_code: "HKD",
      list01: [
        {
          acct_bal: 0,
          acct_current_level_inrt: 0.09,
          acct_current_level_inrt_amt: 0,
          acct_next_level_inrt: 0.24,
          acct_next_level_inrt_amt: 2000,
          ccy_code: "HKD",
          inrt_level: 1,
          last_date_instam: 6.093,
          next_level_inrt_add_amt: 2000,
          sub_acct_no: "1000000401",
          year_sum_instam: 0,
        }
      ]


    }
  })
  // 存款账户汇总折算余额查询 没有存款
  mock.onPost('/cocgw/4303').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      acct_no: "0258000010025",
      conv_amt_sum: 14990.5,
      exchange_ccy_code: "HKD",
      list01: [
        {
          acct_bal: 14990.5,
          acct_current_level_inrt: 0.8,
          acct_current_level_inrt_amt: 10000,
          acct_next_level_inrt: 1,
          acct_next_level_inrt_amt: 20000,
          ccy_code: "HKD",
          inrt_level: 4,
          next_level_inrt_add_amt: 5009.5,
          stad_sum_round_inst: 0,
          sub_acct_no: "1000000602",
          sum_round_inst: 200,
          year_sum_instam: 0
        }
      ]


    }
  })

    // 存款账户汇总折算余额查询 没有存款
    mock.onPost('/cocgw/4303').reply(200, {
      "resultData": {
       "list01": [{
        "next_level_inrt_add_amt": 0,
        "stad_sum_round_inst": 0,
        "inrt_level": 1,
        "ccy_code": "HKD",
        "year_sum_instam": 0.00,
        "sum_round_inst": 0,
        "last_date_instam": 6.10,
        "acct_current_level_inrt": 0.125000,
        "sub_acct_no": "1000000201",
        "acct_bal": 200001.00
       }],
       "acct_no": "0258000002018",
       "exchange_ccy_code": "HKD",
       "conv_amt_sum": 200001.00
      },
      "resultCode": 1
     })


  // 存款产品分层利率数组信息查询
  mock.onPost('/cocgw/4302').reply(200, {"resultData":{"inrt_code":"CASA-201-HNA","list01":[{"month_add_inst":0E-8,"inst_rate":0.050000,"inrt_level_amt":0,"month_inst":0E-8,"mark_avg_inst":0.000000,"scale_display_mark":"Y","mark_avg_inrt":0.00},{"month_add_inst":0.33360000,"inst_rate":0.200000,"inrt_level_amt":2000,"month_inst":0.33360000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":0.66720000,"inst_rate":0.200000,"inrt_level_amt":4000,"month_inst":0.66720000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":2.50020000,"inst_rate":0.500000,"inrt_level_amt":6000,"month_inst":2.50020000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":3.33360000,"inst_rate":0.500000,"inrt_level_amt":8000,"month_inst":3.33360000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":6.66600000,"inst_rate":0.800000,"inrt_level_amt":10000,"month_inst":6.66600000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":7.99920000,"inst_rate":0.800000,"inrt_level_amt":12000,"month_inst":7.99920000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":9.33240000,"inst_rate":0.800000,"inrt_level_amt":14000,"month_inst":9.33240000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":10.66560000,"inst_rate":0.800000,"inrt_level_amt":16000,"month_inst":10.66560000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":11.99880000,"inst_rate":0.800000,"inrt_level_amt":18000,"month_inst":11.99880000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":16.66800000,"inst_rate":1.000000,"inrt_level_amt":20000,"month_inst":16.66800000,"mark_avg_inst":0.000000,"scale_display_mark":"Y","mark_avg_inrt":0.00},{"month_add_inst":18.33480000,"inst_rate":1.000000,"inrt_level_amt":22000,"month_inst":18.33480000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":20.00160000,"inst_rate":1.000000,"inrt_level_amt":24000,"month_inst":20.00160000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":21.66840000,"inst_rate":1.000000,"inrt_level_amt":26000,"month_inst":21.66840000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":23.33520000,"inst_rate":1.000000,"inrt_level_amt":28000,"month_inst":23.33520000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":25.00200000,"inst_rate":1.000000,"inrt_level_amt":30000,"month_inst":25.00200000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":26.66880000,"inst_rate":1.000000,"inrt_level_amt":32000,"month_inst":26.66880000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":28.33560000,"inst_rate":1.000000,"inrt_level_amt":34000,"month_inst":28.33560000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":30.00240000,"inst_rate":1.000000,"inrt_level_amt":36000,"month_inst":30.00240000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":31.66920000,"inst_rate":1.000000,"inrt_level_amt":38000,"month_inst":31.66920000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":33.33600000,"inst_rate":1.000000,"inrt_level_amt":40000,"month_inst":33.33600000,"mark_avg_inst":0.000000,"scale_display_mark":"Y","mark_avg_inrt":0.00},{"month_add_inst":35.00280000,"inst_rate":1.000000,"inrt_level_amt":42000,"month_inst":35.00280000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":36.66960000,"inst_rate":1.000000,"inrt_level_amt":44000,"month_inst":36.66960000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":38.33640000,"inst_rate":1.000000,"inrt_level_amt":46000,"month_inst":38.33640000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":40.00320000,"inst_rate":1.000000,"inrt_level_amt":48000,"month_inst":40.00320000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":41.67000000,"inst_rate":1.000000,"inrt_level_amt":50000,"month_inst":41.67000000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":43.33680000,"inst_rate":1.000000,"inrt_level_amt":52000,"month_inst":43.33680000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":45.00360000,"inst_rate":1.000000,"inrt_level_amt":54000,"month_inst":45.00360000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":46.67040000,"inst_rate":1.000000,"inrt_level_amt":56000,"month_inst":46.67040000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":48.33720000,"inst_rate":1.000000,"inrt_level_amt":58000,"month_inst":48.33720000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":50.00400000,"inst_rate":1.000000,"inrt_level_amt":60000,"month_inst":50.00400000,"mark_avg_inst":0.000000,"scale_display_mark":"Y","mark_avg_inrt":0.00},{"month_add_inst":51.67080000,"inst_rate":1.000000,"inrt_level_amt":62000,"month_inst":51.67080000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":53.33760000,"inst_rate":1.000000,"inrt_level_amt":64000,"month_inst":53.33760000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":55.00440000,"inst_rate":1.000000,"inrt_level_amt":66000,"month_inst":55.00440000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":56.67120000,"inst_rate":1.000000,"inrt_level_amt":68000,"month_inst":56.67120000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":58.33800000,"inst_rate":1.000000,"inrt_level_amt":70000,"month_inst":58.33800000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":60.00480000,"inst_rate":1.000000,"inrt_level_amt":72000,"month_inst":60.00480000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":61.67160000,"inst_rate":1.000000,"inrt_level_amt":74000,"month_inst":61.67160000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":63.33840000,"inst_rate":1.000000,"inrt_level_amt":76000,"month_inst":63.33840000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":65.00520000,"inst_rate":1.000000,"inrt_level_amt":78000,"month_inst":65.00520000,"mark_avg_inst":0.000000,"mark_avg_inrt":0.00},{"month_add_inst":66.67200000,"inst_rate":1.000000,"inrt_level_amt":80000,"month_inst":66.67200000,"mark_avg_inst":0.000000,"scale_display_mark":"Y","mark_avg_inrt":0.00}],"prod_id":"CA01","prod_name":"Personal  Current  Account"},"resultCode":1})

  // 存款产品利率信息查询
  mock.onPost('/cocgw/4301').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      prod_id: '4561321564',
      prod_name: 'saving product',
      inrt_code: '003',
      list01: {
        mark_avg_inrt: 1.2,
        inrt_level_amt: 40,
        inrt_rate: 0.68
      }
    }
  })
  // 存款账户利息累计标准值减少接口（浇花）
  mock.onPost('/cocgw/4306').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      inst_level_value: 2
    }
  })
  // 存款账户交易明细接口查询
  mock.onPost('/cocgw/4304').reply(200, { "resultData": { "list01": [{ "back_value_date": "20181128", "trxn_ccy": "HKD", "trxn_branch": "1234", "summary_value_three": "HKD SAVING", "debit_credit": "C", "trxn_teller": "88880001", "trxn_date": "20181128", "opp_card_no": "", "summary_code": "TRD", "host_date": "20190411", "trxn_record_type": "1", "trxn_seq": "2018112802580000000013334", "cash_trxn_ind": "T", "trxn_time": "15:56:24 127", "bal_after_trxn": 5000.00, "opp_branch_id": "1234", "summary_value_one": "Transfer In 12343440000001100013", "opp_branch_name": "", "trxn_amt": 5000.00, "picture_tag": "1", "trxn_status": "N", "summary_value_two": "", "acct_no": "0258000010025", "summary_name": "Top Up Incentive", "serial_no": 2, "sub_acct_seq": "00001", "opp_acct_no": "12343440000001100013", "trxn_channel": "107" }, { "customer_remark": "", "back_value_date": "20181128", "trxn_branch": "1234", "agent_name": "", "trxn_area_ccy": "", "debit_credit": "D", "trxn_teller": "88880001", "opp_acct_ccy": "HKD", "opp_card_no": "", "summary_code": "TRD", "trxn_record_type": "1", "trxn_seq": "2018112802580000000013340", "cash_trxn_ind": "T", "trxn_area_exch_rate": 0E-7, "real_opp_acct_name": "", "bal_after_trxn": 4999.00, "agent_doc_type": "", "trxn_area": "", "opp_branch_id": "", "opp_branch_name": "", "acct_no": "0258000010025", "real_opp_bank_id": "", "serial_no": 3, "agent_doc_no": "", "trxn_ccy": "HKD", "real_opp_country": "", "summary_value_three": "HKD SAVING", "trxn_date": "20181128", "agent_country": "", "consume_date": "", "trxn_remark": "", "real_opp_bank_name": "", "host_date": "20190411", "trxn_area_amt": 0.00, "real_opp_acct_alias": "", "real_opp_acct_no": "", "trxn_time": "16:00:29 219", "real_opp_remark": "", "third_party_date": "", "summary_value_one": "Transfer In 12343441210000500019", "trxn_amt": 1.00, "real_opp_branch_name": "", "picture_tag": "1", "trxn_status": "N", "summary_value_two": "", "opp_sub_acct_seq": "", "summary_name": "Export remittance", "sub_acct_seq": "00001", "opp_acct_no": "12343441210000500019", "trxn_channel": "107" }] }, "resultCode": 1 })

}