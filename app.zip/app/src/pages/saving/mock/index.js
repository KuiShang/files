import saving from './saving'
var axios = require('axios')

var MockAdapter = require('axios-mock-adapter')

var mock = new MockAdapter(axios, {
    delayResponse: 1000
})

saving(mock)