import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, hashHistory } from 'react-router';
import createSagaMiddleware from 'redux-saga'
import { Provider } from 'react-redux';
import { applyMiddleware, createStore, compose } from 'redux'
import initReactFastclick from 'react-fastclick';

import App from './App.jsx';
import * as serviceWorker from '../../serviceWorker';
import './reset.css'
import './rem.js'
import './mock'

import rootSaga from './redux/saga'
import reducer from './redux/reducers'

import { getSysType } from 'utils/utils';
import * as SDK from 'sdk/wrapper'


initReactFastclick();
// 初始化native相关
const platformInfo = getSysType();
const isJDAPP = platformInfo.isJdApp;
window.$SDK = SDK;

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const sagaMiddleware = createSagaMiddleware()
const store = createStore(reducer, /* preloadedState, */ composeEnhancers(applyMiddleware(sagaMiddleware)));
sagaMiddleware.run(rootSaga)

async function initAppData() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        console.info('公用設備信息:', ret)
        window.$DeviceInfo = ret
    } else {
        // 兼容处理 防止在h5页调试的时候 页面会报错
        window.$DeviceInfo = {
            androidUuid: 'AndroidUuid',
            appChannel: 'AppChannel',
            appVersion: 'AppVersion',
            language: 'zh-CN'
        }
    };

    ReactDOM.render(
        <Provider store={store}>
            <Router history={hashHistory}>
                <Route path={'/'} components={App}></Route>
                <Route path={'/l1'} components={App}></Route>
                <Route path={'/l2'} components={App}></Route>
                <Route path={'/l3'} components={App}></Route>
            </Router>
        </Provider>, document.getElementById('root')
    );
}

initAppData();
serviceWorker.unregister();
