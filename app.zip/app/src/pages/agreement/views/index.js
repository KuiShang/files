import React from 'react';
import intl from 'utils/react-intl-universal';
import styled from  'styled-components'
import Button from './button'
import { Base } from 'utils/base64';
import { urlStr2Json } from 'utils/utils';
import {getProtocolDetail, getProtocolDetailModel}  from 'api/protocol';




const Container = styled.div`
  width: 100%;
  box-sizing: border-box;
  height: 100vh;
  max-height: calc(100% - .76rem);
  font-family: SFUIDisplay, DroidSans, Arial;
  font-size: .12rem;
  color: #484848;
  line-height: .16rem;
  padding: .2rem .2rem .84rem
`

const ButtonContainer = styled.div`
  width: 100%;
  position: relative;
  bottom: -0.2rem;
  text-align: center;
  button{
    &:first-child{
      margin-right: 10px;
    }
  }
`
const ContentWrapper = styled.div`
  font-size: .14rem;
  color: #484848;
  height: 100%;
  overflow-y: auto;
  line-height: .2rem;
`

export default class Home extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      isReadAll: false, // 用来存储是否下拉完成
      agreementContent: '',
      contentRef: React.createRef(),
      times: 1
    }
  }

  static getDerivedStateFromProps(nextProps, prevState){
    try {
      console.log(urlStr2Json(decodeURIComponent(Base.decode(window.location.hash.substr(3)))));
      console.log(!JSON.parse(isSign));
    } catch (error) {
      
    }
    const {
      agreementNo,
      agreementVersion,
      type,
      designType, // 1为交互1 2为交互2
      isSign
    } = urlStr2Json(decodeURIComponent(Base.decode(window.location.hash.substr(3)))) || {}
    const { contentRef } = prevState
    const CurrentContent = contentRef.current

    window.$SDK.setTitle({
      title:  intl.get('01.04.036-1'), // 需要一个通用的title
      mHeaderTitle: {
        showEnd: 0,
        showBack: designType == 1 ? 1 : 0
      }
    })

    designType == 1 && window.$SDK.onBackPress( () => {
      window.$SDK.closeWebViewAndSendResult({ resultCode: 1})
    })
    
    return {
      // isReadAll: CurrentContent && CurrentContent.offsetHeight + CurrentContent.scrollTop >= CurrentContent.scrollHeight,
      isSign,
      agreementNo,
      agreementVersion,
      designType,
      type
    };
  } 

	async componentDidMount() {
    const {
      agreementNo,
      agreementVersion,
      type,
    } = this.state;
		if(type == 1) {
			// 通用协议
			var res = await getProtocolDetail({
        agreementNo,
        agreementVersion
      })
		} else {
			// 个人协议
			var res = await getProtocolDetailModel({
        agreementNo,
        agreementVersion
      })
		}
    if (res.data.resultCode === 1) {
			const agreementContent = res.data.resultData.agreementContent || '';
      this.setState({ agreementContent })
    }
  }
  componentDidUpdate() {
    if (this.state.times !== 1) return;
    const CurrentContent = this.state.contentRef.current;
    const isReadAll = CurrentContent && CurrentContent.offsetHeight + CurrentContent.scrollTop >= CurrentContent.scrollHeight;
    this.setState({isReadAll: isReadAll,times: 2})

  }
  agree() {
    window.$SDK.closeWebViewAndSendResult({ resultCode: 1})
  }

  cancel() {
    window.$SDK.closeWebView()
  }

  scrollContent() {
    const {
      contentRef,
      designType,
      isSign,
      isReadAll
    } = this.state
    const CurrentContent = contentRef.current
    if(designType == 2 && isSign && !JSON.parse(isSign) && !isReadAll ) {
      const readResult = 1.1 * CurrentContent.offsetHeight + CurrentContent.scrollTop >= CurrentContent.scrollHeight
      this.setState({
        isReadAll: readResult
      })
    }
  }

  render() {
    const {
      isSign,
      agreementContent,
      contentRef,
      designType,
      isReadAll
    } = this.state;
    console.info(isReadAll)
    return (
      <Container>
        <ContentWrapper onScroll={ ()=>this.scrollContent() } ref={contentRef} dangerouslySetInnerHTML={{__html: agreementContent}} />
        { designType == 2 ? <ButtonContainer> 
          <Button disabled={isSign && !JSON.parse(isSign) && !isReadAll} onClick={ ()=>this.agree() } type='primary' width={'45%'}>
            { intl.get('01.04.036-2') }
          </Button>
          <Button width={'45%'} onClick={ ()=>this.cancel() } type='default'>
            { intl.get('01.04.036-3') }
          </Button>
        </ButtonContainer> : '' }
      </Container>
    )
  }
} 