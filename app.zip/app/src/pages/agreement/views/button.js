import React from 'react'
import styled from 'styled-components'
import PropTypes from 'prop-types';

const ButtonWrapper = styled.button`
  width: ${props => props.width || '100%'};
  height: ${props => props.height || '.48rem'};
  font-size: .16rem;
  font-family: SFUIDisplay, DroidSans, Arial;
  border-radius: .04rem;
  border: 1px solid transparent;
  outline: none;
  &.btn-default {
    border: 1px solid #a5a9ad;
    background-color: #fff;
    color: #484848;
  }
  &.btn-primary {
    background-color: #2b3d5d;
    color: #08ffd5;
  }
  &:active {
    opacity: .8;
  }
  &[disabled]{
    background-color: #f3f3f4;
    color: #dfe1e2;
  }
`

export default class Button extends React.Component {
  static propTypes = {
    type: PropTypes.string,
    onClick: PropTypes.func
  }

  static defaultProps = {
    type: 'default',  //primary
    onClick: () => {}
  }

  classNames(clsObj) {
    return Object.entries(clsObj).filter(([k,v]) => v).map(([k,v]) => k).join(' ')
  }
  
  render() {
    const {
      width,
      disabled,
      type,
      onClick
    } = this.props

    const cls = this.classNames({
      'btn-primary': type == 'primary',
      'btn-default': type == 'default',
    })
    
    return (
      <ButtonWrapper className={cls} {...this.props}>
        {this.props.children}
      </ButtonWrapper>
    )
  }
}