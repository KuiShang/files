import React from 'react';
import VConsole from 'vconsole';
// 国际化语言模块
import intl from 'utils/react-intl-universal';
import zhCN from './i18n/zh_CN';
import zhHK from './i18n/zh_HK';
import enHK from './i18n/en_US';
import debugI18n from './i18n/debug_i18n';
import * as SDK from 'sdk/wrapper';

import Home from './views/index';
import './assets/css/reset.css';
import './assets/js/rem.js';

require('mock/index.js')

window.localeLanguage = 'en-HK';
const platformInfo = SDK.getSysType();
const debugI18nEnv = platformInfo.debugI18n || false;
const isJDAPP = platformInfo.isJdApp;

async function getAppLang() {
  if (isJDAPP) {
    const ret = await SDK.getCommonInfo();
    console.info(`当前语言类型是${ret.language}`);
    if (!!ret.language) {
      window.localeLanguage = ret.language;
    }
  }
}

(isJDAPP == true && debugI18nEnv) ?  window.localeLanguage = 'debug-i18n' : getAppLang();
if (debugI18nEnv) {
  new VConsole();
}

export default class App extends React.Component {
	constructor(props) {
		super(props)
		this.state = {
      		initDone: false
		}
  }
  componentDidMount() {
    this.loadLocales()
  }
  	loadLocales() {
		intl.init({
		currentLocale: window.localeLanguage,
		locales: {
			"en-HK": enHK,
			"zh-CN": zhCN,
			"zh-HK": zhHK,
			"debug-i18n": debugI18n
		}
		})
		.then(() => {
			this.setState({ initDone: true });
		});
	}
  	render() {
		return (
			this.state.initDone && <Home/>
		)
	}
}
