const en_US = {
    "01.04.036-1": "Terms of Service",
    "01.04.036-2": "Agree",
    "01.04.036-3": "Cancel"
}
export default en_US;