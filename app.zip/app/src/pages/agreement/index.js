import React from 'react';
import ReactDOM from 'react-dom';
import VConsole from 'vconsole';
import App from './App'
import * as serviceWorker from 'serviceWorker';
import initReactFastclick from 'react-fastclick';
import { getSysType } from 'utils/utils';
import * as SDK from 'sdk/wrapper'

// 300ms延迟
initReactFastclick();

// 初始化native相关
const platformInfo = getSysType();
const isJDAPP = platformInfo.isJdApp;
const debugI18nEnv = platformInfo.debugI18n || false;
if (debugI18nEnv) {
    var vConsole = new VConsole();
}

window.$SDK = SDK;
// 报错 所以注释
async function initAppData() {
    if (isJDAPP) {
      const ret = await window.$SDK.getCommonInfo()
      window.$DeviceInfo = ret
    } else {
        // 兼容处理 防止在h5页调试的时候 页面会报错
        window.$DeviceInfo = {
            androidUuid: 'AndroidUuid',
            appChannel: 'AppChannel',
            appVersion: 'AppVersion',
            language: 'zh-CN'
        }
    };

    // react 渲染dom
    ReactDOM.render(<App style={{'height': `${document.documentElement.clientHeight}`}}/>, document.getElementById('root'));
}

initAppData();
serviceWorker.unregister();
