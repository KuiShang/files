import { combineReducers } from 'redux'
import interlocution from './interlocution'
const reducer = combineReducers({
    interlocution
})
export default reducer
