import React from 'react';
import './FAQList.scss';
import { Link } from 'react-router';

// 不分组的列表
export default class accountSetting extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      menuDatas: []
    }
  }
  componentDidMount() {
    if(!!this.props.FAQlistData) {
      this.setState({menuDatas: this.props.FAQlistData.faqQuestions || []})
    }
  }
  componentWillReceiveProps(nextProps) {
    this.setState({menuDatas: nextProps.FAQlistData.faqQuestions || []})
  }
  render() {
    return (
      <div className="help-support-list-2">
        <header className="choice-fqa">
          <ul>
            {
              (this.state.menuDatas || []).map((item, index) => 
                <Link to={{ pathname: '/ShowHtmlDetail', state : { type: this.renderMenuContentMessageDeatil(item) }}} key={ index }>
                <li  key = { index } className="clearFix">
                  {/* 将每个item传入函数展示文案中 */}
                  <p>{ this.renderMenuTitleMessage(item) }</p>
                  <i>
                    <img src={require('./next@2x.png')} alt=" " />
                  </i>
                </li>
              </Link>
              )
            }
          </ul>
        </header>
      </div>
    );
  }
  // 判断设备语言 来进行国际化筛选， 如果没有就默认走中文繁体
  renderMenuTitleMessage(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.titleEnglish
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.titleSimple
      )
    } else {
      return (
        item.titleTraditional
      )
    }
  }
  // contentSimpleUrl
  renderMenuContentMessageDeatil(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.contentEnglishUrl
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.contentSimpleUrl
      )
    } else {
      return (
        item.contentTraditionalUrl
      )
    }
  }
}