import React from 'react'
import './LiveChat.scss'
import intl from 'utils/react-intl-universal'
import { getLiveChatUrl }  from 'api/accountSetting'

export default class LiveChat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isShowState: false
    };
  }
  render() {
    return (
      <footer className="contact-us fr">
        <div className="tel" onClick={() => this.handleClick()}>
          <img className="liveChat" src={require('./customers.png')} alt=" " />
          <span>{ intl.get('05.01.004-2') }</span>
        </div>
      </footer>
    )
  }
  /**
   * 跳转客服系统，请求服务端地址
   */
  async handleClick () {
    console.info('跳转客服系统，请求服务端地址')
    const res = await getLiveChatUrl({
      
    })
    console.info('跳转客服系统，请求服务端地址 ******* res')
    console.info(res)
    if (res.data.resultCode === 1) {
      try {
        window.location = res.data.resultData;
      } catch (error) {
      }
      //处理逻辑
    }
  }
}