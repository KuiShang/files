import React from 'react'
import './ShowHtmlDetail.css'

const showHtml = `<section class="s_card z_c1">
<!--正文_s-->
<article class="art_box">
    <!--标题_s-->
    <h1 class="art_tit_h1">发生了什么？白宫停止援助瓜伊多，只因发现大批导弹            </h1>
    <!--标题_e-->
    <!--关注_s-->
    <section>
        <figure class="weibo_info look_info" data-uid="6730943895" data-key="7a7efc552150ca7a8288ee9284b5eaa0" data-time="1551786572">
            <a href="http://k.sina.cn/media_6730943895.html">
                <em class="weibo_img">
                    <img class="img_width" src="https://n.sinaimg.cn/sinacn00/240/w120h120/20181013/e906-hmhhnqs1923360.jpg">
                    <span class=""></span>
                </em>
            </a>
            <figcaption class="weibo_detail">
                <h2 class="weibo_user">辉煌建林</h2>
                <em class="look_logo"></em>
                <time class="weibo_time">
                    <span class="weibo_time_day">03月05日</span>09:40</time>
                                            <a class="look_sub j_article_wbreco" href="javascript:void(0)"><span class="icon_add look_sub_ic"></span>关注</a>
                
            </figcaption>
        </figure>
    </section>
    <!--背景浮层-->
    <section class="fl_bg j_float_bg hide"></section>
    <!--确认弹出框-->
    <section class="fl_popup j_float_wbro hide">
        <h3 class="fl_popup_tit">确定不再关注此人吗</h3>
        <aside class="fl_popup_bottom"><a class="fl_popup_bottom_a" data-content="yes" href="javascript:void(0)">确定</a><a class="fl_popup_bottom_a" data-content="no" href="javascript:void(0)">取消</a></aside>
    </section>
    <!--关注_e-->
    <div id="wx_pic" style="margin:0 auto;display:none;">
        <img src="//n.sinaimg.cn/default/2fb77759/20151125/320X320.png">
    </div>
    <section class="art_pic_card art_content" data-sudaclick="kandian_a" data-sudatagname="a">
        <p><font>前一段时间，白宫一直致力于援助瓜伊多，只为了让马杜罗立马下台。美国为了这件事也是耗费了许多资源，甚至援助了一批又一批的食物以及必须的医疗资源，企图为瓜伊多打响名声。然而，就在这样的形势之下，美国突然停止了帮助，难道是想放弃吗？</font></p><p></p><figure><p><img src="//n.sinaimg.cn/sinacn10109/220/w640h380/20190305/9ccd-htwhfzs0400497.jpg" alt="发生了什么？白宫停止援助瓜伊多，只因发现大批导弹" class="finpic"></p></figure><p></p><p><font>瓜伊多是一个年轻人，虽已入政治领域但仍然不过三十而立而已。他早年是工人家庭出身，也并不富裕，但是他在学习过程中十分的努力向上，最终获得了前往美国乔治大学的进修机会。在那里&nbsp;，他认识他的同学萨卡什维利，他们的友谊十分美好。</font></p><p><font>这个人也是一个并不陌生的名字。在2015年，瓜伊多开始崭露头角，然而在一场活动中却不幸被警察的一颗子弹击中，生命十分危险。也是因为这次活动，他开始对杜罗马产生了怨言，并且开始反对他。正是在美国的留学经历，使的瓜伊多早期过的顺风顺水。</font></p><p></p><figure><p><img src="//n.sinaimg.cn/sinacn10109/232/w640h392/20190305/adfe-htwhfzs0400664.jpg" alt="发生了什么？白宫停止援助瓜伊多，只因发现大批导弹" class="finpic"></p></figure><p></p><p><font>美国为了实现自己的计划，迫切的需要杜罗马下台，因此也是花费了大量时间精力去帮助瓜伊多。不仅提供物资，还会替瓜伊多宣传，增加国际上的知名度。并且通过自己的资源，拉拢了多个国家一起宣传造势。</font></p><p><font>同时美国也在一直打击委内瑞拉的国际经济情况。不断地打击委内瑞拉赖以生存的石油能源产业，大幅度恶化其经济发展，同时断绝物资援助、这样的行为一度使得委内瑞拉的人民生活十分践行。然而这次却突然喊停，大有撒手不管的意思。</font></p><p></p><figure><p><img src="//n.sinaimg.cn/sinacn10109/235/w640h395/20190305/b4ad-htwhfzs0400870.jpg" alt="发生了什么？白宫停止援助瓜伊多，只因发现大批导弹" class="finpic"></p></figure><p></p><p><font>这是为什么呢？其实是因为美国五角大楼的一颗侦查卫星，突然发现在，在委内瑞拉的上空有一大批导弹。这可把美国吓坏了。这些导弹全都源于俄罗斯。因为杜罗马早年就和俄罗斯来往密切并且做着一系列军火生意。这次杜罗马也是抓住了机会才没有失去这个国家。</font></p><p><font>?</font></p>            </section>
    <!-- 分享模块_s -->
    <script type="text/javascript">window.STO=window.STO||{};window.STO.fw=new Date().getTime();</script>
</article>
<!--正文_e-->
<!-- 相关视频_s -->
<section class="s_card j_relevent_video hide"></section>
<!-- 相关视频_e -->
<section class="warning_box open">
    <section class="warning_select">特别声明<span class="icon_open"></span></section>
    <section class="warning_wrap"><span class="warning_statement"><strong class="warning_s">特别声明：</strong>以上文章内容仅代表作者本人观点，不代表新浪看点观点或立场。如有关于作品内容、版权或其它问题请于作品发布后的30日内与新浪看点联系。</span></section>
</section>
</section>`;
export default class ShowHtmlDetail extends React.Component{
    constructor(props) {
        super(props)
        this.state = { html: showHtml }
    }
    render() {
        return (
            <div className="ShowHtmlDetail-content" dangerouslySetInnerHTML = {{__html: this.state.html}}></div>
        )
    }
}