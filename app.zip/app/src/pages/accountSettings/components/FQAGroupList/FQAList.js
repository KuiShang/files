import React from 'react';
import { Link } from 'react-router';
import './GroupFQAList.scss'
import { print } from 'utils/utils'

export default class accountSetting extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      expandId: 0,
      menuDatas: []
    }
  }
  clickHandler(menuDataId) {
    // 2019-07-23 产品李妮 规定的默认全部展开
    return ;
    this.state.expandId === menuDataId ? this.setState({ expandId: this.state.expandId }) : this.setState({ expandId: menuDataId })
  }
  componentDidMount() {
    if (this.props.FAQlistData && this.props.FAQlistData.menuChilds[0]) 
    this.setState({
      expandId: this.props.FAQlistData.menuChilds[0].menu.menuId,
      menuDatas: this.props.FAQlistData.menuChilds
    })
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.FAQlistData && nextProps.FAQlistData.menuChilds[0])
    this.setState({
      expandId: nextProps.FAQlistData.menuChilds[0].menu.menuId,
      menuDatas: nextProps.FAQlistData.menuChilds
    })
  }
  render() {
    const _this = this;
    const menusDataDom = (this.state.menuDatas || []).map(function (crtMenuData, index1) {
      let liData = null;
      liData = (crtMenuData.faqQuestions || []).map(function (currentLiData, index2) {
        return (
          
          <Link to={{ pathname: '/ShowHtmlDetail', state : { type: _this.renderMenuContentMessageDeatil(currentLiData) }}} key={ index2 }>
            <li
              key={index2}
              // className={crtMenuData.menu.menuId === _this.state.expandId ? "" : "hidden"} 注释掉
            >
               {/* 将每个item传入函数展示文案中 */}
               <span>{ _this.renderMenuContentMessage(currentLiData) }</span>
              <i>
                <img src={require('./next@2x.png')} alt=" " />
              </i>
            </li>
          </Link>
        )
      });
      liData = <ul className="item-ul">{liData}</ul>
      return (
        <li key={index1}>
          <div className="choice-item" onClick={_this.clickHandler.bind(_this, crtMenuData.menu.menuId)}>
            {/* 将每个item传入函数展示文案中 */}
            { _this.renderMenuTitleMessage(crtMenuData.menu) }
            {/* <i>
              <img src={require('./expand-2@2x.png')} alt=" " />
            </i> */}
          </div>
          {liData ? liData : ""}
        </li>
      );
    })
    return (
      <div className="help-support-list">
        <ul className="choice-fqa">
          {menusDataDom}
        </ul>
      </div>
    )
  }
  // contentSimpleUrl
  renderMenuContentMessageDeatil(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.contentEnglishUrl
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.contentSimpleUrl
      )
    } else {
      return (
        item.contentTraditionalUrl
      )
    }
  }
  // 判断设备语言 来进行国际化筛选， 如果没有就默认走中文繁体
  renderMenuContentMessage(item) {
    
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.titleEnglish
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.titleSimple
      )
    } else {
      return (
        item.titleTraditional
      )
    }
  }
  
  // 判断设备语言 来进行国际化筛选， 如果没有就默认走中文繁体
  renderMenuTitleMessage(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.menuEnglish
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.menuSimple
      )
    } else {
      return (
        item.menuTraditional
      )
    }
  }
}