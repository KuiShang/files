import React from 'react'
import './CallUs.scss'
import intl from 'utils/react-intl-universal'

export default class CallUs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isShowState: false
    };
  }
  render() {
    return (
      <footer className="contact-us fl">
        <div className="tel" onClick={() => this.CallTel(true)}>
          <img src={require('.//mobile.png')} alt=" " />
          <span>{ intl.get('05.01.004-1') }</span>
        </div>
        <div className={`tel-dialog ${this.state.isShowState === true ? 'actived' : ''} `}>
          <section className= {`content ${this.state.isShowState === true ? 'popIn' : ''} `}>
            <p className="tel-msg">{ intl.get('05.01.008-1') }</p>
            <div className="handle">
              <p className="cancel" onClick={() => this.onChecked(false)}>{ intl.get('05.01.008-2') }</p>
              <p className="sure" onClick={() => this.CallTel()}>{ intl.get('05.01.008-3') }</p>
            </div>
          </section>
        </div>
      </footer>
    )
  }
  // diglog状态更换
  onChecked = (status) => {
    // 产品李妮2019-08-29 需求，去掉弹窗。直接调用JS方法。
    // this.setState({ isShowState: status });
  }
  /**
   * 调用Native方法 拨打客服电话
   * todo 客服电话待提供
   */
  CallTel = () => {
    const json = {
      type: 'native',
      address: '/editcallphone/os',
      params: {
        to: 85239882388,
        context: '',
        title: ''
      }
    };
    window.$SDK.goNativeAction(json, ()=>{

    });
    // this.onChecked(false);
  }
}