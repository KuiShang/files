import React from 'react';
import './NavChoice.scss';
import * as SDK from 'sdk/wrapper';

class NavChoice extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checkedIndex: 0,
      navBarData: []
    };
  }
  componentDidMount() {
    !!this.props.navBarData && this.setState({navBarData: this.props.navBarData || []})
  }
  componentWillReceiveProps(nextProps) {
    !!nextProps.navBarData && this.setState({navBarData: nextProps.navBarData || []})
  }
  render() {
    
    return (
      <div className="card-to">
        <ul className="card-to-items">
          {
            (this.state.navBarData || []).map((item, index) => {
              return (
                <li key={index} className={`card-to-item ${this.state.checkedIndex === index ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(index, item.menuId, item)}>
                  <div className="card-to-item-info">
                    <img alt=" " src={item.iconUrl} />
                    {/* 将每个item传入函数展示文案中 */}
                    <span>{ this.renderMenuTitleMessage(item) }</span>
                  </div>
                </li>
              )
            })
          }
        </ul >
      </div >
    )
  }
  // 判断设备语言 来进行国际化筛选， 如果没有就默认走中文繁体
  renderMenuTitleMessage(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if(sysLanguare === 'en-HK') {
      return (
        item.menuEnglish
      )
    } else if(sysLanguare === 'zh-CN') {
      return (
        item.menuSimple
      )
    } else {
      return (
        item.menuTraditional
      )
    }
  }
  /**
   * 点击切换tab
   */
  onChecked = (index, type, item) => {
    const pageTitleText = this.renderMenuTitleMessage(item);
     // 设置标题
     try {
      SDK.setTitle({
        title: pageTitleText
      });
    } catch(err) {
      console.info(err)
    }
    this.setState({ checkedIndex: index }, () => {
      this.props.onChecked && this.props.onChecked(type);
    })
  }
  
}

export default NavChoice;