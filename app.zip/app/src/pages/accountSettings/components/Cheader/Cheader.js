import React from 'react'
import './Cheader.css'
export default class Cheader extends React.Component {
  clickHandler() {
    window.history.go(-1)
  }
  render() {
    return (
      <header className="top-header">
        <i  onClick={this.clickHandler}>
          <img src={require('./back@2x.png')} alt=" " />
        </i>
        <p>Loan</p>
      </header>
    )
  }
}