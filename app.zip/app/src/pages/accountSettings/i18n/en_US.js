const en_US = {
	// FAQ
	"05.01.004-1": "Contact the livi Team",
	"05.01.004-2": "客服(待提供)",
	"05.01.008-1": "+852 3988 2388",
	"05.01.008-2": "Cancel",
	"05.01.008-3": "Call",
	"14.05.001-1": "No Content(待翻)",
	// about 页面
	'05.01.009-1': 'Our Story',
	'05.01.009-2': 'Money may make the world go round, but it shouldn’t make your head spin! ',
	'05.01.009-3': 'Everyone deserves a great relationship with money.',
	'05.01.009-4': 'Fun, fulfilling and a path to contentment.',
	'05.01.009-5': 'We believe banks can positively shape this relationship. ',
	'05.01.009-6': 'It’s why we created livi.  ',
	'05.01.009-7': 'To reframe the role of money in context of what truly matters.',
	'05.01.009-8': 'To make it easy to cultivate good habits.',
	'05.01.009-9': 'To nudge you in the right direction to create your best future.',
	'05.01.009-10': "To spark joy and experience life's kaleidoscope.",
	'05.01.009-11': "And to help you gain perspective, not just control.",
	'05.01.009-12': 'livi. It’s banking made positive.',
	'05.01.009-13': 'livi is backed by BOCHK (Holdings), JD Digits and Jardines.',
}
export default en_US;