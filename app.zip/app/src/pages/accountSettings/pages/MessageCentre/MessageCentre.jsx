import React from 'react';
import './MessageCentre.scss';
import intl from 'utils/react-intl-universal'
export default class About extends React.Component{
  render() {
    return(
      <div className="messageCenter-box">
        <img src={require('./no-email@2x.png')} alt=" "/>
        <div className="messageCenter-container">
          <h6>Ready for tax season?</h6>
          <p className="show-timer-msg">2018/11/15 at 10:20 AM • Reminder</p>
          <div className="text">
            On average, more than half of app users won’t opt-in to receiving push notifications. So what’s the best way to communicate with them? We suggest employing in-app messaging. 
          </div>
          <div className="confirm-btn">Proceed</div>
        </div>
        
      </div>
    )
  }
}