import React from 'react';
import './TermsConditions.scss';
import { Link } from 'react-router';

  
export default class TermsConditions extends React.Component {
  render() {
    return (
      <div className="Terms-Conditions">
        <header className="choice-fqa">
          <ul>
            <Link to={{ pathname: '/ShowHtmlDetail', state: { type: 1 } }} key={'item.jumpUrlId'}>
              <li className="clearFix">
                <p>Terms of Use</p>
                <i>
                  <img src={require('./next@2x.png')} alt=" " />
                </i>
              </li>
            </Link>
            <li className="clearFix">
              <p>Privacy Policy</p>
              <i>
                <img src={require('./next@2x.png')} alt=" " />
              </i>
            </li>
          </ul>
        </header>
      </div>
    );
  }
}