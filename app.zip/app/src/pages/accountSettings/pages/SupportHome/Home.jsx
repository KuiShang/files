import React from 'react';
import './home.scss';
import intl from 'utils/react-intl-universal';
import NavChoice from 'pages/accountSettings/components/NavChoice/NavChoice';
import GroupFQAList from 'pages/accountSettings/components/FQAGroupList/FQAList.js';
import FQAList from 'pages/accountSettings/components/FQAList/FQAList.1.js';
import CallUs from 'pages/accountSettings/components/CallUs/CallUs';
// 在线客服入口 - laout
import LiveChat from 'pages/accountSettings/components/LiveChat/LiveChat';
import * as SDK from 'sdk/wrapper';

import { getFaqHomeData } from 'api/accountSetting';

function Greeting(props) {
  const GreetingData = props.GreetingData;
  // console.info(GreetingData)
  if (GreetingData && GreetingData.faqQuestions && GreetingData.faqQuestions.length === 0) {
    // 1. 分组类型
    return <GroupFQAList FAQlistData={GreetingData} />;
  }
  // 2. 正常类型
  return <FQAList FAQlistData={GreetingData} />;
}

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      NavChoiceData: [],
      GreetingData: [],
      serverData: {},
      renderTplStatus: 0 // 0 初始状态不渲染 1 正常数据 2 空数据 
    };
  }
  componentDidMount() {
    this.initData();
  }
  render() {
    return (
      this.state.renderTplStatus == 1 ?
      <div className="support-home">
        <div className="faq-header">
          <NavChoice navBarData={this.state.NavChoiceData} onChecked={index => this.onChecked(index)} />
        </div>
        <div className="FAQ-list">
          <Greeting GreetingData={this.state.GreetingData} />
        </div>
        <div className="support-home-bottom">
          <CallUs />
          <LiveChat />
        </div>
      </div>
      : this.state.renderTplStatus == 2 ?
      // 没有设置faq问题，数组数据为空
      <div className="support-home-empty">
        <div className="faqHome-empty-data">
          <img src="" src={require('./nocontent@3x.png')} />
          <p>{ intl.get('14.05.001-1') }</p>
        </div>
        <div className="support-home-bottom">
          <CallUs />
          <LiveChat />
        </div>
      </div>
      :
      // 
      <div></div>
    )
  }
  onChecked = (index) => {
    const GreetingData = (this.state.serverData.faqMenuRes || []).filter((item) => {
      if (index === item.menu.menuId) {
        return item;
      }
    })
    this.setState({ GreetingData: GreetingData[0] });
  }
  // 初始化数据
  async initData() {
    const res = await getFaqHomeData()
    if (res.data.resultCode === 1) {
      const serverData = Object.assign({}, res.data.resultData)
      const navBarData = serverData.faqMenuRes.map((item) => {
        return item.menu
      });
      // 设置标题
      try {
        SDK.setTitle({
          title: this.setTitleContent(navBarData[0])
        });
      } catch (err) {
        console.info(err)
      }
      if (serverData.faqMenuRes.length !== 0) {
        // 只有当运营配置问答列表才展示页面
        this.setState({
          serverData: serverData,
          NavChoiceData: navBarData,
          GreetingData: serverData.faqMenuRes[0],
          renderTplStatus: 1
        })
      } else if ( serverData.faqMenuRes.length === 0 ) {
        this.setState({
          renderTplStatus: 2
        })
      }
    }
  }
  // 设置标题语言
  setTitleContent(item) {
    const sysLanguare = window.$DeviceInfo.language;
    if (sysLanguare === 'en-HK') {
      return (
        item.menuEnglish
      )
    } else if (sysLanguare === 'zh-CN') {
      return (
        item.menuSimple
      )
    } else {
      return (
        item.menuTraditional
      )
    }
  }
}

export default Home;