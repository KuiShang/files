import React from 'react';
import './About.scss';
import intl from 'utils/react-intl-universal'
export default class About extends React.Component{
  
  componentWillMount() {
   try {
    window.$SDK.setTitle({
      title:  intl.get('05.01.009-1')
    })
   } catch (error) {
     
   }
  }
  render() {
    return(
      <div className="about-container">
        <div className="text">
          <p>
          { intl.get('05.01.009-2') }
          </p>
          <p>
          { intl.get('05.01.009-3') }
          </p>
          <p>
          { intl.get('05.01.009-4') }
          </p>
          <p>
          { intl.get('05.01.009-5') }
          </p>
          <p>
          { intl.get('05.01.009-6') }
          </p>
          <p>
          { intl.get('05.01.009-7') }
          </p>
          <p>
          { intl.get('05.01.009-8') }
          </p>
          <p>
          { intl.get('05.01.009-9') }
          </p>
          <p>
          { intl.get('05.01.009-10') }
          </p>
          <p>
          { intl.get('05.01.009-11') }
          </p>
          <p>
          { intl.get('05.01.009-12') }
          </p>
          <p>
          { intl.get('05.01.009-13') }
          </p>
        </div>
      </div>
      
    )
  }
}