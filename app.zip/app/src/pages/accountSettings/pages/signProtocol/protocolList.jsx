import React from 'react';
import './protocolList.scss';
import { getProtocolList } from 'api/protocol';
import {  Base } from 'utils/base64'

export default class accountSetting extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      menuDatas: []
    }
  }
  componentDidMount() {
    this.initData();
  }
  render() {
    return (
      <div className="protocol-list">
        <header className="choice-fqa">
          <ul>
            {
              (this.state.menuDatas || []).map((item, index) =>
                  <li onClick={()=>{this.showProtocol(item)}} key={index} className="clearFix">
                    <p>{item.agreementName}</p>
                    <i>
                      <img src={require('./next@2x.png')} alt=" " />
                    </i>
                  </li>
              )
            }
          </ul>
        </header>
      </div>
    );
  }
  async initData() {
    const res = await getProtocolList(
      { "languageType": "zh-CN", "pageSize": 200, "currentPage": 1 }
    )
    if (res.data.resultCode === 1) {
      const serverData = res.data.resultData.data || []
      this.setState({
        menuDatas: serverData
      })
    }
  }
  showProtocol(params) {
    const b =  Base.encode(`No=${params.agreementNo}&Ver=${params.agreementVersion}&type=1`);
    window.location.href = `http://localhost:3000/protocol.html#/detailProtocol?${b}`;
  }
}