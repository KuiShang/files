import React from 'react'
import './ShowHtmlDetail.scss'
export default class ShowHtmlDetail extends React.Component {
  constructor(props) {
    super(props)
    this.state = { imgsrc: '' }
  }
  componentDidMount() {
    console.info(this.props.location)
    this.setState({imgsrc: this.props.location.state.type || ''})
  }
  render() {
    return (
      <div className="ShowHtmlDetail-content" >
        <img src={ this.state.imgsrc } alt=" "/>
      </div>
    )
  }
}