import React from 'react';
import './CloseAccount.scss';
import intl from 'utils/react-intl-universal'

export default class About extends React.Component{
  render() {
    return(
      <div className="close-account-detail">
        <div className="text">
          <h6>Please make sure you meet the criteria below:</h6>
          <ol className="desc-items">
            <li>
              <span>Your savings account must have zero balance.</span>
            </li>
            <li>
              <span>Your loan must be paid off.</span>
            </li>
            <li>
              <span>No occurring payments.</span>
            </li>
            <li>
              <span>No pending payments.</span>
            </li>
            <li>
              <span>All outstanding and pending items must be completed.</span>
            </li>
            <li>
              <span>No frozen amount in the account.</span>
            </li>
          </ol>
        </div>
      </div>
      
    )
  }
}