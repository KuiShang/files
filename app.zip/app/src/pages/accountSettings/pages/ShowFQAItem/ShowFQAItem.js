import React from 'react';
import './FQAList.css'
import Cheader from '../../components/Cheader/Cheader'
import HasGroup from '../../components/FQAGroupList/FQAList'
import NoGroup from '../../components/FQAList/FQAList.1'


export default class accountSetting extends React.Component {
  render() {
    let ShowFQAItemGroup = null
    const groupType = this.props.location.state.type
    console.info(groupType)
    groupType ? ShowFQAItemGroup = HasGroup: ShowFQAItemGroup = NoGroup
    return (
      <div className="help-support-list">
        <Cheader />
        <ShowFQAItemGroup />
      </div>
    )
  }
}