import React from 'react';
import { Router, hashHistory, Route } from 'react-router';
import { Provider } from 'react-redux';
import store from 'redux/store';
import VConsole from 'vconsole';
// 样式初始化 & rem.js脚本引入
import './assets/css/reset.css';
import './assets/js/rem.js';
import * as SDK from 'sdk/wrapper'

// 国际化语言模块
import intl from 'utils/react-intl-universal';
import zhCN from './i18n/zh_CN';
import zhHK from './i18n/zh_HK';
import enHK from './i18n/en_US';
import debugI18n from './i18n/debug_i18n';


// 页面组件引入
import Home from './pages/SupportHome/Home';
import ShowFQAItem from './pages/ShowFQAItem/ShowFQAItem';
import ShowHtmlDetail from './pages/ShowHtmlDetail/ShowHtmlDetail';
import About from './pages/About/About';
import TermsConditions from './pages/TermsConditions/TermsConditions';
import signProtocol from './pages/signProtocol/protocolList';
// 销户介绍页面
import CloseAccount from './pages/CloseAccount/CloseAccount';
import MessageCentre from './pages/MessageCentre/MessageCentre';


// 本地mock数据
require('mock/index.js');
// 初始化默认语言为en-HK
window.localeLanguage = 'en-HK';
const platformInfo = SDK.getSysType();
const debugI18nEnv = platformInfo.debugI18n || false;
const isJDAPP = platformInfo.isJdApp;

async function getAppLang() {
  if (isJDAPP) {
    const ret = await SDK.getCommonInfo();
    console.info(`当前语言类型是${ret.language}`);
    if (!!ret.language) {
      window.localeLanguage = ret.language;
    }
  }
}
// ********* 设置环境变量 *********
// 获取当前Native的环境
// 获取当前Native的
(isJDAPP == true && debugI18nEnv) ?  window.localeLanguage = 'debug-i18n' : getAppLang();
if (debugI18nEnv) {
  var vConsole = new VConsole();
}

export default class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      initDone: false
    }
  }

  componentDidMount() {
    this.loadLocales()
  }

  loadLocales() {
    intl.init({
      currentLocale: window.localeLanguage,
      locales: {
        "en-HK": enHK,
        "zh-CN": zhCN,
        "zh-HK": zhHK,
        "debug-i18n": debugI18n
      }
    })
      .then(() => {
        this.setState({ initDone: true });
      });
  }

  render() {
    return (
      this.state.initDone &&
      <Provider store={store}>
        <Router history={hashHistory}>
          <Route path={'/'} components={Home}></Route>
          <Route path={'/ShowFQAItem'} components={ShowFQAItem}></Route>
          <Route path={'/ShowHtmlDetail'} components={ShowHtmlDetail}></Route>
          <Route path={'/About'} components={About}></Route>
          <Route path={'/TermsConditions'} components={TermsConditions}></Route>
          <Route path={'/signProtocol'} components={signProtocol}></Route>
          <Route path={'/CloseAccount'} components={CloseAccount}></Route>
          <Route path={'/MessageCentre'} components={MessageCentre}></Route>
        </Router>
      </Provider>
    )
  }
}
