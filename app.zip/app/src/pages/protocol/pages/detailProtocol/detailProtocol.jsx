import React from 'react'
import { Base } from 'utils/base64';
import { urlStr2Json } from 'utils/utils';

import {getProtocolDetail, getProtocolDetailModel}  from 'api/protocol';

export default class ShowHtmlDetail extends React.Component {
	constructor(props) {
		super(props)
		this.state = {
			html: ''
		}
	}
	componentDidMount() {
		const protocolParams = this.props.location.search.substr(1) || '';
		console.info(protocolParams)
		Object.keys(protocolParams).length !== 0 && this.initData(protocolParams)
  }
	render() {
		return (
			<div className="ShowHtmlDetail-content" dangerouslySetInnerHTML={{ __html: this.state.html }}></div>
		)
	}
	async initData(protocolParams) {
		const params = urlStr2Json(decodeURIComponent(Base.decode(protocolParams)));
		console.info(params)
		if(params.type === 1) {
			// 通用协议
			var  res = await getProtocolDetail(params)
		} else {
			// 个人协议
			var  res = await getProtocolDetailModel({
				"agreementNo" : params.No,
				"agreementVersion" : params.Ver
			})
		}
    if (res.data.resultCode === 1) {
			const serverData = res.data.resultData.agreementContent || '';
      this.setState({
        html: serverData
      })
    }
  }
}