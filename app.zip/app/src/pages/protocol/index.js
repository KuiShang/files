import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, hashHistory } from 'react-router';
import { Provider } from 'react-redux';
import store from 'redux/store';
import App from './App.jsx';
import * as serviceWorker from '../../serviceWorker';
import VConsole from 'vconsole';
import { getSysType } from 'utils/utils';
import detailProtocol from './pages/detailProtocol/detailProtocol'

const platformInfo = getSysType();
const debugI18nEnv = platformInfo.debugI18n || false;
if (debugI18nEnv) {
    var vConsole = new VConsole();
}

// require('mock/index.js')

ReactDOM.render(
	<Provider store={store}>
		<Router history={hashHistory}>
			<Route path={'/'} components={App}></Route>
			<Route path={'/detailProtocol'} components={detailProtocol}></Route>
		</Router>
	</Provider>, document.getElementById('root'));

serviceWorker.unregister();