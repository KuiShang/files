import React from 'react'

import Button from '@/ui/button/button'
import Histogram from '@/ui/Histogram/Histogram'
import './style.scss'
export default class DefaultCustomer extends React.Component {
  render() {
    return (
      <div className="DefaultCustomer">
        <section className="part1">
          <p className="title">Smart Savings</p>
          <p className="We-offer-up-to-15">We offer up to 1.5% interest on your savings with our daily accumulated rate. The more you save, the more interest you gain through our interest tiers.</p>
          <div className="gram">
            <p className="How-our-interest-tie">How our interest tiers work</p>
            <Histogram ></Histogram>
          </div>
          <div className="btn-wraper">
            <Button type="primary">Start saving with us</Button>
          </div>
        </section>
        <section className="part2">
          <p className="title">Let’s Try with Your Savings</p>
          <p className="content">
            Use the calculator to see how much interest you will gain with your allocated amount. 
          </p>
          <div className="bg"></div>
        </section>
        <section className="part3">
        <span className="Account-ready"></span>
          <p className="Title-here-title-her">Your VB is almost ready</p>
          <p className="description">
            You are few steps away from having a VB account. Get yours now to enjoy a new digital banking experience. 
          </p>
          <div className="btn-wraper">
            <Button type="primary">Get your VB account</Button>
            <p className="pdt"></p>
            <Button>Share</Button>
          </div>
        </section>
      </div>
    )
  }
}