var a = {
  "resultCode": 1,
  "resultData": {
      "level": 1,
      // 利率对比展示
      "interestExhibitionList": [
        {
          type: 1,
          "interest": '0.2%',
          minMoney: 0
        },
        {
          type: 0,
          "interest": '0.2%',
        }
      ],
      // 利率计算器
      "interestCalc": {
        HKD: [
          {
            accumulatedInterest: '0.5%',
            otherInterest: '0.125%',
            interestGained: '+234.12',
            savingAmount: 100
          },
          {
            accumulatedInterest: '0.5%',
            otherInterest: '0.125%',
            interestGained: '+234.12',
            savingAmount: 100
          }
        ],
        CNY: [
          {
            accumulatedInterest: '0.5%',
            otherInterest: '0.125%',
            interestGained: '+234.12',
            savingAmount: 100
          },
          {
            accumulatedInterest: '0.5%',
            otherInterest: '0.125%',
            interestGained: '+234.12',
            savingAmount: 100
          }
        ]
     
      },
      accountId: '398-123123-8888',
      aggregatedBalance: '0.00HKD',
      // 养成计划  花🌹
      cultivatePlan: {
        'HKD': {
          currentInterest: '0.2% ',
          nextInterest: '0.3%',
          currentLev: 1,
          balance: 0,
          todayGain: 1.45,
          YesterdayGain: 111,
          currentWaterLevel: 50,
          masterWaterLevel: 100
        },
        CNY: {
          currentInterest: '0.2% ',
          balance: 0,
          todayGain: 1.45,
          YesterdayGain: 111,
          currentWaterLevel: 50,
          masterWaterLevel: 100
        },
        HKDToCNYExchangeRate: 0.8
      },
      transtction: {
        pageNo:1,
        pageSize: 20,//一页多少条记录
        list: [
          {
            type: '1', // 1 topup  2 withdraw
            title: 'loan repayment',
            date: '151417693089',
            amount: '356456',
            inoutFlag: '1'
          }
        ]
      }
  },
  "errorData": null,
  "resultMsg": "success"
}

// 浇花

var b =  {
  "resultCode": 1,
  "resultData":  {
    'HKD': {
      currentInterest: '0.2% ',
      nextInterest: '0.3%',
      currentLev: 1,
      balance: 0,
      todayGain: 1.45,
      YesterdayGain: 111,
      currentWaterLevel: 50,
      masterWaterLevel: 100
    },
    CNY: {
      currentInterest: '0.2% ',
      balance: 0,
      todayGain: 1.45,
      YesterdayGain: 111,
      currentWaterLevel: 50,
      masterWaterLevel: 100
    },
    HKDToCNYExchangeRate: 0.8
  },
  "errorData": null,
  "resultMsg": "success"
}