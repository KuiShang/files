import React from 'react'
import './style.scss'
import Button from '@/ui/button/button'
import Tabs from '@/ui/Tabs/Tabs'
import Gallery from '@/ui/gallery/gallery'
import Listview from '@/ui/listview/listview'
export default class DefaultCustomer extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {

    return (
      <div className="NewCustomer">
        <section className="pd2">
          <p className="title">savings 398-89789-888</p>
          <p className="aggregated_balance">aggregated balance 0.00 Hkd</p>
          <div className="card">
            <p className="Lets-get-started">lets get started</p>
            <p className="Deposit-now-to-rise">Deposit now to rise up the interest tiers and earn up to 1.5% interest with your HKD savings account</p>
            <Button type="primary">Deposit</Button>
            <p className="Learn-more-about-the">Learn more about the interest tiers</p>
          </div>
          <div className="card">
            <Tabs tabs={[
              { title: 'HKD' },
              { title: 'CNY' },
              ]}
              onTabClick={(tab, index) => { console.info('onTabClick', index, tab); }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff', fontSize:'12px' }}>
                Content of first tab
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff', fontSize:'12px' }}>
                Content of second tab
              </div>
            </Tabs>
            <Button type="primary">Deposit</Button>
          </div>
        </section>
        <Gallery></Gallery>
        <Listview></Listview>
      </div>
    )
  }
}