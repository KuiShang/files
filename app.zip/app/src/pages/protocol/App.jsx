import React from 'react'
import './style.scss'

export default class App extends React.Component {
  render() {
    return (
      <div className="saving">
       123455
      </div>
    )
  }
}