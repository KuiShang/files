const en_US = {
	// FAQ
	"05.01.004-1": "Contact the livi Team",
	"05.01.004-2": "客服(待提供)",
	"05.01.008-1": "+852 3988 2388",
	"05.01.008-2": "Cancel",
	"05.01.008-3": "Call",
	"14.05.001-1": "No Content(待翻)",
	// about 页面
	'05.01.009-1': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod  empor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo  onsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cil.',
}
export default en_US;