import React from 'react';
import './index.scss'
import imgPulldown from 'assets/imgs/pulldown/pulldown-small@3x.png';
import svgContact from 'assets/imgs/contact/Contact.png';

export default class MobileNumber extends React.Component {
    render() {
        return (
            <div className="mobile-number">
                <div className="mobile-number-code">
                    <span>+582</span>
                    <img alt="" src={imgPulldown} />
                </div>
                <div className="mobile-number-input">
                    <input type="text" placeholder="Mobile Number" />
                </div>
                <img alt="" src={svgContact} />
            </div>
        )
    }
}