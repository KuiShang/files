import React from 'react';
import "./index.scss";

export default class CardReview extends React.Component {
    render() {
        return (
            <div className="card-review">
                {this.props.children}
            </div>
        )
    }
}