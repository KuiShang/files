import React from 'react';
import PropTypes from 'prop-types';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import intl from 'react-intl-universal'
import './index.scss';

class CardFrom extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            balance: props.balance,
            unit: props.unit,
            account: props.account,
            showTips: false
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            account: props.account,
            balance: props.balance || 0,
            showTips: props.showTips
        }
    }

    render() {
        const { unit, account, balance, showTips } = this.state;
        const bal = this.onConstructMoney(balance)
        return (
            <div className="card-from">
                <div className="card-from-title">{intl.get('transfer_from')}</div>
                <div className="card-from-account">
                    <div className="card-from-actions">
                        <div>{intl.get('transfer_vb_savings_account')}</div>
                    </div>
                    <div className="card-from-price">
                        <span className="card-from-price-remainder">{thousandBitSeparator(keep2DecimalFull(bal))}</span>
                        <span className="card-from-price-unit">{unit}</span>
                        {showTips && <span className="card-from-price-tip">{intl.get("insuficient_balance")}</span>}
                    </div>
                    <div className="card-from-no">{account}</div>
                </div>
            </div>
        )
    }

    onConstructMoney = () => {
        const { balance } = this.state;
        return balance;
    }

    onSwitch = () => {
        this.props.onSwitch && this.props.onSwitch()
    }
}

CardFrom.propTypes = {
    balance: PropTypes.number,
    unit: PropTypes.string.isRequired,
    onSwitch: PropTypes.func,
}

CardFrom.defaultProps = {
    balance: 0,
    unit: 'HKD',
    account: '0000-0000-0000-8888'
}

export default CardFrom;