import React from 'react'
import renderer from 'react-test-renderer'

import CardFrom from './index'

it('render correctly', () => {
    const tree = renderer
        .create(<CardFrom className="success">Snapshot testing</CardFrom>)
        .toJSON();

    expect(tree).toMatchSnapshot();
})