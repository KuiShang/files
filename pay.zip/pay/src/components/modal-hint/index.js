import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';
import imgCard1 from 'assets/imgs/hint/card1@2x.png';
import imgCard2 from 'assets/imgs/hint/card2@2x.png';
import imgCard3 from 'assets/imgs/hint/card3@2x.png';

class Hint extends React.Component {
    render() {
        return (
            <div className="hint">
                <div>
                    {intl.get('hint_title')}
                </div>
                <div className="hint-cards">
                    <img src={imgCard1} />
                    <p>
                        <span>{intl.get('hint_eg_one')}</span>
                    </p>
                    <img src={imgCard2} />
                    <p>
                        <span>{intl.get('hint_eg_two')}</span>
                    </p>
                    <img src={imgCard3} />
                    <p>
                        <span>{intl.get('hint_eg_three')}</span>
                    </p>
                </div>
                <div>
                    {intl.get('hint_bottom')}
                </div>
            </div>
        )
    }
}

export default Hint;