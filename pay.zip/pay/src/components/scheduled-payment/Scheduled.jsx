import React from 'react';
import PropTypes from 'prop-types';
import './Scheduled.scss';

class CardTo extends React.Component {
  state = { checkedIndex: 0 }
  // static defaultProps = {
  //   checkedIndex: 0
  // }
  componentDidMount() {
    if (this.props.checkedIndex) {
      this.setState({
        checkedIndex: this.props.checkedIndex
      })
    }

  }
  render() {
    const { checkedIndex } = this.state;
 
    return (
      <div className="scheduled-payment">
        <div className="scheduled-payment-title">Scheduled Payment</div>
        <ul className="scheduled-payment-items">
          <li className={`scheduled-payment-item ${checkedIndex === 0 ? 'scheduled-payment-item-actived' : ''}`} onClick={() => this.onChecked(0)}>
          Once a Week
          </li>
          <li className={`scheduled-payment-item ${checkedIndex === 1 ? 'scheduled-payment-item-actived' : ''}`} onClick={() => this.onChecked(1)}>
          Once a month
          </li>
          <li className={`scheduled-payment-item ${checkedIndex === 2 ? 'scheduled-payment-item-actived' : ''}`} onClick={() => this.onChecked(2)}>
          Spacific Date
          </li>
        </ul >
      </div >
    )
  }

  onChecked = (index) => {
    this.setState({ checkedIndex: index }, () => {
      this.props.onChecked && this.props.onChecked(index);
    })
  }
}

export default CardTo;