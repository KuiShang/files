import React from 'react';
import './index.scss';
import imgBank from 'assets/imgs/bank/bank@3x.svg';
import imgPulldown from 'assets/imgs/pulldown/pulldown-small.png';
import intl from 'react-intl-universal';

export default class EDDAReviewAuthorization extends React.Component {
    state = {
        info: this.props.info
    }

    static getDerivedStateFromProps(props) {
        return {
            info: props.info
        }
    }

    render() {
        const { info } = this.state;

        return (
            <div className="edda-review-authorization">
                <div className="edda-review-authorization-title">{intl.get("from")}</div>
                <div className="edda-review-authorization-cont">
                    {/* <img alt="" src={imgBank} /> */}
                    <div className="edda-review-authorization-cont-b">VB</div>
                    <div className="edda-review-authorization-cont-acc">
                        <div className="edda-review-authorization-cont-bank">{intl.get("livi_savings_account")}</div>
                        <div className="edda-review-authorization-cont-alias">{info.from.number}</div>
                    </div>
                </div>
                <div className="edda-review-authorization-title">{intl.get("to")}</div>
                <div className="edda-review-authorization-cont">
                    <div className="edda-review-authorization-cont-s">CT</div>
                    <div className="edda-review-authorization-cont-acc">
                        <div className="edda-review-authorization-cont-bank">{info.merchant.alias}</div>
                        <div className="edda-review-authorization-cont-alias">{info.merchant.cdtrRef}</div>
                    </div>
                </div>
            </div>
        )
    }
}