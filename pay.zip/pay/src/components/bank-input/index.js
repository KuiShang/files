import React from 'react';
import TextField from 'components/text-field';
import intl from 'react-intl-universal';
import './index.scss';

export default class BankInput extends React.Component {
    state = {
        accountNum: this.props.accountNum
    }

    static getDerivedStateFromProps(props) {
        return {
            accountNum: props.accountNum,
            bankAccount: props.bankAccount,
            pybank: props.pybank
        }
    }

    render() {
        const { bankAccount, pybank, accountNum } = this.state;
        
        return (
            <div className="bank-input">
                <div className="bank-input-code">
                    <span className="bank-input-code-ti">{intl.get('bank_code')}</span>
                    <span className="bank-input-code-no">{pybank || (bankAccount && bankAccount.bank_code)}</span>
                </div>
                <div className="bank-input-no">
                    <TextField
                        requireInputMessage=''
                        propValue={{
                            hasRequiredMessage: true,
                            requireInputMessage: '',
                            regExp: /^[a-zA-z0-9]{8,16}$/,
                            regExpMessgae: '',
                            value: accountNum,
                            isPass: false,
                            placeHolder: `${intl.get('account_number')}`
                        }}
                        // continueBtnUnClickShow={this.props.continueBtnUnClickShow}
                        // continueBtnClickShow={this.props.continueBtnClickShow}
                        bankAccount = {bankAccount}
                        stateName={'accountNum'}
                        setCurrentInputData={this.onHandleBankAccount.bind(this)}>
                    </TextField>
                </div>
            </div>
        )
    }

    onHandleBankAccount = (pn, json) => {
        this.setState({ accountNum: json.value }, () => {
            this.props.onChangeAccountNum && this.props.onChangeAccountNum(json.value);
        })
    }
}