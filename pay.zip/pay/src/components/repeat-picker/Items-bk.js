import React from 'react';
import { addPrefixCss, formatCss } from './utils/PrefixUtil.js';

const DATE_HEIGHT = 40;                              // 每个数据的高度
const DATE_LENGTH = 10;                              // 数据的个数
const MIDDLE_INDEX = Math.floor(DATE_LENGTH / 2);    // 数据数组中间值的索引
const MIDDLE_Y = - DATE_HEIGHT * MIDDLE_INDEX;       // translateY值

const isUndefined = val => typeof val === 'undefined';

function shallowEqual(prev, next) {
    if (prev === next) return true;
    const prevKeys = Object.keys(prev);
    const nextKeys = Object.keys(next);

    if (prevKeys.length !== nextKeys.length) return false;

    return prevKeys.every((key) => {
        return prev.hasOwnProperty(key) && prev[key] === next[key];
    });
}

export default class Item extends React.Component {
    constructor(props) {
        super(props);

        this.animating = false;                 // 判断是否在transition过渡动画之中
        this.touchY = 0;                        // 保存touchstart的pageY
        this.translateY = 0;                    // 容器偏移的距离
        this.currentIndex = MIDDLE_INDEX;       // 滑动中当前日期的索引
        this.moveDateCount = 0;                 // 一次滑动移动了多少个时间

        this.state = {
            translateY: (- DATE_HEIGHT * (props.value)) || MIDDLE_Y,
            //marginTop: (this.currentIndex) * DATE_HEIGHT,
            value: props.value,
            numbers: this._initNumbers(props.max || 99)
        };

        //console.info(props.value, MIDDLE_Y, this.translateY, this.state.marginTop);

        this.handleContentTouch = this.handleContentTouch.bind(this);
        this.handleContentMouseDown = this.handleContentMouseDown.bind(this);
        this.handleContentMouseMove = this.handleContentMouseMove.bind(this);
        this.handleContentMouseUp = this.handleContentMouseUp.bind(this);
    }

    componentDidMount() {
        const viewport = this.viewport;
        viewport.addEventListener('touchstart', this.handleContentTouch, false);
        viewport.addEventListener('touchmove', this.handleContentTouch, false);
        viewport.addEventListener('touchend', this.handleContentTouch, false);
        viewport.addEventListener('mousedown', this.handleContentMouseDown, false);
    }

    componentWillReceiveProps(nextProps) {
        //console.info(nextProps.value, this.props.value);
        if (nextProps.value === this.props.value) {
            return;
        }

        // this.currentIndex = MIDDLE_INDEX;
        // this.setState({
        // translateY: MIDDLE_Y,
        // marginTop: (this.currentIndex - MIDDLE_INDEX) * DATE_HEIGHT,
        // });
    }

    shouldComponentUpdate(nextProps, nextState) {
        return nextProps.value !== this.props.value || !shallowEqual(nextState, this.state);
    }

    render() {
        const scrollStyle = ({
            transform: `translateY(${this.state.translateY}px)`,
            marginTop: this.state.marginTop,
        });

        return (
            <React.Fragment>
                <div className="repeat-picker-col-1"></div>
                <div className="repeat-picker-col-1">
                    <div className="repeat-picker-viewport" ref={viewport => this.viewport = viewport}>
                        <div className="repeat-picker-wheel" style={{ height: '40px' }}>
                            <ul ref="scroll" className="repeat-picker-scroll" style={scrollStyle}>
                                {this.renderItems()}
                            </ul>
                        </div>
                    </div>
                </div>
                <div className="repeat-picker-col-1">
                    <div style={{ fontSize: '16px', color: '#484848' }}>Time</div>
                </div>
            </React.Fragment>
        )
    }

    componentWillUnmount() {
        const viewport = this.viewport;
        viewport.removeEventListener('touchstart', this.handleContentTouch, false);
        viewport.removeEventListener('touchmove', this.handleContentTouch, false);
        viewport.removeEventListener('touchend', this.handleContentTouch, false);
        viewport.removeEventListener('mousedown', this.handleContentMouseDown, false);
    }

    renderItems = () => {
        const { numbers } = this.state;

        let styles = {
            height: '40px',
            lineHeight: '40px'
        }

        return numbers.map((value, index) => {
            return <li key={`REP${index}`} style={styles}>{value + 1}</li>
        })
    }

    /**
     * 滑动选择器触屏事件
     * @param  {Object} event 事件对象
     * @return {undefined}
     */
    handleContentTouch(event) {
        event.preventDefault();
        if (this.animating) return;
        if (event.type === 'touchstart') {
            this.handleStart(event);
        } else if (event.type === 'touchmove') {
            this.handleMove(event);
        } else if (event.type === 'touchend') {
            this.handleEnd(event);
        }
    }

    /**
     * 滑动选择器鼠标事件
     * @param  {Object} event 事件对象
     * @return {undefined}
     */
    handleContentMouseDown(event) {
        if (this.animating) return;
        this.handleStart(event);
        document.addEventListener('mousemove', this.handleContentMouseMove);
        document.addEventListener('mouseup', this.handleContentMouseUp);
    }

    handleContentMouseMove(event) {
        if (this.animating) return;
        this.handleMove(event);
    }

    handleContentMouseUp(event) {
        if (this.animating) return;
        this.handleEnd(event);
        document.removeEventListener('mousemove', this.handleContentMouseMove);
        document.removeEventListener('mouseup', this.handleContentMouseUp);
    }

    /**
     * 滑动开始
     * @param {*} event 
     */
    handleStart(event) {
        this.touchY = (!isUndefined(event.targetTouches) && !isUndefined(event.targetTouches[0])) ?
            event.targetTouches[0].pageY :
            event.pageY;

        this.translateY = this.state.translateY;
        this.moveDateCount = 0;
    }

    /**
     * 滑动移动
     * @param {*} event 
     */
    handleMove(event) {
        const touchY = (!isUndefined(event.targetTouches) && !isUndefined(event.targetTouches[0])) ?
            event.targetTouches[0].pageY :
            event.pageY;

        const dir = touchY - this.touchY;
        const translateY = this.translateY + dir;
        const direction = dir > 0 ? -1 : 1;

        if (this.currentIndex < 0 || this.currentIndex > (this.props.max ? (this.props.max - 1) : 98)) {
            return;
        }

        if (this._checkIsUpdateDates(direction, translateY)) {
            this.moveDateCount = direction > 0 ? this.moveDateCount + 1 : this.moveDateCount - 1;
            this._updateDates(direction);
        }

        this.setState({ translateY });
    }

    /**
     * 滑动结束
     * @param {*} event 
     */
    handleEnd(event) {
        const touchY = event.pageY || event.changedTouches[0].pageY;
        const dir = touchY - this.touchY;
        const direction = dir > 0 ? -1 : 1;
        this._moveToNext(direction);
    }

    _initNumbers = (max) => {
        let nums = Array.from(new Array(max).keys());
        return nums;
    }

    _checkIsUpdateDates(direction, translateY) {
        return direction === 1 ?
            this.currentIndex * DATE_HEIGHT + DATE_HEIGHT / 2 < -translateY :
            this.currentIndex * DATE_HEIGHT - DATE_HEIGHT / 2 > -translateY;
    }

    /**
     * 滑动到下一日期
     * Option 1:  1 -- 上
     * Option 2: -1 -- 下
     * @param  {number} direction 滑动方向
     * @return {undefined}
     */
    _moveToNext(direction) {
        if (direction === -1 && this.moveDateCount) {
            this._updateDates(1);
        } else if (direction === 1 && this.moveDateCount) {
            this._updateDates(-1);
        }

        this._moveTo(this.refs.scroll, this.currentIndex);
    }

    _updateDates(direction) {
        if (direction === 1) {
            const curValue = this.currentIndex++;
            //this.setState({ value: curValue });
        } else {
            const curValue = this.currentIndex--;
            //this.setState({ value: curValue });
        }
    }

    /**
     * 添加滑动动画
     * @param  {DOM} obj   DOM对象
     * @param  {number} angle 角度
     * @return {undefined}
     */
    _moveTo(obj, currentIndex) {
        this.animating = true;

        addPrefixCss(obj, { transition: 'transform .2s ease-out' });

        this.setState({
            translateY: -currentIndex * DATE_HEIGHT,
        });
        console.info(this.currentIndex);
        // NOTE: There is no transitionend, setTimeout is used instead.
        setTimeout(() => {
            this.animating = false;
            this.props.onSelect(this.currentIndex + 1);
            this._clearTransition(this.refs.scroll);
        }, 200);
    }

    /**
     * 清除对象的transition样式
     * @param  {Dom}     obj     指定的对象
     * @return {undefined}
     */
    _clearTransition(obj) {
        addPrefixCss(obj, { transition: '' });
    }
}