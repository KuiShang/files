import React from 'react';
import Items from './Items';
import './index.scss';

/**
 * TODO
 * Q1: 滑动效果现在没有问题，但需要进行优化
 * Q2: 有太多的冗余逻辑，例如对于交互时间 TOUCHSTART、TOUCHMOVE、TOUCHEND需要做一定的统一处理；
 */
export default class RepeatPicker extends React.Component {
    state = { value: 3, max: this.props.max || 12 }

    static getDerivedStateFromProps(props, state) {
        let { value } = state;
        if (props.value) {
            value = props.value;
        }

        return {
            value
        }
    }

    render() {
        return (
            <div className="repeat-picker default">
                <div className="repeat-picker-content">
                    <Items max={this.state.max} value={this.state.value} onSelect={this.props.onSelectRepeat}></Items>
                </div>
            </div>
        )
    }
}