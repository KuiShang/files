import React from 'react';
import './index.scss';

export default class CardNo extends React.Component {
    constructor(props) {
        super(props);

        const data = this.onConstructNum(props.data);
        this.state = {
            data
        }
    }

    render() {
        return (
            <span>{this.state.data}</span>
        )
    }

    onConstructNum = () => {

    }
}