import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'components/text-field';
import intl from 'react-intl-universal';
import './index.scss';

class TextFieldContact extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            country: props.country || '+852',
            mobile: props.mobile,
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            country: props.country,
            mobile: props.mobile
        }
    }

    render() {
        const { mobile } = this.state;
        console.info(mobile);
        return (
            <TextField
                inputType="number"
                propValue={{
                    hasRequiredMessage: false,
                    regExp: /^\d{7,}$/,
                    regExpMessgae: '手机号格式不正确',
                    value: mobile,
                    isPass: false,
                    placeHolder: intl.get('mobile_number')
                }}
                stateName={'mobile'}
                setCurrentInputData={this.onHandleInput.bind(this)}
                leftBoxObj={{
                    handleClick: this.setNumberClick.bind(this),
                    setHtml: this.setHtml()
                }}
                rightIconObj={{
                    iconUrl: require('assets/imgs/contact/Contact@3x.svg'),
                    handleClick: this.setIconClick.bind(this)
                }}>
            </TextField>
        )
    }

    setNumberClick() {
        this.props.onSelectCountryCode && this.props.onSelectCountryCode();
    }

    setIconClick() {
        this.props.onSelectContact && this.props.onSelectContact();
    }

    setHtml() {
        const { country } = this.state;
        return (
            <div className="text-field-contact-left">{`${country}`}<i></i></div>
        );
    }

    onHandleInput(pn, json) {
        const mobile = json.value.isOnlyNumber();
        if (mobile.split("").length > 18) {
            return;
        }
        this.props.onHandleContact && this.props.onHandleContact(mobile);
    }
}

TextFieldContact.propTypes = {
    mobile: PropTypes.string
}

export default TextFieldContact;