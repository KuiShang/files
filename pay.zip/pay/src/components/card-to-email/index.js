import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'commonComponents/text-field';
import BankRecipient from 'components/bank-recipient';
import CardToContinue from 'components/card-to-continue';
import intl from 'react-intl-universal';
import './index.scss';

class CardToEmail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectRecipient: props.selectRecipient,
            defaultBank: props.defaultBank,
            email: props.email,
            disabled: props.disabled,
            showTips: props.showTips,
            showBanks: props.showBanks,
            showContinue: props.showContinue,
            onContinue: props.onContinue
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            selectRecipient: props.selectRecipient,
            email: props.email,
            disabled: props.disabled,
            showTips: props.showTips,
            showBanks: props.showBanks,
            showContinue: props.showContinue,
            bankAccount: props.bankAccount,
            onSelectBank: props.onSelectBank,
            defaultBank: props.defaultBank,
        }
    }

    render() {
        const { selectRecipient, email, defaultBank, disabled, bankAccount, showTips, showBanks, showContinue, onContinue, onSelectBank } = this.state;

        return (
            <div className="card-to-email">
                {
                    !selectRecipient &&
                    <div className="card-to-email-con">
                        <TextField inputType="email"
                            propValue={{ 
                                value: email, 
                                placeHolder: intl.get('recipient_email'), 
                                regExpMessgae: "error email", 
                                isPass: true,
                                hasRequiredMessage: true,
                             }}
                            stateName={'email'}
                            regExpFn={this.regExpEmail}
                            requireInputMessage='can not be empty'
                            setCurrentInputData={this.onHandleEmail.bind(this)}>
                        </TextField>
                    </div>
                }
                {
                    showBanks &&
                    <BankRecipient
                        defaultBank={defaultBank}
                        title={intl.get('recipient_bank')}
                        bankAccount={bankAccount}
                        onSwitchBanks={this.onSwitchBanks}
                        onSelectBank={onSelectBank}>
                    </BankRecipient>
                }
                {
                    showContinue &&
                    <CardToContinue disabled={disabled} showTips={showTips} onContinue={onContinue}>
                    </CardToContinue>
                }
            </div >
        )
    }

    regExpEmail = (val) => {
        // 验证Email地址
        const nameReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/
        
        if (!val || !nameReg.test(val)) {
          this.setState({
            showBanks: false,
            showContinue: false
          })
          return false
        } else {
          this.setState({
            showBanks: true,
            showContinue: true
          })
        }
        return true
      }

    onHandleEmail(pn, json) {
        const email = json.value.isNotChinese();
        if (email.split('').length > 30) {
            return;
        }
        let { showBanks, showContinue } = this.state;
        if (email.indexOf('@') > 0) {
            showContinue = true;
            showBanks = true;
        } else {
            showContinue = false;
            showBanks = false;
        }

        this.props.onChangeEmail && this.props.onChangeEmail(email, showContinue, showBanks);
    }

    onSwitchBanks = (e) => {
        this.props.onSwitchBanks && this.props.onSwitchBanks(e);
    }
}

CardToEmail.propTypes = {
    showTips: PropTypes.bool,
    showContinue: PropTypes.bool,
    disabled: PropTypes.bool,
    email: PropTypes.string
}

CardToEmail.defaultProps = {
    showTips: false,
    showContinue: false,
    disabled: false,
    email: ''
}

export default CardToEmail;