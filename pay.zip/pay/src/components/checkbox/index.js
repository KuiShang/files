import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';

class Checkbox extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            checked: props.checked
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            checked: props.checked
        }
    }

    render() {
        return (
            <div className="checkbox">
                <input type="checkbox" id="atcheckbox" onChange={this.onChecked} checked={this.state.checked} />
                <label htmlFor="atcheckbox">{this.props.children}</label>
            </div>
        )
    }

    onChecked = () => {
        this.props.onChecked && this.props.onChecked(!this.state.checked);
    }
}

Checkbox.propTypes = {
    checked: PropTypes.bool
}

export default Checkbox;