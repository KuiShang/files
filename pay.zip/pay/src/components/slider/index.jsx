import React from 'react';
import './index.scss'

class Slider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            maxValue: this.props.sliderData.maxValue,
            minValue: this.props.sliderData.minValue,
            step: this.props.sliderData.step,
            rangeVal: this.props.sliderData.rangeVal,
            firstValue: this.props.sliderData.firstValue,
            oSliderLeftAreaWidth: '0%',
            oSliderRightAreaWidth: '0%'
        }
        this.changeHandel = this.changeHandel.bind(this);
    }
    render() {
        return (
            <div className="slider-box">
                <input
                    className="slider-input"
                    type="range"
                    min={this.state.minValue}
                    max={this.state.maxValue}
                    step={this.state.step}
                    value={this.state.firstValue}
                    onChange={this.changeHandel.bind(this, "first")}
                />
                <div
                    ref="sliderLeftArea"
                    className="slider-left-area"
                    style={{ width: this.state.oSliderLeftAreaWidth }}
                ></div>
                <div
                    ref="sliderRightArea"
                    className="slider-right-area"
                    style={{ width: this.state.oSliderRightAreaWidth }}
                ></div>
            </div>
        )
    }
    componentDidMount() {
        this.setSliderVal(this.state.rangeVal);
        this.setState({ firstValue: this.state.rangeVal});
    }
    setSliderVal(val) {
        // alert(val)
        // alert(this.state.maxValue)
        const choiceValPercent = val/this.state.maxValue * 100;
        this.setState({ oSliderLeftAreaWidth: `calc(${choiceValPercent}%)` });
        this.setState({ oSliderRightAreaWidth: `calc(100% - ${choiceValPercent}%)` }, () => {
            this.props.onChange && this.props.onChange(val);
        });
        // console.info(`当前的value${val}`)
    }
    changeHandel(name, event) {
        let value = event.target.value;
        this.setState({ firstValue: value });
        this.setSliderVal(value);
    }
}
export default Slider;
