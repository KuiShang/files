import React from 'react';
import CardSwitch from 'components/card-switch';
import BankSelect from 'components/bank-select';
import intl from 'react-intl-universal'
import './index.scss';

export default class BankRecipient extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            title: props.title,
            checkind: props.defaultBank || 0,
            bankAccount: null,
            onSelectBank: null
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            bankAccount: props.bankAccount,
            onSelectBank: props.onSelectBank,
            checkind: props.defaultBank,

        }
    }

    render() {
        const { title, checkind, bankAccount, onSelectBank } = this.state;
        return (
            <div className="bank-recipient">
                <CardSwitch
                    title={title || intl.get('send_to_recipient')}
                    options={[intl.get('default_bank'), intl.get('another_bank')]}
                    checkind={checkind}
                    onSwitch={this.onSwitch}>
                </CardSwitch>
                {
                    (checkind === 1) &&
                    <div className="bank-recipient-bank">
                        <BankSelect
                            bankAccount={bankAccount}
                            onSelectBank={onSelectBank}>
                        </BankSelect>
                    </div>
                }
            </div>
        )
    }

    onSwitch = (e) => {
        this.props.onSwitchBanks && this.props.onSwitchBanks(e);
    }
}