import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';

export default class TextLabel extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            label: props.label,
            value: props.value,
            des: props.des
        }
    }

    render() {
        const { label, value, des } = this.state;

        return (
            <div className="text-label">
                <div className="text-label-key">{label}</div>
                <div className="text-label-value">{value}</div>
                {des && <div className="text-label-des">{des}</div>}
            </div>
        )
    }
}

TextLabel.propTypes = {
    label: PropTypes.string,
    value: PropTypes.string
}