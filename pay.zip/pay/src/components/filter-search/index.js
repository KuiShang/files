import React from 'react';
import './index.scss';

export default class FiterSearch extends React.Component {
    render() {
        const { placeholder, onChange } = this.props;
        return (
            <div className="filter-search">
                <input type="text" placeholder={placeholder || ''} onChange={onChange}></input>
            </div >
        )
    }
}