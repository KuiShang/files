import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';

export default class BankSelect extends React.Component {
    state = {
        bankAccount: null,
        onSelectBank: null
    }

    static getDerivedStateFromProps(props) {
        return {
            bankAccount: props.bankAccount,
            onSelectBank: props.onSelectBank
        }
    }

    render() {
        const { bankAccount, onSelectBank } = this.state;
        return (
            <div className="bank-select">
                <i alt="" className="bank-select-icon" />
                <span className="bank-select-con">{(bankAccount && bankAccount.bank_en_name) || intl.get('select')}</span>
                <i alt="" className="bank-select-next" onClick={onSelectBank} />
            </div>
        )
    }
}