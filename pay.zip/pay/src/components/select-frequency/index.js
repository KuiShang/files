import React from 'react';
import intl from 'react-intl-universal'
import './index.scss';

export default class SelectFrequency extends React.Component {
    state = {
        title: '',
        value: ''
    }

    static getDerivedStateFromProps(props) {
        return {
            title: props.title,
            value: props.value
        }
    }

    render() {
        const { title, value } = this.state;
        const frequency = value !== '' ? intl.get(value) : '';
        return (
            <div className="select-frequency">
                <div className="select-frequency-content">
                    <div className={`select-frequency-content-title ${value ? 'select-frequency-content-title-edit' : ''}`}>{title}</div>
                    <div className="select-frequency-content-value">{frequency}</div>
                </div>
                <i onClick={this.props.onSelect} />
            </div>
        )
    }
}