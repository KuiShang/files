import React from 'react';
import TextLabel from 'components/text-label';
import Account from './Account';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import './index.scss';
import imgPulldown from 'assets/imgs/pulldown/pulldown-small.png';
import intl from 'react-intl-universal';

const frequency = [
    { key: 'daily', label: ('once_every_day'), value: 'DAIL' },
    { key: 'weekly', label: ('once_every_week'), value: 'WEEK' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'FRTN' },
    { key: 'monthly', label: ('once_every_month'), value: 'MNTH' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'QURT' },
]

export default class CardEDDA extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            collapsed: false,
        }
    }

    render() {
        const { collapsed } = this.state;
        const { data } = this.props;
        const { endtp, endnum, toDt } = data;
        let expiry = (endtp === 'number') ? endnum : (endtp === 'time' && toDt === '' ? 'Never' : toDt);
        if (expiry === 'Never') {
            expiry = intl.get('no_end_date')
        }
        return (
            <div className="card-deposit">
                <div className="card-deposit-con">
                    <Account data={data}
                        onEdit={() => { this.props.onEdit && this.props.onEdit(data) }}>
                    </Account>
                    <div className="card-deposit-sec">
                        <div className="card-deposit-50">
                            <TextLabel label={intl.get("deposit_limit")} value={`${thousandBitSeparator(keep2DecimalFull(data.maxAmt))} ${data.maxAmtCcy}`}></TextLabel>
                        </div>
                        <div className="card-deposit-50">
                            <TextLabel label={intl.get("frequency_limit")} value={this.onGetFrequency(data.prd)}></TextLabel>
                        </div>
                    </div>
                    {
                        collapsed &&
                        <div>
                            <div>
                                <TextLabel label={intl.get("end_date")} value={expiry}></TextLabel>
                            </div>
                            <div style={{ marginBottom: '7px' }}>
                                <TextLabel label={intl.get("deposit_from")} value={intl.get("livi_savings_account")}
                                    des={data.dbtAcctId}>
                                </TextLabel>
                            </div>
                            <div>
                                <TextLabel label={intl.get("remarks")} value={data.ustrd}></TextLabel>
                            </div>
                        </div>
                    }
                    <div className="card-deposit-action">
                        <img alt="" src={imgPulldown} className={collapsed ? 'card-deposit-action-collapsed' : ''} onClick={() => this.setState({ collapsed: !this.state.collapsed })} />
                    </div>
                </div>
            </div>
        )
    }

    onGetFrequency = (prd) => {
        const temp = frequency.filter(item => {
            return item.value === prd;
        })

        return temp.length > 0 ? intl.get(temp[0].label) : ''
    }
}