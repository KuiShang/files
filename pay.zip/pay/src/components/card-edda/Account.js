import React from 'react';
import intl from 'react-intl-universal';

export default class Account extends React.Component {
    render() {
        const { data } = this.props;
        return (
            <div className="card-deposit-account">
                <div className="card-deposit-account-tip">
                    <div>{(data ? data.crdNm : '')}</div>
                    {(data && data.eddaStatus !== 'changing' && data.eddaStatus !== 'binding') && <div className="ai-btn-edit" onClick={() => this.props.onEdit()}>{intl.get("change")}</div>}
                </div>
                <div className="card-deposit-account-info">
                    <span className="card-deposit-account-alias">{(data ? data.crdAcctId : '')}</span>
                    <span className="card-deposit-account-status">
                        {this.renderAccountMessageStatus()}
                    </span>
                </div>
            </div>
        )
    }

    /**
     * 根据状态判断 显示过期或者非过期
     * 
     * Option 0: 激活状态 bindsuc/unbindfail/changesuc/changefail/suspfail
     * Option 1: 过期状态 bindfail/unbindsuc/suspsuc
     * Option 2: 签约状态 binding
     * Option 3: 中间状态 unbinding/changing/susping(不能终止，不能修改,商户不可做扣款，个人不可做即时，定时入金)
     */
    renderAccountMessageStatus() {
        const { data } = this.props;

        if (data && (data.eddaStatus === 'bindfail' || data.eddaStatus === 'unbindsuc' || data.eddaStatus === 'suspsuc')) {
            return (
                <span>
                    <span className="card-deposit-account-circle-red"></span>
                    <span>{intl.get("expired")}</span>
                </span>
            )
        } else if (data && (data.eddaStatus === 'bindsuc' || data.eddaStatus === 'unbindfail' ||
            data.eddaStatus === 'changesuc' || data.eddaStatus === 'changefail' || data.eddaStatus === 'suspfail')) {
            return (
                <span>
                    <span className="card-deposit-account-circle"></span>
                    <span>{intl.get("authorized")}</span>
                </span>
            )
        } else if (data && (data.eddaStatus === 'changing' || data.eddaStatus === 'unbinding' || data.eddaStatus === 'susping')) {
            return (
                <span>
                    <span className="card-deposit-account-circle-yellow"></span>
                    <span>{intl.get("processing")}</span>
                </span>
            )
        } else if (data && (data.eddaStatus === 'binding')) {
            return (
                <span>
                    <span className="card-deposit-account-circle-yellow"></span>
                    <span>{intl.get("pending")}</span>
                </span>
            )
        }
    }
}