import React from 'react';
import Toast from 'components/toast';
import { connect } from 'react-redux'
class Loading extends React.Component {
    componentWillReceiveProps(nextProps) {
        if (nextProps.isFetching) {
            Toast.loading('Loading...', 0);
        } else {
            Toast.hide()
        }
    }
    
    render() {
        return '';
    }
}

const mapStateToProps = (state) => ({
    isFetching: state.common.isFetching
})

export default connect(
    mapStateToProps
)(Loading)