import React from 'react';
import ReviewItem from 'components/review-item';
import intl from 'react-intl-universal';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import './index.scss';

export default class ReviewPaymentDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            info: props.info
        }
    }

    render() {
        const { info } = this.state;

        return (
            <div className="review-payment-detail">
                <div className="review-payment-detail-title">
                    <div className="review-payment-detail-title-tip">{intl.get('transfer_details')}</div>
                    <div className="ai-btn-edit" onClick={() => this.props.onEdit()}>{intl.get('change')}</div>
                </div>
                <div className="review-payment-detail-item">
                    <ReviewItem title={intl.get('amount')}>{thousandBitSeparator(keep2DecimalFull(info.pay.amount))} HKD</ReviewItem>
                </div>
                {(info.pay.isNow === 0) && this.renderNowPay()}
                {(info.pay.isNow === 1) && this.renderScheduledPay()}
                <div className="review-payment-detail-item">
                    <ReviewItem title={intl.get('remarks')}>{info.pay.remarks}</ReviewItem>
                </div>
            </div>
        )
    }

    renderNowPay = () => {
        return (
            <div className="review-payment-detail-item">
                <ReviewItem title={intl.get('transfer_time1')}>{intl.get('now')}</ReviewItem>
            </div>
        )
    }

    renderScheduledPay = () => {
        const { info } = this.state;

        let expiryValue = (info.pay.frequency.key === 'specialdate' ? '' : (info.pay.expiry.key === 'ondate' ? info.pay.expiry.value.Format('yyyy/MM/dd') : info.pay.expiry.value))
        if (info.pay.expiry.key === 'never') {
            expiryValue = intl.get('no_end_date')
        } else if (info.pay.expiry && info.pay.expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiryValue} ${intl.get('times')}`
        }

        return (
            <React.Fragment>
                <div className="review-payment-detail-item">
                    <ReviewItem title={intl.get('frequency')}>{`${info.pay.frequency ? intl.get(info.pay.frequency.label) : intl.get('once_every_month')}`}</ReviewItem>
                </div>
                <div className="review-payment-detail-item">
                    <ReviewItem title={intl.get('start_date')}>{`${info.pay.startDate ? info.pay.startDate.Format('yyyy/MM/dd') : ''}`}</ReviewItem>
                </div>
                {
                    info.pay.frequency.key !== 'specialdate' &&
                    <div className="review-payment-detail-item">
                        <ReviewItem title={intl.get('end_date')}>{expiryValue}</ReviewItem>
                    </div>
                }
            </React.Fragment>
        )
    }
}