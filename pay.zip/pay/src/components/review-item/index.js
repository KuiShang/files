import React from 'react';
import './index.scss';

export default class ReviewItem extends React.Component {
    render() {
        return (
            <div className="review-item">
                <div className="review-item-title">{this.props.title}</div>
                <div className="review-item-value">{this.props.children}</div>
            </div>
        )
    }
}