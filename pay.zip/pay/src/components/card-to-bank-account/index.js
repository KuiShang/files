import React from 'react';
import PropTypes from 'prop-types';
import BankSelect from 'components/bank-select';
import BankInput from 'components/bank-input';
import TextField from 'components/text-field';
import CardToContinue from 'components/card-to-continue';
import intl from 'react-intl-universal';
import './index.scss';

export default class CardToBankAccount extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectRecipient: props.selectRecipient,
            accountNum: props.accountNum,
            accountHolder: props.accountFullName,
            inviteCodeJSON: {
                value: this.props.rmname,
                isPass: true,
                placeHolder: intl.get('utilTip-bankInput')
            },
            disabled: props.disabled,
            bankAccount: props.bankAccount,
            showTips: props.showTips,
            showContinue: false,
            onHint: props.onHint,
            onContinue: props.onContinue,
            onSelectBank: props.onSelectBank,
            currentNewVal: ''
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            selectRecipient: props.selectRecipient,
            disabled: props.disabled,
            showTips: props.showTips,
            bankAccount: props.bankAccount,
            showContinue: props.showContinue,
            accountNum: props.accountNum,
            accountHolder: props.accountFullName
        }
    }

    render() {
        const { selectRecipient, disabled, bankAccount, accountNum, accountHolder, showTips, showContinue, onHint, onContinue, onSelectBank } = this.state;

        return (
            <div className="card-to-bank-account">
                {
                    !selectRecipient &&
                    <React.Fragment>
                        <div className="card-to-bank-account-title">{intl.get('recipient_bank')}</div>
                        <BankSelect bankAccount={bankAccount} onSelectBank={onSelectBank}></BankSelect>
                        <span style={{ height: 20, display: 'inline-block' }}></span>
                        <div className="card-to-bank-account-title">
                            {intl.get('account_details')}
                            <span style={{ color: '#008ecc', fontSize: '14px' }} onClick={onHint}>{intl.get('tips')}</span>
                        </div>
                        <BankInput
                            accountNum={accountNum}
                            bankAccount={bankAccount}
                            pyacct={this.props.pyacct}
                            pybank={this.props.pybank}
                            onChangeAccountNum={this.onChangeAccountNum}>
                        </BankInput>
                        <div style={{ margin: '20px 0 0 0' }}>
                            <TextField
                                requireInputMessage='can not be empty'
                                propValue={{
                                    // handleInputFn:this.handleInputFn.bind(this),
                                    hasRequiredMessage: true,
                                    // regExp: /^[a-zA-z]{1,25}$/,
                                    regExp: /[^\u4e00-\u9fa5]{1,60}/,
                                    regExpMessgae: 'Error',
                                    isPass: false,
                                    value: accountHolder,
                                    placeHolder: intl.get('contact_bank'),
                                }}
                                stateName={'accountHolder'}
                                setCurrentInputData={this.onHandleAccountFullName.bind(this)}>
                            </TextField>
                        </div>
                    </React.Fragment>
                }
                {
                    showContinue &&
                    <CardToContinue disabled={disabled} showTips={showTips} onContinue={onContinue}>
                    </CardToContinue>
                }
            </div>
        )
    }

    /**
     * Account No
     * 只支持数字、英文，字符长度8-16
     */
    // handleInputFn(value){
    //     // 校验输入框的值:输入值除了中文什么都可以输入，字符长度60个字符
    //     if(value.length<60){
    //         if(/[\u4e00-\u9fa5]/.test(value)){
    //             const currentReplaceVal = value.replace(/[\u4e00-\u9fa5]+/,'');
    //             // const currentNewVal = currentReplaceVal;
    //             this.setState({
    //                 currentNewVal: currentReplaceVal
    //             }) 
    //         }else{
    //             this.setState({
    //                 currentNewVal: value
    //             }) 
    //         }
    //     }else{
    //         return; 
    //     }
    //     return this.state.currentNewVal;
    // }
    onChangeAccountNum = (num) => {
        let { showContinue } = this.state;
        num = num.isOnlyNumChar();
        if (num.split("").length > 16) {
            return;
        }

        if (num.split("").length >= 8) {
            showContinue = true;
        } else {
            showContinue = false;
        }

        this.setState({ accountNum: num, showContinue }, () => {
            this.props.onChangeAccountNum && this.props.onChangeAccountNum(num, showContinue);
        })
    }

    /**
     * Account Holder Full Name
     * 字符长度为1-25
     * @param {*} pn 
     * @param {*} json 
     */
    onHandleAccountFullName(pn, json) {
        const accountFullName = json.value;
        this.props.onHandleAccountFullName && this.props.onHandleAccountFullName(accountFullName);
    }
}

CardToBankAccount.propTypes = {
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
    onHint: PropTypes.func.isRequired
}

CardToBankAccount.defaultProps = {
    showTips: false,
    disabled: false,
}

