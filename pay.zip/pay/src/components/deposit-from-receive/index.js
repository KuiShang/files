import React from 'react';
import intl from 'react-intl-universal';
import * as Mask from 'utils/MaskUtil';
import './index.scss';
import imgBank from 'assets/imgs/bank/bank-12.png';

export default class DepositFromReceive extends React.Component {
    state = {
        data: this.props.data
    }

    render() {
        const { data } = this.state;

        return (
            <div className="deposit-from-receive">
                <div className="deposit-from-receive-title">{intl.get('deposit_from')}</div>
                <div className="deposit-from-receive-cont">
                    <img alt="" src={imgBank} />
                    <div className="deposit-from-receive-cont-acc">
                        <div className="deposit-from-receive-cont-bank">{(data && data.from.bankName)}</div>
                        {/* <div className="deposit-from-receive-cont-alias">{(data && data.from.bankNo)}</div> */}
                        <div className="deposit-from-receive-cont-alias">{(data && Mask.maskName(data.receive.accountName))}</div>
                        {(data && data.from && data.from.eddaStatus === 'binding') && <div style={{ fontSize: '12px', color: '#848484' }}>Pending Authorization (3-5 business days)</div>}
                    </div>
                </div>
                <div className="deposit-from-receive-title">{intl.get('receiving_account')}</div>
                <div className="deposit-from-receive-cont">
                    <div className="deposit-from-receive-cont-s">{intl.get('livi_savings_account')}</div>
                    <div className="deposit-from-receive-cont-acc">
                        <div className="deposit-from-receive-cont-bank">{intl.get('transfer_vb_savings_account')}</div>
                        <div className="deposit-from-receive-cont-alias">{(data && data.receive.accountNo)}</div>
                    </div>
                </div>
            </div>
        )
    }
}