import React from 'react';
import ItemContactColor from 'components/item-contact-color';
import intl from 'react-intl-universal';
import './index.scss';

export default class BankRegisteredRecipient extends React.Component {
    state = {
        selectRecipient: this.props.selectRecipient,
        onChangeRecipient: this.props.onChangeRecipient
    }

    static getDerivedStateFromProps(props) {
        return {
            selectRecipient: props.selectRecipient
        }
    }

    render() {
        const { selectRecipient, onChangeRecipient } = this.state;

        return (
            <div className="bank-registered-recipient">
                <div style={{ padding: '0 18px', border: 'solid 1px #edeeef', borderRadius: '6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <ItemContactColor data={selectRecipient} style={{ border: 'none' }}>
                    </ItemContactColor>
                    <div style={{ fontSize: '14px', color: '#3f7cff' }} onClick={onChangeRecipient}>{intl.get('transfer_change')}</div>
                </div>
            </div>
        )
    }
}