import React from 'react';
import './index.scss';

export default class SelectCalendar extends React.Component {
    state = {
        title: this.props.title,
        value: this.props.value
    }

    static getDerivedStateFromProps(props) {
        return {
            title: props.title,
            value: props.value
        }
    }

    render() {
        const { title, value } = this.state;
        const date = value ? value.Format('yyyy/MM/dd') : '';
        return (
            <div className="calendar-field">
                <div className="calendar-field-content">
                    <div className={`calendar-field-content-title ${value ? 'calendar-field-content-title-edit' : ''}`}>{title}</div>
                    <div className="calendar-field-content-value">{date}</div>
                </div>
                <i onClick={this.props.onSelect} />
            </div>
        )
    }
}