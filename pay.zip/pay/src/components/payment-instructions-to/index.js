import React from 'react';
import PropTypes from 'prop-types';
import CardReview from 'components/card-review';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import intl from 'react-intl-universal';
import './index.scss';

class PaymentInstructionsTo extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isFocus: false,
            info: props.info,
            amount: props.amount,
            formatAmount: thousandBitSeparator(keep2DecimalFull(props.amount))
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            amount: props.amount,
            formatAmount: state.formatAmount
        }
    }

    render() {
        const { isFocus, info, amount, formatAmount } = this.state;
        const val = isFocus ? (amount === 0 ? '' : amount.toString()) : formatAmount;
        const realStr = val.replace(/,/, "").replace(/./, "");
        const width = (17 * realStr.split("").length) + 17;
        const showInsufficient = (info.from.balance < amount) ? true : false;

        return (
            <div className="payment-instructions-to">
                <div className="payment-instructions-to-title">{intl.get('to_t')} <span style={{ overflowWrap: 'break-word' }}>{info.to.alias}</span><span> ({info.to.number})</span></div>
                <CardReview>
                    <div className="payment-instructions-to-cont">
                        <div className="payment-instructions-to-sub">{intl.get('transfer_amount')}</div>
                        <div className="payment-instructions-to-money">
                            <div style={{ display: 'flex' }}>
                                <input type='text'
                                    style={{ width: '100%' }}
                                    value={val}
                                    onChange={e => this.onChangeAmount(e.target.value)}
                                    onFocus={this.onFocus}
                                    onBlur={this.onBlur} />
                            </div>
                            <span style={{ padding: '0 0 5px 0' }}>HKD</span>
                        </div>

                        <div className="payment-instructions-to-balance">{intl.get('currency_balance')}    &nbsp;&nbsp;    <span>{thousandBitSeparator(info.from.balance)} HKD</span>
                            {showInsufficient && <span className="card-from-price-tip" style={{ color: 'red' }}>{intl.get("insuficient_balance")}</span>}
                        </div>
                    </div>
                </CardReview>
            </div>
        )
    }

    /**
     * 修改转账金额（始终保留两位有效数字）
     */
    onChangeAmount = (amount) => {
        const val = /\D/.test(amount);
        console.info(val);

        amount = formatNum(amount);
        const ind = amount.indexOf('.');
        let temp = amount;
        if (ind > 0) {
            temp = amount.substring(0, ind);
        }

        if (temp.split("").length > 13) {
            return;
        }

        this.props.onChangeAmount && this.props.onChangeAmount(amount);
    }

    onFocus = () => {
        this.setState({ isFocus: true, formatAmount: (this.state.amount === 0 ? '' : this.state.amount) })
    }

    onBlur = () => {
        if (this.state.amount === "") {
            this.setState({ formatAmount: thousandBitSeparator(keep2DecimalFull(0)), isFocus: false })
        } else {
            this.setState({ isFocus: false, formatAmount: thousandBitSeparator(keep2DecimalFull(this.state.amount)) })
        }
    }
}

PaymentInstructionsTo.propTypes = {
    info: PropTypes.object.isRequired
}

export default PaymentInstructionsTo;

function formatNum(amount) {
    amount = amount.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    amount = amount.replace(/^\./g, ""); // 验证第一个字符是数字
    amount = amount.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    amount = amount.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    amount = amount.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); // 只能输入两个小数
    return amount;
}