import React from 'react';
import PropTypes from 'prop-types';
import DateItem from './DateItem.js';
import PureRender from './utils/PureRenderUtil.js';
import { nextDate } from './utils/TimeUtil.js';
import { dateConfigMap } from './Config';

/**
 * 大写首字母
 * @param {String} 字符串 
 */
const capitalize = ([first, ...rest]) => first.toUpperCase() + rest.join('');

/**
 * 判断数组
 * @param {any} val 
 */
const isArray = val => Object.prototype.toString.apply(val) === '[object Array]';

class Date extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            value: props.value ? nextDate(props.value) : null,
        };

        this.handleFinishBtnClick = this.handleFinishBtnClick.bind(this);
        this.handleDateSelect = this.handleDateSelect.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        const date = nextDate(nextProps.value);
        if (date.getTime() !== this.state.value.getTime()) {
            this.setState({ value: date });
        }
    }

    /**
     * When you swipe two datepickeritems at the same time.
     * Prevent dates from going out.
     */
    componentDidUpdate() {
        const value = this.state.value;
        const { min, max } = this.props;
        if (value.getTime() > max.getTime()) {
            this.setState({ value: max });
        }

        if (value.getTime() < min.getTime()) {
            this.setState({ value: min });
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        const date = nextDate(nextState.value);
        return date.getTime() !== this.state.value.getTime() || PureRender.shouldComponentUpdate(nextProps, nextState, this.props, this.state);
    }

    render() {
        const { min, max, dateConfig } = this.props;
        const value = this.state.value; 
        const dataConfigList = this.normalizeDateConfig(dateConfig);
        return (
            <div className={`datepicker default`}>
                <div className="datepicker-content">
                    {
                        dataConfigList.map((item, index) => {
                            return (
                                <DateItem key={index} value={value} min={min} max={max}
                                    step={item.step} type={item.type} format={item.format}
                                    onSelect={this.handleDateSelect} />
                            )
                        })
                    }
                </div>
                {
                    (this.props.doTitle && this.props.onDoClick) &&
                    <div className="datepicker-actions">
                        <div onClick={this.onDoClick}>{this.props.doTitle}</div>
                    </div>
                }
            </div>
        )
    }

    /**
     * 点击完成按钮事件
     * @return {undefined}
     */
    handleFinishBtnClick() {
        this.props.onSelect(this.state.value);
    }

    /**
     * 选择下一个日期
     * @return {undefined}
     */
    handleDateSelect(value) {
        this.props.onSelectDate && this.props.onSelectDate(value);
    }

    /**
     * 格式化dateConfig
     * @param {*} dataConfig dateConfig属性
     */
    normalizeDateConfig(dataConfig) {
        const configList = [];
        for (const key in dataConfig) {
            if (dataConfig.hasOwnProperty(key)) {
                const lowerCaseKey = key.toLocaleLowerCase();
                if (dateConfigMap.hasOwnProperty(lowerCaseKey)) {
                    configList.push({
                        ...dateConfigMap[lowerCaseKey],
                        ...dataConfig[key],
                        type: capitalize(lowerCaseKey),
                    });
                }
            }
        }

        return configList;
    }

    onDoClick = () => {
        this.props.onDoClick && this.props.onDoClick()
    }
}

Date.propTypes = {
    theme: PropTypes.string,
    value: PropTypes.object,
    min: PropTypes.object,
    max: PropTypes.object,
    showHeader: PropTypes.bool,
    showCaption: PropTypes.bool,
    dateConfig: PropTypes.oneOfType([
        PropTypes.object,
        PropTypes.array
    ]),
    headerFormat: PropTypes.string,
    confirmText: PropTypes.string,
    cancelText: PropTypes.string,
    onSelect: PropTypes.func,
    onCancel: PropTypes.func,
}

export default Date;