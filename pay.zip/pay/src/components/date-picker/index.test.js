import React from 'react'
import renderer from 'react-test-renderer'

import DatePicker from './index'

it('render correctly', () => {
    const tree = renderer
        .create(<DatePicker className="success">Snapshot testing</DatePicker>)
        .toJSON();

    expect(tree).toMatchSnapshot();
})