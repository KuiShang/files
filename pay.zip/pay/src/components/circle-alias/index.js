import React from 'react';

export default class CircleAlias extends React.Component {
    state = { value: this.props.value }

    static getDerivedStateFromProps(props) {
        return {
            value: props.value
        }
    }

    render() {
        return (
            <div></div>
        )
    }
}