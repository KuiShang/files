import React from 'react';
import List from 'components/list';
import './index.scss';

export default class PhonePicker extends React.Component {
    state = {
        data: []
    }

    static getDerivedStateFromProps(props) {
        return {
            data: props.data
        }
    }

    render() {
        const { data } = this.state;

        return (
            <List>
                <div className="phone-picker">
                    {
                        data.map((item, index) => {
                            return <div className="phone-item" key={index} onClick={() => this.props.onSelect(item)}>{item.value}</div>
                        })
                    }
                </div>
            </List>
        )
    }
}