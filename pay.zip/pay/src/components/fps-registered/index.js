import React from 'react';
import intl from 'react-intl-universal';
import CheckBoxCircle from 'components/check-box-circle';
import * as SDK from 'utils/SDKUtil';
import * as Mask from 'utils/MaskUtil';
import './index.scss';

export default class FPSRegistered extends React.Component {
    state = {
        checkedType: 0,
        checkedAccount: null,
        email: '',
        mobile: '',
        seddaEmail: [],
        seddaMobile: []
    }

    static getDerivedStateFromProps(props) {
        return {
            checkedType: props.checkedType,
            checkedAccount: props.checkedAccount,
            email: props.email,
            mobile: props.mobile,
            seddaEmail: props.seddaEmail,
            seddaMobile: props.seddaMobile
        }
    }

    componentDidMount(){
        this.props.continueBtnCanClick&&this.props.continueBtnCanClick();
    }

    render() {
        const { mobile, email } = this.state;

        return (
            <div className="fps-registered">
                <div className="fps-registered-item">
                    <div className="fps-registered-item-tip">{intl.get('linked_to')} {Mask.maskMobile(mobile)}</div>
                    {this.renderMobileItems()}
                </div>
                <div className="fps-registered-item">
                    <div className="fps-registered-item-tip">{intl.get('linked_to')} {Mask.maskEmail(email)}</div>
                    {this.renderEmailItems()}
                </div>
            </div>
        )
    }

    renderMobileItems = () => {
        const { seddaMobile, checkedType, checkedAccount } = this.state;
        if (!seddaMobile || seddaMobile.length <= 0) {
            return null;
        }

        return (
            seddaMobile.map(item => {
                let checked = false;
                if (checkedType === 0 && checkedAccount && checkedAccount.agent_MmbId === item.agent_MmbId) {
                    checked = true;
                }

                return (
                    <div key={`MO-${item.agent_MmbId}`} className="fps-registered-item-detail">
                        <div style={{ margin: '0 10px 0 0' }}>
                            <CheckBoxCircle checked={checked}
                                onChecked={() => this.onCheckAccount(0, item)}>
                            </CheckBoxCircle>
                        </div>
                        <div className="fps-registered-item-account">
                            <span>{item.partnm}</span>
                            <span>{Mask.maskName(item.dispNm_en)}</span>
                        </div>
                    </div>
                )
            })
        )
    }

    renderEmailItems = () => {
        const { seddaEmail, checkedType, checkedAccount } = this.state;
        if (!seddaEmail || seddaEmail.length <= 0) {
            return null;
        }

        return (
            seddaEmail.map(item => {
                let checked = false;
                if (checkedType === 1 && checkedAccount && checkedAccount.agent_MmbId === item.agent_MmbId) {
                    checked = true;
                }

                return (
                    <div key={`EM-${item.agent_MmbId}`} className="fps-registered-item-detail">
                        <div style={{ margin: '0 10px 0 0' }}>
                            <CheckBoxCircle
                                checked={checked}
                                onChecked={() => this.onCheckAccount(1, item)}>
                            </CheckBoxCircle>
                        </div>
                        <div className="fps-registered-item-account">
                            <span>{item.partnm}</span>
                            <span>{Mask.maskName(item.dispNm_en)}</span>
                        </div>
                    </div>
                )
            })
        )
    }

    onCheckAccount = (type, account) => {
        this.props.onCheckAccount && this.props.onCheckAccount(type, account);
    }
}