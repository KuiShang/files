import React from 'react';
import intl from 'react-intl-universal';
import * as Mask from 'utils/MaskUtil';

export default class Account extends React.Component {
    render() {
        const { data } = this.props;
        return (
            <div className="card-deposit-account">
                <div className="card-deposit-account-tip">
                    <div>{(data && data.otbkna) || ''}</div>
                    {(data && data.transt !== 'Pending') && <div className="ai-btn-edit" onClick={() => this.props.onEdit()}>{intl.get('change')}</div>}
                </div>
                <div className="card-deposit-account-info">
                    <span className="card-deposit-account-alias">{(data && Mask.maskName(data.otacna))}</span>
                    <span className="card-deposit-account-status">
                        {this.renderAccountMessageStatus()}
                    </span>
                </div>
            </div>
        )
    }

    /**
     * 根据状态判断 显示过期或者非过期
     */
    renderAccountMessageStatus() {
        const { data } = this.props;
        if (data && data.transt === 'Invalid') {
            return (
                <span>
                    <span className="card-deposit-account-circle-red"></span>
                    <span>{intl.get('expired')}</span>
                </span>
            )
        } else if (data && data.transt === 'Enable') {
            return (
                <span>
                    <span className="card-deposit-account-circle"></span>
                    <span>{intl.get('authorized')}</span>
                </span>
            )
        } else if (data && data.transt === 'Pending') {
            return (
                <span>
                    <span className="card-deposit-account-circle-yellow"></span>
                    <span>{intl.get('pending')}</span>
                </span>
            )
        }
    }
}