import React from 'react';
import TextLabel from 'components/text-label';
import Account from './Account';
import intl from 'react-intl-universal';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import './index.scss';
import imgPulldown from 'assets/imgs/pulldown/pulldown-small.png';

const frequency = [
    { key: 'specialdate', label: 'on_a_specific_date', value: 'specialdate' },
    { key: 'daily', label: ("once_a_day"), value: 'daily' },
    { key: 'weekly', label: ("once_a_week"), value: 'weekly' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'biweekly' },
    { key: 'monthly', label: ("once_a_month"), value: 'monthly' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'quarterly' },
]

export default class CardDeposit extends React.Component {
    state = { collapsed: false }

    render() {
        const { collapsed } = this.state;
        const { data } = this.props;
        const { signtp, todate } = data;
        let expiry = (signtp === 'number') ? todate : (signtp === 'time' && todate === '' ? 'Never' : todate);
        if (expiry === 'Never') {
            expiry = intl.get('no_end_date');
        }
        return (
            <div className="card-deposit">
                <div className="card-deposit-con">
                    <Account data={data}
                        onEdit={() => { this.props.onEdit && this.props.onEdit(data) }}>
                    </Account>
                    <div className="card-deposit-sec">
                        <div className="card-deposit-50">
                            <TextLabel label={intl.get('deposit_amount')} value={`${thousandBitSeparator(keep2DecimalFull(data.insamt))} ${data.insccy}`}></TextLabel>
                        </div>
                        <div className="card-deposit-50">
                            <TextLabel label={intl.get('frequency')} value={this.onGetFrequency(data.resvpd) && intl.get(this.onGetFrequency(data.resvpd))}></TextLabel>
                        </div>
                    </div>
                    {
                        collapsed &&
                        <div>
                            <div>
                                <TextLabel label={intl.get('end_date')} value={expiry}></TextLabel>
                            </div>
                            <div>
                                <TextLabel label={intl.get('start_date')} value={data.fmdate}></TextLabel>
                            </div>
                            <div>
                                <TextLabel label={intl.get('remarks')} value={data.ustrd || ''}></TextLabel>
                            </div>
                        </div>
                    }
                    <div className="card-deposit-action">
                        <img alt="" src={imgPulldown} className={collapsed ? 'card-deposit-action-collapsed' : ''} onClick={() => this.setState({ collapsed: !this.state.collapsed })} />
                    </div>
                </div>
            </div>
        )
    }

    onGetFrequency = (prd) => {
        const temp = frequency.filter(item => {
            return item.value === prd;
        })

        return temp.length > 0 ? temp[0].label : null;
    }
}