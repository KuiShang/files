import React from 'react'
import TouchFeedback from 'rmc-feedback';
import PropTypes from 'prop-types'
import './style.scss'
import logo from './icons-24-x-24-bank-12@3x.png';
import arrow from './icons-20-x-20-next@3x.png';

class ClickItem extends React.Component {
  static defaultProps = {
    prefixCls: 'v-click-item',
    size: 'large',
    inline: false,
    disabled: false,
    loading: false,
    activeStyle: {},
  }
  render() {
    const {
      prefixCls,
      disabled,
      activeStyle,
      activeClassName
    } = this.props
    return (
      <TouchFeedback
        activeClassName={
          activeClassName || (activeStyle ? `${prefixCls}-active` : undefined)}
        disabled={disabled}
        activeStyle={activeStyle}
      >
      {/* eslint-disable-next-line */}
      <div className="v-click-item">
          <p className="left-container">
            <img src={logo} alt="" className="logo"/>
            <span className="text">please select</span>
          </p>
      
          <img src={arrow} alt="" className="arrow"/>
        </div>
      </TouchFeedback>
    )
  }

}

ClickItem.propTypes = {
  type: PropTypes.oneOf(['primary', 'warning'])
}

export default ClickItem