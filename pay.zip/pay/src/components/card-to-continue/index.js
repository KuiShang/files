import React from 'react';
import PropTypes from 'prop-types';
import intl from 'react-intl-universal';
import './index.scss';

class CardToContinue extends React.Component {
    state = {
        disabled: false,
        showTips: false
    }

    static getDerivedStateFromProps(props) {
        return {
            disabled: props.disabled,
            showTips: props.showTips
        }
    }

    render() {
        const { showTips } = this.state;

        return (
            <React.Fragment>
                {
                    showTips &&
                    <div className="card-to-continue-tips">
                        <span className="card-to-continue-tip-red">{intl.get('no_activated_fps')}</span>
                        <span className="card-to-continue-tip">{intl.get('tips_transfer_using_account')}</span>
                        {/* <span className="card-to-continue-tip">{intl.get('tips_transfer_using_account_for_friend')}</span> */}
                    </div>
                }
                <div className="card-to-continue">
                    <div id="btn-continue" className="ai-btn-primary" disabled={this.state.disabled} onClick={this.onContinue}>{intl.get("transfer_continue")}</div>
                </div>
            </React.Fragment>
        )
    }

    onContinue = () => {
        if (this.state.disabled) {
            return false;
        }

        this.props.onContinue && this.props.onContinue();
    }
}

CardToContinue.propTypes = {
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
}

CardToContinue.defaultProps = {
    showTips: false,
    disabled: false,
}

export default CardToContinue;