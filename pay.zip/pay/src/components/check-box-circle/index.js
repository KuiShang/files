import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';

class CheckBoxCircle extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            checked: props.checked
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            checked: props.checked
        }
    }

    render() {
        const { checked } = this.state;

        return (
            <div className={`checkbox`} onClick={this.onChecked}>
                <img alt="" src={checked ? require('assets/imgs/circle/active.png') : require('assets/imgs/circle/normal.png')} />
            </div>
        )
    }

    onChecked = () => {
        this.props.onChecked && this.props.onChecked();
    }
}

CheckBoxCircle.propTypes = {
    checked: PropTypes.bool
}

export default CheckBoxCircle;