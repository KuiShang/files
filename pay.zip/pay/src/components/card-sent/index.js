import React from 'react';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import intl from 'react-intl-universal';
import './index.scss';

export default class CardSent extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            amount: thousandBitSeparator(keep2DecimalFull(props.amount || 0)),
            alias: props.alias || '',
            proxyNo: props.proxyNo || '',
            title: props.title || '',
            des: props.des || '',
        }
    }

    render() {
        const { title, des, amount, alias, proxyNo } = this.state;
        return (
            <div className="card-sent">
                <div className="card-sent-title">{title}</div>
                <div className="card-sent-money">{amount}<span className="card-sent-money-unit">HKD</span></div>
                <div className="card-sent-to">
                    {des}
                    {!des &&
                        <React.Fragment>
                            {intl.get("to_p")}<span className="card-sent-to-name">{alias}</span><span>({proxyNo})</span>
                        </React.Fragment>
                    }
                </div>
            </div>
        )
    }
}