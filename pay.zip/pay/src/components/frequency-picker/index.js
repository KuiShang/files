import React from 'react';
import List from 'components/list';
import Item from './Item';
import './index.scss';

/**
 * 预约转账时周期枚举
 */
const frequencies = [
    { key: 'specialdate', label: 'on_a_specific_date', value: 'specialdate' },
    { key: 'weekly', label: 'once_every_week', value: 'weekly' },
    { key: 'biweekly', label: 'once_every_2_weeks', value: 'biweekly' },
    { key: 'monthly', label: 'once_every_month', value: 'monthly' },
    { key: 'quarterly', label: 'once_every_quarter', value: 'quarterly' },
]

/**
 * eDDA周期枚举
 */
const eddaFrequencies = [
    // { key: 'specialdate', label: 'on_a_specific_date', value: 'specialdate' },
    { key: 'daily', label: 'once_every_day', value: 'DAIL' },
    { key: 'weekly', label: 'once_every_week', value: 'WEEK' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'FRTN' },
    { key: 'monthly', label: 'once_every_month', value: 'MNTH' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'QURT' },
    // { key: 'yearly', label: 'once_every_year', value: 'YEAR' },
    // { key: 'unlimited', label: 'Unlimited', value: 'UNLIMITED' }
]

/**
 * 其他定时入金SeDDA时周期枚举
 */
const seddaFrequencies = [
    { key: 'specialdate', label: 'on_a_specific_date', value: 'specialdate' },
    { key: 'daily', label: ("once_a_day"), value: 'daily' },
    { key: 'weekly', label: ("once_a_week"), value: 'weekly' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'biweekly' },
    { key: 'monthly', label: ("once_a_month"), value: 'monthly' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'quarterly' },
    // { key: 'halfyearly', label: ("once_a_half_year"), value: 'semiyearly' },
    // { key: 'yearly', label: ("once_a_year"), value: 'yearly' },
]

class FrequencyPicker extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isTransfer: props.isTransfer || false,
            iseDDA: props.iseDDA || false,
            isSeDDA: props.isSeDDA || false,
            frequency: props.data
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            frequency: props.data
        }
    }

    render() {
        const { isTransfer, iseDDA, isSeDDA } = this.state;
        return (
            <div>
                {(!isTransfer && !isSeDDA)}
                {/* {(!isTransfer && !isSeDDA) && <div>Transfer will occur on start date</div>} */}
                <List>
                    {isTransfer && this.renderTransferFrequenceies()}
                    {iseDDA && this.renderEDDAFrequencies()}
                    {isSeDDA && this.renderSeDDAFrequencies()}
                </List>
            </div>

        )
    }

    renderTransferFrequenceies = () => {
        const { frequency } = this.state;

        return frequencies && frequencies.map(item => {
            return <Item key={item.key} data={item} checked={(frequency && (item.key === frequency.key)) ? true : false} onSelectItem={() => this.onSelectItem(item)}></Item>
        })
    }

    renderEDDAFrequencies = () => {
        const { frequency } = this.state;

        return eddaFrequencies.map(item => {
            return <Item key={item.key} data={item} checked={(frequency && (item.key === frequency.key)) ? true : false} onSelectItem={() => this.onSelectItem(item)}></Item>
        })
    }

    renderSeDDAFrequencies = () => {
        const { frequency } = this.state;

        return seddaFrequencies.map(item => {
            return <Item key={item.key} data={item} checked={(frequency && (item.key === frequency.key)) ? true : false} onSelectItem={() => this.onSelectItem(item)}></Item>
        })
    }

    onSelectItem = (item) => {
        this.props.onSelectFrequency && this.props.onSelectFrequency(item);
    }
}

export default FrequencyPicker;

