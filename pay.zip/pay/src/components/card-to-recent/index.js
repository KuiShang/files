import React from 'react';
import FilterSearch from 'components/filter-search';
import BankRecipient from 'components/bank-recipient';
import CardToContinue from 'components/card-to-continue';
import intl from 'react-intl-universal';

export default class CardToRecent extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectRecipient: props.selectRecipient,
            showBanks: props.showBanks,
            bankAccount: props.bankAccount,
            defaultBank: props.defaultBank,
            disabled: props.disabled,
            onChangeRecipient: props.onChangeRecipient,
            onContinue: props.onContinue,
            onSelectBank: props.onSelectBank,
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            disabled: props.disabled,
            selectRecipient: props.selectRecipient,
            showBanks: props.showBanks,
            bankAccount: props.bankAccount,
            defaultBank: props.defaultBank,
            onSelectBank: props.onSelectBank,
        }
    }

    render() {
        const { showBanks, selectRecipient, defaultBank, bankAccount, disabled, onChangeRecipient, onSelectBank, onContinue } = this.state;

        return (
            <div>
                <div style={{ padding: '0 20px 0' }}>
                    {
                        showBanks &&
                        <BankRecipient
                            defaultBank={defaultBank}
                            onSwitchBanks={this.onSwitchBanks}
                            bankAccount={bankAccount}
                            onSelectBank={onSelectBank}>
                        </BankRecipient>
                    }
                    {
                        selectRecipient &&
                        <React.Fragment>
                            <CardToContinue disabled={disabled} onContinue={onContinue}></CardToContinue>
                        </React.Fragment>
                    }
                    {
                        !selectRecipient &&
                        <FilterSearch placeholder={intl.get('search')} onChange={this.onFilter}></FilterSearch>
                    }
                </div>
            </div>
        )
    }

    onFilter = (e) => {
        if (!e.target) {
            return;
        }

        this.props.onFilter && this.props.onFilter(e.target.value);
    }

    onSelectItem = (obj) => {
        this.setState({ selectRecipient: obj })
    }

    onSwitchBanks = (e) => {
        this.props.onSwitchBanks && this.props.onSwitchBanks(e);
    }
}