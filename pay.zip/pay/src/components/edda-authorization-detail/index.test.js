import React from 'react'
import renderer from 'react-test-renderer'

import EDDAAuthorizationDetail from './index'

it('render correctly', () => {
    const tree = renderer
        .create(<EDDAAuthorizationDetail>Snapshot testing</EDDAAuthorizationDetail>)
        .toJSON();

    expect(tree).toMatchSnapshot();
})