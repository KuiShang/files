import React from 'react';
import './index.scss';
import intl from 'react-intl-universal';

export default class EDDAAuthorizationDetail extends React.Component {
    state = { detail: this.props.detail }

    render() {
        const { detail } = this.state;
        const { endnum, endtp, toDt } = detail;
        const expiry = ((endtp === 'number') ? endnum : (endtp === 'time' && toDt === '' ? 'Never' : toDt));

        return (
            <div className="transaction-detail">
                <div className="transaction-detail-card">
                    <div className="transaction-detail-card-title">{intl.get("debit_details")}</div>
                    <div>
                        <div className="transaction-detail-card-title-sub">{intl.get("from")}</div>
                        <div className="transaction-detail-info-label">{intl.get("livi_savings_account")}</div>
                        <div className="transaction-detail-info-value">{detail.dbtAcctId || ''}</div>
                    </div>
                    <div>
                        <div className="transaction-detail-card-title-sub">{intl.get("to")}</div>
                        <div className="transaction-detail-info-label">{detail.crdNm}</div>
                        <div className="transaction-detail-info-value">{detail.crdAcctId}</div>
                        {/* <div className="transaction-detail-card-title-sub">Authorized</div>
                        <div className="transaction-detail-info-label">{detail.crdNm}</div>
                        <div className="transaction-detail-info-value">{detail.cdtrRef}</div> */}
                    </div>
                </div>
                <div className="transaction-detail-card">
                    <div className="transaction-detail-card-title">{intl.get("debit_Instructions")}</div>
                    {/* <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">Authorization Type</div>
                        <div className="transaction-detail-info-value">Set Debit Limit</div>
                    </div> */}
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("debit_limit_per_transaction")}</div>
                        <div className="transaction-detail-info-value">{detail.maxAmt} HKD</div>
                    </div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("frequency_limit")}</div>
                        <div className="transaction-detail-info-value">{detail.prd}</div>
                    </div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("end_date")}</div>
                        <div className="transaction-detail-info-value">{expiry}</div>
                    </div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("remarks")}</div>
                        <div className="transaction-detail-info-value">{detail.ustrd}</div>
                    </div>
                </div>
            </div>
        )
    }
}