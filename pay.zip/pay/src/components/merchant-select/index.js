import React from 'react';
import './index.scss';
import intl from 'react-intl-universal';

export default class MerchantSelect extends React.Component {
    state = {
        merchant: null,
        onSelectMerchant: null
    }

    static getDerivedStateFromProps(props) {
        return {
            merchant: props.merchant,
            onSelectMerchant: props.onSelectMerchant
        }
    }

    render() {
        const { merchant, onSelectMerchant } = this.state;
        return (
            <div className="merchant-select">
                <div className="merchant-select-tip">
                    <span style={{ color: '#848484' }}>{intl.get("merchant")}</span>
                    <span className="merchant-select-con">{(merchant && merchant.custnm) || intl.get('select')}</span>
                </div>
                <i alt="" className="merchant-select-next" onClick={onSelectMerchant} />
            </div>
        )
    }
}