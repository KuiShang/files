import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';

export default class DialogSeDDAPendingTip extends React.Component {
    render() {
        return (
            <div className="dialog-sedda-pending">
                <img alt="" src={require('assets/imgs/pending/pending.png')} />
                <div className="dialog-sedda-pending-tip">
                    <div style={{ color: '#484848' }}>{intl.get('pending_authorization')}</div>
                    <div style={{ color: '#848484' }}>{intl.get('authorization_requires_business_days')}</div>
                </div>
                <ul className="dialog-sedda-pending-actions">
                    <li className="ai-btn-primary" style={{ color: '#FFFFFF' }} onClick={() => this.props.onOkay()}>Okay</li>
                </ul>
            </div>
        )
    }
}