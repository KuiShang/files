import React from 'react';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import intl from 'react-intl-universal';
import './index.scss';

export default class DepositDetail extends React.Component {
    state = {
        detail: this.props.detail
    }

    render() {
        const { detail } = this.state;

        return (
            <div className="transaction-detail">
                {/* <div className="transaction-detail-card">
                    <div className="transaction-detail-card-title">Bank Account Info</div>
                    <div>
                        <div className="transaction-detail-card-title-sub">{intl.get("from")}</div>
                        <div className="transaction-detail-info-label">{intl.get("transfer_vb_savings_account")}</div>
                        <div className="transaction-detail-info-value">{detail.dbtAcctId || ''}</div>
                    </div>
                    <div>
                        <div className="transaction-detail-card-title-sub">To</div>
                        <div className="transaction-detail-info-label">{detail.crdNm || ''}</div>
                        <div className="transaction-detail-info-value">{detail.crdAcctId || ''}</div>
                        <div className="transaction-detail-info-label">{intl.get("default_bank")}</div>
                    </div>
                </div> */}
                <div className="transaction-detail-card">
                    <div className="transaction-detail-card-title">{intl.get('transfer_details')}</div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("amount")}</div>
                        <div className="transaction-detail-info-value">{thousandBitSeparator(keep2DecimalFull(detail.instdAmt || 0))} HKD</div>
                    </div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("from")}</div>
                        <div className="transaction-detail-info-value">{detail.dbtNm || ""} ({detail.dbtAcctId || ''})</div>
                    </div>
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get("transfer_time")}</div>
                        <div className="transaction-detail-info-value">{detail.trandt || ''}</div>
                    </div>
                    {
                        detail.qytype === "1" &&
                        <div className="transaction-detail-info">
                            <div className="transaction-detail-info-label">{intl.get('start_date')}</div>
                            <div className="transaction-detail-info-value">{detail.stadat || ''}</div>
                        </div>
                    }
                    {
                        ((detail.qytype === "1" || detail === '') && (detail.period !== 'specialdate')) &&
                        <div className="transaction-detail-info">
                            <div className="transaction-detail-info-label">{intl.get('end_date')}</div>
                            <div className="transaction-detail-info-value">{detail.enddat === '' ? intl.get('no_end_date') : (detail.endtp === 'time' ? detail.enddat : (`${intl.get('repeat')} ${detail.enddat} ${intl.get('times')}`))}</div>
                        </div>
                    }
                    <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">{intl.get('remarks')}</div>
                        <div className="transaction-detail-info-value">{detail.ustrd}</div>
                    </div>
                    {/* <div className="transaction-detail-info">
                        <div className="transaction-detail-info-label">Transfer Code</div>
                        <div className="transaction-detail-info-value">{detail.chnlcd || ''}</div>
                    </div> */}
                </div>
            </div>
        )
    }

    /**
     * Option 1: 00 - 转账成功
     * Option 2: 01 - 初始化
     * Option 3: 02 - 失败
     * Option 4: 03 - 过风控返回
     * Option 5: 04 - 发送支付渠道成功
     */
    onConstruct = (key) => {
        const status = [
            { key: '00', value: '转账成功' },
            { key: '01', value: '初始化' },
            { key: '02', value: '失败' },
            { key: '03', value: '过风控返回' },
            { key: '04', value: '发送支付渠道成功' },
        ]

        const temp = status.filter(item => {
            return key === item.key;
        });

        return temp.length > 0 ? temp[0].value : "发送支付渠道成功";
    }
}