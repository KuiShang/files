import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { InputComponent, TextFieldWrapper, LeftBox, RightIcon } from './style';

/**
 * 底层基础输入控件，不要将业务逻辑相应的字符限制输入放入此处。
 * 对于特定的输入框，需要可以将其再做一层封装。
 * 此处的修改会影响到整个的输入；
 */
export default class TextField extends Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
    this.state = {
      isEdit: false,
      isError: false
    };
  }
  render() {
    const { placeHolder, regExpMessgae, hasRequiredMessage, value, handleInputFn } = this.props.propValue;
    const { requireInputMessage, leftBoxObj, inputType, rightIconObj, hasCloseBtn } = this.props;

    return (
      <InputComponent>
        <TextFieldWrapper
          onClick={(event) => { this.wrapperClick(event) }}
          style={{ 'borderColor': this.state.isError ? '#d0021b' : '#edeeef' }}
          className={this.state.isEdit || value ? 'edit' : ''}>
          {leftBoxObj && leftBoxObj.setHtml ?
            <LeftBox
              onClick={() => { this.inputHandleClick() }}>{leftBoxObj.setHtml}</LeftBox> : ''
          }
          <div
            className="wrapper"
            onClick={(ev) => { this.handleClick(ev) }}>
            <div className="place-holder">{placeHolder}</div>
            <input
              style={{ width: '100%' }}
              ref={this.inputRef}
              onBlur={() => { this.handleBlur() }}
              onChange={(ev) => { this.handleInput(ev) }}
              value={handleInputFn ? handleInputFn(value) : value}
              type={inputType} />
          </div>
          <div className="flex-right">
            {hasCloseBtn && value ? <div className="close-btn" onClick={() => { this.closeFn() }}><i></i></div> : ''}
            {rightIconObj && rightIconObj.iconUrl ?
              <div className="icon-btn" onClick={() => { this.iconHandleClick() }}><RightIcon iconUrl={rightIconObj.iconUrl} /></div> : ''
            }
          </div>
        </TextFieldWrapper>
        <div className="error-box" style={{ display: this.state.isError ? 'block' : 'none' }}>
          {!value && hasRequiredMessage ? requireInputMessage : regExpMessgae}
        </div>
      </InputComponent>
    );
  }
  handleClick(event) {
    this.setState({
      isEdit: true,
      isError: false
    });
    this.inputRef.current.focus();
    event.stopPropagation();
    event.preventDefault();
  }
  wrapperClick(event) {
    this.setState({
      isError: false
    });
    event.stopPropagation();
    event.preventDefault();
  }
  inputHandleClick() {
    if (this.props.leftBoxObj && this.props.leftBoxObj.handleClick) {
      this.props.leftBoxObj.handleClick();
    }
  }
  iconHandleClick() {
    if (this.props.rightIconObj && this.props.rightIconObj.handleClick) {
      this.props.rightIconObj.handleClick();
    }
  }
  closeFn() {
    this.setState({
      isEdit: true
    });
    this.inputRef.current.focus();
    this.inputRef.current.value = '';
    this.props.setCurrentInputData && this.props.setCurrentInputData(this.props.stateName, {
      value: this.inputRef.current.value
    }, false);
  }
  handleBlur() {
    const regExp = this.props.propValue.regExp;
    const currentValue = this.inputRef.current.value;
    let isPass = false;
    if (regExp) {
      if (regExp.test(currentValue)) {
        isPass = true;
        this.setState({
          isError: false
        });
      } else {
        isPass = false;
        this.setState({
          isError: true
        });
      }
    }
    this.props.setCurrentInputData && this.props.setCurrentInputData(this.props.stateName, {
      isPass,
      value: currentValue
    });
    if (!currentValue) {
      this.setState({
        isEdit: false
      });
    }
  }
  handleInput(e) {
    let currentVal = e.target.value;
    if (this.props.propValue && this.props.propValue.handleInputFn) {
      currentVal = this.props.propValue.handleInputFn(currentVal);
    }
    this.setState({
      isError: false
    });
    this.props.setCurrentInputData && this.props.setCurrentInputData(this.props.stateName, {
      value: currentVal
    }, false);
  }
}

TextField.propTypes = {
  requireInputMessage: PropTypes.string,
  inputType: PropTypes.string,
  hasCloseBtn: PropTypes.bool
};
// 为属性指定默认值:
TextField.defaultProps = {
  requireInputMessage: 'Can not be empty',
  inputType: 'text',
  hasCloseBtn: true
};

