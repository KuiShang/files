import styled from 'styled-components';

export const InputComponent = styled.div`
  .error-box {
    padding-top: 0.04rem;
    font-family: SFUIDisplay DroidSans Arial;
    font-size: 0.11rem;
    line-height: 0.16rem;
    color: #d0021b;
  }
`;

export const TextFieldWrapper = styled.div`
  display: flex;
  align-items: center;

  box-sizing: border-box;
  width: 100%;
  height: ${(props) => props.height ? props.height : '0.56rem'};
  border-radius: 0.04rem;
  border: 0.01rem solid #edeeef;
  transition: all ease 0.3s;
  font-size: 0.16rem;
  .wrapper {
    position: relative;
    overflow: hidden;
    height: 100%;
    flex: 1;
  }
  .place-holder {
    z-index: 2;
    position: absolute;
    left: 0.16rem;
    top: 0.16rem;
    right: 0;
    height: 0.24rem;
    line-height: 0.24rem;
    color: #848484;
    transition: all 0.3s ease;
  }
    
  input {
    /* caret-color: #4A90E2; */
    box-sizing:border-box;
    position: absolute;
    bottom: 0.06rem;
    left: 0.16rem;
    /* min-width: 80%; */
    height: 0.24rem;
    line-height: 0.24rem;
    font-size: .16rem;
    color: #484848;
    border: 0;
    min-width:0;
    max-width: calc(100% - 0.16rem);
  }
  &.edit {
    .place-holder {
      font-size: .11rem;
      color: #848484;
      transform: translate3d(0,-44%,0);
    }
    &.pass:not(.active):not(.error) .place-holder {
      color: #ccc;
    }
    &.active, &:focus{
      .place-holder { color: blue;}
    }
  }
  .flex-right {
    display: flex;
    align-items: center;
    padding-right: 0.09rem;
  }
  .close-btn {
    padding: 0.09rem;
    & > i {
      display: block;
      width: 0.2rem;
      height: 0.2rem;
      background: url(${require('./close.png')}) no-repeat;
      background-size: cover;
    }
  }
  .icon-btn {
    padding: 0.09rem;
    & > i {
      display: block;
      width: 0.2rem;
      height: 0.2rem;
      background-repeat: no-repeat;
      background-size: cover;
    }
  }
`;

export const LeftBox = styled.div`
  width: ${(props) => props.width ? props.width : '0.8rem'};
  height: 100%;
`;
export const RightIcon = styled.i`
  width: ${(props) => props.width ? props.width : '0.4rem'};
  background-image:  url(${(props) => props.iconUrl ? props.iconUrl : ''});
  height: 100%;
`;
