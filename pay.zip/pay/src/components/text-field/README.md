### 父组件传入子组件的必传字段：
```
<TextField
  inputType="number"
  leftBoxObj={{
    handleClick: this.setNumberClick.bind(this),
    setHtml: this.setHtml()
  }}
  propValue={this.state.inviteCodeJSON}
  stateName={'inviteCodeJSON'}
  setCurrentInputData={this.setCurrentInputData.bind(this)}
/>
```
>基于以上代码，父子组件通讯必传字段有： propValue/stateName/setCurrentInputData
非必传字段：inputType/leftBoxObj/rightBoxObj
##### propValue
>其中propValue为子集所需json数据为必传字段，各属性详情如下：
```
{
  handleInputFn: function(value) {   // 非必传，输入内容规则类似vue中的filter，如下代码为输入金额三位加,分割
    return value.replace(/,/g, '')
      .replace(/(\d{3})(?=\d)/g, '$1,')
  },
  hasRequiredMessage: true, // 非必传，此参数如果为true则有默认输入框为空时的wran信息
  regExp: /^\d{8}$/, // 非必传，正则规则有指则验证正则
  regExpMessgae: 'error message: phone number', // 非必传，正则规则对应的文案
  value: '', // 必传，当前输入框的默认值
  isPass: false, // 必传，当前输入框是否通过校验
  placeHolder: 'Mobile Number' //必传，placeHolder
}
```
##### stateName
> stateName值与propValue中传入的state中的属性名称保持一致

##### setCurrentInputData
> 此函数为子组件改变数据向父组件派发事件，父组件需要处理的函数

```
setCurrentInputData(properyName, json, needCheck = true) {
  let data = Object.assign({}, this.state[properyName], json);
  this.setState({
    [properyName]: data
  }, () => {
    if (needCheck) {
      this.getPassState(this.state.phoneNumberJSON, this.state.otpCodeJSON)
    }
  })
}
```
>"properyName": 需要改变的state

>"json": 需要变化的值

>"needCheck": 非必传，默认为true表示需要验证是否通过表单校验规则

##### inputType
>指定当前输入框的类型，默认为”text“

##### leftBoxObj
>leftBoxObj可在输入框左侧添加一片dom，并且允许有点击事件
```
leftBoxObj={{
  handleClick: this.setNumberClick.bind(this),
  setHtml: this.setHtml()
}}
```
>setHtml: 返回一段dom元素由引入该组件的父组件定义

>handleClick: 点击事件的回调函数由父组件定义


##### rightIconObj
>leftBoxObj可在输入框左侧添加一片dom，并且允许有点击事件
```
rightIconObj = {{
  iconUrl: require('./pulldown.png'),
  handleClick: this.setIconClick.bind(this)
}}
```
>iconUrl: 右侧icon的链接

>handleClick: 点击事件的回调函数由父组件定义

##### hasCloseBtn 默认为true，传入false则无右侧close按钮
