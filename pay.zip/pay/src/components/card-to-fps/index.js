import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'components/text-field';
import CardToContinue from 'components/card-to-continue';

export default class CardToFPS extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectRecipient: props.selectRecipient,
            disabled: props.disabled || false,
            fps: props.fps,
            showTips: props.showTips,
            showContinue: props.showContinue,
            onContinue: props.onContinue,
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            selectRecipient: props.selectRecipient,
            disabled: props.disabled,
            fps: props.fps,
            showTips: props.showTips,
            showContinue: props.showContinue,
        }
    }

    render() {
        const { disabled, fps, selectRecipient, showTips, showContinue, onContinue } = this.state;

        return (
            <div>
                {
                    !selectRecipient &&
                    <TextField stateName={'fps'}
                        propValue={{
                            value: fps,
                            placeHolder: 'FPS ID'
                        }}
                        setCurrentInputData={this.onHandleFPS.bind(this)}>
                    </TextField>
                }
                {
                    showContinue &&
                    <CardToContinue disabled={disabled} showTips={showTips} onContinue={onContinue}>
                    </CardToContinue>
                }
            </div>
        )
    }

    onHandleFPS(pn, json) {
        const fps = json.value.isOnlyNumber();

        if (fps.split('').length > 7) {
            return;
        }

        let showContinue = false;
        if (fps.split('').length >= 5) {
            showContinue = true;
        }

        this.props.onChangeFPS && this.props.onChangeFPS(fps, showContinue);
    }
}

CardToFPS.propTypes = {
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
}

CardToFPS.defaultProps = {
    showTips: false,
    disabled: false,
}