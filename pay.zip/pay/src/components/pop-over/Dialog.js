import React from 'react';

class Dialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            disClose: props.disClose,
            onClose: props.onClose,
            onDone: props.onDone
        }
    }

    render() {
        return (
            <div className="pop-dialog">
                <div className="pop-dialog-content">
                    <div className="pop-dialog-content-header">
                        {
                            !this.state.disClose &&
                            <img alt="" onClick={this.props.onClose} src={require('assets/imgs/close/close.svg')} />
                        }
                    </div>
                    {this.props.children}
                </div>
            </div>
        )
    }
}

export default Dialog;