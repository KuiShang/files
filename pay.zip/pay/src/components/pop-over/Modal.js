import React from 'react';

class Modal extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            title: props.title,
            titleDone: props.titleDone,
            onShow: props.onShow,
            onDone: props.onDone,
            result: null
        }
    }

    render() {
        const { title, titleDone, onShow, onDone } = this.state;
        return (
            <div className="pop-over">
                <div className="pop-over-header">
                    <div className='title'>
                        <img alt="" onClick={() => { onShow && onShow(); document.body.classList.remove('overflow-hidden') }} src={require('assets/imgs/close/close.svg')} />
                        <span>{title}</span>
                        <span className="pop-over-header-done" onClick={() => { this.onDone(); document.body.classList.remove('overflow-hidden') }}>{onDone && (titleDone)}</span>
                    </div>
                </div>
                {this.props.children && React.cloneElement(this.props.children, { onChange: this.onChange })}
            </div>
        )
    }

    componentDidMount () {
        document.body.classList.add('overflow-hidden');
    }

    onChange = (obj) => {
        this.setState({ result: obj })
    }

    onDone = () => {
        this.props.onDone && this.props.onDone(this.state.result);
    }
}

export default Modal;