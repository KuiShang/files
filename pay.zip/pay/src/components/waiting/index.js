import React from 'react';
import './index.scss';

export default class Waiting extends React.Component {
    render() {
        return (
            <div className="waiting">
                <div className="waiting-msg">
                    <span>We are processing your request,</span>
                    <span>please wait…</span>
                </div>
            </div>
        )
    }
}