import React from 'react';

class Number extends React.Component {
    render() {
        return (
            <div className="ai-input-number">
                <input type="number" />
            </div>
        )
    }
}

export default Number;