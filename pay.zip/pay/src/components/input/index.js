import React from 'react';
import PropTypes from 'prop-types';
import Mobile from './Mobile';
import './index.scss';

class Input extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            type: props.type,
            icon: props.icon,
            isFocus: false,
            isBlur: false,
        }
    }

    render() {
        const { icon, isBlur, isFocus } = this.state;

        return (
            <div className="ai-input">
                <div>
                    <input type="text" onFocus={() => this.setState({ isFocus: !isFocus })} onBlur={() => this.setState({ isBlur: !isBlur })} />
                    <span className={`ai-input-label ${isFocus ? 'ai-input-label-active' : ''}`}>Input Text</span>
                </div>
                {icon && <img alt="" src={icon} />}
            </div>
        )
    }
}

Input.propTypes = {
    type: PropTypes.string,
    icon: PropTypes.object
};

Input.defaultProps = {
    type: 'input',
    icon: null
}

Input.Mobile = Mobile;

export default Input;