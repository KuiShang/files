import React from 'react';

class Email extends React.Component {
    render() {
        return (
            <div className="ai-input-email">
                <input type="email" />
            </div>
        )
    }
}

export default Email;