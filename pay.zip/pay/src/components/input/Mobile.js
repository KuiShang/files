import React from 'react';
import imgMobile from 'assets/imgs/contact/Contact@3x.svg';

export default class Mobile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            type: props.type,
            icon: props.icon
        }
    }

    render() {
        return (
            <React.Fragment>
                <label className="ai-input-label">Input Text</label>
                <input type="text" />
                <img alt="" src={imgMobile} />
            </React.Fragment>
        )
    }
}