import React from 'react';
import PropTypes from 'prop-types';

class Money extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            placeholder: props.placeholder,
            unit: props.unit
        }
    }

    render() {
        const { placeholder, unit } = this.state;

        return (
            <div className="ai-input-money">
                <input type="text" placeholder={placeholder} />
                <span>{unit}</span>
            </div>
        )
    }
}

Money.propTypes = {
    placeholder: PropTypes.string,
    unit: ProTypes.string
}

Money.defaultProps = {
    placeholder: '',
    unit: ''
}

export default Money;