import React from 'react';
import PropTypes from 'prop-types';
import Switch from './Switch';
import './index.scss';

class CardSwitch extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            checkind: 0,
            title: props.title,
            options: props.options,
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            checkind: props.checkind
        }
    }

    render() {
        const { checkind, title, options } = this.state;

        return (
            <div className="card-switch">
                {title && <div className="card-switch-title">{title}</div>}
                <div className="card-switch-options">
                    <Switch checked={checkind === 0 ? true : false} onSwitch={() => this.onSwitch(0)}>{options && options[0]}</Switch>
                    <Switch checked={checkind === 1 ? true : false} onSwitch={() => this.onSwitch(1)}>{options && options[1]}</Switch>
                </div>
            </div>
        )
    }

    onSwitch = (checkind) => {
        //this.setState({ checked: !this.state.checked }, () => {
        this.props.onSwitch && this.props.onSwitch(checkind);
        //});
    }
}

CardSwitch.propTypes = {
    title: PropTypes.string,
    options: PropTypes.array.isRequired,
}

export default CardSwitch;