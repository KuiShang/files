import React from 'react';
import './index.scss';

export default class Switch extends React.Component {
    render() {
        const { checked } = this.props;
        return (
            <div className={`card-switch-option ${checked ? 'card-switch-option-actived' : ''}`} onClick={this.onSwitch}>
                {this.props.children}
            </div>
        )
    }

    onSwitch = () => {
        const { onSwitch } = this.props;
        onSwitch && onSwitch();
    }
}