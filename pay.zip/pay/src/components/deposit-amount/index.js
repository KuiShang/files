import React from 'react';
import intl from 'react-intl-universal';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import './index.scss';

export default class DepositAmount extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isFocus: false,
            amount: props.amount || 0,
            formatAmount: thousandBitSeparator(keep2DecimalFull(props.amount || 0))
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            amount: props.amount,
            formatAmount: state.formatAmount
        }
    }

    render() {
        const { isFocus, amount, formatAmount } = this.state;
        const val = isFocus ? (amount === 0 ? '' : amount.toString()) : formatAmount;

        return (
            <div className="deposit-amount">
                <div className="deposit-amount-title">
                    <div>{intl.get('deposit_amount')}</div>
                </div>
                <div className="deposit-amount-count">
                    <div className="deposit-amount-count-money">
                        <div>
                            <input type={`${isFocus ? 'number' : 'text'}`}
                                style={{ width: '100%' }}
                                value={val}
                                onChange={e => this.onChangeAmount(e.target.value)}
                                onFocus={this.onFocus}
                                onBlur={this.onBlur} />
                        </div>
                        <span className="deposit-amount-count-unit">HKD</span>
                    </div>
                </div>
            </div>
        )
    }

    /**
     * 修改转账金额（始终保留两位有效数字）
     * TODO 
     * 此问题建议反馈给产品测。
     * 1:由于20位已经非常长 再加上后续的 千分符/两位有效小数，界面一行已经非常长了；
     * 2:客户端也会存在超长字符千分号计算错乱问题；
     */
    onChangeAmount = (amount) => {
        if (amount.substring(0, 1) === '0') {
            return;
        }

        amount = formatNum(amount); //amount.isOnlyNumWithTwoDecimal();
        const ind = amount.indexOf('.');
        let temp = amount;
        if (ind > 0) {
            temp = amount.substring(0, ind);
        }

        if (temp.split("").length > 13) {
            return;
        }

        this.props.onChangeAmount && this.props.onChangeAmount(amount);
    }

    onFocus = () => {
        this.setState({ isFocus: true, formatAmount: (this.state.amount === 0 ? '' : this.state.amount) })
    }

    onBlur = () => {
        if (this.state.amount === "") {
            this.setState({ formatAmount: thousandBitSeparator(keep2DecimalFull(0)), isFocus: false })
        } else {
            this.setState({ isFocus: false, formatAmount: thousandBitSeparator(keep2DecimalFull(this.state.amount)) })
        }
    }
}

function formatNum(amount) {
    amount = amount.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    amount = amount.replace(/^\./g, ""); // 验证第一个字符是数字
    amount = amount.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    amount = amount.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    amount = amount.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); // 只能输入两个小数
    return amount;
}