import React from 'react';
import './index.scss';

export default class SelectField extends React.Component {
    state = {
        title: this.props.title,
        value: this.props.value
    }

    static getDerivedStateFromProps(props) {
        return {
            title: props.title,
            value: props.value
        }
    }

    render() {
        const { title, value } = this.state;

        return (
            <div className="select-field">
                <div className="select-field-content">
                    <div className={`select-field-content-title ${value ? 'select-field-content-title-edit' : ''}`}>{title}</div>
                    <div className="select-field-content-value">{value}</div>
                </div>
                <i onClick={this.props.onSelect} />
            </div>
        )
    }
}