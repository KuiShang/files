import React from 'react';
import intl from 'react-intl-universal';
import * as Mask from 'utils/MaskUtil';
import './index.scss';
import imgBank from 'assets/imgs/bank/bank@3x.svg';
import imgPulldown from 'assets/imgs/pulldown/pulldown-small.png';

export default class DepositFrom extends React.Component {
    state = {
        data: this.props.data,
        onShowDepositAccount: this.props.onShowDepositAccount
    }

    static getDerivedStateFromProps(props) {
        return {
            data: props.data
        }
    }

    render() {
        const { data, onShowDepositAccount } = this.state;

        return (
            <div className="deposit-from">
                <div className="deposit-from-title">{intl.get('deposit_from')}</div>
                <div className="deposit-from-cont">
                    <img alt="" src={imgBank} />
                    {
                        data && data.eddaStatus === 'binding'?
                        <div className="deposit-from-cont-acc">Bank Account Not Available</div>
                        :
                        <div className="deposit-from-cont-acc">
                            <div className="deposit-from-cont-bank">{data && data.dbtMmbNa}</div>
                            <div className="deposit-from-cont-alias">{data && Mask.maskName(data.dbtNm)}</div>
                            {(data && data.eddaStatus === 'binding') && <div style={{ fontSize: '12px', color: '#848484' }}>{intl.get('pending_authorisation')}</div>}
                        </div>
                    }
                    <img alt="" src={imgPulldown} onClick={onShowDepositAccount} />
                </div>
            </div>
        )
    }
}