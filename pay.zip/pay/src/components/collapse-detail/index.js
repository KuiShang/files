import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';

class CollapseDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            collapsed: props.collapsed
        }
    }

    render() {
        const { collapsed } = this.state;

        return (
            <div className="collapse-detail" onClick={this.onCollapse}>
                <span>{this.props.title}</span>
                <span className={`collapse-detail-down ${collapsed ? "collapse-detail-down-collapse" : ""}`}></span>
            </div>
        )
    }

    onCollapse = () => {
        this.setState({ collapsed: !this.state.collapsed });
        this.props.onCollapse && this.props.onCollapse(!this.state.collapsed);
    }
}

CollapseDetail.propTypes = {
    collapsed: PropTypes.bool,
    title: PropTypes.string.isRequired
}

CollapseDetail.defaultProps = {
    collapsed: true,
}

export default CollapseDetail;