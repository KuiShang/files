import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';
import imgClose from 'assets/imgs/close-account/close-account@2x.png';
import imgError from 'assets/imgs/error/error.png';

export default class DialogConfirmTerminate extends React.Component {
    state = { isResult: this.props.isResult || false }

    static getDerivedStateFromProps(props) {
        return {
            isSuccess: props.isSuccess,
            isPending: props.isPending
        }
    }

    render() {
        const { isResult } = this.props;

        return (
            <div className="dialog-small-value">
                {!isResult && this.renderActions()}
                {isResult && this.renderResult()}
            </div>
        )
    }

    renderActions = () => {
        return (
            <React.Fragment>
                <img alt="" src={imgClose} />
                <div className="dialog-small-value-tip">
                    <div style={{ color: '#848484' }}>{intl.get("unlink_this_authorization")}</div>
                </div>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-minor" onClick={() => this.props.onTerminate()}>{intl.get("yes")}</li>
                    <li className="ai-btn-tripple" onClick={() => { this.props.onCancel && this.props.onCancel() }}>{intl.get("no")}</li>
                </ul>
            </React.Fragment>
        )
    }

    renderResult = () => {
        const { isSuccess, isPending } = this.state;

        return (
            <React.Fragment>
                <img alt="" src={isSuccess ? imgClose : imgError} />
                <div className="dialog-small-value-tip">
                    {isSuccess && <div style={{ color: '#848484' }}>{intl.get("account_unlink")}</div>}
                    {(!isSuccess && isPending) && <div style={{ color: '#848484' }}>{intl.get("account_unlink_pending")}</div>}
                    {!isSuccess && <div style={{ color: '#848484' }}>{intl.get("account_unlink_fail")}</div>}
                </div>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-primary" onClick={() => this.props.onOkay()}>{intl.get("done")}</li>
                </ul>
            </React.Fragment>
        )
    }
}