import React from 'react';
import './index.scss';

export default class ItemBankCode extends React.Component {
    render() {
        const { data, onSelect } = this.props;
        return (
            <div className="item-bank-code" onClick={onSelect}>
                <img alt="" src={(data.bank_logo_url ? data.bank_logo_url : require('../../assets/imgs/common/bank.svg'))} />
                <span className="item-bank-code-title">{`${(data.bank_code ? data.bank_code : '')} ${(data.bank_en_name ? data.bank_en_name : '')}`}</span>
            </div>
        )
    }
}