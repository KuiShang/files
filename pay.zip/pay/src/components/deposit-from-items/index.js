import React from 'react';
import intl from 'react-intl-universal';
import List from 'components/list';
import Item from './Item';
import './index.scss';

export default class DepositFromItems extends React.Component {
    state = {
        data: this.props.data,
        checkedItem: this.props.checkedItem
    }

    static getDerivedStateFromProps(props) {
        return {
            data: props.data,
            checkedItem: props.checkedItem
        }
    }

    render() {
        const { data } = this.state;
        if (!data) {
            return null;
        }

        return (
            <div className="deposit-from-items">
                <List>
                    {this.renderItems()}
                </List>
                <div style={{height:'55px',marginTop:'30px'}}>
                    <div className="ai-btn-edit" style={{ fontSize: 14, width: '180px',margin:'0 auto' }} onClick={() => { this.props.onNewBankAccount && this.props.onNewBankAccount() }}>{intl.get('link_another_bank_account')}</div>
                </div>
                
            </div>
        )
    }

    renderItems = () => {
        const { data, checkedItem } = this.state;

        return data.map((item, index) => {
            // let checked = false;
            // if (checkedItem === item) {
            //     checked = true;
            // }

            return (<Item key={index} data={item} onSelect={() => this.props.onSelectDepositAccount(item, index)}></Item>)
        })
    }
}