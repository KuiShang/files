import React from 'react';
import * as SDK from 'utils/SDKUtil';
import imgBank from 'assets/imgs/bank/bank@3x.svg'
import imgTick from 'assets/imgs/tick/Tick.png';

export default class Item extends React.Component {
    state = {
        checked: this.props.checked,
        data: this.props.data,
        data_sensitive: this.props.data
    }

    render() {
        const { data, data_sensitive } = this.state;
        const eddaStatus = data.eddaStatus;
        return (
            //pointerEvents属性是使元素点击事件无效
            <div className="deposit-from-items-detail" style={{color: eddaStatus==="binding"?"lightgray":"black",pointerEvents: eddaStatus==="binding"?"none":"auto"}} onClick={() => this.props.onSelect()}>
                <div className="deposit-from-items-detail-info">
                    <img alt="" src={imgBank} />
                    <div className="deposit-from-items-detail-info-name">
                        <span>{data.dbtMmbNa || ''}</span>
                        <span>{data_sensitive.dbtNm || ''}</span>
                        {
                            data.eddaStatus === 'binding' &&
                            <span className="deposit-from-items-info-status" style={{ color: "#fcab10" }}>Pending Authorization (3-5 business days)</span>
                        }
                    </div>
                </div>
                {
                    // this.state.checked &&
                    data.checked &&
                    <img alt="" src={imgTick} style={{ width: 18 }} />
                }
            </div>
        )
    }

    componentDidMount() {
        this.onMaskInfo();
    }

    onMaskInfo = async () => {
        let { data_sensitive } = this.state;
        const name = await SDK.maskInfo({ type: 'name', value: data_sensitive.dbtNm });
        data_sensitive.dbtNm = name;
        this.setState({ data_sensitive });
    }
}