import React from 'react';
import DatePicker from 'components/date-picker';
import RepeatPicker from 'components/repeat-picker';
import intl from 'react-intl-universal';
import './index.scss';

export default class ExpiryDatePicker extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            checkedNever: props.checkedNever || false,
            checkedOnDate: props.checkedOnDate || false,
            checkedRepeat: props.checkedRepeat || false,
            expiry: props.expiry || null,
            dateConfig: props.dateConfig || null,
            max: props.max || 12
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            checkedNever: ((props.expiry && props.expiry.key === 'never') ? true : false),
            checkedOnDate: ((props.expiry && props.expiry.key === 'ondate') ? true : false),
            checkedRepeat: ((props.expiry && props.expiry.key === 'repeat') ? true : false),
            expiry: props.expiry,
        }
    }

    render() {
        const { checkedNever, checkedOnDate, checkedRepeat, expiry, dateConfig } = this.state;
        const now = new Date();
        const nowT1 = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);

        return (
            <div className="expiry-date-picker">
                <div className="expiry-date-picker-item"
                    onClick={() => this.onSelectExpiryDate('never', 'Never')}>
                    <div>{intl.get('no_end_date')}</div>
                    {checkedNever && <i className="expiry-date-picker-item-checked"></i>}
                </div>
                <div className="expiry-date-picker-item"
                    onClick={() => this.onSelectExpiryDate('ondate', (nowT1))}>
                    <div>{intl.get("on_a_specific_date")}</div>
                    {checkedOnDate && <i className="expiry-date-picker-item-checked"></i>}
                </div>
                {
                    checkedOnDate &&
                    <DatePicker date={expiry.value || nowT1}
                        config={dateConfig}
                        onSelectDate={date => this.onSelectExpiryDate('ondate', date)}>
                    </DatePicker>
                }
                <div className="expiry-date-picker-item"
                    onClick={() => this.onSelectExpiryDate('repeat', 1)}>
                    <div>{intl.get('set_number_of_times')}</div>
                    {checkedRepeat && <i className="expiry-date-picker-item-checked"></i>}
                </div>
                {
                    checkedRepeat &&
                    <RepeatPicker value={expiry.value} max={this.state.max}
                        onSelectRepeat={repeat => this.onSelectExpiryDate('repeat', repeat)}>
                    </RepeatPicker>
                }
            </div>
        )
    }

    onSelectExpiryDate = (key, value) => {
        let expiry = { key, value };
        if (key === 'ondate' && value === null) {
            expiry.value = new Date();
        }
        else if (key === 'repeat' && value === null) {
            expiry.value = 1;
        }

        this.props.onSelectExpiryDate && this.props.onSelectExpiryDate(expiry)
    }
}