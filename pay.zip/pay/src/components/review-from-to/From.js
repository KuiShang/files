import React from 'react';
import intl from 'react-intl-universal';

export default class From extends React.Component {
    static defaultProps = {
        editable: true,
    }

    static getDerivedStateFromProps(props) {
        return {
            pytype: props.initData ? props.initData.pytype : null,
            insccy: props.initData ? props.initData.insccy : null,
            otacct: props.initData ? props.initData.otacct : null
        }
    }


    render() {
        const { data } = this.props;

        return (
            <div className={this.props.className}>
                <div className="review-from-to-title">{intl.get('from')}</div>
                <div className="review-from-to-account">
                    <div className="review-from-to-account-avator">
                        <div className="review-from-to-account-avator-from">VB</div>
                    </div>
                    <div className="review-from-to-account-detail">
                        <div className="review-from-to-account-bank">
                            <div className="review-from-to-account-bank-action">
                                <div>{intl.get('transfer_vb_savings_account')}</div>
                                <div className={`ai-btn-edit ${this.props.editable ? '' : 'hide'}`} onClick={this.props.onEdit}>{intl.get('change')}</div>
                            </div>
                        </div>
                        <div className="review-from-to-account-no">{data.accountNo}</div>
                    </div>
                </div>
            </div>
        )
    }
}
