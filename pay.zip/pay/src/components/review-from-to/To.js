import React from 'react';
import intl from 'react-intl-universal';

export default class To extends React.Component {
    render() {
        const { data } = this.props;

        return (
            <div className={this.props.className}>
                <div className="review-from-to-title">{intl.get('to')}</div>
                <div className="review-from-to-account">
                    <div className="review-from-to-account-avator">
                        <div className="review-from-to-account-avator-to">CT</div>
                    </div>
                    <div className="review-from-to-account-detail">
                        <div className="review-from-to-account-bank" style={{ display: 'block' }}>
                            <div style={{ overflowWrap: 'break-word', padding: '0 40px 0 0' }}>{data.alias}</div>
                        </div>
                        <div className="review-from-to-account-no">{data.number}</div>
                        <div className="review-from-to-account-bank">{data.isDefaultBank ? intl.get('default_bank') : data.bankDes}</div>
                    </div>
                </div>
            </div>
        )
    }
}