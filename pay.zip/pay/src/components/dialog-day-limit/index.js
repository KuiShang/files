import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';
import imgSuccess from 'assets/imgs/result/transfer-success.svg';

export default class DialogDayLimit extends React.Component {
    render() {
        return (
            <div className="dialog-small-value">
                <img alt="" src={imgSuccess} />
                <div>{intl.get("set_up_daily_transfer_limit")}</div>
                <div className="dialog-small-value-tip">
                    <div style={{ color: '#848484' }}>{intl.get('small_value_transfer_tips')}</div>
                </div>
                <ul className="dialog-small-value-actions">
                    <li style={{ color: '#008ecc' }} onClick={this.props.onGoSetDayLimit}>{intl.get("set_up_now")}</li>
                    <li onClick={this.onNotNow}>{intl.get("do_it_later")}</li>
                </ul>
            </div>
        )
    }

    onNotNow = () => {
        this.props.onCancel && this.props.onCancel();
    }
}