import React from 'react';
import './index.scss';

function initState(data) {
    const obj = {};
    return data.map((item, index) => {
        //const i = item.lastIndexOf(' ');
        const en = item.cusTp;//item.slice(0, i);
        //const ch = item.slice(i + 1);
        let first = false;
        if (obj[en.slice(0, 1)]) {
            first = false;
        } else {
            first = true;
            obj[en.slice(0, 1)] = true;
        }
        return { en: en, ch: item.custnm, first: first, ...item }
    });
}

export default class ListIndexed extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isTouching: false,
            lastChar: 'A',
            country: initState(props.data)
        }

        this.charStr = '*ABCDEFGHIJKLMNOPQRSTUVWXYZ#';
        // this.isTouching = false;
        this.boxClientTop = 100;
        // this.lastChar = 'A';
        this.touchStart = this.touchStart.bind(this);
        this.touchMove = this.touchMove.bind(this);
        this.touchEnd = this.touchEnd.bind(this);
        this.getChar = this.getChar.bind(this);
        this.gotoChar = this.gotoChar.bind(this);
    }

    static getDerivedStateFromProps(props, state) {
        state.country = initState(props.data);
        return state;
    }

    render() {
        const merchantType = this.props.merchantType;
        return (
            <div className="country-list">
                <div className="country-border" ref="countryList">
                    { merchantType?(<div className="item-first">{merchantType.mctpnm}</div>):'' }
                    {
                        this.state.country.map((item, index) => {
                            return (
                                <div key={index}>
                                    {merchantType?
                                        '':
                                        (item.first && <div className="item-first" data-en={item.en.slice(0, 1)}>{item.en.slice(0, 1)}</div>)    
                                    }
                                    <div className="item" style={{ display: 'flex', alignItems: 'center', height: '55px' }} onClick={() => this.onSelectItem(item)}>
                                        <div className="item-left">{item.en}</div>
                                        <div>{item.ch}</div>
                                    </div>
                                </div>
                            )
                        })
                    }
                    <div className="char-list-border" style={{ paddingTop: '100px' }}>
                        <ul ref="charBar" className="char-list"
                            onTouchStart={this.touchStart}
                            onTouchMove={this.touchMove}
                            onTouchEnd={this.touchEnd}>
                            {
                                this.charStr.split('').map((char, index) => {
                                    return (
                                        <li className="char-item" key={index}>{char}</li>
                                    )
                                })
                            }
                        </ul>
                    </div>
                    {this.state.isTouching && <div className="char-tip">{this.state.lastChar}</div>}
                </div>
            </div>
        )
    }

    onSelectItem = (item) => {
        this.props.onSelectItem && this.props.onSelectItem(item);
    }

    touchStart(e) {
        e.preventDefault();
        // this.isTouching = true;
        this.setState({ isTouching: true });
        const char = this.getChar(e.touches[0].clientY);
        this.gotoChar(char);
    }

    touchMove(e) {
        //e.preventDefault();
        const char = this.getChar(e.touches[0].clientY);
        this.gotoChar(char);
    }

    touchEnd(e) {
        e.preventDefault();
        this.setState({ isTouching: false });
    }

    getChar(clientY) {
        const charHeight = this.refs.charBar.offsetHeight / this.charStr.length;
        const index = Math.floor((clientY - this.boxClientTop) / charHeight);
        return this.charStr[index];
    }

    gotoChar(char) {
        if (char === this.lastChar) {
            return false;
        }
        this.setState({ lastChar: char });
        // this.lastChar = char;
        if (char === '*') {
            this.refs.countryList.scrollTop = 0;
        } else if (char === '#') {
            this.refs.countryList.scrollTop = this.refs.countryList.scrollHeight;
        }
        const target = document.querySelector('[data-en="' + char + '"]');
        if (target) {
            target.scrollIntoView();
        }
    }
}