import React from 'react';
import PropTypes from 'prop-types';
import TextFieldContact from 'commonComponents/text-field-contact';
import BankRecipient from 'components/bank-recipient';
import CardToContinue from 'components/card-to-continue';
import * as SDK from 'utils/SDKUtil';
import './index.scss';

class CardToMobile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectRecipient: props.selectRecipient,
            defaultBank: props.defaultBank,
            mobile: props.mobile,
            disabled: props.disabled,
            country: '+852',
            showBanks: props.showBanks,
            showContinue: props.showContinue,
            showTips: props.showTips,
            onContinue: props.onContinue,
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            selectRecipient: props.selectRecipient,
            disabled: props.disabled,
            bankAccount: props.bankAccount,
            country: props.country,
            mobile: props.mobile,
            defaultBank: props.defaultBank,
            showBanks: props.showBanks,
            showContinue: props.showContinue,
            showTips: props.showTips,
            onSelectBank: props.onSelectBank,
        }
    }

    render() {
        const { showBanks, showContinue, showTips, defaultBank, selectRecipient, country, mobile, bankAccount, disabled, onContinue, onSelectBank } = this.state;
       
        return (
            <div className="card-to-mobile">
                {
                    !selectRecipient &&
                    <TextFieldContact
                        country={country}
                        mobile={mobile}
                        onHandleContact={this.onHandleContact}
                        onSelectCountryCode={this.onSelectCountryCode}
                        onSelectContact={this.onSelectMobile}>
                    </TextFieldContact>
                }
                {
                    showBanks &&
                    <BankRecipient
                        defaultBank={defaultBank}
                        onSwitchBanks={this.onSwitchBanks}
                        bankAccount={bankAccount}
                        onSelectBank={onSelectBank}>
                    </BankRecipient>
                }
                {
                    showContinue && 
                    <CardToContinue disabled={disabled} showTips={showTips} onContinue={onContinue}>
                    </CardToContinue>
                }
            </div>
        )
    }

    /**
     * 选择手机号国家码
     */
    onSelectCountryCode = () => {
        this.props.onSelectCountryCode && this.props.onSelectCountryCode()
    }

    /**
     * 选择手机号
     */
    onSelectMobile = () => {
        this.props.onSelectMobile && this.props.onSelectMobile()
    }

    /**
     * 修改手机号
     */
    onHandleContact = (mobile) => {
        this.props.onChangeMobile && this.props.onChangeMobile(mobile)
    }

    onSwitchBanks = (e) => {
        this.props.onSwitchBanks && this.props.onSwitchBanks(e);
    }
}

CardToMobile.propTypes = {
    showBank: PropTypes.bool,
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
    mobile: PropTypes.string
}

CardToMobile.defaultProps = {
    showBank: false,
    showTips: false,
    disabled: false,
    mobile: ''
}

export default CardToMobile;

