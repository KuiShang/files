import React from 'react';
import intl from 'react-intl-universal';
import './index.scss';

export default class DialogConfirmUpdateAutoDeposit extends React.Component {
    render() {
        return (
            <div className="dialog-small-value">
                <img alt="" src={require('assets/imgs/warning/warning.png')} />
                <div className="dialog-small-value-tip">
                    <div style={{ color: '#484848', fontSize: '20px', paddingBottom: '40px' }}>{intl.get('you_Might_Miss_a_Deposit')}</div>
                    <div style={{ color: '#848484' }}>{intl.get('if_you_update_the_deposit')}</div>
                    {/* <div style={{ color: '#484848' }}>your auto deposit?</div>
                    <div style={{ color: '#848484' }}>Note: today's auto deposit request</div>
                    <div style={{ color: '#848484' }}>would be stopped if updating.</div> */}
                </div>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-primary" onClick={() => this.props.onUpdate()}>{intl.get('continue')}</li>
                    <li className="ai-btn-tripple" onClick={() => { this.props.onCancel && this.props.onCancel() }}>{intl.get('cancel')}</li>
                </ul>
            </div>
        )
    }
}