import puppeteer from 'puppeteer';

describe('SendMoney', () => {

})