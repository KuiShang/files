import React from 'react';
import './index.scss';
import intl from 'react-intl-universal'
export default class SelectFrequency extends React.Component {
    state = {
        title: ''
    }

    // static getDerivedStateFromProps(props) {
    //     return {
    //         title: props.title,
    //         value: props.value
    //     }
    // }
    getvalue = (key) => {
        const frequencies = [
            { key: 'specialdate', value: 'Special date' },
            { key: 'daily', value: 'Daily' },
            { key: 'weekly', value: 'Weekly' },
            { key: 'biweekly', value: 'Biweekly' },
            { key: 'monthly', value: 'Monthly' },
            { key: 'quarterly', value: 'Quarterly' },
            { key: 'yearly', value: 'Yearly' },
        ]
        const r = {
            specialdate:  intl.get('Specific Date'),
            daily:  intl.get('Once a Day'),
            weekly:  intl.get('Once a Week'),
            biweekly:  intl.get('Once Every 2 Weeks'),
            monthly:  intl.get('Once a Month'),
            quarterly:  intl.get('Once a Quarter'),
            yearly:   intl.get('Once a Year'),
        }
        return r[key] ? r[key] : key
    }
    render() {
        const { title, value } = this.state;
        return (
            <div className="select-frequency">
                <div className="select-frequency-content">
                    <div className={`select-frequency-content-title ${this.props.datakey ? 'select-frequency-content-title-edit' : ''}`}>       {this.props.title}
                    </div>
                    <div className="select-frequency-content-value">{this.getvalue(this.props.datakey)}</div>
                </div>
                <i onClick={this.props.onSelect} />
            </div>
        )
    }
}