import React from 'react';
import PropTypes from 'prop-types';
import intl from 'react-intl-universal'
import BankSelect from '../bank-select';
import BankInput from '../bank-input';
import TextField from 'commonComponents/text-field';
import CardToContinue from 'components/card-to-continue';
import './index.scss';

export default class CardToBankAccount extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            accountNum: '',
            inviteCodeJSON: {
                value: this.props.rmname,
                isPass: true,
                placeHolder: intl.get('utilTip-bankInput')
            },
            disabled: props.disabled,
            bankAccount: props.bankAccount,
            accountHolder: '',
            showTips: props.showTips,
            showContinue: false,
            onHint: props.onHint,
            onContinue: props.onContinue,
            onSelectBank: props.onSelectBank
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            disabled: props.disabled,
            showTips: props.showTips,
            bankAccount: props.bankAccount
        }
    }
    regExpName = (val) => {
        // 只能包含字符、数字和下划线
        const nameReg =/^[\S]{1,60}$/
        console.info(val)
        if (!val || !nameReg.test(val)) {
       
          return false
        } 
        return true
      }
    render() {
        const { disabled, bankAccount, accountNum, accountHolder, showTips, showContinue, onHint, onContinue, onSelectBank } = this.state;
        const pyname = this.props.pyname
        return (
            <div className="card-to-bank-account">
                <div className="card-to-bank-account-title"> {intl.get('Contacts Bank')}  </div>
                <BankSelect banknm={this.props.banknm} onSelectBank={onSelectBank} ></BankSelect>
                <span style={{ height: 20, display: 'inline-block' }}></span>
                <div className="card-to-bank-account-title">
                 {intl.get('Bank Account Details')} 
                    <span style={{ color: '#008ecc', fontSize: '14px' }} onClick={onHint}> {intl.get('Tips')} </span>
                </div>
                <BankInput
                    accountNum={accountNum}
                    bankAccount={bankAccount}
                    pyacct={this.props.pyacct}
                    pybank={this.props.pybank}
                    onAccountStates = {this.props.onAccountStates}
                    onChangeAccountNum={this.onChangeAccountNum}></BankInput>
                <div style={{ margin: '20px 0 0 0' }}>
                    <TextField
                        requireInputMessage= 'Full Name is empty'
                        regExpFn={this.regExpName}
                        propValue={{
                            hasRequiredMessage: true,
                            isPass: true,
                            value: pyname,
                            placeHolder: intl.get('Contacts Full Name'),
                            regExpMessgae: '只能1-60字符'
                        }}
                        stateName={'bankAccount'}
                        setCurrentInputData={this.onHandleAccountFullName.bind(this)}
                        >
                    </TextField>
                </div>
              
            </div >
        )
    }

    /**
     * Account No
     * 只支持数字、英文，字符长度8-16
     */
    onChangeAccountNum = (num) => {
        let { showContinue } = this.state;
        num = num.isOnlyNumChar();
        if (num.split("").length > 16) {
            return;
        }

        if (num.split("").length >= 8) {
            showContinue = true;
        } else {
            showContinue = false;
        }

        this.setState({ accountNum: num, showContinue }, () => {
            this.props.onChangeAccountNum && this.props.onChangeAccountNum(num, showContinue);
        })
    }

    /**
     * Account Holder Full Name
     * 字符长度为1-25
     * @param {*} pn 
     * @param {*} json 
     */
    onHandleAccountFullName(pn, json) {
        const accountFullName = json.value
        this.props.onHandleAccountFullName && this.props.onHandleAccountFullName(accountFullName);
    }
}

CardToBankAccount.propTypes = {
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
    onHint: PropTypes.func.isRequired
}

CardToBankAccount.defaultProps = {
    showTips: false,
    disabled: false,
}

