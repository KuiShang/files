import React from 'react';
import Date from './Date';
import { defaultConfig } from './Config';
import './index.scss';

const monthMap = {
    '1': 'January',
    '2': 'February',
    '3': 'March',
    '4': 'April',
    '5': 'May',
    '6': 'June',
    '7': 'July',
    '8': 'August',
    '9': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'December',
};

const dateConfig = {
    'year': {
        format: 'YYYY',
        caption: 'Year',
        step: 1,
    },
    'month': {
        format: value => monthMap[value.getMonth() + 1],
        caption: 'Mon',
        step: 1,
    },
    'date': {
        format: 'DD',
        caption: 'Day',
        step: 1,
    },
};

export default class DatePicker extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isOpen: props.isOpen,
            date: props.date
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            date: props.date
        }
    }

    render() {
        return (
            <div className="date-picker">
                <div className="datepicker-modal">
                    <Date {...defaultConfig}
                        value={this.state.date}
                        dateConfig={dateConfig}
                        onSelectDate={this.props.onSelectDate} />
                </div>
            </div>
        )
    }
}