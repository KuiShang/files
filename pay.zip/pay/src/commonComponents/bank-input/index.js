import React from 'react';
import TextField from 'commonComponents/text-field';
import intl from 'react-intl-universal'
import './index.scss';

export default class BankInput extends React.Component {
    state = {
        accountNum: ''
    }

    static getDerivedStateFromProps(props) {
        return {
            accountNum: props.accountNum,
            bankAccount: props.bankAccount,
            pybank: props.pybank
        }
    }
    regExpAccount = (val) => {
        // 验证m-n位的数字 8-16
        const nameReg =  /^[0-9a-zA-Z]{8,16}$/
        console.info(val)
        if (!val || !nameReg.test(val)) {
            this.props.onAccountStates && this.props.onAccountStates(false)
          return false
        } else {
            this.props.onAccountStates && this.props.onAccountStates(true)
        }
        return true
      }
    render() {
        const { bankAccount, pybank, accountNum } = this.state;
        const {pyacct} =  this.props
        return (
            <div className="bank-input">
                <div className="bank-input-code">
                    <span className="bank-input-code-ti">{intl.get('Bank Code')}</span>
                    <span className="bank-input-code-no">{pybank || (bankAccount && bankAccount.bank_code)}</span>
                </div>
                <div className="bank-input-no">
                    <TextField
                        propValue={{
                            hasRequiredMessage: true,
                            regExpMessgae: '8-16位数字和英文',
                           
                            value: pyacct,
                            isPass: false,
                            placeHolder: intl.get('Account Number')
                        }}
                        regExpFn={this.regExpAccount}
                        requireInputMessage={intl.get('errTips-bankInput_1')}
                        stateName={'inviteCodeJSON'}
                        setCurrentInputData={this.onHandleBankAccount.bind(this)}>
                    </TextField>
                </div>
            </div>
        )
    }

    onHandleBankAccount = (pn, json) => {
        this.setState({ accountNum: json.value }, () => {
            this.props.onChangeAccountNum && this.props.onChangeAccountNum(json.value);
        })
    }
}