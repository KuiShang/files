import React from 'react';
import './index.scss';
import intl from 'react-intl-universal'
export default class BankSelect extends React.Component {
    state = {
        bankAccount: null,
        onSelectBank: null
    }

    static getDerivedStateFromProps(props) {
        return {
            bankAccount: props.bankAccount,
            onSelectBank: props.onSelectBank
        }
    }

    render() {
        const { bankAccount, onSelectBank } = this.state;
        return (
            <div className="bank-select">
                <i alt="" className="bank-select-icon" />
                <span className="bank-select-con">{this.props.banknm || intl.get('Please Select') }</span>
                <i alt="" className="bank-select-next" onClick={onSelectBank} />
            </div>
        )
    }
}