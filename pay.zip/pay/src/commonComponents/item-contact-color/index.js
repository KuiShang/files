import React from 'react';
import './index.scss';

export default class ItemContactColor extends React.Component {
    state = {
        style: this.props.style,
        data: this.props.data,
        onSelectItem: this.props.onSelectItem
    }
    static getDerivedStateFromProps(props, state) {
        console.info('-----',state, props)
       
    }
    render() {
        const { style, onSelectItem } = this.state;
        const {data} = this.props
        return (
            <div className="item-contact-color" style={style ? style : null} onClick={() => onSelectItem && onSelectItem()}>
                <div className={`item-contact-color-left item-contact-color-left-${this.onHandleAlias((data && data.pyform) || '')}`}>{(data && data.pyform && data.pyform.substring(0, 1)) || ''}</div>
                <div className="item-contact-color-right">
                    <div className="item-contact-color-right-name">{(data && data.pyform) || ''}</div>
                    <div className="item-contact-color-right-account">
                        {(data && data.inactp && data.inactp !== 'BBAN') && <span>{(data && data.pyacct) || ''}</span>}
                        {(data && data.inactp && data.inactp === 'BBAN') && <span>{(data && `${data.banknm.substring(0, 10)}...`) || ''}</span>}
                        {(data && data.inactp && data.inactp === 'BBAN') && <span>{(data && data.pyacct) || ''}</span>}
                    </div>
                </div>
            </div>
        )
    }

    onHandleAlias = (alias) => {
        const firstChar = alias.substring(0, 1).toUpperCase();
        const isInA = "AEIMQUY", isInB = "BFJNRVZ", isInC = "CGKOSW", isInD = "DHLPTX";
        if (isInA.indexOf(firstChar) >= 0) {
            return 'a';
        } else if (isInB.indexOf(firstChar) >= 0) {
            return 'b';
        } else if (isInC.indexOf(firstChar) >= 0) {
            return 'c';
        } else if (isInD.indexOf(firstChar) >= 0) {
            return 'd';
        }

        return 'a';
    }
}