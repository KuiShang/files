import React from 'react';
import './index.scss';
import intl from 'react-intl-universal'
import DatePicker from 'commonComponents/date-picker';
import Numicker from 'commonComponents/num-picker';
const NEVER = 'NEVER'
const ONDATE = 'ONDATE'
const REPEAT = 'REPEAT'

class SelectEndType extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            checked: props.checked,
            date: props.date,
            onSelectEndTypeItem: props.onSelectEndTypeItem,
            onSelectDate: props.onSelectDate,
            currentTimes: props.currentTimes,
            onSelectNum: props.onSelectNum

        }
    }
    // static getDerivedStateFromProps(props) {
    //     console.info('ddd', props)
    //     return {
    //         checked: props.checked,
    //         date: props.date,
    //         onSelectEndTypeItem: props.onSelectEndTypeItem,
    //         onSelectDate: props.onSelectDate,
    //     }
    // }
    render() {
        const { checked, date, onSelectEndTypeItem, onSelectDate, currentTimes, onSelectNum } = this.state;
        return (
            <ul className="select-end-type">
                <li className="select-end-item" onClick={() => this.onSelectItem(NEVER)}>
                    <div>{intl.get('No End Date')}</div>
                    {checked === NEVER && <i className="select-end-item-checked"></i>}
                </li>
                <li className="select-end-item" onClick={() => this.onSelectItem(ONDATE)}>
                    <div>{intl.get('On a Specific Date')}</div>
                    {checked === ONDATE && <i className="select-end-item-checked"></i>}
                </li>
                {checked === ONDATE && <DatePicker date={date} onSelectDate={date => onSelectDate(date)}></DatePicker>}
                {checked === ONDATE && <p className="height1"></p>}
                <li className="select-end-item" onClick={() => this.onSelectItem(REPEAT)}>
                    <div>{intl.get('Set Number of Times')}</div>
                    {checked === REPEAT && <i className="select-end-item-checked"></i>}
                </li>
                {checked === REPEAT &&  
                <div className="end-type-container">
                <Numicker currentTimes={currentTimes} onSelectDate={date => onSelectNum(date)}></Numicker>

                </div>
                
                }
                <li className="height75"></li>
                
            </ul>

        )
    }

    onSelectItem = (item) => {
        this.setState({ checked: item }, () => {
            this.props.onSelectEndTypeItem && this.props.onSelectEndTypeItem(item);
        });
    }
}

export default SelectEndType;

