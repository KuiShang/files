import React from 'react';
import Button from 'commonComponents/button/button';
import { connect } from 'react-redux'
import intl from 'react-intl-universal'
import './deleteModule.scss'

import deleteImg from './img/illustration-medium-close-account.svg'

class DeleteContent extends React.Component {
    getContent = () => {
        if (this.props.content) {
            return this.props.content
        } else {
            return  intl.get('Are you sure you want to remove this contact?') 
        }
    }
    render() {
        return (
            <div className="delete-module-content">
                <img src={deleteImg} alt="" className="img" />
                {
                    this.props.deleteDone ? <p className="txt">{intl.get('Contact Removed')}  </p> : <p className="txt">{this.getContent()}</p>
                }
                <div className="btn-cont">
                    {
                        this.props.deleteDone ? <Button type="primary" onClick={this.props.doneFn}>{intl.get('Done')}</Button> : <Button type="warning" onClick={this.props.deleteFn}>{   intl.get('Yes') }</Button>
                    }

                </div>
                {
                    this.props.showcancelBtn &&   
                    <div className="calcel" onClick={this.props.cancelBtnClick}>
                        {intl.get('Cancel')} 
                    </div>
                }
              
            </div>
        )
    }

}

const mapStateToProps = (state) => ({
    deleteDone: state.recipient.deleteDone
})

export default connect(
    mapStateToProps
)(DeleteContent)
// export default class DeleteModule extends React.Component {
//     state = {
//         show: this.props.show
//     }
//     closePop = () => {
//         this.setState({
//             show: false
//         })
//     }
//     render() {
//         const { show } = this.state

//         return (
//             <div className="delete-module">
//                 <PopOver isDialog={true} visible={show}
//                     onShow={this.closePop}
//                     onDone={this.closePop}>
//                     <Content></Content>
//                 </PopOver>
//             </div>
//         )
//     }
// }