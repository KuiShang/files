import React from 'react';
import PropTypes from 'prop-types';
import TextFieldContact from 'commonComponents/text-field-contact';
import * as SDK from 'utils/SDKUtil';
import './index.scss';

class CardToMobile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showTips: props.showTips,
            mobile: props.mobile,
            disabled: props.disabled,
            onContinue: props.onContinue,
            country: '+852',
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            disabled: props.disabled,
            showTips: props.showTips,
            bankAccount: props.bankAccount,
            onSelectBank: props.onSelectBank,
            country: props.country,
            mobile: props.mobile,
        }
    }

    render() {
        const {  showTips, country, mobile, bankAccount, disabled, onContinue, onSelectBank } = this.state;
        
        return (
            <div className="card-to-mobile">
                <TextFieldContact
                    country={country}
                    mobile={mobile}
                    onHandleContact={this.onHandleContact}
                    onSelectCountryCode={this.onSelectCountryCode}
                    onMobileStates = {this.onMobileStates}
                    onSelectContact={this.onSelectMobile}>
                </TextFieldContact>
            </div>
        )
    }
    onMobileStates = (mobileStatus) => {
        this.props.onMobileStates && this.props.onMobileStates(mobileStatus)
    }
    /**
     * 选择手机号国家码
     */
    onSelectCountryCode = () => {
        this.props.onSelectCountryCode && this.props.onSelectCountryCode()
    }

    /**
     * 选择手机号
     */
    onSelectMobile = () => {
        this.props.onSelectMobile && this.props.onSelectMobile()
    }

    /**
     * 修改手机号
     */
    onHandleContact = (mobile) => {
        this.props.onChangeMobile && this.props.onChangeMobile(mobile)
    }

    onSwitchBanks = (e) => {
        this.props.onSwitchBanks && this.props.onSwitchBanks(e);
    }
}

CardToMobile.propTypes = {
    showBank: PropTypes.bool,
    showTips: PropTypes.bool,
    disabled: PropTypes.bool,
    mobile: PropTypes.string
}

CardToMobile.defaultProps = {
    showBank: false,
    showTips: false,
    disabled: false,
    mobile: ''
}

export default CardToMobile;

