import React from 'react';

export default class Item extends React.Component {
    state = {
        checked: false,
        data: null
    }

    static getDerivedStateFromProps(props) {
        return {
            data: props.data,
            checked: props.checked
        }
    }

    render() {
        const { checked, data } = this.state;
        return (
            <div className="picker-item" onClick={() => {this.onSelectItem(data); document.body.classList.remove('overflow-hidden')}}>
                <div>{data.value}</div>
                {checked && <i className="picker-item-checked"></i>}
            </div>
        )
    }

    componentDidMount () {
        document.body.classList.add('overflow-hidden');
    }

    onSelectItem = (obj) => {
        this.props.onSelectItem && this.props.onSelectItem(obj)
    }
}