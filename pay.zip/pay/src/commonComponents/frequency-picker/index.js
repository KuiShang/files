import React from 'react';
import List from 'components/list';
import Item from './Item';
import './index.scss';
import intl from 'react-intl-universal'


let frequencies = []

class FrequencyPicker extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            frequency: props.data

        }

        let a =  intl.get('Specific Date')
        // let b =  intl.get('Once a Day')
        let c =  intl.get('Once a Week')
        let d =  intl.get('Once Every 2 Weeks')
        
        let e =  intl.get('Once a Month')
        let f =  intl.get('Once a Quarter')
        // let g =  intl.get('Once a Year')
       frequencies = [
            { key: 'specialdate', value:  a },
            // { key: 'daily', value: b },
            { key: 'weekly', value:  c },
            { key: 'biweekly', value:  d},
            { key: 'monthly', value: e },
            { key: 'quarterly', value: f}
            // { key: 'yearly', value: g },
        ]
    }
    componentDidMount() {
     
        
    }
    static getDerivedStateFromProps(props) {
        return {
            frequency: props.data
        }
    }

    render() {
        const { frequency } = this.state;

        return (
            <div>
                <List>
                    {
                        frequencies && frequencies.map(item => {
                            return <Item key={item.key} data={item} checked={(frequency && (item.key === frequency)) ? true : false} onSelectItem={() => this.onSelectItem(item)}></Item>
                        })
                    }
                </List>
            </div>

        )
    }

    onSelectItem = (item) => {
        this.setState({ frequency: item }, () => {
            
            this.props.onSelectFrequency && this.props.onSelectFrequency(item);
        });
    }
}

export default FrequencyPicker;

