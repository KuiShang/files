import React from 'react';
import Num from './Num';
import { defaultConfig } from './Config';
import './index.scss';

const monthMap = {
    '1': 'January',
    '2': 'February',
    '3': 'March',
    '4': 'April',
    '5': 'May',
    '6': 'June',
    '7': 'July',
    '8': 'August',
    '9': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'December',
};

const dateConfig = {
 
    'num': {
        step: 1,
    }
};

export default class NumPicker extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isOpen: props.isOpen,
            currentTimes: props.currentTimes
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            currentTimes: props.currentTimes
        }
    }

    render() {
        return (
            <div className="num-picker">
                <div className="datepicker-modal">
                    <Num {...defaultConfig}
                        value={this.state.currentTimes}
                        dateConfig={dateConfig}
                        onSelectDate={this.props.onSelectDate} />
                </div>
            </div>
        )
    }
}