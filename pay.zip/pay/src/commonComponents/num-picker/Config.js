/**
 * 默认属性
 */
export const defaultConfig = {
    isPopup: true,
    isOpen: false,
    value: new Date(),
    min: 1,
    max: 12,
    showHeader: true,
    showCaption: false,
    dateConfig: {
        'year': {
            format: 'YYYY',
            caption: 'Year',
            step: 1,
        },
        'month': {
            format: 'M',
            caption: 'Mon',
            step: 1,
        },
        'date': {
            format: 'D',
            caption: 'Day',
            step: 1,
        },
    },
    headerFormat: 'YYYY/MM/DD',
    onSelect: () => { },
    onCancel: () => { },
};

/**
 * 日期配置
 */
export const dateConfigMap = {
    'year': {
        format: 'YYYY',
        caption: 'Year',
        step: 1,
    },
    'month': {
        format: 'M',
        caption: 'Mon',
        step: 1,
    },
    'date': {
        format: 'D',
        caption: 'Day',
        step: 1,
    },
    'num': {
        format: '',
        caption: '',
        step: 1,
    }
};
