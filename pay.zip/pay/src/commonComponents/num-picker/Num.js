import React from 'react';
import PropTypes from 'prop-types';
import NumItem from './NumItem.js';
import PureRender from './utils/PureRenderUtil2.js';
import { nextNum } from './utils/TimeUtil2.js';
import { dateConfigMap } from './Config';

/**
 * 大写首字母
 * @param {String} 字符串 
 */
const capitalize = ([first, ...rest]) => first.toUpperCase() + rest.join('');

/**
 * 判断数组
 * @param {any} val 
 */
const isArray = val => Object.prototype.toString.apply(val) === '[object Array]';

class Numb extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            value: props.value ? nextNum(props.value) : null,
        };
        this.handleFinishBtnClick = this.handleFinishBtnClick.bind(this);
        this.handleDateSelect = this.handleDateSelect.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        const date = nextNum(nextProps.value);
        if (date  !== this.state.value ) {
            this.setState({ value: date });
        }
    }

    /**
     * When you swipe two datepickeritems at the same time.
     * Prevent dates from going out.
     */
    componentDidUpdate() {
        const value = this.state.value;
        const { min, max } = this.props;
        if (value  > max ) {
            this.setState({ value: max });
        }

        if (value  < min ) {
            this.setState({ value: min });
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        const date = nextNum(nextState.value);
        return date  !== this.state.value  || PureRender.shouldComponentUpdate(nextProps, nextState, this.props, this.state);
    }

    render() {
        const { min, max, dateConfig } = this.props;
        const value = this.state.value; 
        const dataConfigList = this.normalizeDateConfig(dateConfig);
        console.info('dataConfigList', dataConfigList)
        return (
            <div className={`datepicker default`}>
                <div className="datepicker-content">
                    {
                        dataConfigList.map((item, index) => {
                            return (
                                <NumItem key={index} value={value} min={min} max={max}
                                    step={item.step} type={item.type} format={item.format}
                                    onSelect={this.handleDateSelect} />
                            )
                        })
                    }
                </div>
             
            </div>
        )
    }

    /**
     * 点击完成按钮事件
     * @return {undefined}
     */
    handleFinishBtnClick() {
        this.props.onSelect(this.state.value);
    }

    /**
     * 选择下一个日期
     * @return {undefined}
     */
    handleDateSelect(value) {
        this.props.onSelectDate && this.props.onSelectDate(value);
    }

    /**
     * 格式化dateConfig
     * @param {*} dataConfig dateConfig属性
     */
    normalizeDateConfig(dataConfig) {
        const configList = [];
        for (const key in dataConfig) {
            if (dataConfig.hasOwnProperty(key)) {
                const lowerCaseKey = key.toLocaleLowerCase();
                if (dateConfigMap.hasOwnProperty(lowerCaseKey)) {
                    configList.push({
                        ...dateConfigMap[lowerCaseKey],
                        ...dataConfig[key],
                        type: capitalize(lowerCaseKey),
                    });
                }
            }
        }

        return configList;
    }

    onDoClick = () => {
        this.props.onDoClick && this.props.onDoClick()
    }
}

Numb.propTypes = {
    theme: PropTypes.string,
    // value: PropTypes.object,
    // min: PropTypes.object,
    // max: PropTypes.object,
    showHeader: PropTypes.bool,
    showCaption: PropTypes.bool,
    dateConfig: PropTypes.oneOfType([
        PropTypes.object,
        PropTypes.array
    ]),
    headerFormat: PropTypes.string,
    confirmText: PropTypes.string,
    cancelText: PropTypes.string,
    onSelect: PropTypes.func,
    onCancel: PropTypes.func,
}

export default Numb;