import React from 'react';
import PropTypes from 'prop-types';
import ReactTestUtils from 'react-dom/test-utils';
import styled from 'styled-components';
import Dialog from './Dialog';
import Modal from './Modal';
import './index.scss';

const PopupWrapper = styled.div`
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  will-change: transform;
  transform: translateZ(0);
  z-index: ${props => props.visible ? '222' : '-1'};
  background-color: ${props => props.visible ? 'rgba(0,0,0,0.8)' : 'rgba(0,0,0,0)'};
  transition: all .3s ease-in;
  .container{
    background: #FFFFFF;
    border-radius: .15rem .15rem .02rem .02rem;
    position: absolute;
    min-height:10%;
    bottom: 0;
    width: 100%;
    transition: all .3s ease-in;
    will-change: transform;
    transform: ${props => props.visible ? 'translateY(0%)' : 'translateY(100%)'};
    box-sizing: border-box;
    padding:0 .2rem;
    .btn-wrapper{
      width: 100%;
      position: absolute;
      margin-left: -.2rem;
      bottom: 0.3rem;
      text-align: center;
    }
    >.content{
      overflow: hidden;
      position: relative;
      width: 100%;
      max-height: 65%;
      overflow-y: auto;
      font-family: SFUIDisplay DroidSans Arial;
      font-size: .12rem;
      color: #484848;
      line-height: .16rem;
      margin:.36rem 0 1.24rem
    }
    >div.title{
      margin-top: .17rem;
      line-height: .2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      img{
        width: .18rem;
        height: .18rem;
        margin-left: .2rem;
        position: absolute;
        left: 0;
      }
      span{
        font-family: SFUIDisplay DroidSans Arial;
        font-size: .14rem;
        color: #484848;
        text-align: center;
      }
    }
  }
`

class PopOver extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: props.visible,
      title: props.title,
      titleDone: props.titleDone,
      onShow: props.onShow,
      onDone: props.onDone,
      isDialog: props.isDialog,
      children: props.children
    }
  }
  render() {
    const { visible, title, titleDone, children, isDialog, onShow, onDone } = this.state;
    return (
      <PopupWrapper visible={visible}>
        {
          isDialog &&
          <Dialog onClose={onShow}>
            {children && React.cloneElement(children, { onShow, onDone })}
          </Dialog>
        }
        {
          !isDialog &&
          <Modal title={title} titleDone={titleDone} onShow={onShow} onDone={onDone}>
            {children && React.cloneElement(children, { onShow, onDone })}
          </Modal>
        }
      </PopupWrapper>
    )
  }
}

PopOver.propTypes = {
  title: PropTypes.string,
  titleDone: PropTypes.string,
  visible: PropTypes.bool.isRequired,
  onShow: PropTypes.func,
  onDone: PropTypes.func
}

PopOver.defaultProps = {
  visible: false,
  onShow: () => { },
  onDone: () => { }
}

export default PopOver;