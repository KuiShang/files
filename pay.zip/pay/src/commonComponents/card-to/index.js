import React from 'react';
import PropTypes from 'prop-types';
import './index.scss';
import imgTime from 'assets/imgs/recent/time.svg';
import imgTimeWhite from 'assets/imgs/recent/time-white.svg';
import imgMail from 'assets/imgs/mail/mail.svg';
import imgMailWhite from 'assets/imgs/mail/mail-white.svg';
import imgCard from 'assets/imgs/card/acc.svg';
import imgCardWhite from 'assets/imgs/card/acc-white.svg';
import imgMobile from 'assets/imgs/mobile/mobile.svg';
import imgMobileWhite from 'assets/imgs/mobile/mobile-white.svg';
import imgFPS from 'assets/imgs/fps/fps-id.svg';
import imgFPSWhite from 'assets/imgs/fps/fps-id-white.svg';
import intl from 'react-intl-universal'
class CardTo extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            checkedIndex: props.hideRecent ? 1 : props.checkedIndex,
            title: props.title,
            hideRecent: props.hideRecent
        }
    }

    render() {
        const { title, checkedIndex, hideRecent } = this.state;

        return (
            <div className="card-to">
                <div className="card-to-title">{title}</div>
                <ul className="card-to-items">
                    {
                        !hideRecent &&
                        <li className={`card-to-item ${checkedIndex === 0 ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(0)}>
                            <div className="card-to-item-info">
                                <img alt="" src={checkedIndex === 0 ? imgTimeWhite : imgTime} />
                                <span>Recent</span>
                            </div>
                        </li>
                    }
                    <li className={`card-to-item ${checkedIndex === 1 ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(1)}>
                        <div className="card-to-item-info">
                            <img alt="" src={checkedIndex === 1 ? imgMobileWhite : imgMobile} />
                            <span>{intl.get('Mobile Number')}</span>
                        </div>
                    </li>
                    <li className={`card-to-item ${checkedIndex === 2 ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(2)}>
                        <div className="card-to-item-info">
                            <img alt="" src={checkedIndex === 2 ? imgCardWhite : imgCard} />
                            <span>{intl.get('Account No.')} </span>
                        </div>
                    </li>
                    <li className={`card-to-item ${checkedIndex === 3 ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(3)}>
                        <div className="card-to-item-info">
                            <img alt="" src={checkedIndex === 3 ? imgMailWhite : imgMail} />
                            <span>{intl.get('Email')} </span>
                        </div>
                    </li>
                    <li className={`card-to-item ${checkedIndex === 4 ? 'card-to-item-actived' : ''}`} onClick={() => this.onChecked(4)}>
                        <div className="card-to-item-info">
                            <img alt="" src={checkedIndex === 4 ? imgFPSWhite : imgFPS} />
                            <span>{intl.get('FPS ID')} </span>
                        </div>
                    </li>
                </ul >
            </div >
        )
    }

    onChecked = (index) => {
        this.setState({ checkedIndex: index });
        this.props.onChecked && this.props.onChecked(index);
    }
}

CardTo.propTypes = {
    title: PropTypes.string,
    checkedIndex: PropTypes.number
}

export default CardTo;