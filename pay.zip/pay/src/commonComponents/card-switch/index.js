import React from 'react';
import PropTypes from 'prop-types';
import Switch from './Switch';
import './index.scss';

class CardSwitch extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            checked: props.checked,
            title: props.title,
            options: props.options,
        }
    }

    render() {
        const { checked, title, options } = this.state;

        return (
            <div className="card-switch">
                {title && <div className="card-switch-title">{title}</div>}
                <div className="card-switch-options">
                    <Switch checked={checked} onSwitch={() => this.onSwitch(checked)}>{options && options[0]}</Switch>
                    <Switch checked={!checked} onSwitch={() => this.onSwitch(!checked)}>{options && options[1]}</Switch>
                </div>
            </div>
        )
    }

    onSwitch = (checked) => {
        if (checked) {
            return;
        }

        this.setState({ checked: !this.state.checked }, () => {
            this.props.onSwitch && this.props.onSwitch(this.state.checked);
        });
    }
}

CardSwitch.propTypes = {
    title: PropTypes.string,
    checked: PropTypes.bool,
    options: PropTypes.array.isRequired,
}

CardSwitch.defaultProps = {
    checked: true
}

export default CardSwitch;