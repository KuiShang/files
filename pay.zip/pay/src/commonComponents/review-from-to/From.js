import React from 'react';
import intl from 'react-intl-universal'
export default class From extends React.Component {
    static defaultProps = {
        editable: true,
    }

    // static getDerivedStateFromProps(props) {
    //     return {
    //         pytype: props.initData ? props.initData.pytype : null,
    //         insccy: props.initData ? props.initData.insccy : null,
    //         otacct: props.initData ? props.initData.otacct : null
    //     }
    // }



    render() {
        const { pytype, insccy, otacct, data } = this.props;

        return (
            <div className={this.props.className}>
                <div className="review-from-to-title">{intl.get('From')}</div>
                <div className="review-from-to-account">
                    <div className="review-from-to-account-avator">
                        <div className="review-from-to-account-avator-from">VB</div>
                    </div>
                    <div className="review-from-to-account-detail">
                        <div className="review-from-to-account-bank">
                        <div className="review-from-to-account-bank">
                            <div>{this.props.initData.otbkna} ({this.props.initData.insccy})</div>
                            <div className={`ai-btn-edit ${this.props.editable ? '' : 'hide'}`} onClick={this.props.onEdit}>Edit</div>
                        </div>
                        </div>
                        <div className="review-from-to-account-no">{this.props.initData.otacct}</div>
                    </div>
                </div>
            </div>
        )
    }
}
