import React from 'react';
import From from './From';
import To from './To';
import './index.scss';

class ReviewFromTo extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            info: props.info
        }
    }

    render() {
        const { info } = this.state;
        
        return (
            <div className="review-from-to">
                <From className="review-from-to-from"
                   
                    editable={this.props.editable}
                    initData={this.props.initData}
                    onEdit={() => this.props.onEdit()}>
                </From>
                <To className="review-from-to-to"
                    initData={this.props.initData}
                    onEdit={() => this.props.onEdit()}>
                </To>
            </div>
        )
    }
}

ReviewFromTo.propTypes = {
}

export default ReviewFromTo;