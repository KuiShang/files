import React from 'react';
import intl from 'react-intl-universal'
export default class To extends React.Component {
    render() {
        const { data } = this.props;

        return (
            <div className={this.props.className}>
                <div className="review-from-to-title">{intl.get('To')}</div>
                <div className="review-from-to-account">
                    <div className="review-from-to-account-avator">
                        <div className="review-from-to-account-avator-to">CT</div>
                    </div>
                    <div className="review-from-to-account-detail">
                        <div className="review-from-to-account-bank">{this.props.initData.inacna}</div>
                        <div className="review-from-to-account-no">{this.props.initData.inacct}</div>
                        <div className="review-from-to-account-bank">{this.props.initData.inbkna}</div>
                    </div>
                </div>
            </div>
        )
    }
}