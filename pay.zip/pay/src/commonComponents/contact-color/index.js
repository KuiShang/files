import React from 'react';
import List from 'components/list';
import ItemContactColor from 'commonComponents/item-contact-color';
import intl from 'react-intl-universal'
import './index.scss';

function onInitData(data) {
    const obj = {};
    return data.map((item) => {
        const en = item.pyform.slice(0, 1);
        let first = false;
        if (obj[en.slice(0, 1)]) {
            first = false;
        } else {
            first = true;
            obj[en.slice(0, 1)] = true;
        }
        return { ...item, en, first: first }
    });
}

export default class ContactColor extends React.Component {
    state = {
        data: [],
        showContinue: this.props.showContinue
    }

    static getDerivedStateFromProps(props) {
        return {
            data: props.data,
            showContinue: props.showContinue
        }
    }

    render() {
        if (this.state.showContinue) {
            return null;
        }

        return (
            <div className="contact-color">
                {this.renderContent()}
            </div>
        )
    }

    renderContent = () => {
        return this.renderList();
    }

    renderList = () => {
        const { data } = this.state;

        if (data && ((data.last_use_list && data.last_use_list.length > 0) || (data.name_list && data.name_list.length > 0))) {
        } else {
            return <div className="no-registered">{intl.get('No-Registered-Recipients')}</div>
        }

        return (
            <React.Fragment>
                <List>
                    {data.last_use_list && data.last_use_list.map((item, index) => {
                        return (
                            <div key={index} style={{ padding: '0 21px' }}>
                                <ItemContactColor data={item} onSelectItem={() => this.props.onSelectItem(item)}></ItemContactColor>
                            </div>
                        )
                    })}
                </List>
                <List>
                    {this.renderIndexed()}
                </List>
            </React.Fragment>
        )
    }

    renderIndexed = () => {
        const items = this.props.data.name_list ? onInitData(this.props.data.name_list) : null;
        if (!items) {
            return null;
        }

        return items.map((item, index) => {
            return (
                <React.Fragment key={index}>
                    {item.first && <div className="contact-color-title">{item.en}</div>}
                    <div style={{ padding: '0 21px' }}>
                        <ItemContactColor key={item.payeno} data={item} onSelectItem={() => this.props.onSelectItem(item)}></ItemContactColor>
                    </div>
                </React.Fragment>
            )
        })
    }
}