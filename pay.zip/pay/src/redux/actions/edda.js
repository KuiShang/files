export const DO_QUERY_EDDA_ACTION = "DO_QUERY_EDDA_ACTION";
export const DONE_QUERY_EDDA_ACTION = "DONE_QUERY_EDDA_ACTION";

export function doQueryEddaAction(params, callback) {
    return {
        type: DO_QUERY_EDDA_ACTION,
        params,
        callback
    }
}

export function doneQueryEddaAction(result) {
    return {
        type: DONE_QUERY_EDDA_ACTION,
        result
    }
}

export const DO_SIGN_EDDA_CONTRACT_ACTION = "DO_SIGN_EDDA_CONTRACT_ACTION";
export const DONE_SIGN_EDDA_CONTRACT_ACTION = "DONE_SIGN_EDDA_CONTRACT_ACTION";

export function doSignEDDAContractAction(params, callback) {
    return {
        type: DO_SIGN_EDDA_CONTRACT_ACTION,
        params,
        callback
    }
}

export function doneSignEDDAContractAction(result) {
    return {
        type: DONE_SIGN_EDDA_CONTRACT_ACTION,
        result
    }
}

export const DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION = "DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION";
export const DONE_SIGN_EDDA_MERCHANT_CONTRACT_ACTION = "DONE_SIGN_EDDA_MERCHANT_CONTRACT_ACTION";

export function doSignEDDAMerchantContractAction(params, callback) {
    return {
        type: DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION,
        params,
        callback
    }
}

export function doneSignEDDAMerchantContractAction(result) {
    return {
        type: DONE_SIGN_EDDA_MERCHANT_CONTRACT_ACTION,
        result
    }
}

export const DO_QUERY_SIGN_EDDA_RESULT_ACTION = "DO_QUERY_SIGN_EDDA_RESULT_ACTION";
export const DONE_QUERY_SIGN_EDDA_RESULT_ACTION = "DONE_QUERY_SIGN_EDDA_RESULT_ACTION";

export function doQuerySignEDDAResultAction(params, callback) {
    return {
        type: DO_QUERY_SIGN_EDDA_RESULT_ACTION,
        params,
        callback
    }
}

export function doneQuerySignEDDAResultAction(result) {
    return {
        type: DONE_QUERY_SIGN_EDDA_RESULT_ACTION,
        result
    }
}

export const DO_TERMINATE_EDDA_ACTION = "DO_TERMINATE_EDDA_ACTION";
export const DONE_TERMINATE_EDDA_ACTION = "DONE_TERMINATE_EDDA_ACTION";

export function doTerminateEDDAAction(params, callback) {
    return {
        type: DO_TERMINATE_EDDA_ACTION,
        params,
        callback
    }
}

export function doneTerminateEDDAAction(result) {
    return {
        type: DONE_TERMINATE_EDDA_ACTION,
        result
    }
}

export const DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION = "DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION";
export const DONE_SIGN_IMMED_DEPOSIT_EDDA_ACTION = "DONE_SIGN_IMMED_DEPOSIT_EDDA_ACTION";

export function doSignImmedDepositEDDAAction(params, callback) {
    return {
        type: DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION,
        params,
        callback
    }
}

export function doneSignImmedDepositEDDAAction(result) {
    return {
        type: DONE_SIGN_IMMED_DEPOSIT_EDDA_ACTION,
        result
    }
}

export const DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION = "DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION";
export const DONE_UPDATE_SIGNED_MERCHANT_EDDA_ACTION = "DONE_UPDATE_SIGNED_MERCHANT_EDDA_ACTION";

export function doUpdateSignedMerchantEDDAAction(params, callback) {
    return {
        type: DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION,
        params,
        callback
    }
}

export function doneUpdateSignedMerchantEDDAAction(result) {
    return {
        type: DONE_UPDATE_SIGNED_MERCHANT_EDDA_ACTION,
        result
    }
}