export const DO_QUERY_PAYEES_ACTION = "DO_QUERY_PAYEES_ACTION";
export const DONE_QUERY_PAYEES_ACTION = "DONE_QUERY_PAYEES_ACTION";
export const DO_ADD_PAYEE_ACTION = "DO_ADD_PAYEE_ACTION";
export const DONE_ADD_PAYEE_ACTION = "DONE_ADD_PAYEE_ACTION";

/**
 * 查询收款人
 */
export function doQueryPayeesAction(params, callback) {
    return {
        type: DO_QUERY_PAYEES_ACTION,
        params,
        callback
    }
}

export function doneQueryPayeesAction(result) {
    return {
        type: DONE_QUERY_PAYEES_ACTION,
        result
    }
}

/**
 * 添加收款人
 * @param {*} params 
 */
export function doAddPayeeAction(params) {
    return {
        type: DO_ADD_PAYEE_ACTION,
        params
    }
}

export function doneAddPayeeAction(result) {
    return {
        type: DONE_ADD_PAYEE_ACTION,
        result
    }
}