export const DO_QUERY_DEPOSIT_ACCOUNT = "DO_QUERY_DEPOSIT_ACCOUNT";
export const DONE_QUERY_DEPOSIT_ACCOUNT = "DONE_QUERY_DEPOSIT_ACCOUNT";
export const DO_QUERY_BANKS_ACTION = "DO_QUERY_BANKS_ACTION";
export const DONE_QUERY_BANKS_ACTION = "DONE_QUERY_BANKS_ACTION";
export const DO_SELECT_RECIPIENT_BANK_ACTION = "DO_SELECT_RECIPIENT_BANK_ACTION";
export const DONE_SELECT_RECIPIENT_BANK_ACTION = "DONE_SELECT_RECIPIENT_BANK_ACTION";
export const DO_GET_USER_INFO_ACTION = "DO_GET_USER_INFO_ACTION";
export const DONE_GET_USER_INFO_ACTION = "DONE_GET_USER_INFO_ACTION";
export const DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION = "DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION";
export const DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION = "DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION";
export const DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION = "DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION";
export const DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION = "DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION";
export const DO_TRANSFER_WITH_TIMING_ACTION = "DO_TRANSFER_WITH_TIMING_ACTION";
export const DONE_TRANSFER_WITH_TIMING_ACTION = "DONE_TRANSFER_WITH_TIMING_ACTION";
export const DO_TRANSFER_WITH_PASS_RISK_ACTION = "DO_TRANSFER_WITH_PASS_RISK_ACTION";
export const DONE_TRANSFER_WITH_PASS_RISK_ACTION = "DONE_TRANSFER_WITH_PASS_RISK_ACTION";

export function doCheckRiskControlBeforeTransferWithImmedAction(params, callback) {
    return {
        type: DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION,
        params,
        callback
    }
}

export function doneCheckRiskControlBeforeTransferWithImmedAction(result) {
    return {
        type: DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION,
        result
    }
}

export function doCheckRiskControlBeforeTransferWithAppointAction(params, callback) {
    return {
        type: DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION,
        params,
        callback
    }
}

export function doneCheckRiskControlBeforeTransferWithAppointAction(result) {
    return {
        type: DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION,
        result
    }
}

export function doTransferWithTimingAction(params) {
    return {
        type: DO_TRANSFER_WITH_TIMING_ACTION,
        params
    }
}

export function doneTransferWithTimingAction(result) {
    return {
        type: DONE_TRANSFER_WITH_TIMING_ACTION,
        result
    }
}

export function doTransferWithPassRiskAction(params, callback) {
    return {
        type: DO_TRANSFER_WITH_PASS_RISK_ACTION,
        params,
        callback
    }
}

export function doneTransferWithPassRiskAction(result) {
    return {
        type: DONE_TRANSFER_WITH_PASS_RISK_ACTION,
        result
    }
}

export function doQueryDepositAccountAction(params) {
    return {
        type: DO_QUERY_DEPOSIT_ACCOUNT,
        params
    }
}

export function doneQueryDepositAccountAction(result) {
    return {
        type: DONE_QUERY_DEPOSIT_ACCOUNT,
        result
    }
}

export function doQueryBanksAction(params, callback) {
    return {
        type: DO_QUERY_BANKS_ACTION,
        params,
        callback
    }
}

export function doneQueryBanksAction(result) {
    return {
        type: DONE_QUERY_BANKS_ACTION,
        result
    }
}

export function doSelectRecipientBankAction(params, callback) {
    return {
        type: DO_SELECT_RECIPIENT_BANK_ACTION,
        params,
        callback
    }
}

export function doneSelectRecipientBankAction(result) {
    return {
        type: DONE_SELECT_RECIPIENT_BANK_ACTION,
        result
    }
}

export function doGetUserInfoAction(params, callback) {
    return {
        type: DO_GET_USER_INFO_ACTION,
        params,
        callback
    }
}

export function doneGetUserInfoAction(result) {
    return {
        type: DONE_GET_USER_INFO_ACTION,
        result
    }
}


export const DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION = "DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION";
export const DONE_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION = "DONE_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION";

export function doQueryAppointTransferDepositRecordsAction(params, callback) {
    return {
        type: DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION,
        params,
        callback
    }
}

export function doneQueryAppointTransferDepositRecordsAction(result) {
    return {
        type: DONE_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION,
        result
    }
}