export const DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION = 'DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION';
export const DONE_CREATE_NEW_APPOINT_DEPOSIT_ACTION = "DONE_CREATE_NEW_APPOINT_DEPOSIT_ACTION";

export function doCreateNewAppointDepositAction(params, callback) {
    return {
        type: DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION,
        params,
        callback
    }
}

export function doneCreateNewAppointDepositAction(result) {
    return {
        type: DONE_CREATE_NEW_APPOINT_DEPOSIT_ACTION,
        result
    }
}

export const DO_CREATE_NEW_IMMED_DEPOSIT_ACTION = 'DO_CREATE_NEW_IMMED_DEPOSIT_ACTION';
export const DONE_CREATE_NEW_IMMED_DEPOSIT_ACTION = "DONE_CREATE_NEW_IMMED_DEPOSIT_ACTION";

export function doCreateNewImmedDepositAction(params, callback) {
    return {
        type: DO_CREATE_NEW_IMMED_DEPOSIT_ACTION,
        params,
        callback
    }
}

export function doneCreateNewImmedDepositAction(result) {
    return {
        type: DONE_CREATE_NEW_IMMED_DEPOSIT_ACTION,
        result
    }
}

export const DO_TERMINATE_APPOINT_DEPOSIT_ACTION = 'DO_TERMINATE_APPOINT_DEPOSIT_ACTION';
export const DONE_TERMINATE_APPOINT_DEPOSIT_ACTION = "DONE_TERMINATE_APPOINT_DEPOSIT_ACTION";

export function doTerminateAppointDepositAction(params, callback) {
    return {
        type: DO_TERMINATE_APPOINT_DEPOSIT_ACTION,
        params,
        callback
    }
}

export function doneTerminateAppointDepositAction(result) {
    return {
        type: DONE_TERMINATE_APPOINT_DEPOSIT_ACTION,
        result
    }
}

export const DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION = 'DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION';
export const DONE_QUERY_IMMED_DEPOSIT_RESULT_ACTION = "DONE_QUERY_IMMED_DEPOSIT_RESULT_ACTION";

export function doQueryImmedDepositResultAction(params, callback) {
    return {
        type: DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION,
        params,
        callback
    }
}

export function doneQueryImmedDepositResultAction(result) {
    return {
        type: DONE_QUERY_IMMED_DEPOSIT_RESULT_ACTION,
        result
    }
}

export const DO_UPDATE_APPOINT_DEPOSIT_ACTION = 'DO_UPDATE_APPOINT_DEPOSIT_ACTION';
export const DONE_UPDATE_APPOINT_DEPOSIT_ACTION = "DONE_UPDATE_APPOINT_DEPOSIT_ACTION";

export function doUpdateAppointDepositAction(params, callback) {
    return {
        type: DO_UPDATE_APPOINT_DEPOSIT_ACTION,
        params,
        callback
    }
}

export function doneUpdateAppointDepositAction(result) {
    return {
        type: DONE_UPDATE_APPOINT_DEPOSIT_ACTION,
        result
    }
}

