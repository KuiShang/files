export const DO_GET_ACCOUNT_4401_ACTION = "DO_GET_ACCOUNT_4401_ACTION";
export const DONE_GET_ACCOUNT_4401_ACTION = "DONE_GET_ACCOUNT_4401_ACTION";

export function doGetAccount4401Action(params) {
    return {
        type: DO_GET_ACCOUNT_4401_ACTION,
        params
    }
}

export function doneGetAccount4401Action(result) {
    return {
        type: DONE_GET_ACCOUNT_4401_ACTION,
        result
    }
}

export const DO_GET_ACCOUNT_INFO_3014_ACTION = "DO_GET_ACCOUNT_INFO_3014_ACTION";
export const DONE_GET_ACCOUNT_INFO_3014_ACTION = "DONE_GET_ACCOUNT_INFO_3014_ACTION";

export function doGetAccountInfo3014Action(params, callback) {
    return {
        type: DO_GET_ACCOUNT_INFO_3014_ACTION,
        params,
        callback
    }
}

export function doneGetAccountInfo3014Action(result) {
    return {
        type: DONE_GET_ACCOUNT_INFO_3014_ACTION,
        result
    }
}