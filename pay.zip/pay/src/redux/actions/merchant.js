export const DO_QUERY_MERCHANT_ITEMS_ACTION = "DO_QUERY_MERCHANT_ITEMS_ACTION";
export const DONE_QUERY_MERCHANT_ITEMS_ACTION = "DONE_QUERY_MERCHANT_ITEMS_ACTION";
export const DO_QUERY_MERCHANT_TYPES_ACTION = "DO_QUERY_MERCHANT_TYPES_ACTION";
export const DONE_QUERY_MERCHANT_TYPES_ACTION = "DONE_QUERY_MERCHANT_TYPES_ACTION";

export function doQueryMerchantItemsAction(params, callback) {
    return {
        type: DO_QUERY_MERCHANT_ITEMS_ACTION,
        params,
        callback
    }
}

export function doneQueryMerchantItemsAction(result) {
    return {
        type: DONE_QUERY_MERCHANT_ITEMS_ACTION,
        result
    }
}

export function doQueryMerchantTypesAction(params) {
    return {
        type: DO_QUERY_MERCHANT_TYPES_ACTION,
        params
    }
}

export function doneQueryMerchantTypesAction(result) {
    return {
        type: DONE_QUERY_MERCHANT_TYPES_ACTION,
        result
    }
}