export const DO_QUERY_FPS_INFO_ACTION = "DO_QUERY_FPS_INFO_ACTION";
export const DONE_QUERY_FPS_INFO_ACTION = "DONE_QUERY_FPS_INFO_ACTION";
export const DO_QUERY_FPS_INFO_LOOP_ACTION = "DO_QUERY_FPS_INFO_LOOP_ACTION";
export const DONE_QUERY_FPS_INFO_LOOP_ACTION = "DONE_QUERY_FPS_INFO_LOOP_ACTION";
export const DO_QUERY_SELF_FPS_INFO_ACTION = "DO_QUERY_SELF_FPS_INFO_ACTION";
export const DONE_QUERY_SELF_FPS_INFO_ACTION = "DONE_QUERY_SELF_FPS_INFO_ACTION";

export function doQueryFPSInfoLoopAction(params, callback) {
    return {
        type: DO_QUERY_FPS_INFO_LOOP_ACTION,
        params,
        callback
    }
}

export function doneQueryFPSInfoLoopAction(result) {
    return {
        type: DONE_QUERY_FPS_INFO_LOOP_ACTION,
        result
    }
}

export function doQueryFPSInfoAction(params, callback) {
    return {
        type: DO_QUERY_FPS_INFO_ACTION,
        params,
        callback
    }
}

export function doneQueryFPSInfoAction(result) {
    return {
        type: DONE_QUERY_FPS_INFO_ACTION,
        result
    }
}

export function doQuerySelfFPSInfoAction(params, callback) {
    return {
        type: DO_QUERY_SELF_FPS_INFO_ACTION,
        params,
        callback
    }
}

export function doneQuerySelfFPSInfoAction(result) {
    return {
        type: DONE_QUERY_SELF_FPS_INFO_ACTION,
        result
    }
}

export const DO_QUERY_ALL_FPS_INFO_ACTION = "DO_QUERY_ALL_FPS_INFO_ACTION";
export const DONE_QUERY_ALL_FPS_INFO_ACTION = "DONE_QUERY_ALL_FPS_INFO_ACTION";

export function doQueryAllFPSInfoAction(params, callback) {
    return {
        type: DO_QUERY_ALL_FPS_INFO_ACTION,
        params,
        callback
    }
}

export function doneQueryAllFPSInfoAction(result) {
    return {
        type: DONE_QUERY_ALL_FPS_INFO_ACTION,
        result
    }
}

export const DO_QUERY_CENTER_FPS_INFO_ACTION = "DO_QUERY_CENTER_FPS_INFO_ACTION";
export const DONE_QUERY_CENTER_FPS_INFO_ACTION = "DONE_QUERY_CENTER_FPS_INFO_ACTION";

export function doQueryCenterFPSInfoAction(params, callback) {
    return {
        type: DO_QUERY_CENTER_FPS_INFO_ACTION,
        params,
        callback
    }
}

export function doneQueryCenterFPSInfoAction(result) {
    return {
        type: DONE_QUERY_CENTER_FPS_INFO_ACTION,
        result
    }
}

export const DO_QUERY_FPS_REGISTER_INFO_ACTION = "DO_QUERY_FPS_REGISTER_INFO_ACTION";
export const DONE_QUERY_FPS_REGISTER_INFO_ACTION = "DONE_QUERY_FPS_REGISTER_INFO_ACTION";

export function doQueryFPSRegisterInfoAction(params, callback) {
    return {
        type: DO_QUERY_FPS_REGISTER_INFO_ACTION,
        params,
        callback
    }
}

export function doneQueryFPSRegisterInfoAction(result) {
    return {
        type: DONE_QUERY_FPS_REGISTER_INFO_ACTION,
        result
    }
}