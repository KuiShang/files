export const DO_QUERY_TRANSFER_LIMIT_ACTION = "DO_QUERY_TRANSFER_LIMIT_ACTION";
export const DONE_QUERY_TRANSFER_LIMIT_ACTION = "DONE_QUERY_TRANSFER_LIMIT_ACTION";
export const DO_TRANSFER_REMITTANCE_ACTION = "DO_TRANSFER_REMITTANCE_ACTION";
export const DONE_TRANSFER_REMITTANCE_ACTION = "DONE_TRANSFER_REMITTANCE_ACTION";
export const DO_QUERY_TRANSFER_PAYER_ACTION = "DO_QUERY_TRANSFER_PAYER_ACTION";
export const DONE_QUERY_TRANSFER_PAYER_ACTION = "DONE_QUERY_TRANSFER_PAYER_ACTION";
export const DO_QUERY_TRANSFER_RESULT_ACTION = "DO_QUERY_TRANSFER_RESULT_ACTION";
export const DONE_QUERY_TRANSFER_RESULT_ACTION = "DONE_QUERY_TRANSFER_RESULT_ACTION";
export const DO_QUERY_PLAN_TRANSFER_ACTION = "DO_QUERY_PLAN_TRANSFER_ACTION";
export const DONE_QUERY_PLAN_TRANSFER_ACTION = "DONE_QUERY_PLAN_TRANSFER_ACTION";

export function doQueryPlanTransferAction(params, callback) {
    return {
        type: DO_QUERY_PLAN_TRANSFER_ACTION,
        params,
        callback
    }
}

export function doneQueryPlanTransferAction(result) {
    return {
        type: DONE_QUERY_PLAN_TRANSFER_ACTION,
        result
    }
}

/**
 * 查询日转账限额
 * @param {*} params 
 * @param {*} callback 
 */
export function doQueryTransferLimitAction(params, callback) {
    return {
        type: DO_QUERY_TRANSFER_LIMIT_ACTION,
        params,
        callback
    }
}

export function doneQueryTransferLimitAction(result) {
    return {
        type: DONE_QUERY_TRANSFER_LIMIT_ACTION,
        result
    }
}

/**
 * 转账汇款
 */
export function doTransferRemittanceAction(params) {
    return {
        type: DO_TRANSFER_REMITTANCE_ACTION,
        params
    }
}

export function doneTransferRemittanceAction(result) {
    return {
        type: DONE_TRANSFER_REMITTANCE_ACTION,
        result
    }
}

export function doQueryTransferPayerAction(params, callback) {
    return {
        type: DO_QUERY_TRANSFER_PAYER_ACTION,
        params,
        callback
    }
}

export function doneQueryTransferPayerAction(result) {
    return {
        type: DONE_QUERY_TRANSFER_PAYER_ACTION,
        result
    }
}

export function doQueryTransferResultAction(params, callback) {
    return {
        type: DO_QUERY_TRANSFER_RESULT_ACTION,
        params,
        callback
    }
}

export function doneQueryTransferResultAction(result) {
    return {
        type: DONE_QUERY_TRANSFER_RESULT_ACTION,
        result
    }
}

export const DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION = "DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION";
export const DONE_QUERY_SMALL_TRANSFER_LIMIT_ACTION = "DONE_QUERY_SMALL_TRANSFER_LIMIT_ACTION";

export function doQuerySmallTransferLimitAction(params, callback) {
    return {
        type: DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION,
        params,
        callback
    }
}

export function doneQuerySmallTransferLimitAction(result) {
    return {
        type: DONE_QUERY_SMALL_TRANSFER_LIMIT_ACTION,
        result
    }
}