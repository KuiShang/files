import FetchUtil from 'utils/FetchUtil';

export function queryTransferPayer(params) {
    return FetchUtil.post('/cocgw/4303', params)
}

export function queryTransferLimit(params) {
    return FetchUtil.post('/cocgw/4213', params);
}

export function transferRemittance(params) {
    return FetchUtil.post('/cocgw/fpscrdtran', params);
}

/**
 * 查询即时/预约转账结果详情，可以本行、可以跨行交易；
 * 查询定时入金（存款）结果详情，都是跨行交易；设置定时入金业务其实是核心系统即时进行的操作行为；
 * @param {*} params 
 */
export function queryTransferResult(params) {
    return FetchUtil.post('/cocgw/enqtranback', params);
}

/**
 * 查询预约转账
 * @param {*} params 
 */
export function queryPlanTransfer(params) {
    return FetchUtil.post('/cocgw/qrmedda', params);
}

export function querySmallTransferLimit(params) {
    return FetchUtil.post('/cocgw/enqadtf', params);
}