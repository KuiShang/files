import { put, call } from 'redux-saga/effects';
import {
    doneQueryTransferLimitAction, doneTransferRemittanceAction, doneQueryTransferPayerAction,
    doneQueryTransferResultAction, doneQueryPlanTransferAction, doneQuerySmallTransferLimitAction
} from '../../actions/transfer';
import {
    queryTransferLimit, transferRemittance, queryTransferPayer,
    queryTransferResult, queryPlanTransfer, querySmallTransferLimit
} from './api'

export function* doQueryTransferLimit(action) {
    let result = {};
    try {
        const response = yield call(queryTransferLimit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryTransferLimitAction(result));
}

export function* doTransferRemittance(action) {
    let result = {};
    try {
        const response = yield call(transferRemittance, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneTransferRemittanceAction(result));
}

export function* doQueryTransferPayer(action) {
    let result = {};
    try {
        const response = yield call(queryTransferPayer, action.params);

        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryTransferPayerAction(result));
}

export function* doQueryTransferResult(action) {
    let result = {};
    try {
        const response = yield call(queryTransferResult, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryTransferResultAction(result));
}

export function* doQueryPlanTransfer(action) {
    let result = {};
    try {
        const response = yield call(queryPlanTransfer, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryPlanTransferAction(result));
}

export function* doQuerySmallTransferLimit(action) {
    let result = {};
    try {
        const response = yield call(querySmallTransferLimit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQuerySmallTransferLimitAction(result));
}