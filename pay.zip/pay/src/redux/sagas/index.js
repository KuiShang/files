import { takeLatest, fork, takeEvery } from 'redux-saga/effects';
import {
    DO_QUERY_DEPOSIT_ACCOUNT, DO_QUERY_BANKS_ACTION,
    DO_SELECT_RECIPIENT_BANK_ACTION, DO_GET_USER_INFO_ACTION,
    DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION,
    DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION,
    DO_TRANSFER_WITH_TIMING_ACTION, DO_TRANSFER_WITH_PASS_RISK_ACTION,
    DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION
} from '../actions/common';
import {
    DO_QUERY_TRANSFER_LIMIT_ACTION, DO_QUERY_TRANSFER_PAYER_ACTION, DO_TRANSFER_REMITTANCE_ACTION,
    DO_QUERY_TRANSFER_RESULT_ACTION, DO_QUERY_PLAN_TRANSFER_ACTION, DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION
} from '../actions/transfer';
import { DO_QUERY_PAYEES_ACTION, DO_ADD_PAYEE_ACTION } from '../actions/payee';
import {
    DO_QUERY_FPS_INFO_ACTION, DO_QUERY_SELF_FPS_INFO_ACTION, DO_QUERY_FPS_INFO_LOOP_ACTION,
    DO_QUERY_ALL_FPS_INFO_ACTION, DO_QUERY_CENTER_FPS_INFO_ACTION, DO_QUERY_FPS_REGISTER_INFO_ACTION
} from '../actions/fps';
import { DO_QUERY_MERCHANT_ITEMS_ACTION, DO_QUERY_MERCHANT_TYPES_ACTION } from '../actions/merchant';
import {
    doQueryTransferLimit, doQueryTransferPayer, doTransferRemittance,
    doQueryTransferResult, doQueryPlanTransfer, doQuerySmallTransferLimit
} from './transfer';
import {
    DO_QUERY_EDDA_ACTION, DO_SIGN_EDDA_CONTRACT_ACTION,
    DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION, DO_QUERY_SIGN_EDDA_RESULT_ACTION,
    DO_TERMINATE_EDDA_ACTION, DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION,
    DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION
} from '../actions/edda';
import { DO_GET_ACCOUNT_4401_ACTION, DO_GET_ACCOUNT_INFO_3014_ACTION } from '../actions/account';
import {
    doQueryDepositAccount, doQueryBanks, doSelectRecipientBank, doGetUserInfo,
    doCheckRiskControlBeforeTransferWithImmed, doCheckRiskControlBeforeTransferWithAppoint,
    doTransferWithTiming, doTransferWithPassRisk, doQueryAppointTransferDepositRecords
} from './common';
import { doQueryPayees, doAddPayee } from './payee';
import {
    doQueryFPSInfo, doQuerySelfFPSInfo, doQueryFPSInfoLoop, doQueryAllFPSInfo,
    doQueryCenterFPSInfo, doQueryFPSRegisterInfo
} from './fps';
import {
    doQueryEdda, doSignEdda, doSignMerchantEdda, doQuerySignEddaResult, doTerminateEdda,
    doSignImmedEDDA, doUpdateSignedMerchantEDDA
} from './edda';
import { doGetAccount4401, doGetAccountInfo3014 } from './account';
import { doQueryMerchantItems, doQueryMerchantTypes } from './merchant';
import {
    DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION, DO_CREATE_NEW_IMMED_DEPOSIT_ACTION, DO_TERMINATE_APPOINT_DEPOSIT_ACTION,
    DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION, DO_UPDATE_APPOINT_DEPOSIT_ACTION
} from '../actions/deposit';
import {
    doCreateNewImmedDeposit, doCreateNewAppointDeposit, doTerminateAppointDeposit, doQueryImmedDepositResult,
    doUpdateAppointDeposit
} from './deposit'

export default function* index() {
    yield [
        takeLatest(DO_TRANSFER_REMITTANCE_ACTION, doTransferRemittance),
        takeLatest(DO_ADD_PAYEE_ACTION, doAddPayee),
        takeLatest(DO_QUERY_TRANSFER_LIMIT_ACTION, doQueryTransferLimit),
        takeLatest(DO_QUERY_DEPOSIT_ACCOUNT, doQueryDepositAccount),
        takeLatest(DO_QUERY_BANKS_ACTION, doQueryBanks),
        takeLatest(DO_QUERY_PAYEES_ACTION, doQueryPayees),
        takeLatest(DO_QUERY_FPS_INFO_ACTION, doQueryFPSInfo),
        takeLatest(DO_QUERY_TRANSFER_PAYER_ACTION, doQueryTransferPayer),
        takeLatest(DO_QUERY_TRANSFER_RESULT_ACTION, doQueryTransferResult),
        takeLatest(DO_QUERY_SELF_FPS_INFO_ACTION, doQuerySelfFPSInfo),
        takeLatest(DO_SELECT_RECIPIENT_BANK_ACTION, doSelectRecipientBank),
        takeLatest(DO_QUERY_EDDA_ACTION, doQueryEdda),
        takeLatest(DO_GET_USER_INFO_ACTION, doGetUserInfo),
        takeLatest(DO_QUERY_FPS_INFO_LOOP_ACTION, doQueryFPSInfoLoop),
        takeLatest(DO_GET_ACCOUNT_4401_ACTION, doGetAccount4401),
        takeLatest(DO_QUERY_PLAN_TRANSFER_ACTION, doQueryPlanTransfer),
        takeLatest(DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION, doCheckRiskControlBeforeTransferWithImmed),
        takeLatest(DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION, doCheckRiskControlBeforeTransferWithAppoint),
        takeLatest(DO_TRANSFER_WITH_TIMING_ACTION, doTransferWithTiming),
        takeLatest(DO_TRANSFER_WITH_PASS_RISK_ACTION, doTransferWithPassRisk),
        takeLatest(DO_QUERY_MERCHANT_ITEMS_ACTION, doQueryMerchantItems),
        takeLatest(DO_QUERY_MERCHANT_TYPES_ACTION, doQueryMerchantTypes),
        takeLatest(DO_SIGN_EDDA_CONTRACT_ACTION, doSignEdda),
        takeLatest(DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION, doSignMerchantEdda),
        takeLatest(DO_QUERY_SIGN_EDDA_RESULT_ACTION, doQuerySignEddaResult),
        takeEvery(DO_TERMINATE_EDDA_ACTION, doTerminateEdda),
        takeLatest(DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION, doSignImmedEDDA),
        takeEvery(DO_QUERY_ALL_FPS_INFO_ACTION, doQueryAllFPSInfo),
        takeEvery(DO_QUERY_CENTER_FPS_INFO_ACTION, doQueryCenterFPSInfo),
        takeLatest(DO_GET_ACCOUNT_INFO_3014_ACTION, doGetAccountInfo3014),
        takeLatest(DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION, doCreateNewAppointDeposit),
        takeLatest(DO_CREATE_NEW_IMMED_DEPOSIT_ACTION, doCreateNewImmedDeposit),
        takeLatest(DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION, doQueryAppointTransferDepositRecords),
        takeLatest(DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION, doQuerySmallTransferLimit),
        takeLatest(DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION, doUpdateSignedMerchantEDDA),
        takeLatest(DO_TERMINATE_APPOINT_DEPOSIT_ACTION, doTerminateAppointDeposit),
        takeLatest(DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION, doQueryImmedDepositResult),
        takeLatest(DO_UPDATE_APPOINT_DEPOSIT_ACTION, doUpdateAppointDeposit),
        takeLatest(DO_QUERY_FPS_REGISTER_INFO_ACTION, doQueryFPSRegisterInfo),
    ]
}