import FetchUtil from 'utils/FetchUtil';

/**
 * 查询商户列表
 * @param {*} params 
 */
export function queryMerchantItems(params) {
    return FetchUtil.post('/cocgw/fpseqmerch', params);
}

export function queryMerchantTypes(params) {
    return FetchUtil.post('/cocgw/eqmerchtp', params);
}