import { put, call } from 'redux-saga/effects';
import { doneQueryMerchantItemsAction, doneQueryMerchantTypesAction } from 'redux/actions/merchant';
import { queryMerchantItems, queryMerchantTypes } from './api'

export function* doQueryMerchantItems(action) {
    let result = {};
    try {
        const response = yield call(queryMerchantItems, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryMerchantItemsAction(result));
}

export function* doQueryMerchantTypes(action) {
    let result = {};
    try {
        const response = yield call(queryMerchantTypes, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneQueryMerchantTypesAction(result));
}

