import FetchUtil from 'utils/FetchUtil';

export function queryDepositAccount(params) {
    return FetchUtil.post('/cocgw/4033', params);
}

export function queryBanks(params) {
    return FetchUtil.post('/cocgw/enqbkcd', params);
}

/**
 * 即时转账前先进行风控方式检查
 * @param {*} params 
 */
export function checkRiskControlBeforeTransferWithImmed(params) {
    return FetchUtil.post('/cocgw/befcrdtran', params);
}

/**
 * 预约转账先进行风控方式检查
 * @param {*} params 
 */
export function checkRiskControlBeforeTransferWithAppoint(params) {
    return FetchUtil.post('/cocgw/initmedda', params);
}

/**
 * /定时入金先进行风控方式检查
 * @param {*} params 
 */
export function transferWithTiming(params) {
    return FetchUtil.post('/cocgw/initmedda', params);
}

/**
 * 风控接口查询以完成流程
 * @param {*} params 
 */
export function transferWithPassRisk(params) {
    return FetchUtil.post('/cocgw/qryrisk', params);
}

/**
 * 查询预约转账/定时存款入金记录
 * @param {*} params 
 */
export function queryAppointTransferDepositRecords(params) {
    return FetchUtil.post('/cocgw/qrmedda', params);
}