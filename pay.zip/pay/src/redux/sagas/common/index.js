import { put, call } from 'redux-saga/effects';
import * as SDK from 'utils/SDKUtil';
import {
    doneQueryDepositAccountAction, doneQueryBanksAction,
    doneSelectRecipientBankAction, doneGetUserInfoAction,
    doneCheckRiskControlBeforeTransferWithImmedAction,
    doneCheckRiskControlBeforeTransferWithAppointAction,
    doneTransferWithTimingAction, doneTransferWithPassRiskAction,
    doneQueryAppointTransferDepositRecordsAction
} from 'redux/actions/common';
import {
    queryDepositAccount, queryBanks,
    checkRiskControlBeforeTransferWithImmed, checkRiskControlBeforeTransferWithAppoint,
    transferWithAppoint, transferWithTiming, transferWithPassRisk, queryAppointTransferDepositRecords
} from './api'

export function* doQueryDepositAccount(action) {
    let result = {};
    try {
        const response = yield call(queryDepositAccount, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneQueryDepositAccountAction(result));
}

export function* doQueryBanks(action) {
    let result = {};
    try {
        const response = yield call(queryBanks, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryBanksAction(result));
}

export function* doSelectRecipientBank(action) {
    let result = {};
    result.account = action.params;

    yield put(doneSelectRecipientBankAction(result));
    action.callback && typeof action.callback === "function" && action.callback({ ...result });
}

export function* doGetUserInfo(action) {
    SDK.getUserInfo((res) => {
        action.callback && typeof action.callback === "function" && action.callback(res);

    });
}

export function* doCheckRiskControlBeforeTransferWithImmed(action) {
    let result = {};
    try {
        const response = yield call(checkRiskControlBeforeTransferWithImmed, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneCheckRiskControlBeforeTransferWithImmedAction(result));
}

export function* doCheckRiskControlBeforeTransferWithAppoint(action) {
    let result = {};
    try {
        const response = yield call(checkRiskControlBeforeTransferWithAppoint, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneCheckRiskControlBeforeTransferWithAppointAction(result));
}

export function* doTransferWithTiming(action) {
    let result = {};
    try {
        const response = yield call(transferWithTiming, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneTransferWithTimingAction(result));
}

export function* doTransferWithPassRisk(action) {
    let result = {};
    try {
        const response = yield call(transferWithPassRisk, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneTransferWithPassRiskAction(result));
}


export function* doQueryAppointTransferDepositRecords(action) {
    let result = {};
    try {
        const response = yield call(queryAppointTransferDepositRecords, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryAppointTransferDepositRecordsAction(result));
}
