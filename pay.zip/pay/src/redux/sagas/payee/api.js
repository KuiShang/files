import * as SDK from 'utils/SDKUtil';
import FetchUtil from 'utils/FetchUtil';

/**
 * 查询收款人
 * @param {*} params 
 */
export function queryPayess(params) {
    return FetchUtil.post('/cocgw/qrpyfo', params);
}

/**
 * 添加收款人
 * @param {*} params 
 */
export function addPayee(params) {
    return FetchUtil.post('/cocgw/adpyfo', params);
}