import { put, call } from 'redux-saga/effects';
import { doneQueryPayeesAction, doneAddPayeeAction } from '../../actions/payee';
import { queryPayess, addPayee } from './api'

export function* doQueryPayees(action) {
    let result = {};
    try {
        const response = yield call(queryPayess, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryPayeesAction(result));
}

export function* doAddPayee(action) {
    let result = {};
    try {
        const response = yield call(addPayee, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneAddPayeeAction(result));
}