import FetchUtil from 'utils/FetchUtil';

/**
 * 新增即时入金
 * @param {*} params 
 */
export function createNewImmedDeposit(params) {
    return FetchUtil.post('/cocgw/crfpsdbttran', params);
}

/**
 * 新增定时入金
 * @param {*} params 
 */
export function createNewAppointDeposit(params) {
    return FetchUtil.post('/cocgw/initmdeposit', params);
}

/**
 * 终止定时入金
 * @param {*} params 
 */
export function terminateAppointDeposit(params) {
    return FetchUtil.post('/cocgw/cancelmedda', params);
}

/**
 * 查询即时入金结果
 * @param {*} params 
 */
export function queryImmedDepositResult(params) {
    //return FetchUtil.post('/cocgw/enqpyst', params);
    return FetchUtil.post('/cocgw/qryfundtx', params);
}

/**
 * 维护修改定时入金配置
 * @param {*} params 
 */
export function updateAppointDeposit(params) {
    return FetchUtil.post('/cocgw/amendmedda', params);
}
