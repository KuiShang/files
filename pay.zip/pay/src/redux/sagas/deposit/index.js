import { put, call } from 'redux-saga/effects';
import {
    doneCreateNewAppointDepositAction, doneCreateNewImmedDepositAction,
    doneTerminateAppointDepositAction, doneQueryImmedDepositResultAction,
    doneUpdateAppointDepositAction
} from 'redux/actions/deposit';
import {
    createNewImmedDeposit, createNewAppointDeposit, terminateAppointDeposit,
    queryImmedDepositResult, updateAppointDeposit
} from './api'

export function* doCreateNewImmedDeposit(action) {
    let result = {};
    try {
        const response = yield call(createNewImmedDeposit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneCreateNewImmedDepositAction(result));
}

export function* doCreateNewAppointDeposit(action) {
    let result = {};
    try {
        const response = yield call(createNewAppointDeposit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneCreateNewAppointDepositAction(result));
}

export function* doTerminateAppointDeposit(action) {
    let result = {};
    try {
        const response = yield call(terminateAppointDeposit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneTerminateAppointDepositAction(result));
}

export function* doQueryImmedDepositResult(action) {
    let result = {};
    try {
        const response = yield call(queryImmedDepositResult, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryImmedDepositResultAction(result));
}

export function* doUpdateAppointDeposit(action) {
    let result = {};
    try {
        const response = yield call(updateAppointDeposit, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneUpdateAppointDepositAction(result));
}