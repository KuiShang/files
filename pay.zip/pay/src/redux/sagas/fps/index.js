import { put, call } from 'redux-saga/effects';
import {
    doneQueryFPSInfoAction, doneQuerySelfFPSInfoAction, doneQueryFPSInfoLoopAction,
    doneQueryAllFPSInfoAction, doneQueryCenterFPSInfoAction, doneQueryFPSRegisterInfoAction
} from '../../actions/fps';
import {
    queryFPSInfo, querySelfFPSInfo, queryFPSInfoLoop,
    queryAllFPSInfo, queryCenterFPSInfo, queryFPSRegisterInfo
} from './api';

export function* doQueryFPSInfo(action) {
    let result = {};
    try {
        const response = yield call(queryFPSInfo, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryFPSInfoAction(result));
}

/**
 * 查询所有FPS记录
 * @param {*} action 
 */
export function* doQueryAllFPSInfo(action) {
    let result = {};
    try {
        const response = yield call(queryAllFPSInfo, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryAllFPSInfoAction(result));
}

export function* doQueryFPSInfoLoop(action) {
    let result = {};
    try {
        //yield call(delay, 2000);
        const response = yield call(queryFPSInfoLoop, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryFPSInfoLoopAction(result));
}

export function* doQuerySelfFPSInfo(action) {
    let result = {};
    try {
        const response = yield call(querySelfFPSInfo, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQuerySelfFPSInfoAction(result));
}

/**
 * 查询FPS中心注册记录
 * @param {*} action 
 */
export function* doQueryCenterFPSInfo(action) {
    let result = {};
    try {
        const response = yield call(queryCenterFPSInfo, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryCenterFPSInfoAction(result));
}

export function* doQueryFPSRegisterInfo(action) {
    let result = {};
    try {
        const response = yield call(queryFPSRegisterInfo, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryFPSRegisterInfoAction(result));
}