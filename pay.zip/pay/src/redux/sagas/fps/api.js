import FetchUtil from 'utils/FetchUtil';

/**
 * 查询收款方FPS登记信息
 * @param {*} params 
 */
export function queryFPSInfo(params) {
    return FetchUtil.post('/cocgw/crenqaddr', params);
}

/**
 * 查询本业务系统数据库中所有FPS信息
 * @param {*} params 
 */
export function queryAllFPSInfo(params) {
    return FetchUtil.post('/cocgw/crenqfpsaddr', params);
}

/**
 * 轮询从FPS中心查询登记信息
 * @param {*} params 
 */
export function queryCenterFPSInfo(params) {
    return FetchUtil.post('/cocgw/enqfpsaddrbk', params);
}

export function queryFPSRegisterInfo(params) {
    return FetchUtil.post('/cocgw/enqaddr', params);
}

/**
 * 查询操作FPS结果(轮询查询登记结果)
 * @param {*} params 
 */
export function queryFPSInfoLoop(params) {
    return FetchUtil.post('/cocgw/enqaddrbk', params);
}

export function querySelfFPSInfo(params) {
    return FetchUtil.post('/cocgw/crqyadrsprox', params);
}

