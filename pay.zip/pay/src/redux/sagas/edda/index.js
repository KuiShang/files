import { put, call } from 'redux-saga/effects';
import {
    doneQueryEddaAction, doneSignEDDAContractAction, doneSignEDDAMerchantContractAction,
    doneQuerySignEDDAResultAction, doneTerminateEDDAAction,
    doneSignImmedDepositEDDAAction, doneUpdateSignedMerchantEDDAAction
} from 'redux/actions/edda';
import {
    queryEdda, signEdda, signMerchantEdda, querySignEddaResult,
    terminateEdda, signImmedEDDA, updateSignedMerchanteDDA
} from './api'

export function* doQueryEdda(action) {
    let result = {};
    try {
        const response = yield call(queryEdda, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQueryEddaAction(result));
}

export function* doSignEdda(action) {
    let result = {};
    try {
        const response = yield call(signEdda, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneSignEDDAContractAction(result));
}

export function* doSignMerchantEdda(action) {
    let result = {};
    try {
        const response = yield call(signMerchantEdda, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneSignEDDAMerchantContractAction(result));
}

export function* doQuerySignEddaResult(action) {
    let result = {};
    try {
        const response = yield call(querySignEddaResult, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneQuerySignEDDAResultAction(result));
}

export function* doTerminateEdda(action) {
    let result = {};
    try {
        const response = yield call(terminateEdda, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneTerminateEDDAAction(result));
}

export function* doSignImmedEDDA(action) {
    let result = {};
    try {
        const response = yield call(signImmedEDDA, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneSignImmedDepositEDDAAction(result));
}

export function* doUpdateSignedMerchantEDDA(action) {
    let result = {};
    try {
        const response = yield call(updateSignedMerchanteDDA, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    action.callback && typeof action.callback === "function" && action.callback({ ...result });
    yield put(doneUpdateSignedMerchantEDDAAction(result));
}