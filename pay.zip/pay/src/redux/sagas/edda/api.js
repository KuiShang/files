import FetchUtil from 'utils/FetchUtil';

/**
 * 查询签约
 * Option 1: 商户eDDA签约
 * Option 2: 定时存款/入金SeDDA签约
 * @param {*} params 
 */
export function queryEdda(params) {
    return FetchUtil.post('/cocgw/qredda', params);
}

export function signEdda(params) {
    return FetchUtil.post('/cocgw/initedda', params);
}

export function signMerchantEdda(params) {
    return FetchUtil.post('/cocgw/initmerchant', params);
}

/**
 * 查询eDDA/SeDDA签约结果（商户/个人）
 * 
 * 签约sedda，终止sedda；
 * 签约edda，修改edda，终止edda；
 * 如果交易结果是处理中；需要用fpsqryeddatx 接口进行轮询查询
 */
export function querySignEddaResult(params) {
    return FetchUtil.post('/cocgw/fpsqryeddatx', params);
}

/**
 * 终止eDDA签约（商户/个人）
 */
export function terminateEdda(params) {
    return FetchUtil.post('/cocgw/cr_canceledda', params);
}

/**
 * 即时入金eDDA签约
 * @param {*} params 
 */
export function signImmedEDDA(params) {
    return FetchUtil.post('/cocgw/cr_initedda', params);
}

/**
 * 更新签约商户eDDA
 * @param {*} params 
 */
export function updateSignedMerchanteDDA(params) {
    return FetchUtil.post('/cocgw/cr_amendedda', params);
}