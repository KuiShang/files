import { put, call } from 'redux-saga/effects';
import { doneGetAccount4401Action, doneGetAccountInfo3014Action } from 'redux/actions/account';
import { getAccount4401, getAccountInfo3014 } from './api'

export function* doGetAccount4401(action) {
    let result = {};
    try {
        const response = yield call(getAccount4401, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneGetAccount4401Action(result));
}

export function* doGetAccountInfo3014(action) {
    let result = {};
    try {
        const response = yield call(getAccountInfo3014, action.params);
        if (response) {
            result = response;
        }
    } catch (ex) {
        result.msg = ex;
    }

    yield put(doneGetAccountInfo3014Action(result));
}
