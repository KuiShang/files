import FetchUtil from 'utils/FetchUtil';

export function getAccount4401(params) {
    return FetchUtil.post('/cocgw/4401', params);
}

export function getAccountInfo3014(params) {
    return FetchUtil.post('/cocgw/3014', params);
}