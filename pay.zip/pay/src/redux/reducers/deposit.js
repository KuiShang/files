import {
    DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION, DONE_CREATE_NEW_APPOINT_DEPOSIT_ACTION,
    DO_CREATE_NEW_IMMED_DEPOSIT_ACTION, DONE_CREATE_NEW_IMMED_DEPOSIT_ACTION,
    DO_TERMINATE_APPOINT_DEPOSIT_ACTION, DONE_TERMINATE_APPOINT_DEPOSIT_ACTION,
    DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION, DONE_QUERY_IMMED_DEPOSIT_RESULT_ACTION,
    DO_UPDATE_APPOINT_DEPOSIT_ACTION, DONE_UPDATE_APPOINT_DEPOSIT_ACTION
} from '../actions/deposit';

export function doCreateNewAppointDepositReducer(state = {}, action) {
    switch (action.type) {
        case DO_CREATE_NEW_APPOINT_DEPOSIT_ACTION:
            return state;
        case DONE_CREATE_NEW_APPOINT_DEPOSIT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doCreateNewImmedDepositReducer(state = {}, action) {
    switch (action.type) {
        case DO_CREATE_NEW_IMMED_DEPOSIT_ACTION:
            return state;
        case DONE_CREATE_NEW_IMMED_DEPOSIT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doTerminateAppointDepositReducer(state = {}, action) {
    switch (action.type) {
        case DO_TERMINATE_APPOINT_DEPOSIT_ACTION:
            return state;
        case DONE_TERMINATE_APPOINT_DEPOSIT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryImmedDepositResultReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_IMMED_DEPOSIT_RESULT_ACTION:
            return state;
        case DONE_QUERY_IMMED_DEPOSIT_RESULT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doUpdateAppointDepositReducer(state = {}, action) {
    switch (action.type) {
        case DO_UPDATE_APPOINT_DEPOSIT_ACTION:
            return state;
        case DONE_UPDATE_APPOINT_DEPOSIT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}