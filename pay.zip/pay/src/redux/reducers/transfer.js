import {
    DO_QUERY_TRANSFER_LIMIT_ACTION, DONE_QUERY_TRANSFER_LIMIT_ACTION,
    DO_TRANSFER_REMITTANCE_ACTION, DONE_TRANSFER_REMITTANCE_ACTION,
    DO_QUERY_TRANSFER_PAYER_ACTION, DONE_QUERY_TRANSFER_PAYER_ACTION,
    DO_QUERY_TRANSFER_RESULT_ACTION, DONE_QUERY_TRANSFER_RESULT_ACTION,
    DO_QUERY_PLAN_TRANSFER_ACTION, DONE_QUERY_PLAN_TRANSFER_ACTION,
    DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION, DONE_QUERY_SMALL_TRANSFER_LIMIT_ACTION
} from '../actions/transfer';

export function doQueryPlanTransferReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_PLAN_TRANSFER_ACTION:
            return state;
        case DONE_QUERY_PLAN_TRANSFER_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryTransferLimitReducer(state = { isLoading: false }, action) {
    switch (action.type) {
        case DO_QUERY_TRANSFER_LIMIT_ACTION:
            return { isLoading: true };
        case DONE_QUERY_TRANSFER_LIMIT_ACTION:
            return Object.assign({}, action.result, { isLoading: false });
        default:
            return state;
    }
}

export function doTransferRemittanceReducer(state = {}, action) {
    switch (action.type) {
        case DO_TRANSFER_REMITTANCE_ACTION:
            return state;
        case DONE_TRANSFER_REMITTANCE_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryTransferPayerReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_TRANSFER_PAYER_ACTION:
            return state;
        case DONE_QUERY_TRANSFER_PAYER_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryTransferResultReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_TRANSFER_RESULT_ACTION:
            return state;
        case DONE_QUERY_TRANSFER_RESULT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQuerySmallTransferLimitReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_SMALL_TRANSFER_LIMIT_ACTION:
            return state;
        case DONE_QUERY_SMALL_TRANSFER_LIMIT_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}