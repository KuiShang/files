import {
    DO_QUERY_DEPOSIT_ACCOUNT, DONE_QUERY_DEPOSIT_ACCOUNT,
    DO_QUERY_BANKS_ACTION, DONE_QUERY_BANKS_ACTION,
    DO_SELECT_RECIPIENT_BANK_ACTION, DONE_SELECT_RECIPIENT_BANK_ACTION,
    DO_GET_USER_INFO_ACTION, DONE_GET_USER_INFO_ACTION,
    DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION,
    DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION,
    DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION,
    DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION,
    DO_TRANSFER_WITH_TIMING_ACTION, DONE_TRANSFER_WITH_TIMING_ACTION,
    DO_TRANSFER_WITH_PASS_RISK_ACTION, DONE_TRANSFER_WITH_PASS_RISK_ACTION,
    DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION, DONE_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION
} from '../actions/common';

export function doQueryDepositAccountReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_DEPOSIT_ACCOUNT:
            return state;
        case DONE_QUERY_DEPOSIT_ACCOUNT:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryBanksReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_BANKS_ACTION:
            return state;
        case DONE_QUERY_BANKS_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doSelectRecipientBankReducer(state = {}, action) {
    switch (action.type) {
        case DO_SELECT_RECIPIENT_BANK_ACTION:
            return state;
        case DONE_SELECT_RECIPIENT_BANK_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doGetUserInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_GET_USER_INFO_ACTION:
            return state;
        case DONE_GET_USER_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doCheckRiskControlBeforeTransferWithImmedReducer(state = {}, action) {
    switch (action.type) {
        case DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION:
            return state;
        case DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_IMMED_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doCheckRiskControlBeforeTransferWithAppointReducer(state = {}, action) {
    switch (action.type) {
        case DO_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION:
            return state;
        case DONE_CHECK_RISK_CONTROL_BEFORE_TRANSFER_WITH_APPOINT_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doTransferWithTimingReducer(state = {}, action) {
    switch (action.type) {
        case DO_TRANSFER_WITH_TIMING_ACTION:
            return state;
        case DONE_TRANSFER_WITH_TIMING_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doTransferWithPassRiskReducer(state = {}, action) {
    switch (action.type) {
        case DO_TRANSFER_WITH_PASS_RISK_ACTION:
            return state;
        case DONE_TRANSFER_WITH_PASS_RISK_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQueryAppointTransferDepositRecordsReucer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION:
            return state;
        case DONE_QUERY_APPOINT_TRANSFER_DEPOSIT_RECORDS_ACTION:
            return action.result;
        default:
            return state;
    }
}