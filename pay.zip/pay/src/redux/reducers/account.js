import {
    DO_GET_ACCOUNT_4401_ACTION, DONE_GET_ACCOUNT_4401_ACTION,
    DO_GET_ACCOUNT_INFO_3014_ACTION, DONE_GET_ACCOUNT_INFO_3014_ACTION
} from '../actions/account';

export function doGetAccount4401Reducer(state = {}, action) {
    switch (action.type) {
        case DO_GET_ACCOUNT_4401_ACTION:
            return state;
        case DONE_GET_ACCOUNT_4401_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doGetAccountInfo3014Reducer(state = {}, action) {
    switch (action.type) {
        case DO_GET_ACCOUNT_INFO_3014_ACTION:
            return state;
        case DONE_GET_ACCOUNT_INFO_3014_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}