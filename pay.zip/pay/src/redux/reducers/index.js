import { combineReducers } from 'redux';
import {
    doQueryTransferLimitReducer, doTransferRemittanceReducer, doQueryTransferPayerReducer,
    doQueryTransferResultReducer, doQueryPlanTransferReducer, doQuerySmallTransferLimitReducer
} from './transfer';
import {
    doQueryDepositAccountReducer, doQueryBanksReducer, doSelectRecipientBankReducer, doGetUserInfoReducer,
    doCheckRiskControlBeforeTransferWithImmedReducer, doCheckRiskControlBeforeTransferWithAppointReducer,
    doTransferWithTimingReducer, doTransferWithPassRiskReducer, doQueryAppointTransferDepositRecordsReucer
} from './common';
import { doQueryPayeesReducer, doAddPayeeReducer } from './payee';
import {
    doQueryFPSInfoReducer, doQuerySelfFPSInfoReducer, doQueryFPSInfoLoopReducer,
    doQueryAllFPSInfoReducer, doQueryCenterFPSInfoReducer, doQueryFPSRegisterInfoReducer
} from './fps';
import {
    doQueryEddaReducer, doSignEDDAContractReducer, doSignEDDAMerchantContractReducer,
    doQuerySignEDDAResultReducer, doTerminateEDDAReducer, doSignImmedDepositEDDAReducer,
    doUpdateSignedMerchantEDDAReducer
} from './edda';
import { doGetAccount4401Reducer, doGetAccountInfo3014Reducer } from './account';
import { doQueryMerchantItemsReducer, doQueryMerchantTypesReducer } from './merchant';
import {
    doCreateNewAppointDepositReducer, doCreateNewImmedDepositReducer, doTerminateAppointDepositReducer,
    doQueryImmedDepositResultReducer, doUpdateAppointDepositReducer
} from './deposit';

export default combineReducers({
    doQueryFPSInfoLoopReducer,
    doQueryTransferPayerReducer,
    doTransferRemittanceReducer,
    doQueryTransferLimitReducer,
    doQueryDepositAccountReducer,
    doQueryBanksReducer,
    doQueryPayeesReducer,
    doQueryFPSInfoReducer,
    doAddPayeeReducer,
    doTransferWithPassRiskReducer,
    doQueryTransferResultReducer,
    doQuerySelfFPSInfoReducer,
    doSelectRecipientBankReducer,
    doQueryEddaReducer,
    doGetUserInfoReducer,
    doGetAccount4401Reducer,
    doQueryPlanTransferReducer,
    doCheckRiskControlBeforeTransferWithImmedReducer,
    doCheckRiskControlBeforeTransferWithAppointReducer,
    doTransferWithTimingReducer,
    doTransferWithPassRiskReducer,
    doQueryMerchantItemsReducer,
    doQueryMerchantTypesReducer,
    doSignEDDAContractReducer,
    doSignEDDAMerchantContractReducer,
    doQuerySignEDDAResultReducer,
    doTerminateEDDAReducer,
    doSignImmedDepositEDDAReducer,
    doQueryAllFPSInfoReducer,
    doQueryCenterFPSInfoReducer,
    doGetAccountInfo3014Reducer,
    doCreateNewAppointDepositReducer,
    doCreateNewImmedDepositReducer,
    doQueryAppointTransferDepositRecordsReucer,
    doQuerySmallTransferLimitReducer,
    doUpdateSignedMerchantEDDAReducer,
    doTerminateAppointDepositReducer,
    doQueryImmedDepositResultReducer,
    doUpdateAppointDepositReducer,
    doQueryFPSRegisterInfoReducer
})