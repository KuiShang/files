import {
    DO_QUERY_EDDA_ACTION, DONE_QUERY_EDDA_ACTION,
    DO_SIGN_EDDA_CONTRACT_ACTION, DONE_SIGN_EDDA_CONTRACT_ACTION,
    DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION, DONE_SIGN_EDDA_MERCHANT_CONTRACT_ACTION,
    DO_QUERY_SIGN_EDDA_RESULT_ACTION, DONE_QUERY_SIGN_EDDA_RESULT_ACTION,
    DO_TERMINATE_EDDA_ACTION, DONE_TERMINATE_EDDA_ACTION,
    DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION, DONE_SIGN_IMMED_DEPOSIT_EDDA_ACTION,
    DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION, DONE_UPDATE_SIGNED_MERCHANT_EDDA_ACTION
} from '../actions/edda';

export function doQueryEddaReducer(state = { isLoading: false }, action) {
    switch (action.type) {
        case DO_QUERY_EDDA_ACTION:
            return { isLoading: true };
        case DONE_QUERY_EDDA_ACTION:
            return Object.assign({}, action.result, { isLoading: false });
        default:
            return state;
    }
}

export function doSignEDDAContractReducer(state = {}, action) {
    switch (action.type) {
        case DO_SIGN_EDDA_CONTRACT_ACTION:
            return state;
        case DONE_SIGN_EDDA_CONTRACT_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doSignEDDAMerchantContractReducer(state = {}, action) {
    switch (action.type) {
        case DO_SIGN_EDDA_MERCHANT_CONTRACT_ACTION:
            return state;
        case DONE_SIGN_EDDA_MERCHANT_CONTRACT_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQuerySignEDDAResultReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_SIGN_EDDA_RESULT_ACTION:
            return state;
        case DONE_QUERY_SIGN_EDDA_RESULT_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doTerminateEDDAReducer(state = {}, action) {
    switch (action.type) {
        case DO_TERMINATE_EDDA_ACTION:
            return state;
        case DONE_TERMINATE_EDDA_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doSignImmedDepositEDDAReducer(state = {}, action) {
    switch (action.type) {
        case DO_SIGN_IMMED_DEPOSIT_EDDA_ACTION:
            return state;
        case DONE_SIGN_IMMED_DEPOSIT_EDDA_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doUpdateSignedMerchantEDDAReducer(state = {}, action) {
    switch (action.type) {
        case DO_UPDATE_SIGNED_MERCHANT_EDDA_ACTION:
            return state;
        case DONE_UPDATE_SIGNED_MERCHANT_EDDA_ACTION:
            return action.result;
        default:
            return state;
    }
}