import {
    DO_QUERY_FPS_INFO_ACTION, DONE_QUERY_FPS_INFO_ACTION,
    DO_QUERY_FPS_INFO_LOOP_ACTION, DONE_QUERY_FPS_INFO_LOOP_ACTION,
    DO_QUERY_SELF_FPS_INFO_ACTION, DONE_QUERY_SELF_FPS_INFO_ACTION,
    DO_QUERY_ALL_FPS_INFO_ACTION, DONE_QUERY_ALL_FPS_INFO_ACTION,
    DO_QUERY_CENTER_FPS_INFO_ACTION, DONE_QUERY_CENTER_FPS_INFO_ACTION,
    DO_QUERY_FPS_REGISTER_INFO_ACTION, DONE_QUERY_FPS_REGISTER_INFO_ACTION
} from '../actions/fps';

export function doQueryFPSInfoLoopReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_FPS_INFO_LOOP_ACTION:
            return state;
        case DONE_QUERY_FPS_INFO_LOOP_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQueryFPSInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_FPS_INFO_ACTION:
            return state;
        case DONE_QUERY_FPS_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQuerySelfFPSInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_SELF_FPS_INFO_ACTION:
            return state;
        case DONE_QUERY_SELF_FPS_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQueryAllFPSInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_ALL_FPS_INFO_ACTION:
            return state;
        case DONE_QUERY_ALL_FPS_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQueryCenterFPSInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_CENTER_FPS_INFO_ACTION:
            return state;
        case DONE_QUERY_CENTER_FPS_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doQueryFPSRegisterInfoReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_FPS_REGISTER_INFO_ACTION:
            return state;
        case DONE_QUERY_FPS_REGISTER_INFO_ACTION:
            return action.result;
        default:
            return state;
    }
}