import { DO_QUERY_PAYEES_ACTION, DONE_QUERY_PAYEES_ACTION, DO_ADD_PAYEE_ACTION, DONE_ADD_PAYEE_ACTION } from '../actions/payee';

export function doQueryPayeesReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_PAYEES_ACTION:
            return state;
        case DONE_QUERY_PAYEES_ACTION:
            return action.result;
        default:
            return state;
    }
}

export function doAddPayeeReducer(state = {}, action) {
    switch (action.type) {
        case DO_ADD_PAYEE_ACTION:
            return state;
        case DONE_ADD_PAYEE_ACTION:
            return action.result;
        default:
            return state;
    }
}