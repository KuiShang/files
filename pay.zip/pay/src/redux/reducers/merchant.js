import {
    DO_QUERY_MERCHANT_ITEMS_ACTION, DONE_QUERY_MERCHANT_ITEMS_ACTION,
    DO_QUERY_MERCHANT_TYPES_ACTION, DONE_QUERY_MERCHANT_TYPES_ACTION
} from '../actions/merchant';

export function doQueryMerchantItemsReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_MERCHANT_ITEMS_ACTION:
            return state;
        case DONE_QUERY_MERCHANT_ITEMS_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}

export function doQueryMerchantTypesReducer(state = {}, action) {
    switch (action.type) {
        case DO_QUERY_MERCHANT_TYPES_ACTION:
            return state;
        case DONE_QUERY_MERCHANT_TYPES_ACTION:
            return Object.assign({}, state, action.result);
        default:
            return state;
    }
}