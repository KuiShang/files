import React from 'react';
import intl from 'react-intl-universal';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import { doQueryTransferResultAction } from 'redux/actions/transfer';
import './index.scss';

class AutoDepositResultFragment extends React.Component {
    state = {
        params: this.props.params,
        isSuccess: false,
        isPending: false,
        isFailed: false
    }

    static getDerivedStateFromProps(props) {
        if (props.result && props.result.resultData) {
            if (props.result.resultData.transt === '00') {
                return {
                    isSuccess: true
                }
            }
        }
    }

    render() {
        const { isSuccess, isPending, isFailed } = this.state;

        return (
            <div className="deposit-account-result" style={{ margin: 0 }}>
                {isSuccess && <img alt='' src={require('assets/imgs/success/success.png')} />}
                {isSuccess &&
                    <div className="deposit-account-result-info">
                        <span>{intl.get('auto_deposit_result_success')}</span>
                    </div>
                }
                {isPending && <img alt='' src={require('assets/imgs/pending/pending.png')} />}
                {isPending &&
                    <div className="deposit-account-result-info">
                        <span>{intl.get('auto_deposit_result_pending')}</span>
                    </div>
                }
                {isFailed && <img alt='' src={require('assets/imgs/error/error.png')} />}
                {isFailed &&
                    <div className="deposit-account-result-info">
                        <span>{intl.get('auto_deposit_result_failed')}</span>
                    </div>
                }
                {(isSuccess || isPending) && <div className="ai-btn-primary actions" onClick={this.onBackToHome}>{intl.get('done')}</div>}
                {(isFailed) && <div className="ai-btn-primary actions" onClick={this.onTryAgain}>Try Again</div>}
                {(isFailed) && <div className="ai-btn-minor actions" onClick={this.onBackToHome}>{intl.get('done')}</div>}
            </div>
        )
    }

    /**
     * 根据的是风控的交易流水去查询的交易结果
     */
    componentDidMount() {
        const { params } = this.state; console.info(params);

        this.props.doQueryTransferResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
            qytype: params.qytype
        }, res => {
            //// SDK.showNativeLoading(false);
        })
    }

    onBackToHome = () => {
        hashHistory.push({ pathname: '/' });
    }

    onTryAgain = () => {
        hashHistory.push({ pathname: '/' });
    }
}

export default connect(function (state) {
    return {
        result: state.doQueryTransferResultReducer
    }
}, { doQueryTransferResultAction })(AutoDepositResultFragment)