import React from 'react';
import CardReview from 'components/card-review';
import CardSwitch from 'components/card-switch';
import './index.scss';

export default class BankAutoDepositFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            data: props.data,
            isSeDDA: props.isSeDDA || false,
            iseDDA: props.iseDDA || true,
            checkind: 0
        }
    }

    render() {
        const { checkind } = this.state;

        return (
            <div className="auto-deposit">
                <div className="auto-deposit-switch">
                    <CardSwitch options={['Active', 'Expired']}
                        checkind={checkind}
                        onSwitch={this.onSwitch}>
                    </CardSwitch>
                </div>
                <div className="auto-deposit-review">
                    <CardReview></CardReview>
                </div>
            </div>
        )
    }

    onSwitch = (index) => {
        this.setState({ checkind: index })
    }
}