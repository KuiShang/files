import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import intl from 'react-intl-universal';
import { doQuerySignEDDAResultAction } from 'redux/actions/edda';
import './index.scss';

/**
 * 签约结果页
 * 跳转到新建存款
 */
class SeDDAAccountResultFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            params: props.info
        }
    }

    /**
     * TODO:
     * 需区分成功、失败、待定
     */
    render() {
        return (
            <div className="deposit-account-result" style={{ margin: 0 }}>
                <img alt='' src={require('assets/imgs/sent/sent.png')} />
                <div>
                    {/* <div className="deposit-account-result-title">{intl.get('authorisation_pending')}</div> */}
                    <div className="deposit-account-result-info">
                        <span>{intl.get('sedda_sign_account_result_success')}</span>
                    </div>
                </div>
                <div className="ai-btn-primary" onClick={this.onGoSetAutoDeposit}>{intl.get('back_to_home')}</div>
            </div>
        )
    }

    componentDidMount() {
        const { params } = this.state;

        this.props.doQuerySignEDDAResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq
        }, res => {

        })
    }

    onGoSetAutoDeposit = () => {
        hashHistory.push({
            pathname: '/'
        })
    }
}

export default connect(function (state) {
    return {
        result: state.doQuerySignMerchantEDDAResultReducer
    }
}, { doQuerySignEDDAResultAction })(SeDDAAccountResultFragment)