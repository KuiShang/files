import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import DepositFromReceive from 'components/deposit-from-receive';
import Toast from 'components/toast';
import TextLabel from 'components/text-label';
import intl from 'react-intl-universal';
import { doGetAccountInfo3014Action } from 'redux/actions/account';
import { doSignImmedDepositEDDAAction } from 'redux/actions/edda';
import { doTransferWithPassRiskAction } from 'redux/actions/common';
import * as SDK from 'utils/SDKUtil';
import * as Mask from 'utils/MaskUtil';
import './index.scss';

class SeDDAAccountReviewFragment extends React.Component {
    constructor(props) {
        super(props);

        const info = props.info;
        this.state = {
            info,
            mobile: '',
            idNo: '',
        }
    }

    static getDerivedStateFromProps(props, state) {
        const { resultCode, resultData } = props.accountAllInfo;
        let { mobile, idNo } = state;
        if (resultCode === 1 && resultData) {
            const { list01, list03 } = resultData;

            list01 && list01.forEach(obj => {
                if (obj.doc_status === '1') {
                    idNo = obj.doc_no;
                    return;
                }
            })

            list03 && list03.forEach(obj => {
                if (obj.contact_method.indexOf('002') >= 0) {
                    mobile = `${obj.int_phone_area_code} ${Mask.maskMobile(obj.contact_content)}`;
                }
            })

            return {
                mobile,
                idNo
            }
        }
    }

    render() {
        const { info, mobile, idNo } = this.state;
        //// misdata...
        if (!info || !mobile || !idNo) {
            return <div className="misdata"></div>
        }

        return (
            <div className="edda-review">
                <CardReview>
                    <DepositFromReceive data={info}></DepositFromReceive>
                    <span className="edda-review-space"></span>
                    <div>
                        <TextLabel label={intl.get('account_holders_full_name')} value={(info && Mask.maskName(info.receive.accountName))}></TextLabel>
                    </div>
                    {/* <div>
                        <TextLabel label='ID Number' value={idNo}></TextLabel>
                    </div> */}
                    <div>
                        <TextLabel label={intl.get('mobile_number')} value={Mask.maskMobile(mobile)}></TextLabel>
                    </div>
                </CardReview>
                <div className="edda-review-action">
                    <div className="ai-btn-primary" onClick={this.onConfirmDepositAccount}>{intl.get('confirm')}</div>
                </div>
            </div>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get('review') });

        this.props.doGetAccountInfo3014Action({});
    }

    /**
     * 进行即时入金SeDDA签约
     */
    onConfirmDepositAccount = () => {
        const { info, idNo, mobile } = this.state;

        this.props.doSignImmedDepositEDDAAction({
            idcard: idNo,
            phonno: mobile,
            dbtNm: info.from.accountName,   //借记名称
            dbtAcctId: info.from.dbtAcctId,   //借记账号
            dbtAcctcd: info.from.type,   //借记账号类型
            dbtAgentMmbId: info.from.bankCode,   //借方银行代码
            cusId: info.from.cusId,
            crdNm: info.receive.accountName,   //贷记名称
            crdAcctId: info.receive.accountNo,   //贷记账号
            crdAcctcd: info.receive.type,   //贷记账号类型
        }, res => {
            this.onNativeVerify(res);
        })
    }

    /**
    * 根据过风控提示的核身方式进行校验，调用原生核身方式
    */
    onNativeVerify = (res, type) => {
        if (res.resultCode === 0 && res.resultData && res.resultData.body) {
            const goNativeData = res.resultData.body.actionData;
            this.goNativeCheck(goNativeData, (natRes) => {
                (natRes && natRes.outData && natRes.outData.businessNo) &&
                    this.onCheckRiskResult(res, natRes.outData.businessNo, type);
            });
        } else {
            alert(res.errorData.msg)
        }
    }

    /**
     * 将风控结果提交转账
     */
    onCheckRiskResult = (obj, businessNo, type) => {
        this.props.doTransferWithPassRiskAction({
            bizInfo: {
                trandt: obj.resultData.trandt,
                transq: obj.resultData.transq,
                busino: obj.resultData.busino,
            },
            securityResultData: {
                businessNo: businessNo,
            },
        }, res => {
            if (res.resultCode === 0) {
                Toast.show(res.errorData.msg);
            } else {
                hashHistory.push({
                    pathname: '/deposit-account-result',
                    state: {
                        chnldt: res.resultData.chnldt,
                        chnlsq: res.resultData.chnlsq
                    }
                })
            }
        });
    }

    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes)
    }
}

export default connect(function (state) {
    return {
        accountAllInfo: state.doGetAccountInfo3014Reducer
    };
}, { doSignImmedDepositEDDAAction, doTransferWithPassRiskAction, doGetAccountInfo3014Action })(SeDDAAccountReviewFragment)