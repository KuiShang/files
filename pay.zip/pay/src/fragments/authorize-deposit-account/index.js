import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardSwitch from 'components/card-switch';
import BankSelect from 'components/bank-select';
import BankInput from 'components/bank-input';
import FPSRegistered from 'components/fps-registered';
import PopOver from 'components/pop-over';
import Hint from 'components/modal-hint';
import Toast from 'components/toast';
import intl from 'react-intl-universal';
import { Base64 } from 'js-base64'
import * as SDK from 'utils/SDKUtil';
import * as Mask from 'utils/MaskUtil';
import { doGetAccountInfo3014Action } from 'redux/actions/account';
import { doQueryAllFPSInfoAction, doQueryCenterFPSInfoAction, doQueryFPSInfoAction, doQueryFPSRegisterInfoAction, doQueryFPSInfoLoopAction } from 'redux/actions/fps'
import './index.scss';

class DepositAccountFragment extends React.Component {
    constructor(props) {
        super(props);

        const info = props.info;
        this.state = {
            isFetching: true,
            isFetchingEmail: true,
            isFetchingMobile: true,
            info,
            account: props.account,
            registers: null,
            accountNum: '',
            accountHolder: '',
            bankAccount: null,
            showHint: false,
            checkind: 0,
            mobile: '',
            mobile_origin: '',
            email: '',
            email_origin: '',
            seddaEmail: [],
            seddaMobile: [],
            checkedType: 0,
            checkedAccount: null,
            disabledNext: true,
        }
    }

    static getDerivedStateFromProps(props, state) {
        let { mobile, email, mobile_origin, email_origin } = state;

        if (props.accountInfo) {
            const { resultCode, resultData } = props.accountInfo;
            if (resultCode === 1 && resultData) {
                const { list03 } = resultData;
                list03 && list03.forEach(obj => {
                    if (obj.contact_method.includes('002')) {
                        mobile = `${obj.int_phone_area_code} ${Mask.maskMobile(obj.contact_content)}`;
                        mobile_origin = `${obj.int_phone_area_code}-${obj.contact_content}`;
                    } else if (obj.contact_method.includes('010')) {
                        email = Mask.maskEmail(obj.contact_content);
                        email_origin = obj.contact_content;
                    }
                })
            }
        }

        return {
            account: props.account,
            mobile,
            email,
            mobile_origin,
            email_origin
        }
    }

    /**
     * 如果没有数据默认是选择Account Number项
     * 
     * Quering EMAIL/MOBILE FPS registered info.
     */
    render() {
        const { checkind, showHint, isFetchingEmail, isFetchingMobile, continueBtnUnClick } = this.state;

        //// Quering data...
        if (isFetchingEmail || isFetchingMobile) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        return (
            <div className="deposit-account">
                <CardSwitch options={[intl.get('fps_registered'), intl.get('by_account_no')]}
                    checkind={checkind}
                    onSwitch={this.onSwitch}>
                </CardSwitch>
                {checkind === 0 && this.renderRegistered()}
                {checkind === 1 && this.renderBankAccount()}
                {
                    showHint &&
                    <PopOver title={intl.get('tips')} visible={showHint}
                        onShow={() => this.setState({ showHint: !this.state.showHint })} >
                        <Hint></Hint>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * Option 1: 没有FPS注册信息
     * Option 2: 有FPS注册的信息
     */
    renderRegistered = () => {
        const { email, mobile, seddaEmail, seddaMobile, checkedType, checkedAccount } = this.state;
        if ((!seddaEmail || seddaEmail.length <= 0) && (!seddaMobile || seddaMobile.length <= 0)) {
            return (
                <div className="deposit-account-no-fps">
                    <img alt="" src={require('assets/imgs/nocontent/nocontent.png')} />
                    <div className="deposit-account-no-fps-title">{intl.get('no_account_is_linked_via_fps')}</div>
                    <div className="deposit-account-no-fps-info">
                        <span>{intl.get('no_account_is_linked_via_fps_tip')}</span>
                    </div>
                </div>
            )
        } else {
            return (
                <React.Fragment>
                    <FPSRegistered
                        checkedType={checkedType}
                        checkedAccount={checkedAccount}
                        email={email} mobile={mobile}
                        seddaEmail={seddaEmail}
                        seddaMobile={seddaMobile}
                        onCheckAccount={(type, account) => this.onCheckAccount(type, account)}>
                    </FPSRegistered>
                    <div className="deposit-account-row">
                        <div style={{ margin: '27px 0' }}>
                            {intl.get('notice_content')}
                            <span style={{ color: 'blue' }} onClick={() => { this.getNoticeContent() }}>
                                {intl.get("notice_content_keywords")}
                            </span>
                            {intl.get("notice_content_end")}
                        </div>
                    </div>
                    <p>{intl.get("sedda_sign_account_number_tip")}</p>
                    <div className="ai-btn-primary" onClick={this.onNext}>{intl.get('continue')}</div>
                </React.Fragment>

            )
        }
    }

    renderBankAccount = () => {
        const { disabledNext, account, accountNum, bankAccount, showHint } = this.state;

        return (
            <React.Fragment>
                <div className="deposit-account-row">
                    <div className="deposit-account-tip">{intl.get('deposit_account_deposit_from')}</div>
                    <BankSelect bankAccount={bankAccount} onSelectBank={this.onSelectBank}></BankSelect>
                </div>
                <div className="deposit-account-row">
                    <div className="deposit-account-tip">
                        {intl.get('deposit_account_bank_account_details')}
                        <span className="ai-btn-edit"
                            onClick={() => this.setState({ showHint: !showHint })}>{intl.get('tips')}</span>
                    </div>
                    <BankInput
                        accountNum={accountNum}
                        bankAccount={bankAccount}
                        onChangeAccountNum={this.onChangeAccountNum}>
                    </BankInput>
                    <div className="deposit-account-bank">
                        <span className="deposit-account-bank-full">{intl.get('account_holders_full_name')}</span>
                        <span className="deposit-account-bank-full-name">{Mask.maskName(account.acct_name)}</span>
                    </div>
                </div>
                <div className="deposit-account-row">
                    <div style={{ margin: '27px 0' }}>
                        {intl.get('notice_content')}
                        <span style={{ color: 'blue' }} onClick={() => { this.getNoticeContent() }}>
                            {intl.get("notice_content_keywords")}
                        </span>
                        {intl.get("notice_content_end")}
                    </div>
                </div>
                <p>{intl.get("sedda_sign_account_number_tip")}</p>
                <div className="ai-btn-primary" disabled={disabledNext} onClick={this.onNext}>{intl.get('continue')}</div>
            </React.Fragment>
        )
    }

    /**
     * TODO：逻辑中包含对于查询FPS的多次异步调用问题，后续需要进行逻辑代码优化；
     * 
     * Step 1: 获取用户信息（身份证号/电话）
     * Step 2: 查询支付系统存储的FPS登记信息，给出结果是否去FPS中心查询信息；
     * Step 3: 去FPS查询信息，根据返回状态（sendSuc表明发送成功）;
     * 
     * Option 1: initial-初始化
     * Option 2: sendSuc-发送成功
     * Option 3: sendFail-发送失败
     * 
     * Option 4: fpsAcct-FPS接受
     * Option 5: fpsRjcj-FPS拒绝
     * 
     * 默认选中手机号的第一个对应登记信息
     */
    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get('set_direct_deposit') });
        this.props.doGetAccountInfo3014Action({})

        this.props.doQueryAllFPSInfoAction({ proxTp: 'EMAL', isedda: 'Y' }, res => {
            if (res.resultCode === 1) {
                const email = res.resultData.proxId;
                if (res.resultData.result === 'Y') {
                    let c = 1
                    this.onQueryFPSCenter(res, 'email', email, c);
                } else {
                    const temp = res.resultData.registerList;
                    this.setState({
                        email, seddaEmail: temp,
                        isFetchingEmail: false,
                    })
                }
            }
        })

        this.props.doQueryAllFPSInfoAction({ proxTp: 'MOBN', isedda: 'Y' }, res => {
            if (res.resultCode === 1) {
                const mobile = res.resultData.proxId;
                if (res.resultData.result === 'Y') {
                    let a = 1;
                    this.onQueryFPSCenter(res, 'mobile', mobile, a);
                } else {
                    const temp = res.resultData.registerList;

                    this.setState({
                        mobile, checkedAccount: res.resultData.registerList[0],
                        seddaMobile: temp,
                        isFetchingMobile: false,
                    })
                }
            }
        })
    }

    /**
     * 查看协议 详情
     */
    getNoticeContent = () => {
        const base_href = Base64.encode(`No=FPSRegistration_001&Ver=20190821_1.0&type=1`);
        const url = `${window.location.origin}/public/protocol.html#/detailProtocol?${base_href}`;
        SDK.goNativeWebview(url, (res) => {
            if (res.code === 1) {
                console.info("查看协议")
            }
        });
    }

    /**
     * Account No
     * 只支持数字、英文，字符长度8-16
     */
    onChangeAccountNum = (num) => {
        //账户号码只能输入数字
        num = num.replace(/[^0-9]+/, '');
        const { bankAccount } = this.state;
        //预约自动存款页面的'下一步'按钮置灰与否判断
        //预约自动取款页面账户号码输入值低于8个字符，按钮置灰且不可点击
        //超过8位字符按钮被激活且可进行点击操作
        if (num.length >= 8 && bankAccount) {
            this.setState({ disabledNext: false, accountNum: num })
        } else {
            this.setState({ disabledNext: true, accountNum: num })
        }
    }

    /**
     * 修改Account Holder Full Name
     * @param {*} pn 
     * @param {*} json 
     */
    onHandleAccountFullName(pn, json) {
        const accountHolder = json.value.isOnlyEnglish();
        if (accountHolder.split("").length > 25) {
            return;
        }

        this.setState({ accountHolder });
    }

    /**
     * 选择银行
     */
    onSelectBank = () => {
        const url = `${window.location.origin}/pay/bank-code.html`;

        SDK.goNativeWebview(url, (res) => {
            if (res.code === 1) {
                const { accountNum } = this.state;
                if (!accountNum || accountNum === "" || accountNum.split("").length < 8) {
                    this.setState({ bankAccount: res.data.outData, disabledNext: true })
                } else {
                    this.setState({ bankAccount: res.data.outData, disabledNext: false })
                }
            }
        });
    }

    onCheckAccount = (checkedType, checkedAccount) => {
        this.setState({ checkedType, checkedAccount })
    }

    onSwitch = (index) => {
        this.setState({ checkind: index })
    }

    /**
     * TODO 处理逻辑需要进行优化，对于Mobile、Email的setState进行修改
     * 轮询查询FPS中心注册信息
     * 上限请求三次
     * 
     * Option 1: initial-初始化
     * Option 2: sendSuc-发送成功
     * Option 3: sendFail-发送失败
     * 
     * Option 4: fpsAcct-FPS接受
     * Option 5: fpsRjcj-FPS拒绝
     * 
     */
    onQueryFPSCenter = (res, key, value, count) => {
        if (count > 3) {
            const { seddaEmail, seddaMobile } = this.state;
            if (seddaEmail.length <= 0 && seddaMobile.length <= 0) {
                this.setState({ checkind: 1, isFetching: false, isFetchingEmail: false, isFetchingMobile: false })
            } else {
                this.setState({ isFetching: false, isFetchingEmail: false, isFetchingMobile: false })
            }

            return;
        }

        this.props.doQueryCenterFPSInfoAction({
            inchdt: res.resultData.chnldt,
            inchsq: res.resultData.chnlsq
        }, resp => {
            const { resultCode, resultData } = resp;
            if (resultCode !== 1) {
                return;
            }
            //// 轮询状态(2秒一循环)
            if (resultData.addrtranst === 'sendSuc' || resultData.addrtranst === 'initial') {
                setTimeout(() => { this.onQueryFPSCenter(res, key, value, ++count); }, 2000);
            }
            //// 成功
            else if (resultData.addrtranst === 'fpsAcct') {
                (key === 'mobile' && this.setState({
                    isFetching: false,
                    isFetchingMobile: false,
                    mobile: value, seddaMobile: resultData.registerList,
                    checkind: (resultData.registerList.length <= 0 && this.state.seddaEmail.length <= 0) ? 1 : 0
                }));

                (key === 'email' && this.setState({
                    isFetching: false,
                    isFetchingEmail: false,
                    email: value, seddaEmail: resultData.registerList,
                    checkind: (resultData.registerList.length <= 0 && this.state.seddaMobile.length <= 0) ? 1 : 0
                }));
            }
            //// 失败
            else if (resultData.addrtranst === 'sendFail' || resultData.addrtranst === 'fpsRjcj') {
                (key === 'mobile' && this.setState({
                    isFetching: false,
                    isFetchingMobile: false,
                    mobile: value, seddaMobile: [],
                    checkind: (this.state.seddaEmail.length <= 0) ? 1 : 0
                }));
                (key === 'email' && this.setState({
                    isFetching: false,
                    isFetchingEmail: false,
                    email: value, seddaEmail: [],
                    checkind: (this.state.seddaMobile.length <= 0) ? 1 : 0
                }));
            }
        })
    }

    onQueryFPSRegisterInfo = (res, count, callback) => {
        if (count > 3) {
            return;
        }

        this.props.doQueryFPSInfoLoopAction({
            chnldt: res.resultData.chnldt,
            chnlsq: res.resultData.chnlsq
        }, resp => {
            const { resultCode, resultData } = resp;

            //// 查询失败
            if (resultCode === 1 && (resultData.addrtranst === 'sendFail' || resultData.addrtranst === 'fpsRjcj')) {
                this.setState({ isQuering: false, showTips: true, disabled: true })
            }
            //// 轮询3次查询结果
            else if (resultCode === 1 && (resultData.addrtranst === 'initial' || resultData.addrtranst === 'recvFps' || resultData.addrtranst === 'sendSuc')) {
                setTimeout(() => { this.onQueryFPSRegisterInfo(res, ++count, callback) }, 2000)
            }
            //// 查询到结果
            else if (resultCode === 1 && resultData.addrtranst === 'fpsAcct') {
                callback && callback(resp);
            } else if (resultCode === 0) {
                Toast.show('查询FPS账号操作失败')
            } else {
                Toast.show('系统出错')
            }
        })
    }

    /**
     * 如果是选择的FPS注册账号，则应该去查询账户信息。
     * 如果是手动输入相关的银行信息，则不需要去查询信息
     * Option 1: checkind === 0 选择FPS的注册账号 
     * Option 2: checkind === 1 手动输入银行信息
     * 
     * Step 1: 根据选择的账户信息,获取相应的FPS流水信息
     * Step 2: 根据FPS返回流水，轮询查询完整的账户信息
     *         Option 1: 'sendSuc' 'initial' 'recvFps' 需要轮询
     *         Option 2: 'sendFail' 'fpsRjct' 查询失败
     *         Option 3: 'fpsAcct' 查询成功
     */
    onNext = () => {
        const { disabledNext, checkind, checkedType, checkedAccount, email_origin, mobile_origin } = this.state;
        if (checkind === 1 && disabledNext) {
            return;
        }

        if (checkind === 0) {
            const params = {
                proxId: checkedType === 0 ? mobile_origin : email_origin,
                proxTp: checkedType === 0 ? 'MOBN' : 'EMAL',
                bankcd: checkedAccount.agent_MmbId
            }

            this.props.doQueryFPSInfoAction(params, res => {
                if (res.resultCode === 1) {
                    this.onQueryFPSRegisterInfo(res, 1, (resp) => {
                        const { info, account, accountNum, bankAccount, checkind } = this.state;
                        const bankName = (checkind === 0) ? checkedAccount.partnm : (bankAccount && bankAccount.bank_en_name || '');
                        const bankCode = (checkind === 0) ? checkedAccount.agent_MmbId : (bankAccount && bankAccount.bank_code);
                        const bankNo = checkind === 0 ? resp.resultData.cusId : accountNum;
                        hashHistory.push({
                            pathname: '/deposit-account-review', state: {
                                from: {
                                    accountName: account.acct_name,
                                    type: params.proxTp,
                                    bankName,
                                    bankCode,
                                    bankNo,
                                    dbtAcctId: params.proxId,
                                    cusId: resp.resultData.cusId,
                                    fullNm_en: resp.resultData.fullNm_en
                                },
                                receive: {
                                    type: 'BBAN',
                                    accountName: (info && info.receive && info.receive.accountName) || account.acct_name,
                                    accountNo: (info && info.receive && info.receive.accountNo) || account.acct_no,
                                }
                            }
                        })
                    });
                } else if (res.resultCode === 0) {
                    Toast.show(res.errorData.msg);
                }
            });
        } else if (checkind === 1) {
            const { info, account, accountNum, bankAccount, checkind, checkedType, checkedAccount } = this.state;
            const bankName = (checkind === 0) ? checkedAccount.partnm : (bankAccount && bankAccount.bank_en_name || '');
            const bankCode = (checkind === 0) ? checkedAccount.agent_MmbId : (bankAccount && bankAccount.bank_code);
            const bankNo = checkind === 0 ? checkedAccount.cusId : accountNum;
            hashHistory.push({
                pathname: '/deposit-account-review', state: {
                    from: {
                        accountName: account.acct_name,
                        type: 'BBAN',
                        bankName,
                        bankCode,
                        bankNo,
                        dbtAcctId: accountNum
                    },
                    receive: {
                        type: 'BBAN',
                        accountName: (info && info.receive && info.receive.accountName) || account.acct_name,
                        accountNo: (info && info.receive && info.receive.accountNo) || account.acct_no,
                    }
                }
            })
        }
    }
}

export default connect(function (state) {
    return {
        accountInfo: state.doGetAccountInfo3014Reducer,
    }
}, {
        doGetAccountInfo3014Action, doQueryAllFPSInfoAction, doQueryCenterFPSInfoAction,
        doQueryFPSInfoAction, doQueryFPSRegisterInfoAction, doQueryFPSInfoLoopAction
    })(DepositAccountFragment)