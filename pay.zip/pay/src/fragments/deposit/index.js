import React from 'react';
import { hashHistory } from 'react-router';
import { connect } from 'react-redux';
import CardReview from 'components/card-review';
import DepositFrom from 'components/deposit-from';
import DepositFromItems from 'components/deposit-from-items';
import DepositAmount from 'components/deposit-amount';
import CardSwitch from 'components/card-switch';
import TextField from 'components/text-field';
import SelectCalendar from 'components/select-calendar';
import SelectFrequency from 'components/select-frequency';
import SelectField from 'components/select-field';
import PopOver from 'components/pop-over';
import DialogSeDDAPendingTip from 'components/dialog-sedda-pending-tip';
import DatePicker from 'components/date-picker';
import ExpiryDatePicker from 'components/expiry-date-picker';
import FrequencyPicker from 'components/frequency-picker';
import Toast from 'components/toast';
import Info from './Info';
import { doQueryEddaAction } from 'redux/actions/edda';
import intl from 'react-intl-universal';
import './index.scss';
import imgTip from 'assets/imgs/edda/edda.svg';

class DepositFragment extends React.Component {
    constructor(props) {
        super(props);

        const now = new Date();
        const nowT1 = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
        const account = props.account;
        const info = props.info;

        this.state = {
            info,
            account,
            showInfo: false,
            showDepositDate: false,
            showFrequency: false,
            showExpiryDate: false,
            showDepositFromItems: false,
            showSeDDAPendingTip: false,
            noSeDDABankAccounts: false,
            checkind: 0,
            amount: 0,
            remarks: '',
            depositDate: nowT1,
            frequency: {
                key: 'monthly',
                label: 'once_every_month',
                value: 'monthly'
            },
            expiry: {
                key: 'never',
                value: intl.get('no_end_date')
            },
            depositAccount: null,
            eddas: [],
            maxDateTimeIndex: ''
        }
    }

    static getDerivedStateFromProps(props) {
        if (props.eddas.resultCode === 1) {
            return {
                eddas: props.eddas.resultData.edda_relation
            }
        }
    }

    render() {
        const { noSeDDABankAccounts, eddas, frequency, expiry, depositDate, depositAccount, checkind, showInfo, showSeDDAPendingTip, showDepositFromItems, showFrequency, showExpiryDate, showDepositDate, amount, remarks } = this.state;

        if (noSeDDABankAccounts) {
            return this.renderNoSeDDABankAccounts();
        }

        return (
            <div className="deposit">
                <div className="deposit-row">
                    <DepositFrom data={depositAccount} onShowDepositAccount={this.onShowDepositAccount}></DepositFrom>
                </div>
                <div className="deposit-row">
                    <CardReview>
                        <DepositAmount amount={amount} onChangeAmount={this.onChangeAmount}></DepositAmount>
                    </CardReview>
                </div>
                <div className="deposit-row">
                    <CardReview>
                        <CardSwitch checkind={checkind} title={intl.get('how_frequent')}
                            options={[intl.get('one_off'), intl.get('recurring')]}
                            onSwitch={this.onSwitch}>
                        </CardSwitch>
                    </CardReview>
                </div>
                {checkind === 1 && this.renderAutoDeposit()}
                <div className="deposit-row">
                    <TextField
                        propValue={{
                            placeHolder: `${intl.get('remark')} (${intl.get('optional')})`,
                            value: remarks
                        }}
                        stateName={'remarks'}
                        setCurrentInputData={this.onChangeMark.bind(this)}>
                    </TextField>
                </div>
                <div>
                    <div disabled={(depositAccount && depositAccount.eddaStatus !== "binding") ? false : true} className="ai-btn-primary" onClick={() => this.onReview()}>{intl.get('continue')}</div>
                </div>
                {
                    showSeDDAPendingTip &&
                    <PopOver isDialog={true} visible={showSeDDAPendingTip}
                        onShow={() => this.setState({ showSeDDAPendingTip: !showSeDDAPendingTip })}>
                        <DialogSeDDAPendingTip onOkay={() => this.onReview()}>
                        </DialogSeDDAPendingTip>
                    </PopOver>
                }
                {
                    showDepositFromItems &&
                    <PopOver title={intl.get('deposit_from')} titleDone={intl.get('done')} visible={showDepositFromItems}
                        onShow={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}
                        onDone={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}>
                        <DepositFromItems checkedItem={depositAccount} data={eddas}
                            onNewBankAccount={this.onNewBankAccount}
                            onSelectDepositAccount={this.onSelectDepositAccount}>
                        </DepositFromItems>
                    </PopOver>
                }
                {
                    showDepositDate &&
                    <PopOver title={intl.get('set_start_date')} titleDone={intl.get('done')} visible={showDepositDate}
                        onShow={() => this.setState({ showDepositDate: !this.state.showDepositDate })}
                        onDone={() => this.setState({ showDepositDate: !this.state.showDepositDate })}>
                        <DatePicker date={depositDate}
                            onSelectDate={this.onSelectDepositDate}></DatePicker>
                    </PopOver>
                }
                {
                    showFrequency &&
                    <PopOver title={intl.get('deposit_frequency')} titleDone={intl.get('done')} visible={showFrequency}
                        onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
                        onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
                        <FrequencyPicker
                            isSeDDA={true}
                            data={frequency}
                            onSelectFrequency={this.onSelectFrequency}>
                        </FrequencyPicker>
                    </PopOver>
                }
                {
                    showExpiryDate &&
                    <PopOver title={intl.get('set_end_date')} titleDone={intl.get('done')} visible={showExpiryDate}
                        onShow={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}
                        onDone={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}>
                        <ExpiryDatePicker
                            expiry={expiry}
                            max={12}
                            onSelectExpiryDate={this.onSelectExpiryDate}>
                        </ExpiryDatePicker>
                    </PopOver>
                }
                {
                    showInfo &&
                    <Info visible={showInfo} onOK={() => this.setState({ showInfo: !showInfo })}></Info>
                }
            </div>
        )
    }

    /**
     * 无主动付款授权记录
     * Option 1: SeDDA
     */
    renderNoSeDDABankAccounts = () => {
        return (
            <div className="edda-no-items">
                <img alt="" src={imgTip} />
                <div className="edda-no-items-title">{intl.get('direct_deposit')}</div>
                <div className="edda-no-items-con">
                    <span>
                        <label>{intl.get('direct_deposit_collect_tips')}</label>
                    </span>
                    <span>
                        <label>{intl.get('direct_deposit_under_hkma')}</label>
                    </span>
                </div>
                <div className="ai-btn-primary" onClick={this.onSetupSeDDABankAccount}>{intl.get('set_up_immediate')}</div>
            </div>
        )
    }

    renderAutoDeposit = () => {
        const { showDepositDate, frequency, depositDate, expiry } = this.state;
        let expiryValue = expiry.value;
        if (expiry.key === 'ondate' && expiry.value !== undefined) {
            expiryValue = expiry.value.toLocaleDateString('zh-CN');
        } else if (expiry.key === 'never') {
            expiryValue = intl.get('no_end_date');
        } else if (expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiry.value} ${intl.get('times')}`
        }

        return (
            <React.Fragment>
                <div className="deposit-row">
                    <SelectCalendar title={intl.get('start_date')} value={depositDate}
                        onSelect={() => this.setState({ showDepositDate: !showDepositDate })}>
                    </SelectCalendar>
                </div>
                <div className="deposit-row">
                    <SelectFrequency title={intl.get('deposit_frequent')} value={frequency.label}
                        onSelect={() => this.setState({ showFrequency: true, title: intl.get('frequency') })}>
                    </SelectFrequency>
                </div>
                {
                    frequency.key !== 'specialdate' &&
                    <div className="deposit-row">
                        <SelectField title={intl.get('end_date')} value={expiryValue}
                            onSelect={() => this.setState({ showExpiryDate: true, title: '' })}>
                        </SelectField>
                    </div>
                }

            </React.Fragment>
        )
    }

    getMax(array) {
        var max = undefined;
        for (var i = 0; i < array.length; i++) {
            max = max === undefined ? Number(array[i]) : (max > Number(array[i]) ? max : Number(array[i]))
        }
        return max;
    }

    searchNewDataIndex(data) {
        //遍历data，将data中的creDtTm值遍历出来组成一个数组dateTimeArr
        const dateTimeArr = [];
        for (var i = 0; i < data.length; i++) {
            if (data[i].eddaStatus === 'bindsuc') {
                dateTimeArr.push(data[i].creDtTm)
            }
        }

        // 如果全是Pending状态的话，默认选中第一个
        if (dateTimeArr.length === 0) {
            return 0;
        }

        //取出数组dateTimeArr中的最大值
        const maxDateTime = this.getMax(dateTimeArr);

        //遍历通过时间的最大值取出数组中对应的值的下标
        var maxDateTimeIndex = '';
        for (var j = 0; j < data.length; j++) {
            if (data[j].creDtTm == maxDateTime) {
                maxDateTimeIndex = j;
            }
        }

        //返回对应的下标
        return maxDateTimeIndex;
    }

    /**
     * 查询有效的SeDDA信息
     */
    componentDidMount() {
        this.props.doQueryEddaAction({ signtp: 'deposit', eddaStu: 'Effective' }, res => {
            if (res.resultCode === 1 && res.resultData && res.resultData.edda_relation.length > 0) {
                const data = res.resultData.edda_relation;
                //获取最新值的下标
                const maxIndex = this.searchNewDataIndex(data);
                //渠道最新的值
                this.setState({ depositAccount: res.resultData.edda_relation[maxIndex] })
            } else {
                this.setState({ noSeDDABankAccounts: true })
            }
        })
    }

    onSwitch = (checkind) => {
        this.setState({ checkind })
    }

    onShowDepositAccount = () => {
        this.setState({ showDepositFromItems: !this.state.showDepositFromItems })
    }

    onChangeAmount = (amount) => {
        this.setState({ amount });
    }

    onChangeMark = (pn, json) => {
        if (json.value.split('').length > 50) {
            return;
        }

        this.setState({ remarks: json.value })
    }

    /**
     * 选择周期
     */
    onSelectFrequency = (item) => {
        this.setState({ showFrequency: false, frequency: item })
    }

    onSelectExpiryDate = (expiry) => {
        this.setState({ expiry });
    }

    onSelectDepositDate = (date) => {
        this.setState({ depositDate: date })
    }

    /**
     * 选择付款账号{
     */
    onSelectDepositAccount = (depositAccount) => {
        this.setState({ depositAccount })
    }

    /**
     * 进入SeDDA银行账户绑定流程
     */
    onSetupSeDDABankAccount = () => {
        const { account } = this.state;

        hashHistory.push({
            pathname: '/deposit-account', state: {
                from: {
                    accountName: '',
                    accountNo: '',
                    type: 'BBAN',
                    bankCode: ''
                },
                receive: {
                    accountName: account.acct_name,
                    accountNo: account.acct_no,
                    idNo: '',
                    phone: '',
                    type: 'BBAN',
                }
            }
        })
    }

    /**
     * Step 1: 前端校验SeDDA授权状态是否为Pending，若是则展示提示弹窗
     * Step 2: 步骤一合规后跳转到Review
     */
    onReview = () => {
        const { amount, checkind, account, depositAccount, depositDate, frequency, expiry, remarks } = this.state;

        if (depositAccount.eddaStatus === "binding") {
            return;
        }

        //// 存款金额必须大于0
        if (amount <= 0) {
            Toast.show('转账金额必须大于0')
            return;
        }

        //// 定时存款开始日期必须大于等于T+1
        //// 定时存款结束日期必须大于开始日期
        if (checkind === 1) {
            const now = new Date();
            if (depositDate <= now) {
                Toast.show('开始日期必须大于等于T+1')
                return;
            }

            if (frequency.key !== 'specialdate' && expiry.key === 'ondate' && expiry.value < depositDate) {
                Toast.show('结束日期必须大于等于开始日期')
                return;
            }
        }

        if (depositAccount && depositAccount.eddaStatus !== 'bindsuc' && !this.state.showSeDDAPendingTip) {
            this.setState({ showSeDDAPendingTip: true });
            return;
        }

        hashHistory.push({
            pathname: '/review',
            state: {
                from: {
                    accountName: depositAccount.dbtNm,
                    accountNo: account.acct_no,
                    bankName: (depositAccount && depositAccount.dbtMmbNa),
                    bankCode: (depositAccount && depositAccount.dbtMmbId),
                    bankNo: (depositAccount && depositAccount.dbtAcctId),
                    dbtAcctCd: (depositAccount && depositAccount.dbtAcctCd),
                },
                receive: {
                    accountName: account.acct_name,
                    accountNo: account.acct_no,
                    bankName: (depositAccount && depositAccount.crdMmbNa),
                    bankCode: (depositAccount && depositAccount.crdMmbId),
                    bankNo: (depositAccount && depositAccount.crdAcctId)
                },
                pay: {
                    isNow: checkind,
                    amount,
                    startDate: depositDate,
                    frequency,
                    expiry,
                    remarks
                }
            }
        })
    }

    /**
     * 跳转到SeDDA账户授权页面
     */
    onNewBankAccount = () => {
        hashHistory.push({
            pathname: '/deposit-account'
        })
    }
}

export default connect(function (state) {
    return {
        eddas: state.doQueryEddaReducer
    }
}, { doQueryEddaAction })(DepositFragment);