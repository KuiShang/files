import React from 'react';
import PopOver from 'components/pop-over';
import * as SDK from 'utils/SDKUtil';

export default class Info extends React.Component {
    state = {
        visible: this.props.visible
    }

    static getDerivedStateFromProps(props) {
        return {
            visible: props.visible
        }
    }

    render() {
        const { visible } = this.state;

        return (
            <PopOver isDialog={true} visible={visible}
                onDone={() => this.props.onOK()}
                onShow={() => this.props.onOK()}>
                <div className="deposit-info">
                    <img alt="" src={require('assets/imgs/pending/pending.png')} />
                    <div className="deposit-info-title">
                        <span>This Bank has been pending </span>
                        <span>Authorization</span>
                    </div>
                    <div className="deposit-info-detail">
                        <span>Authorization requires 3-5 business</span>
                        <span>days. Deposit will be actived once</span>
                        <span>authorization successed.</span>
                    </div>
                    <div className="deposit-info-detail">
                        <span>Note: You may miss the first deposit if </span>
                        <span>authorization hasn't been success.</span>
                    </div>
                    <div className="ai-btn-primary" onClick={() => this.props.onOK()}>Okay</div>
                </div>
            </PopOver>
        )
    }
}