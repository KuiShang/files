import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import ReviewFromTo from 'components/review-from-to';
import ReviewPaymentDetail from 'components/review-payment-detail';
import Checkbox from 'components/checkbox';
import CollapseDetail from 'components/collapse-detail';
import TextField from 'components/text-field';
import Toast from 'components/toast';
import { doQueryPayeesAction, doAddPayeeAction } from 'redux/actions/payee';
import {
    doCheckRiskControlBeforeTransferWithImmedAction, doCheckRiskControlBeforeTransferWithAppointAction,
    doTransferWithTimingAction, doTransferWithPassRiskAction
} from 'redux/actions/common';
import { doTransferRemittanceAction, } from 'redux/actions/transfer';
import * as SDK from 'utils/SDKUtil';
import * as Constants from 'utils/ConstantsUtil';
import intl from 'react-intl-universal';
import './index.scss';

class ReviewFragment extends React.Component {
    constructor(props) {
        super(props);

        const data = SDK.getCache(Constants.TRANSFER_INFO);

        this.state = {
            test: '',
            data,
            showAddAction: true,
            showAdd: false,
            showNotice: false,
            info: props.info,
            displayName: props.info.to.payeeName || '',
            isShowState: false // 控制dialog
        }
    }

    isTransferring = false

    render() {
        const { showAddAction, showAdd, showNotice, info, data, displayName } = this.state;

        return (
            <div className="review">
                <CardReview>
                    <ReviewFromTo info={info} data={data} onEdit={this.onEditFromTo}></ReviewFromTo>
                </CardReview>
                <div style={{ height: 24 }}></div>
                <CardReview>
                    <ReviewPaymentDetail info={info} data={data} onEdit={this.onEditPayment}></ReviewPaymentDetail>
                </CardReview>
                <div style={{ height: 24 }}></div>
                {
                    showAddAction &&
                    <CardReview>
                        <Checkbox checked={showAdd} onChecked={(e) => this.setState({ showAdd: e })}>{intl.get("add_to_friend_list")}</Checkbox>
                        <div style={{ padding: '10px 0 0 0', display: (showAdd ? "" : "none") }}>
                            <TextField
                                requireInputMessage=''
                                propValue={{
                                    hasRequiredMessage: true,
                                    regExp: /^[a-zA-Z]{1,25}$/,
                                    // regExp: /^[a-zA-Z\u4e00-\u9fa5]{0,25}$/,
                                    regExpMessgae: 'Error',
                                    isPass: false,
                                    value: displayName,
                                    placeHolder: intl.get("contact_nick_name")
                                }}
                                stateName={'displayName'}
                                setCurrentInputData={this.onHandleDisplayName.bind(this)}>
                            </TextField>
                        </div>
                    </CardReview>
                }
                <div>
                    <CollapseDetail title={intl.get('important_notice')} onCollapse={(e) => this.setState({ showNotice: !e })}></CollapseDetail>
                    <div className="review-notice" style={{ display: (showNotice ? "" : "none") }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </div>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onTransfer}>{intl.get('confirm')}</button>
                    <button onClick={() => this.onCheckDiaglog(true)} className="ai-btn-cancel">{intl.get('cancel')}</button>
                </div>
                {/* 新增的diglog */}
                <div className={`tel-dialog ${this.state.isShowState === true ? 'actived' : ''} `}>
                    <section className={`content ${this.state.isShowState === true ? 'popIn' : ''} `}>
                        <div className="tel-msg">{intl.get("cancel_transfer")}</div>
                        <div className="handle">
                            <p className="sure" onClick={() => this.onDiaglogResult(true)}>{intl.get('yes')}</p>
                            <p className="cancel" onClick={() => this.onDiaglogResult(false)}>{intl.get('no')}</p>
                        </div>
                    </section>
                </div>
            </div>
        )
    }

    componentDidMount() {
        //// 收款人是否已经添加为收款人或者收款人是否达到上限30人
        this.props.doQueryPayeesAction({}, res => {
            const { info } = this.state;

            const temp = res.resultData.name_list.filter(item => {
                return item.inactp === info.to.transferType && item.pyacct === info.to.number
            });

            if (res.resultData.name_list && (res.resultData.name_list.length >= 30 || temp.length > 0)) {
                this.setState({ showAddAction: false });
            } else {
                this.setState({ showAddAction: true });
            }
        });
    }

    onHandleDisplayName = (pn, json) => {
        if (json.value.split("").length > 25) {
            return false;
        }

        this.setState({ displayName: json.value })
    }

    onEditFromTo = () => {
        let { info } = this.state;
        info.from['isEdit'] = true;
        hashHistory.push({ pathname: '/', state: info })
    }

    onEditPayment = () => {
        let { info } = this.state;
        info.from['isEdit'] = true;
        hashHistory.push({ pathname: '/instructions', state: info })
    }

    /**
     * Option 1: 即时转账
     * Option 2: 预约转账
     * 
     * Step 1: 获取风控方式
     * Step 2: 提交风控结果
     */
    onTransfer = () => {
        if (this.isTransferring) {
            return;
        }

        this.isTransferring = true;
        const { info } = this.state;
        this.onCheckRisk(info);
    }

    /**
     * 转账过风控
     * 
     * Option 1: 0-即时转账
     * Option 2: 1-预约转账
     * 
     * 预约转账 T+1
     */
    onCheckRisk = (obj) => {
        const { displayName } = this.state;
        if (obj.pay.isNow === 0) {
            this.props.doCheckRiskControlBeforeTransferWithImmedAction({
                instdAmt: obj.pay.amount,
                pyform: displayName,
                instdCcy: 'HKD',
                dbtNm: obj.from.accountName, //付款方姓名
                dbtAcctId: obj.from.accountNo, //付款方账户ID
                dbtAcctCd: 'BBAN',
                isRegPayee: this.state.showAdd ? "1" : "0",
                crdNm: obj.to.alias, //收款方姓名
                crdAcctId: obj.to.number, //收款方账户号（手机号、Email、FPS、Account No）
                crdAcctCd: obj.to.transferType, //收款方账户类型
                crdAcctNo: obj.to.bankAccountNo, //收款方银行账号
                crdBankCode: obj.to.bankCode, //收款方银行代码
                ustrd: obj.pay.remarks
            }, res => {
                this.onNativeVerify(res, 0);
            })
        } else {
            this.props.doCheckRiskControlBeforeTransferWithAppointAction({
                signtp: 'timing',
                funcno: 'withdraw',
                pyform: displayName,
                dbtNm: obj.from.accountName,
                dbtAcctId: obj.from.accountNo,
                dbtAcctcd: 'BBAN',
                crdMmbId: obj.to.bankCode, // 贷记银行代码
                crdNm: obj.to.alias,
                crdAcctId: obj.to.number,
                crdAcctcd: obj.to.transferType,
                inacno: obj.to.bankAccountNo, // 收款方银行账号
                stadat: obj.pay.startDate.Format('yyyyMMdd'),
                endtp: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'repeat' ? 'number' : 'time')),
                enddat: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'ondate' ? obj.pay.expiry.value.Format('yyyyMMdd') : (obj.pay.expiry.value === 'Never' ? '' : `${obj.pay.expiry.value}`))),
                instdAmt: obj.pay.amount,
                instdCcy: 'HKD',
                period: obj.pay.frequency.value,
                ustrd: obj.pay.remarks
            }, res => {
                this.onNativeVerify(res, 1);
            })
        }
    }

    /**
     * 根据过风控提示的核身方式进行校验，调用原生核身方式
     */
    onNativeVerify = (res, type) => {
        this.isTransferring = false;
        if (res.resultCode === 0 && res.resultData && res.resultData.body) {
            const goNativeData = res.resultData.body.actionData;
            this.goNativeCheck(goNativeData, (natRes) => {
                (natRes && natRes.outData && natRes.outData.businessNo) && this.onCheckRiskResult(res, natRes.outData.businessNo, type);
            });
        } else if (res.resultCode === 1) {
            this.onCheckRiskResult(res, null, type, true);
        } else {
            Toast.show(res.errorData.msg);
        }
    }

    /**
     * 将风控结果提交转账
     */
    onCheckRiskResult = (obj, businessNo, type, nosecurity) => {
        if (nosecurity) {
            window.location.href = `result.html#/?chnldt=${obj.resultData.chnldt}&chnlsq=${obj.resultData.chnlsq}&qytype=${type}`;
            return;
        }

        const params = {
            bizInfo: {
                trandt: obj.resultData.trandt,
                transq: obj.resultData.transq,
                busino: obj.resultData.busino,
            }
        }

        if (businessNo) {
            params['securityResultData'] = {
                businessNo: businessNo
            }
        }

        this.props.doTransferWithPassRiskAction(params, res => {
            if (res.resultCode === 0) {
                Toast.show(res.errorData.msg);
            } else {
                ///alert(JSON.stringify(res.resultData))
                window.location.href = `result.html#/?chnldt=${res.resultData.chnldt}&chnlsq=${res.resultData.chnlsq}&qytype=${type}`;
            }
        });
    }

    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes)
    }

    /**
     * diaglog
     */
    onDiaglogResult = (status) => {
        this.setState({ isShowState: false });
        if (status) {
            window.history.go(-2);
        }
    }

    /**
    * diaglog
    */
    onCheckDiaglog = () => {
        this.setState({ isShowState: true });
    }
}

function mapStateFromProps(state) {
    return {
        depositAccount: state.queryDepositAccountReducer,
        addPayee: state.doAddPayeeReducer
    }
}

export default connect(mapStateFromProps, {
    doQueryPayeesAction,
    doAddPayeeAction, doTransferRemittanceAction,
    doCheckRiskControlBeforeTransferWithImmedAction, doCheckRiskControlBeforeTransferWithAppointAction,
    doTransferWithTimingAction, doTransferWithPassRiskAction
})(ReviewFragment)