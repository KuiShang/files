import React from 'react';
import intl from 'react-intl-universal';
import { connect } from 'react-redux';
import PopOver from 'components/pop-over';
import CardSent from 'components/card-sent';
import DepositDetail from 'components/deposit-detail';
import CollapseDetail from 'components/collapse-detail';
import DialogSmallValue from 'components/dialog-small-value';
import DatePicker from 'components/date-picker';
import { doQueryTransferResultAction } from 'redux/actions/transfer';
import { doQueryImmedDepositResultAction } from 'redux/actions/deposit';
import * as SDK from 'utils/SDKUtil';
import imgSuccess from 'assets/imgs/success/success.svg';
import imgFailed from 'assets/imgs/error/error.png';
import imgPending from 'assets/imgs/pending/pending.png';
import './index.scss';

class DepositResultFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            params: props.params,
            showDetail: false,
            showSmall: false,
            showCalendar: false,
            isSchedule: (props.params && props.params.type === 0) ? false : true,
            isImmed: (props.params && props.params.type === 0) ? true : false,
            detail: null,
        }
    }

    static getDerivedStateFromProps(props, state) {
        if (!state.isImmed && props.appointDepositResult && props.appointDepositResult.resultCode === 1) {
            return {
                detail: props.appointDepositResult.resultData
            }
        } else if (state.isImmed && props.immedDepositResult && props.immedDepositResult.resultCode === 1) {
            return {
                detail: props.immedDepositResult.resultData
            }
        }
    }

    /**
     * 交易状态
     * Option 1: 00 - 转账成功
     * Option 2: 01 - 初始化
     * Option 3: 02 - 失败
     * Option 4: 03 - 过风控返回
     * Option 5: 04 - 发送支付渠道成功
     */
    render() {
        const { params, detail, isImmed } = this.state;
        //// No parameters.
        if (!params || !params.chnldt || !params.chnlsq) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        //// No result data.
        if (!detail) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        if (detail.transt === '00') {
            return this.renderSuccess();
        } else if (detail.transt === '25' || detail.transt === '27') {
            return this.renderFailed();
        } else {
            return this.renderPending();
        }
    }

    renderSuccess = () => {
        const { showDetail, showSmall, showCalendar, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgSuccess} />
                    <div className="result-status-tip">
                        <span>{intl.get('auto_deposit_result_success')}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get('you_have_deposited')}
                        amount={detail.instdAmt}
                        alias={detail.crdNm}
                        proxyNo={detail.crdAcctId}>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? 'Hide' : 'Show'} Transaction Details`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <DepositDetail isSchedule={true} detail={detail}></DepositDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onDone}>{intl.get('done')}</button>
                </div>
                {
                    showSmall &&
                    <PopOver isDialog={true} visible={showSmall}
                        onShow={() => this.setState({ showSmall: !this.state.showSmall })}>
                        <DialogSmallValue></DialogSmallValue>
                    </PopOver>
                }
                {
                    showCalendar &&
                    <PopOver title={intl.get('Start Date')} titleDone={intl.get('done')} visible={showCalendar}
                        onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
                        onDone={(obj) => { console.info('done action', obj) }}>
                        <DatePicker onSelectDate={(e) => { console.info(e) }}></DatePicker>
                    </PopOver>
                }
            </div>
        )
    }

    renderFailed = () => {
        const { showDetail, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgFailed} />
                    <div className="result-status-tip">
                        <span>{intl.get('auto_deposit_result_failed')}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get('you_have_deposited')}
                        amount={detail.instdAmt}
                        alias={detail.dbtNm}
                        proxyNo={detail.dbtAcctId}>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? 'Hide' : 'Show'} Transaction Details`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <DepositDetail isSchedule={true} detail={detail}></DepositDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onDone}>{intl.get('done')}</button>
                </div>
            </div>
        )
    }

    renderPending = () => {
        const { showDetail, showSmall, showCalendar, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgPending} />
                    <div className="result-status-tip">
                        <span>{intl.get('auto_deposit_result_pending')}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get('you_have_deposited')}
                        amount={detail.instdAmt}
                        alias={detail.dbtNm}
                        proxyNo={detail.dbtAcctId}>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? 'Hide' : 'Show'} Transaction Details`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <DepositDetail isSchedule={true} detail={detail}></DepositDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onDone}>{intl.get('done')}</button>
                </div>
                {
                    showSmall &&
                    <PopOver isDialog={true} visible={showSmall}
                        onShow={() => this.setState({ showSmall: !this.state.showSmall })}>
                        <DialogSmallValue></DialogSmallValue>
                    </PopOver>
                }
                {
                    showCalendar &&
                    <PopOver title={intl.get('Start Date')} titleDone={intl.get('done')} visible={showCalendar}
                        onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
                        onDone={(obj) => { console.info('done action', obj) }}>
                        <DatePicker onSelectDate={(e) => { console.info(e) }}></DatePicker>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * 根据的是风控的交易流水去查询的交易结果
     * Option 0: 即时入金
     * Option 1: 定时入金
     */
    componentDidMount() {
        SDK.showNativeLoading(true);
        const { params } = this.state;

        if (params.type === 0) {
            this.onCheckImmedDepositResult(params, 1);
        } else {
            this.onCheckAppointDepositResult(params, 1);
        }

        SDK.showNativeLoading(false);
    }

    onCheckImmedDepositResult = (params, count) => {
        if (count > 3) {
            return;
        }

        this.props.doQueryImmedDepositResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
        }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.transt === '00') {

            } else if (resultCode === 1 && (resultData.transt === '25' || resultData.transt === '27')) {

            } else {
                setTimeout(() => { this.onCheckImmedDepositResult(params, ++count) }, 2000)
            }
        })
    }

    onCheckAppointDepositResult = (params, count) => {
        if (count > 3) {
            return;
        }

        this.props.doQueryTransferResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
            qytype: 2  // 公用接口，类型2表示定时入金
        }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.transt === '00') {

            } else if (resultCode === 1 && (resultData.transt === '25' || resultData.transt === '27')) {

            } else {
                setTimeout(() => { this.onCheckAppointDepositResult(params, ++count) }, 2000)
            }
        })
    }

    onDone = () => {
        SDK.closeWebView();
    }

    onMakeAnother = () => {
        window.location.href = "transfer.html"
    }
}

function mapStateFromProps(state) {
    return {
        appointDepositResult: state.doQueryTransferResultReducer,
        immedDepositResult: state.doQueryImmedDepositResultReducer,
    }
}

export default connect(mapStateFromProps, { doQueryTransferResultAction, doQueryImmedDepositResultAction })(DepositResultFragment)