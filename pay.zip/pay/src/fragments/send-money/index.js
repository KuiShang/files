import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardFrom from 'components/card-from';
import CardTo from 'components/card-to';
import CardToRecent from 'components/card-to-recent';
import CardToMobile from 'components/card-to-mobile';
import CardToBankAccount from 'components/card-to-bank-account';
import CardToEmail from 'components/card-to-email';
import CardToFPS from 'components/card-to-fps';
import ContactColor from 'components/contact-color';
import PopOver from 'components/pop-over';
import Hint from 'components/modal-hint';
import Toast from 'components/toast';
import DialogDayLimit from 'components/dialog-day-limit';
import PhonePicker from 'components/phone-picker';
import BankRegisteredRecipient from 'components/bank-registered-recipient';
import { doQueryFPSInfoAction, doQueryFPSInfoLoopAction } from 'redux/actions/fps';
import { doQueryPayeesAction } from 'redux/actions/payee';
import { doQueryTransferPayerAction, doQueryTransferLimitAction } from 'redux/actions/transfer';
import { doGetAccount4401Action } from 'redux/actions/account';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import './index.scss';

class SendMoneyFragment extends React.Component {
    constructor(props) {
        super(props);

        let info = props.info, curType = 0,
            isEdit = false, showContinue = false,
            selectRecipient = null, bankAccount = null,
            mobile = '', email = '', fps = '',
            accountFullName = '', accountNum = '';
        if (info) {
            curType = info.from.curType;
            isEdit = info.from.isEdit;

            if (isEdit) {
                selectRecipient = info.selectRecipient;
                bankAccount = info.bankAccount;
                showContinue = true;
                mobile = info.mobile;
                email = info.email;
                fps = info.fps;
                accountFullName = info.to.alias;
                accountNum = info.to.number;
            }
        }

        this.state = {
            account: props.account,
            isEdit,
            curType,
            showPhone: false,
            showContinue,
            showBanks: false,
            showRecent: false,
            showHit: false,
            showDayLimit: false,
            showTips: false,
            showLimitErrorTip: false,
            disabled: false,
            defaultBank: 0,
            transferPayer: null,
            payees: {},
            selectRecipient,
            bankAccount,
            accountNum,
            accountFullName,
            filter: '',
            country: '+852',
            phone: null,
            mobile,
            email,
            fps,
            balanceAmount: 0, // 余额
            limitAmount: 0, // 日限额
            minLimitAmount: 0, // LIVIBK最小转账限额
            pay: {
                instdAmt: 0,
                instdCcy: 'HKD',
                dbtNm: '付款方客户名称',
                dbtAcctId: 100,
                crdNm: '',
                crdAcctId: '',
                crdBankCode: ''
            }
        }

        // 2019-07-25 注释：原因安卓监听回调，此页面跳转到其他h5页面后，返回按钮不可用
        // SDK.onBackPress(() => {
        //     SDK.closeNativeWebview();
        // })


        const title = intl.get('transfer');
        SDK.setTopStatusBar({ title });
        SDK.setTitleRight({ show: 0 });
    }

    //// TODO
    //// Issue 1: 过滤常用收款人使用备注名时无法过滤
    static getDerivedStateFromProps(props, state) {
        let { curType, filter, transferPayer, showRecent, payees, balanceAmount, limitAmount, minLimitAmount } = state;

        if (props.payees.resultCode && props.payees.resultCode === 1) {
            const data = props.payees.resultData;
            if (data && data.last_use_list && data.last_use_list.length > 0) {
                showRecent = true;
                const temp = data.last_use_list.filter(item => {
                    if (curType === 1) {
                        return item.inactp === 'MOBN';
                    } else if (curType === 2) {
                        return item.inactp === 'BBAN';
                    } else if (curType === 3) {
                        return item.inactp === 'EMAL';
                    } else if (curType === 4) {
                        return item.inactp === 'SVID';
                    } else {
                        return true;
                    }
                })

                if (filter === '') {
                    payees.last_use_list = temp;
                } else {
                    payees.last_use_list = temp.filter(item => {
                        if (item.pyform.indexOf(filter) >= 0 || item.pyacct.indexOf(filter) >= 0 || item.banknm.indexOf(filter) > 0) {
                            return item;
                        } else {
                            return false;
                        }
                    })
                }
            }

            if (data && data.name_list && data.name_list.length > 0) {
                showRecent = true;
                const temp = data.name_list.filter(item => {
                    if (curType === 1) {
                        return item.inactp === 'MOBN';
                    } else if (curType === 2) {
                        return item.inactp === 'BBAN';
                    } else if (curType === 3) {
                        return item.inactp === 'EMAL';
                    } else if (curType === 4) {
                        return item.inactp === 'SVID';
                    } else {
                        return true;
                    }
                })

                if (filter === '') {
                    payees.name_list = temp;
                } else {
                    payees.name_list = temp.filter(item => {
                        if (item.pyform.indexOf(filter) >= 0 || item.pyacct.indexOf(filter) >= 0 || item.banknm.indexOf(filter) > 0) {
                            return item;
                        } else {
                            return false;
                        }
                    })
                }
            }
        }

        if (props.transferPayer && props.transferPayer.resultCode === 1) {
            transferPayer = props.transferPayer.resultData;
            balanceAmount = props.transferPayer.resultData.conv_amt_sum;
        }

        if (props.limit && props.limit.resultCode === 1) {
            limitAmount = props.limit.resultData.limit_value;
            minLimitAmount = props.limit.resultData.min_limit_value;
        }

        return {
            account: props.account,
            payees,
            transferPayer,
            showRecent,
            balanceAmount,
            limitAmount,
            minLimitAmount
        }
    }

    /**
     * 账户余额小于最小转账限额，或者账户余额为0，则“下一步“按钮置为灰色，不进行操作
     */
    render() {
        let { showLimitErrorTip, disabled, selectRecipient, balanceAmount, minLimitAmount, accountNum, accountFullName, bankAccount, transferPayer, payees, curType, defaultBank, fps, country, mobile, email, phone, showPhone, showRecent, showHint, showDayLimit, showTips, showBanks, showContinue } = this.state;

        if (!disabled && (balanceAmount < minLimitAmount || balanceAmount === 0)) {
            disabled = true;
            showLimitErrorTip = true;
        }

        return (
            <div className="send-money">
                <div className="send-money-row">
                    <CardFrom showTips={showLimitErrorTip} balance={transferPayer && transferPayer.conv_amt_sum} account={transferPayer && transferPayer.acct_no}></CardFrom>
                    <CardTo hideRecent={!showRecent} checkedIndex={curType} onChecked={index => this.onChecked(index)}></CardTo>
                </div>
                <br />
                {
                    selectRecipient &&
                    <BankRegisteredRecipient
                        selectRecipient={selectRecipient}
                        onChangeRecipient={() => this.onChangeRecipient()}>
                    </BankRegisteredRecipient>
                }
                {
                    (curType === 0 && showRecent) &&
                    <CardToRecent
                        defaultBank={defaultBank}
                        disabled={disabled}
                        selectRecipient={selectRecipient}
                        bankAccount={bankAccount}
                        showBanks={showBanks}
                        onFilter={(e) => this.onFilter(e)}
                        onSelectBank={this.onSelectBank}
                        onSwitchBanks={this.onSwitchBanks}
                        onChangeRecipient={() => this.onChangeRecipient()}
                        onContinue={this.onContinue}>
                    </CardToRecent>
                }
                <div className="send-money-row">
                    {
                        curType === 1 &&
                        <CardToMobile
                            defaultBank={defaultBank}
                            disabled={disabled}
                            selectRecipient={selectRecipient}
                            bankAccount={bankAccount}
                            country={country}
                            mobile={mobile}
                            showTips={showTips}
                            showBanks={showBanks}
                            showContinue={showContinue}
                            onSelectCountryCode={this.onSelectCountryCode}
                            onSelectMobile={this.onSelectMobile}
                            onChangeMobile={this.onChangeMobile}
                            onContinue={this.onContinue}
                            onSwitchBanks={this.onSwitchBanks}
                            onSelectBank={this.onSelectBank}>
                        </CardToMobile>
                    }
                    {
                        curType === 2 &&
                        <CardToBankAccount
                            disabled={disabled}
                            bankAccount={bankAccount}
                            selectRecipient={selectRecipient}
                            accountNum={accountNum}
                            accountFullName={accountFullName}
                            showTips={showTips}
                            showContinue={showContinue}
                            onHint={() => this.setState({ showHint: !showHint }, () => { SDK.forbidLeftBackPress(true) })}
                            onContinue={this.onContinue}
                            onSwitchBanks={this.onSwitchBanks}
                            onSelectBank={this.onSelectBank}
                            onChangeAccountNum={this.onChangeAccountNum}
                            onHandleAccountFullName={this.onHandleAccountFullName}>
                        </CardToBankAccount>
                    }
                    {
                        curType === 3 &&
                        <CardToEmail
                            email={email}
                            defaultBank={defaultBank}
                            disabled={disabled}
                            bankAccount={bankAccount}
                            selectRecipient={selectRecipient}
                            showBanks={showBanks}
                            showTips={showTips}
                            showContinue={showContinue}
                            onContinue={this.onContinue}
                            onSwitchBanks={this.onSwitchBanks}
                            onSelectBank={this.onSelectBank}
                            onChangeEmail={this.onChangeEmail}>
                        </CardToEmail>
                    }
                    {
                        curType === 4 &&
                        <CardToFPS
                            fps={fps}
                            disabled={disabled}
                            selectRecipient={selectRecipient}
                            showTips={showTips}
                            showContinue={showContinue}
                            onContinue={this.onContinue}
                            onSwitchBanks={this.onSwitchBanks}
                            onChangeFPS={this.onChangeFPS}>
                        </CardToFPS>
                    }
                </div>
                {
                    (showRecent && !selectRecipient) &&
                    <ContactColor data={payees} showContinue={showContinue}
                        onSelectItem={obj => this.onSelectRecipient(obj)}>
                    </ContactColor>
                }
                {
                    showHint &&
                    <PopOver title={intl.get('tips')} visible={showHint} onShow={() => this.setState({ showHint: !this.state.showHint }, () => { SDK.forbidLeftBackPress(false) })} >
                        <Hint></Hint>
                    </PopOver>
                }
                {
                    showDayLimit &&
                    <PopOver
                        isDialog={true}
                        visible={showDayLimit}
                        onShow={() => SDK.closeNativeWebview()}>
                        <DialogDayLimit onGoSetDayLimit={this.onGoSetDayLimit} onCancel={() => SDK.closeNativeWebview()}></DialogDayLimit>
                    </PopOver>
                }
                {
                    showPhone &&
                    <PopOver title={intl.get('mobile_number')} visible={showPhone} onShow={() => this.setState({ showPhone: !showPhone })}>
                        <PhonePicker data={phone} onSelect={(item) => this.onPickPhone(item)}></PhonePicker>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * TODO:
     * 
     * 账户余额小于最小限额，则Continue按钮置灰
     * 
     * 
     * 1: LIVI银行设置每日转账额度()，最小转账限额()；
     * 2: 用户设置小额转账额度（必须小于用户自己设置的日限额），日限额（要大于用户自己设置的小额，但是要小于等于LIVI银行设置的每日转账额度）
     */
    componentDidMount() {
        const { account } = this.state;

        //// 获取转账限额
        //// 转账限额小于等于0则弹出需要设置转账限额弹框
        this.props.doQueryTransferLimitAction({
            acct_type: account.acct_type,
            acct_no: account.acct_no,
        }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.limit_value <= 0) {
                this.setState({ showDayLimit: !this.state.showDayLimit })
            }
        });

        //// 获取转账账户余额信息
        this.props.doQueryTransferPayerAction({
            acct_no: account.acct_no
        })

        //// 获取历史收款人
        this.props.doQueryPayeesAction({}, res => {
            if ((!res.resultData.last_use_list || res.resultData.last_use_list.length <= 0) && (!res.resultData.name_list || res.resultData.name_list.length <= 0)) {
                !this.state.isEdit && this.setState({ curType: 1 });
            } else {
                !this.state.isEdit && this.setState({ curType: 0 });
            }
        })

        //// 获取账户信息
        //// this.props.doGetAccount4401Action();
    }

    /**
     * 选择转账方式
     */
    onChecked = (index) => {
        this.setState({
            curType: index,
            selectRecipient: null,
            mobile: '',
            email: '',
            fps: '',
            disabled: false,
            showTips: false,
            showContinue: false,
            showBanks: false,
        });
    }

    /**
     * 选择手机号国家码
     */
    onSelectCountryCode = () => {
        SDK.goCountryCode(res => {
            this.setState({ country: (res.data.outData.mobilePrefix) })
        });
    }

    
    /**
     * 打开原生通讯录、选择手机号
     */
    onSelectMobile = () => {
        SDK.goNativePhoneList((res) => {
            if (res.code === 1) {
                const phone = res.data.outData.phone;
                if (phone.length > 1) {
                    this.setState({ phone, showPhone: true, showBanks: true, showContinue: true });
                } else if (phone.length === 1) {
                    console.info(phone[0].value, phone[0].value.replace(/\s+/g, ""));
                    this.setState({ mobile: phone[0].value, showBanks: true, showContinue: true });
                }
            }
        })
    }

    onPickPhone = (item) => {
        this.setState({ mobile: item.value, showPhone: false })
    }

    /**
     * 修改手机号
     */
    onChangeMobile = (mobile) => {
        let showBanks = false, showContinue = false;
        if (mobile.split("").length >= 7) {
            showBanks = true;
            showContinue = true
        }

        this.setState({ mobile, showBanks, showContinue, disabled: false, showTips: false });
    }

    /**
     * 选择银行
     */
    onSelectBank = () => {
        const url = `${window.location.origin}/pay/bank-code.html?ref=tran`;
        // const url = `${window.location.origin}/bank-code.html?ref=tran`;
        // "Recipient's Bank"
        SDK.goNativeWebview(url, (res) => {
            if (res.code === 1) {
                this.setState({ bankAccount: res.data.outData })
            }
        });
    }

    /**
     * 转换银行类型
     */
    onSwitchBanks = (e) => {
        this.setState({ disabled: false, showTips: false, defaultBank: e })
    }

    /**
     * 修改Email
     */
    onChangeEmail = (email, showContinue, showBanks) => {
        this.setState({ email, showContinue, showBanks, disabled: false, showTips: false })
    }

    /**
     * 修改FPS
     */
    onChangeFPS = (fps, showContinue) => {
        this.setState({ fps, showContinue, disabled: false, showTips: false })
    }

    /**
     * 卡号转账设置卡号
     */
    onChangeAccountNum = (num, showContinue) => {
        this.setState({ accountNum: num, showContinue })
    }

    /**
     * 卡号转账设置全名Full Name
     */
    onHandleAccountFullName = (Name) => {
        
        //校验输入框的值:输入值除了中文什么都可以输入，字符长度60个字符以内
        if(Name.length < 60){
            if(/[\u4e00-\u9fa5]/.test(Name)){
                const currentReplaceVal = Name.replace(/[\u4e00-\u9fa5]+/,'');
                this.setState({
                    accountFullName: currentReplaceVal
                }) 
            }else{
                this.setState({
                    accountFullName: Name
                }) 
            }
        }else{
            return; 
        }
    }

    /**
     * 选择最近收款人取消选择
     */
    onChangeRecipient = () => {
        this.setState({ selectRecipient: null, showContinue: false, showBanks: false })
    }

    /**
     * 选择最近收款人界面过滤
     */
    onFilter = (e) => {
        this.setState({ filter: e })
    }

    /**
     * 选择最近收款人
     */
    onSelectRecipient = (obj) => {
        this.setState({ selectRecipient: obj, showContinue: true, showBanks: ((obj.inactp === 'MOBN' || obj.inactp === 'EMAL') ? true : false) })
    }

    /**
     * 跳转到设置日转账限额页面
     */
    onGoSetDayLimit = () => {
        const returnUrl = window.location.href;
        const url = `${window.location.origin}/pay/transfer-settings.html#/SetLimit?type=1&returnUrl=`;
        // "Recipient's Bank"
        SDK.goNativeWebview(url, (res) => {
            // 关闭WEBVIEW的回调
        });
    }

    /**
     * 1-Mobile、2-AccountNo、3-Email、4-FPS
     * 
     * Option 1: 若账户余额＜最小限额 
     * Option 2: FPS Addressing
     * 
     * Step 1: 查询收款方的FPS登记信息, Account No 转账是直接跳转到输入金额界面
     * Step 2: 轮询查询收款方的登记结果(Mobile/Email/FPS)
     * Step 3: 跳转到输入金额界面
     */
    onContinue = () => {
        const { selectRecipient, defaultBank, curType, account, country, accountNum, bankAccount, accountFullName, mobile, email, fps } = this.state;
        const { transferPayer, limit } = this.props;

        let proxId = mobile, proxTp = 'MOBN';
        if (selectRecipient) {
            proxId = selectRecipient.pyacct;
            proxTp = selectRecipient.inactp;
        } else {
            if (curType === 1) {
                proxId = `${country}-${mobile}`;
                proxTp = "MOBN";
            } else if (curType === 2) {
                proxTp = "BBAN"
                if (accountNum === '' || accountNum === null || accountFullName === '' || accountFullName === null) {
                    Toast.show('未输入账户名称!');
                    return;
                }
            } else if (curType === 3) {
                proxId = email;
                proxTp = "EMAL"
            } else if (curType === 4) {
                proxId = fps;
                proxTp = "SVID";
            }
        }

        if (transferPayer.resultCode === 1 && limit.resultCode === 1) {
            if (transferPayer.resultData.conv_amt_sum < limit.resultData.min_limit_value) {
                this.setState({ showTips: false, disabled: true });
            } else {
                if (proxTp === "MOBN" || proxTp === "EMAL" || proxTp === "SVID") {
                    this.props.doQueryFPSInfoAction({
                        proxId: proxId,
                        proxTp: proxTp,
                        bankcd: defaultBank === 0 ? '' : bankAccount.bank_code,
                    }, res => {
                        if (res.resultCode === 1) {
                            this.doQueryFPSInfoLoop(res, 1, (resp) => {
                                hashHistory.push({
                                    pathname: '/instructions',
                                    state: {
                                        from: {
                                            curType,
                                            accountNo: transferPayer.resultData.acct_no,
                                            accountName: account.acct_name,
                                            balance: transferPayer.resultData.conv_amt_sum,
                                            limit_value: limit.resultData.limit_value,
                                            min_limit_value: limit.resultData.min_limit_value
                                        },
                                        to: {
                                            payeeName: resp.resultData.fullNm_en,
                                            alias: resp.resultData.fullNm_en,
                                            number: resp.resultData.proxId,
                                            isDefaultBank: (defaultBank === 0 ? true : false),
                                            transferType: proxTp,
                                            bankAccountNo: resp.resultData.cusId,
                                            bankCode: defaultBank === 0 ? resp.resultData.mmbId : bankAccount.bank_code,//// 收款方银行代码是从接口返回的
                                            bankDes: defaultBank === 0 ? '' : bankAccount.bank_en_name,
                                            otherBank: bankAccount
                                        },
                                        selectRecipient,
                                        bankAccount,
                                        mobile,
                                        email,
                                        fps,
                                    }
                                });
                            });
                        } else if (res.resultCode === 0) {
                            Toast.show(res.errorData.msg);
                            this.setState({ showTips: true, disabled: true })
                        } else {
                            this.setState({ showTips: true, disabled: true })
                        }
                    })
                } else {
                    hashHistory.push({
                        pathname: '/instructions',
                        state: {
                            from: {
                                curType,
                                accountNo: transferPayer.resultData.acct_no,
                                accountName: account.acct_name,
                                balance: transferPayer.resultData.conv_amt_sum,
                                limit_value: limit.resultData.limit_value,
                                min_limit_value: limit.resultData.min_limit_value
                            },
                            to: {
                                payeeName: "",
                                alias: selectRecipient ? selectRecipient.pyname : accountFullName,
                                number: selectRecipient ? selectRecipient.pyacct : accountNum,
                                isDefaultBank: false,
                                transferType: proxTp,
                                bankAccountNo: selectRecipient ? selectRecipient.pyacct : accountNum,
                                bankCode: (selectRecipient ? selectRecipient.pybank : (bankAccount && bankAccount.bank_code) || ''),
                                bankDes: (selectRecipient ? selectRecipient.banknm : (bankAccount && bankAccount.bank_en_name)),
                                otherBank: bankAccount
                            },
                            selectRecipient,
                            bankAccount,
                            mobile,
                            email,
                            fps,
                        }
                    })
                }
            }
        }
    }

    /**
     * 轮询查询收款方的登记结果(Mobile/Email/FPS)
     * Option 1: 'sendSuc' 'initial' 'recvFps' 需要轮询
     * Option 2: 'sendFail' 'fpsRjct' 查询失败
     * Option 3: 'fpsAcct' 查询成功
     */
    doQueryFPSInfoLoop = (res, count, callback) => {
        if (count > 3) {
            this.setState({ isQuering: false, showTips: true, disabled: true }, () => {
                Toast.show('查询FPS账号操作失败');
            })

            return;
        }

        this.props.doQueryFPSInfoLoopAction({
            chnldt: res.resultData.chnldt,
            chnlsq: res.resultData.chnlsq,
        }, resp => {
            const { resultCode, resultData } = resp;

            //// 查询失败
            if (resultCode === 1 && (resultData.addrtranst === 'sendFail' || resultData.addrtranst === 'fpsRjcj')) {
                this.setState({ isQuering: false, showTips: true, disabled: true })
            }
            //// 轮询3次查询结果
            else if (resultCode === 1 && (resultData.addrtranst === 'initial' || resultData.addrtranst === 'recvFps' || resultData.addrtranst === 'sendSuc')) {
                setTimeout(() => { this.doQueryFPSInfoLoop(res, ++count, callback) }, 2000)
            }
            //// 查询到结果
            else if (resultCode === 1 && resultData.addrtranst === 'fpsAcct') {
                callback && callback(resp);
            } else if (resultCode === 0) {
                this.setState({ isQuering: false, showTips: true, disabled: true }, () => {
                    Toast.show('查询FPS账号操作失败');
                })
            } else {
                this.setState({ isQuering: false, showTips: true, disabled: true }, () => {
                    Toast.show('系统出错');
                })
            }
        })
    }
}

function mapStateToProps(state) {
    return {
        limit: state.doQueryTransferLimitReducer,
        transferPayer: state.doQueryTransferPayerReducer,
        payees: state.doQueryPayeesReducer,
        selfFPSInfo: state.doQuerySelfFPSInfoReducer,
        recipientBank: state.doSelectRecipientBankReducer
    }
}

export default connect(mapStateToProps, {
    doQueryFPSInfoAction, doQueryFPSInfoLoopAction, doQueryTransferLimitAction, doQueryPayeesAction,
    doQueryTransferPayerAction, doGetAccount4401Action
})(SendMoneyFragment)