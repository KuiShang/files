import React from 'react';
import intl from 'react-intl-universal';
import imgClose from 'assets/imgs/close-account/close-account@2x.png';
import imgError from 'assets/imgs/error/error.png';

export default class TerminateResult extends React.Component {
    state = { isSuccess: this.props.isSuccess }

    static getDerivedStateFromProps(props) {
        return {
            isSuccess: props.isSuccess
        }
    }

    render() {
        const { isSuccess } = this.state;

        return (
            <div className="dialog-small-value">
                <img alt="" src={isSuccess ? imgClose : imgError} />
                <div className="dialog-small-value-tip">
                    {isSuccess && <div style={{ color: '#848484' }}>{intl.get('this_direct_debit_instruction_is_cancelled')}</div>}
                    {!isSuccess && <div style={{ color: '#848484' }}>Authorization terminate has</div>}
                    {!isSuccess && <div style={{ color: '#848484' }}>failed.please try again later.</div>}
                </div>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-primary" onClick={() => this.props.onOkay()}>Back to Direct Debt</li>
                </ul>
            </div>
        )
    }
}