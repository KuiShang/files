import React from 'react';
import intl from 'react-intl-universal';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import SelectFrequency from 'components/select-frequency';
import SelectField from 'components/select-field';
import TextField from 'components/text-field';
import FrequencyPicker from 'components/frequency-picker';
import ExpiryDatePicker from 'components/expiry-date-picker';
import Toast from 'components/toast';
import PopOver from 'components/pop-over';
import DialogConfirmTerminate from 'components/dialog-confirm-terminate';
import Terms from './Terms';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import { doTerminateEDDAAction, doQuerySignEDDAResultAction } from 'redux/actions/edda';
import { Base64 } from 'js-base64';
import * as SDK from 'utils/SDKUtil';
import './index.scss';
import TerminateResult from './TerminateResult';


class EDDAInstructionsFragment extends React.Component {
    constructor(props) {
        super(props);
        const info = props.info;

        const isEdit = (info && info.isEdit) ? true : false;
        const mndtId = (info && info.mndtId) ? info.mndtId : null;
        const amount = (info && info.detail) ? info.detail.amount : 0;
        const frequency = (info.detail && info.detail.frequency) || {
            key: 'monthly', label: 'once_every_month', value: 'MNTH'
        }
        let expiry = (info.detail && info.detail.expiry) || {
            key: 'never',
            value: 'Never'
        }
        if (expiry.key === 'ondate' && (typeof expiry.value) === 'string') {
            expiry.value = new Date(expiry.value)
        }
        const remarks = (info && info.detail) ? info.detail.remarks : '';

        //// 计算日历选择的范围
        //// 5年内日期规则今天算起-5年后的本月的第一天；
        const date = new Date();
        const year = date.getFullYear();
        const month = date.getMonth();
        const day = date.getDate();
        const min = new Date(year, month, day);
        const max = new Date((year + 5), month, 1);

        this.state = {
            isEdit,
            mndtId,
            isFocus: false,
            showTerms: false,
            showFrequency: false,
            showExpiryDate: false,
            showConfirm: false,
            showConfirmResult: false,
            info,
            amount,
            formatAmount: thousandBitSeparator(keep2DecimalFull(amount)),
            balance: 0,
            frequency,
            expiry,
            remarks,
            isExpired: false,
            minDate: min,
            maxDate: max
        }
    }

    static getDerivedStateFromProps(props, state) {
        const { info } = state;
        let { isExpired } = state;
        if (info && info.detail &&
            (info.detail.eddaStatus === 'bindfail' || info.detail.eddaStatus === 'unbindsuc' || info.detail.eddaStatus === 'suspsuc')) {
            isExpired = true;
        }

        return {
            isExpired
        }
    }

    render() {
        const { minDate, maxDate, isExpired, isEdit, frequency, expiry, info, isFocus, amount, formatAmount, balance, remarks, showTerms, showConfirm, showConfirmResult, showFrequency, showExpiryDate } = this.state;
        const dateConfig = { min: minDate, max: maxDate };
        const val = isFocus ? (amount === 0 ? '' : amount.toString()) : formatAmount;
        let expiryValue = expiry.value;

        if (expiry && expiry.key === 'ondate' && (typeof expiry.value === 'object')) {
            expiryValue = expiry.value.Format('yyyy/MM/dd')
        } else if (expiry && expiry.key === 'ondate' && (typeof expiry.value === 'string')) {
            expiryValue = (new Date(expiry.value)).Format('yyyy/MM/dd')
        } else if (expiry && expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiry.value} ${intl.get('times')}`;
        } else if (expiry && expiry.key === 'never') {
            expiryValue = intl.get('no_end_date');
        }

        return (
            <div className="edda-instructions">
                <div className="edda-instructions-to">
                    <CardReview>
                        {
                            isEdit && <div className="review-from-to-to">
                                <div className="review-from-to-title">Debit From</div>
                                <div className="review-from-to-account">
                                    <div className="review-from-to-account-avator">
                                        <div className="review-from-to-account-avator-to"
                                            style={{ backgroundImage: `linear-gradient(-151deg, #FF7C80 0%, #FF5A5F 100%)` }}>VB</div>
                                    </div>
                                    <div className="review-from-to-account-detail">
                                        <div className="review-from-to-account-bank">VB Savings(HKD)</div>
                                        <div className="review-from-to-account-no">{info && info.from && info.from.number}</div>
                                    </div>
                                </div>
                            </div>
                        }
                        <div style={{ height: 10 }}></div>
                        <div className="review-from-to-to">
                            <div className="review-from-to-title">{intl.get("to")}</div>
                            <div className="review-from-to-account">
                                <div className="review-from-to-account-avator">
                                    <div className="review-from-to-account-avator-to">CT</div>
                                </div>
                                <div className="review-from-to-account-detail">
                                    <div className="review-from-to-account-bank">{info && info.merchant && info.merchant.alias}</div>
                                    <div className="review-from-to-account-no">{info && info.merchant && info.merchant.cdtrRef}</div>
                                </div>
                            </div>
                        </div>
                    </CardReview>
                    <div className="edda-instructions-row">
                        <div style={{ color: '#484848', fontSize: 16, fontWeight: 600, margin: '16px 0 0 0' }}>{intl.get("set_limit")}</div>
                    </div>
                    <div className="edda-instructions-row">
                        <CardReview>
                            <div className="edda-instructions-to-cont">
                                <div className="edda-instructions-to-sub">{intl.get("amount_limit")}</div>
                                <div className="edda-instructions-to-money">
                                    <div style={{ minWidth: 50, display: 'flex' }}>
                                        <input type={`${isFocus ? 'number' : 'text'}`}
                                            style={{ width: '100%' }}
                                            value={val}
                                            onChange={e => this.onChangeAmount(e.target.value)}
                                            onFocus={this.onFocus}
                                            onBlur={this.onBlur} />
                                    </div>
                                    <span>HKD</span>
                                </div>
                                <div className="edda-instructions-to-balance">{intl.get("max")} <span>{thousandBitSeparator(balance)} HKD</span></div>
                            </div>
                        </CardReview>
                    </div>
                    <div className="edda-instructions-row">
                        <SelectFrequency
                            title={intl.get("frequency_limit")}
                            value={frequency.label}
                            onSelect={() => this.setState({ showFrequency: !showFrequency })} >
                        </SelectFrequency>
                    </div>
                    <div className="edda-instructions-row">
                        <SelectField
                            title={intl.get("end_date")}
                            value={expiryValue}
                            onSelect={() => this.setState({ showExpiryDate: !showExpiryDate })}>
                        </SelectField>
                    </div>
                    <div className="edda-instructions-row">
                        <TextField
                            propValue={{ placeHolder: intl.get("remark_optional"), value: remarks }}
                            stateName={'remarks'}
                            setCurrentInputData={this.onChangeRemarks}>
                        </TextField>
                    </div>
                </div>
                <div className="edda-instructions-terms">
                    <div>
                        {intl.get("notice_content")}
                        <span style={{ color: 'blue' }} onClick={() => { this.getNoticeContent() }}>
                            {intl.get("notice_content_keywords")}
                        </span>
                        {intl.get("notice_content_end")}
                    </div>
                </div>
                {
                    isEdit &&
                    <div className="edda-instructions-actions">
                        {isExpired && <button className="ai-btn-primary" onClick={this.onExtendAuthorization}>Extend Authorization</button>}
                        {!isExpired && <button className="ai-btn-primary" onClick={this.onPreview}>{intl.get('up_date')}</button>}
                        {!isExpired && <button className="ai-btn-tripple" onClick={() => this.setState({ showConfirm: !showConfirm })}>{intl.get('terMinate')}</button>}
                    </div>
                }
                {
                    !isEdit &&
                    <div className="edda-instructions-actions">
                        <button className="ai-btn-primary" onClick={this.onPreview}>{intl.get("continue")}</button>
                    </div>
                }
                {
                    showFrequency &&
                    <PopOver title={intl.get("frequency_limit")} visible={showFrequency}
                        onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
                        onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
                        <FrequencyPicker
                            iseDDA={true}
                            data={frequency}
                            onSelectFrequency={this.onSelectFrequency}>
                        </FrequencyPicker>
                    </PopOver>
                }
                {
                    showExpiryDate &&
                    <PopOver visible={showExpiryDate}
                        title={intl.get('set_end_date')}
                        titleDone={intl.get('done')}
                        onShow={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}
                        onDone={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}>
                        <ExpiryDatePicker
                            expiry={expiry}
                            max={12}
                            dateConfig={dateConfig}
                            onSelectExpiryDate={this.onSelectExpiryDate}>
                        </ExpiryDatePicker>
                    </PopOver>
                }
                {
                    showConfirm &&
                    <PopOver isDialog={true} disClose={true} visible={showConfirm}
                        onShow={() => SDK.closeNativeWebview()}>
                        <DialogConfirmTerminate
                            onTerminate={() => this.onTerminate()}
                            onCancel={() => this.setState({ showConfirm: !showConfirm })}>
                        </DialogConfirmTerminate>
                    </PopOver>
                }
                {
                    showConfirmResult &&
                    <PopOver isDialog={true} disClose={true} visible={showConfirmResult}>
                        <TerminateResult isSuccess={true} onOkay={this.onBackToDirectDebit}></TerminateResult>
                    </PopOver>
                }
                {
                    showTerms &&
                    <PopOver title="" visible={showTerms} onShow={() => this.setState({ showTerms: !showTerms })} >
                        <Terms></Terms>
                    </PopOver>
                }
            </div>
        )
    }

    /**
	 * 查看协议 详情
	 */
    getNoticeContent = () => {
        const base_href = Base64.encode(`No=edda_001&Ver=20190821_1.0&type=1`);
        const url = `${window.location.origin}/public/protocol.html#/detailProtocol?${base_href}`;
        SDK.goNativeWebview(url, (res) => {
            if (res.code === 1) {
              console.info("查看协议")
            }
          });
    }

    /**
     * 修改金额
     */
    onChangeAmount = (amount) => {
        if (amount.substring(0, 1) === '0') {
            return;
        }

        amount = formatNum(amount); //amount.isOnlyNumWithTwoDecimal();
        const ind = amount.indexOf('.');
        let temp = amount;
        if (ind > 0) {
            temp = amount.substring(0, ind);
        }

        if (temp.split("").length > 13) {
            return;
        }

        this.setState({ amount });
    }

    /**
     * 修改备注
     */
    onChangeRemarks = (pn, json) => {
        if (json.value.split("").length > 50) {
            return;
        }

        this.setState({ remarks: json.value })
    }

    /**
     * 选择周期
     */
    onSelectFrequency = (item) => {
        this.setState({ showFrequency: false, frequency: item })
    }

    onSelectExpiryDate = (expiry) => {
        this.setState({ expiry })
    }

    onFocus = () => {
        this.setState({ isFocus: true, formatAmount: this.state.amount })
    }

    onBlur = () => {
        if (this.state.amount === "") {
            this.setState({ formatAmount: thousandBitSeparator(keep2DecimalFull(0)), isFocus: false })
        } else {
            this.setState({ isFocus: false, formatAmount: thousandBitSeparator(keep2DecimalFull(this.state.amount)) })
        }
    }

    /**
     * 终止eDDA签约，（ICL停止FPS需要通知，接口通知）
     */
    onTerminate = () => {
        const { mndtId } = this.state;

        this.props.doTerminateEDDAAction({ mndtId }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 0) {
                Toast.show(res.errorData.msg)
                return;
            }

            if (resultData.transt === 'tranSuc') {
                this.setState({ showConfirm: false, showConfirmResult: true })
            } else if (resultData.transt === 'initial' || resultData.transt === "sendSuc") {
                this.onQuerySignEDDAResult(1, res.resultData);
            } else {
                this.setState({ showConfirm: false, showConfirmResult: true });
            }
        })
    }

    /**
     * 轮询查询FPS中心注册信息
     * 上限请求三次
     * 
     * Option 1 成功：tranSuc
     * Option 2 失败：initial，sendFail，receipt，tranFail
     * Option 3 pending:sendSuc
     * 
     * 
     * Option 1 成功: tranSuc 
     * Option 2 失败：sendFail, receipt, tranFail
     * Option 3 pending:initial, sendSuc
     */
    onQuerySignEDDAResult = (count, params) => {
        if (count > 3) {
            this.setState({ showConfirm: false, showConfirmResult: true });
            return;
        }

        this.props.doQuerySignEDDAResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
        }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 0) {
                Toast.show(res.errorData.msg);
                return;
            }

            if (resultData.transt === 'tranSuc') {
                this.setState({ showConfirm: false, showConfirmResult: true })
            } else if (resultData.transt === 'initial' || resultData.transt === "sendSuc") {
                setTimeout(() => { this.onQuerySignEDDAResult(++count, params) }, 2000);
            } else {
                this.setState({ showConfirm: false, showConfirmResult: true });
            }
        });
    }

    /**
     * 跳转回eDDA首页
     */
    onBackToDirectDebit = () => {
        window.location.href = "edda.html";
    }

    /**
     * 过期授权跳转到预览界面
     */
    onExtendAuthorization = () => {
        const { info, amount, frequency, expiry, remarks } = this.state;
        if (amount <= 0) {
            Toast.show('金额必须大于0');
            return;
        }

        //// 转账金额必须小于日限额
        if (amount > info.from.limit_value) {
            Toast.show('转账金额必须小于日限额')
            return
        }

        hashHistory.push({
            pathname: 'review',
            state: {
                from: info.from,
                merchant: info.merchant,
                detail: {
                    mndtId: info.detail.mndtId,
                    amount,
                    frequency,
                    expiry,
                    remarks
                }
            }
        })
    }

    /**
     * 编辑状态跳转到预览界面
     */
    onPreview = () => {
        const { isEdit, info, amount, frequency, expiry, remarks } = this.state;
        if (amount <= 0) {
            Toast.show('金额必须大于0');
            return;
        }

        //// 转账金额必须小于日限额
        if (amount > info.from.limit_value) {
            Toast.show('转账金额必须小于日限额')
            return
        }

        hashHistory.push({
            pathname: 'review',
            state: {
                isEdit,
                from: info.from,
                merchant: info.merchant,
                detail: {
                    mndtId: (info.detail && info.detail.mndtId),
                    amount,
                    frequency,
                    expiry,
                    remarks
                }
            }
        })
    }

    /**
     * 调用/获取原生风控方式（例如：OTP）结果
     * @param {*} goNativeData 
     * @param {*} cb 
     */
    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes)
    }
}

export default connect(function (state) {
    return null
}, { doTerminateEDDAAction, doQuerySignEDDAResultAction })(EDDAInstructionsFragment)

function formatNum(amount) {
    amount = amount.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    amount = amount.replace(/^\./g, ""); // 验证第一个字符是数字
    amount = amount.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    amount = amount.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    amount = amount.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); // 只能输入两个小数
    return amount;
}