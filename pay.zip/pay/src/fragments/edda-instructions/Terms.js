import React from 'react';

export default class Terms extends React.Component{
    render() {
        return (
            <div>待产品更新条款</div>
        )
    }
}