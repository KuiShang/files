import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import DepositFromReceive from 'components/deposit-from-receive';
import TextLabel from 'components/text-label';
import Toast from 'components/toast';
import intl from 'react-intl-universal';
import { doTransferWithPassRiskAction } from 'redux/actions/common';
import { doCreateNewAppointDepositAction } from 'redux/actions/deposit';
import * as SDK from 'utils/SDKUtil';
import './index.scss';

class SEDDAReviewFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            info: props.info
        }
    }

    render() {
        const { info } = this.state;
        if (!info || !info.pay) {
            return null;
        }

        const { amount, depositDate, frequency, expiry } = info.pay;
        let expiryValue = expiry.key === 'ondate' ? expiry.value.Format('yyyy-MM-dd') : expiry.value
        if (expiry && expiry.key === 'never') {
            expiryValue = intl.get('no_end_date');
        } else if (expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiry.value} ${intl.get('times')}`
        }

        return (
            <div className="edda-review">
                <CardReview>
                    <DepositFromReceive data={info}></DepositFromReceive>
                    <span className="edda-review-space"></span>
                    <div>
                        <TextLabel label='Auto Deposit Amount (per Deposit)' value={`${amount} HKD`}></TextLabel>
                    </div>
                    <div>
                        <TextLabel label={intl.get('start_date')} value={depositDate && new Date(depositDate).Format('yyyy-MM-dd')}></TextLabel>
                    </div>
                    <div>
                        <TextLabel label={intl.get('frequency')} value={intl.get(frequency.label)}></TextLabel>
                    </div>
                    {
                        frequency.key !== 'specialdate' &&
                        <div>
                            <TextLabel label={intl.get('end_date')} value={expiryValue}></TextLabel>
                        </div>
                    }
                    <div>
                        <TextLabel label={`${intl.get('remarks')} (${intl.get('optional')})`} value={info.pay.remarks || ''}></TextLabel>
                    </div>
                </CardReview>
                <div className="edda-review-action">
                    <div className="ai-btn-primary" onClick={this.onSetupNewDeposit}>{intl.get('confirm')}</div>
                </div>
            </div>
        )
    }

    onSetupNewDeposit = () => {
        this.onCheckRisk(this.state.info);
    }

    /**
     * 定时入金过风控
     * 
     * Option 2: 预约入金
     * 
     */
    onCheckRisk = (obj) => {
        this.props.doCreateNewAppointDepositAction({
            signtp: 'timing',
            dbtNm: obj.from.accountName, // 借记名称
            dbtMmbId: obj.from.bankCode,
            dbtAcctId: obj.from.bankNo, // 借记账号
            dbtAcctcd: obj.from.dbtAcctCd, // 借记类型
            crdMmbId: obj.receive.bankCode, // 贷记银行代码
            crdNm: obj.receive.accountName, // 贷记名称
            crdAcctId: obj.receive.accountNo, // 贷记账号
            crdAcctcd: 'BBAN',
            stadat: (obj.pay.depositDate ? (new Date(obj.pay.depositDate).Format('yyyyMMdd')) : ''),
            endtp: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'repeat' ? 'number' : 'time')),
            enddat: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'ondate' ? obj.pay.expiry.value.Format('yyyyMMdd') : (obj.pay.expiry.value === 'Never' ? '' : `${obj.pay.expiry.value}`))),
            instdAmt: obj.pay.amount,
            instdCcy: 'HKD',
            period: obj.pay.frequency.value,
            ustrd: obj.pay.remarks
        }, res => {
            this.onNativeVerify(res, 1);
        })
    }

    /**
     * 根据过风控提示的核身方式进行校验，调用原生核身方式
     */
    onNativeVerify = (res, type) => {
        console.info(res);
        if (res.resultCode === 0 && res.resultData && res.resultData.body) {
            const goNativeData = res.resultData.body.actionData;
            this.goNativeCheck(goNativeData, (natRes) => {
                (natRes && natRes.outData && natRes.outData.businessNo) && this.onCheckRiskResult(res, natRes.outData.businessNo, type);
            });
        } else if (res.resultCode === 0 && res.errorData) {
            Toast.show(res.errorData.msg);
        } else {
            this.onCheckRiskResult(res, null, type);
        }
    }

    /**
     * 将风控结果提交即时/定时入金
     */
    onCheckRiskResult = (obj, businessNo, type) => {
        this.props.doTransferWithPassRiskAction({
            bizInfo: {
                trandt: obj.resultData.trandt,
                transq: obj.resultData.transq,
                busino: obj.resultData.busino,
            },
            securityResultData: {
                businessNo: businessNo,
            },
        }, res => {
            if (res.resultCode === 0) {
                Toast.show(res.errorData.msg);
            } else {
                hashHistory.push({
                    pathname: 'new-auto-deposit-result',
                    state: {
                        chnldt: res.resultData.chnldt,
                        chnlsq: res.resultData.chnlsq,
                        type
                    }
                })
            }
        });
    }

    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes)
    }
}

export default connect(function (state) {
    return {};
}, { doCreateNewAppointDepositAction, doTransferWithPassRiskAction })(SEDDAReviewFragment)