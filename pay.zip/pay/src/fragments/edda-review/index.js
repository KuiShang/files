import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import EDDAReviewAuthorization from 'components/edda-review-authorization';
import Toast from 'components/toast';
import TextLabel from 'components/text-label';
import * as SDK from 'utils/SDKUtil';
import { doTransferWithPassRiskAction } from 'redux/actions/common';
import { doSignEDDAMerchantContractAction, doUpdateSignedMerchantEDDAAction } from 'redux/actions/edda';
import './index.scss';
import intl from 'react-intl-universal';

class EDDAReviewFragment extends React.Component {
    state = {
        info: this.props.info
    }

    constructor(props) {
        super(props);

        SDK.setTitleRight({ show: 0 });
    }

    static getDerivedStateFromProps(props) {
        return {
            info: props.info
        }
    }

    render() {
        const { info } = this.state;
        if (!info || !info.detail) {
            return null;
        }

        const { expiry } = info.detail;
        let expiryValue = expiry.value;

        if (expiry && expiry.key === 'ondate' && (typeof expiry.value === 'object')) {
            expiryValue = expiry.value.Format('yyyy/MM/dd')
        } else if (expiry && expiry.key === 'never') {
            expiryValue = intl.get('no_end_date')
        } else if (expiry && expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiryValue} ${intl.get('times')}`
        }

        return (
            <div className="edda-review">
                <CardReview>
                    <div className="edda-review-sum">
                        <span className="edda-review-sum-title">{intl.get("authorisation_details")}</span>
                        {(!info.isEdit) && <span className="ai-btn-edit" onClick={this.onEditAuth}>{intl.get("change")}</span>}
                    </div>
                    <EDDAReviewAuthorization info={info}></EDDAReviewAuthorization>
                </CardReview>
                <div style={{ height: 17 }}></div>
                <CardReview>
                    <div className="edda-review-sum">
                        <span className="edda-review-sum-title">{intl.get("transfer_details")}</span>
                        <span className="ai-btn-edit" onClick={this.onEditInstruct}>{intl.get("change")}</span>
                    </div>
                    <div>
                        <TextLabel label={intl.get("debit_limit_pre_transaction")} value={`${info.detail.amount || '0.00'} HKD`}></TextLabel>
                    </div>
                    <div>
                        <TextLabel label={intl.get("frequency_limit")} value={`${intl.get(info.detail.frequency.label)}`}></TextLabel>
                    </div>
                    <div>
                        <TextLabel label={intl.get("end_date")} value={expiryValue}></TextLabel>
                    </div>
                    <div>
                        <TextLabel label={intl.get("remark")} value={`${info.detail.remarks}`}></TextLabel>
                    </div>
                </CardReview>
                <div className="edda-review-action">
                    <div className="ai-btn-primary" onClick={this.onConfirm}>{intl.get("confirm")}</div>
                </div>
            </div>
        )
    }

    /**
     * 确认eDDA商户签约
     * Option 1: 更新
     * Option 2: 新建
     */
    onConfirm = () => {
        const { info } = this.state;
        if (info.isEdit) {
            this.onUpdateSignedEDDA()
        } else {
            this.onSignedNewEDDA()
        }
    }

    onSignedNewEDDA = () => {
        const { info } = this.state;
        const { expiry } = info.detail;

        this.props.doSignEDDAMerchantContractAction({
            prdtp: info.detail.frequency.value, //频次限制
            frDt: (new Date().Format('yyyy-MM-dd')), //起始日期
            endtp: (expiry && expiry.key !== 'repeat') ? 'time' : 'number', //过期类型
            endno: ((expiry && expiry.key !== 'never') ? (expiry.key === 'ondate' ? expiry.value.Format('yyyy-MM-dd') : expiry.value.toString()) : ''), //过期值
            maxAmt: info.detail.amount,
            maxAmtCcy: 'HKD',
            crdNm: info.merchant.custnm, //贷记名称
            crdAcctId: info.merchant.proxId, //贷记账号
            crdAcctcd: info.merchant.proxTp, //贷记账号类型
            crdAgentMmbId: info.merchant.partcd, //贷记银行代码
            dbtNm: info.from.alias, //借记名称
            dbtAcctId: info.from.number, //借记账号
            dbtAcctcd: 'BBAN', //借记账号类型，签约商户的时候是无法选择FPS，所以无法预知账号类型。所以这里硬编码
            ustrd: info.detail.remarks, // 交易附言

            //// 以下字段（必填写）方便接口数据处理，需要传入
            cdtrRef: info.merchant.cdtrRef, // 商户账号
            custnm: info.merchant.custnm, // 商户名称（英文）
            ctdpnm: info.merchant.ctdpnm, // 脱敏商户名称（英文）
            chinnm: info.merchant.chinnm, // 商户名称（中文）
            chdpnm: info.merchant.chdpnm, // 脱敏商户名称（英文）
            proxId: info.merchant.proxId, // 商户FPS账户号
            proxTp: info.merchant.proxTp, // 商户FPS账户类型
            partcd: info.merchant.partcd, // 商户银行代码
            cusId: info.merchant.cusId, // 商户银行账号
            cusTp: info.merchant.cusTp, //商户类型
        }, res => {
            this.onNativeVerify(res, 1);
        });
    }

    onUpdateSignedEDDA = () => {
        const { info } = this.state;
        const { expiry } = info.detail;

        const endtp = (expiry && expiry.key !== 'repeat') ? 'time' : 'number';
        const endno = ((expiry && expiry.key !== 'never') ? (expiry.key === 'ondate' ? expiry.value.Format('yyyy-MM-dd') : expiry.value.toString()) : '');

        this.props.doUpdateSignedMerchantEDDAAction({
            mndtId: info.detail.mndtId,	// Mandate Identification	授权标识
            prdtp: info.detail.frequency.value, // 频次限制
            colltnAmt: '', // Collection Amount	固定金额
            maxAmt: info.detail.amount, // Maximum Amount	最大金额
            endtp, // 过期类型
            endno, // 过期值
            ustrd: info.detail.remarks, // 交易附言

            //// 以下字段（必填写）方便接口数据处理，需要传入
            cdtrRef: info.merchant.cdtrRef, // 商户账号
            custnm: info.merchant.custnm, // 商户名称（英文）
            ctdpnm: info.merchant.ctdpnm, // 脱敏商户名称（英文）
            chinnm: info.merchant.chinnm, // 商户名称（中文）
            chdpnm: info.merchant.chdpnm, // 脱敏商户名称（英文）
            proxId: info.merchant.proxId, // 商户FPS账户号
            proxTp: info.merchant.proxTp, // 商户FPS账户类型
            partcd: info.merchant.partcd, // 商户银行代码
            cusId: info.merchant.cusId, // 商户银行账号
            cusTp: info.merchant.cusTp, //商户类型
        }, res => {
            this.onNativeVerify(res, 1);
        });
    }

    /**
     * 根据过风控提示的核身方式进行校验，调用原生核身方式
     */
    onNativeVerify = (res, type) => {
        if (res.resultCode === 0 && res.resultData && res.resultData.body) {
            const goNativeData = res.resultData.body.actionData;
            this.goNativeCheck(goNativeData, (natRes) => {
                (natRes && natRes.outData && natRes.outData.businessNo) &&
                    this.onCheckRiskResult(res, natRes.outData.businessNo, type);
            });
        } else if (res.resultCode === 0 && res.errorData) {
            Toast.show(res.errorData.msg)
        } else if (res.resultCode === 1) {
            window.location.href = `edda-result.html#/?chnldt=${res.resultData.chnldt}&chnlsq=${res.resultData.chnlsq}`;
        }
    }

    /**
     * 调用/获取原生风控方式（例如：OTP）结果
     * @param {*} goNativeData 
     * @param {*} cb 
     */
    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes);
    }

    /**
     * 将风控结果提交设置商户EDDA
     */
    onCheckRiskResult = (obj, businessNo, type) => {
        this.props.doTransferWithPassRiskAction({
            bizInfo: {
                trandt: obj.resultData.trandt,
                transq: obj.resultData.transq,
                busino: obj.resultData.busino,
            },
            securityResultData: {
                businessNo: businessNo,
            },
        }, res => {
            if (res.resultCode === 0) {
                Toast.show(res.errorData.msg);
            } else {
                window.location.href = `edda-result.html#/?chnldt=${res.resultData.chnldt}&chnlsq=${res.resultData.chnlsq}`;
            }
        });
    }

    onEditAuth = () => {
        const { info } = this.state;
        hashHistory.push({ pathname: '/authorization', state: info })
    }

    onEditInstruct = () => {
        const { info } = this.state;
        hashHistory.push({ pathname: '/instructions', state: info })
    }
}

export default connect(function (state) {
    return {
        signMerchantContract: state.doSignEDDAMerchantContractReducer
    }
}, { doTransferWithPassRiskAction, doSignEDDAMerchantContractAction, doUpdateSignedMerchantEDDAAction })(EDDAReviewFragment)