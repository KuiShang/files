import React from 'react';
import { connect } from 'react-redux';
import intl from 'react-intl-universal';
import FilterSearch from 'components/filter-search';
import ListIndexed from 'components/list-indexed';
import PopOver from 'components/pop-over';
import Types from './Types';
import * as SDK from 'utils/SDKUtil';
import { doQueryMerchantItemsAction, doQueryMerchantTypesAction } from 'redux/actions/merchant';
import './index.scss';

class MerchantFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showType: false,
            merchantType: null,
            types: [],
            data: [],
            merchants: [],
            filter: '',
        }

    }

    searchData = {
        merchantType: null,
        isLoading: false,
        pageIndex: 0,
        pageSize: 10
    }

    static getDerivedStateFromProps(props, state) {
        let { types, data, merchants, filter } = state;

        if (filter && filter !== '') {
            merchants = data.filter(item => {
                return item.custnm.indexOf(filter) >= 0 || item.custnm.indexOf(filter.toUpperCase()) >= 0 || item.custnm.indexOf(filter.toLowerCase()) >= 0;
            })
        } else {
            merchants = data;
        }

        if (props.types.resultCode === 1) {
            types = props.types.resultData.merchtpList;
        }

        return {
            merchants,
            types,
        }
    }

    render() {
        const { merchants, showType, merchantType, types } = this.state;
        return (
            <div className="merchant" ref={(container) => this.container = container}>
                <div className="merchant-search">
                    <FilterSearch placeholder={intl.get('search')} onChange={e => this.onChange(e)}></FilterSearch>
                </div>
                <ListIndexed data={merchants} merchantType={merchantType} onSelectItem={this.onSelectItem}></ListIndexed>
                {this.isLoading && <div style={{ width: '100%', lineHeight: '20px', textAlign: 'center' }}>loading more...</div>}
                {
                    showType &&
                    <PopOver title={intl.get('filters')} visible={showType}
                        onShow={() => this.setState({ showType: !showType })}>
                        <Types data={types} type={merchantType} cancelScrollEvent={this.cancelScrollEvent} onSelectType={this.onSelectType}></Types>
                    </PopOver>
                }
            </div>
        )
    }

    componentDidMount() {
        SDK.setTitleRight({
            show: 1,
            iconUrl: require('assets/imgs/merchant/Sortlist@2x.png')
        }, () => {
            this.setState({ showType: true })
        })

        window.addEventListener('scroll', this.bindScrollEvent, false);

        const { pageIndex, pageSize } = this.searchData;

        this.isLoading = true;
        this.props.doQueryMerchantItemsAction({
            page_start: `${pageIndex}`,
            page_size: `${pageSize}`,
            merchTpList: [{ merchTp: '' }]
        }, res => {
            this.isLoading = false;
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.eddaMerch && resultData.eddaMerch.length > 0) {
                this.setState({ data: resultData.eddaMerch });
            }
        })

        this.props.doQueryMerchantTypesAction({});
    }

    componentWillMount() {
        window.removeEventListener('scroll', this.onHandleContentTouch, false);
    }

    cancelScrollEvent() {
        // this.container.style = {
        //     position:'fixed',
        //     top: '0',
        //     height: '100%',
        //     overflow: 'hidden'
        // }
    }

    bindScrollEvent = (e) => {
        let scrollHeight = Math.abs(e.srcElement.body.scrollHeight);
        let clientHeight = Math.abs(e.srcElement.body.clientHeight);
        let scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop

        if ((scrollHeight <= (clientHeight + scrollTop)) && !this.isLoading) {
            this.isLoading = true;
            this.searchData.pageIndex++;
            const { pageIndex, pageSize } = this.searchData;
            const { merchantType } = this.state;

            this.props.doQueryMerchantItemsAction({
                page_start: `${pageIndex}`,
                page_size: `${pageSize}`,
                merchTpList: [{ merchTp: merchantType ? merchantType.merchTp : '' }]
            }, res => {
                this.isLoading = false;
                const { resultCode, resultData } = res;
                if (resultCode === 1 && resultData.eddaMerch && resultData.eddaMerch.length > 0) {
                    const { data } = this.state;
                    this.setState({ data: data.concat(resultData.eddaMerch) });
                }
            })
        }
    }

    /**
     * 选择商户类型的时候，重新加载第一页的数据
     */
    onSelectType = (merchantType) => {
        this.searchData.merchantType = merchantType;
        this.searchData.pageIndex = 1;
        this.props.doQueryMerchantItemsAction({
            page_start: `1`,
            page_size: `${this.searchData.pageSize}`,
            merchTpList: [{ merchTp: merchantType.merchTp }],
        }, res => {
            this.isLoading = false;
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.eddaMerch && resultData.eddaMerch.length > 0) {
                this.setState({ data: resultData.eddaMerch, merchantType, showType: !this.state.showType });
            }
        })
    }

    onChange = (e) => {
        const option = e.target.value;
        this.setState({ filter: option })
    }

    onSelectItem = (item) => {
        SDK.closeNativeWebview(item);
    }
}

export default connect(function (state) {
    return {
        merchants: state.doQueryMerchantItemsReducer,
        types: state.doQueryMerchantTypesReducer
    }
}, { doQueryMerchantItemsAction, doQueryMerchantTypesAction })(MerchantFragment)