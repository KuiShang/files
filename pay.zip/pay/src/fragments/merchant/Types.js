import React from 'react';
import List from 'components/list';
import Item from './Item';

export default class Types extends React.Component {
    state = { data: this.props.data, type: this.props.type }

    render() {
        return (
            <div className="merchant-type">
                <List>
                    {this.renderItems()}
                </List>
            </div>

        )
    }

    componentDidMount(){
        this.props.cancelScrollEvent();
    }

    renderItems = () => {
        const { type, data } = this.state;
        return data.map((item, key) => {   
            return <Item key={key} checked={((type && type.merchTp === item.merchTp) ? true : false)} data={item} onSelect={() => this.props.onSelectType(item)}></Item>
        })
    }
}