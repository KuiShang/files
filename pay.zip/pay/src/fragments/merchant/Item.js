import React from 'react';
import imgTick from 'assets/imgs/tick/Tick.png';

export default class Item extends React.Component {
    state = { checked: this.props.checked, data: this.props.data }

    render() {
        const { checked, data } = this.state;

        return (
            <div className="merchant-type-item" onClick={() => this.props.onSelect()}>
                <div>
                    <span>{data.mctpnm}</span>
                </div>
                {
                    checked &&
                    <img alt="" src={imgTick} style={{ width: 18 }} />
                }
            </div>
        )
    }
}