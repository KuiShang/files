import React from 'react';
import { hashHistory } from 'react-router';
import { connect } from 'react-redux';
import CardReview from 'components/card-review';
import DepositFromItems from 'components/deposit-from-items';
import DepositAmount from 'components/deposit-amount';
import TextField from 'components/text-field';
import SelectCalendar from 'components/select-calendar';
import SelectFrequency from 'components/select-frequency';
import SelectField from 'components/select-field';
import PopOver from 'components/pop-over';
import DatePicker from 'components/date-picker';
import ExpiryDatePicker from 'components/expiry-date-picker';
import FrequencyPicker from 'components/frequency-picker';
import DepositFromReceive from 'components/deposit-from-receive';
import Toast from 'components/toast';
import ConfirmTerminate from './ConfirmTerminate';
import TerminateResult from './TerminateResult';
import DialogConfirmUpdateAutoDeposit from 'components/dialog-confirm-update-auto-deposit';
import intl from 'react-intl-universal'
import { doQueryEddaAction, doQuerySignEDDAResultAction } from 'redux/actions/edda';
import { doTerminateAppointDepositAction } from 'redux/actions/deposit';
import { doQueryTransferResultAction } from 'redux/actions/transfer';
import './index.scss';

class AutoDepositFragment extends React.Component {
    constructor(props) {
        super(props);

        const depositDate = (props.info && props.info.detail) ? props.info.detail.depositDate.formatDate() : new Date();
        const frequency = (props.info && props.info.detail) ? props.info.detail.frequency : { key: 'monthly', label: 'once_every_month', value: 'monthly' }
        const expiry = (props.info && props.info.detail) ? props.info.detail.expiry : { key: 'never', value: 'Never' }

        this.state = {
            info: props.info,
            showDepositDate: false,
            showFrequency: false,
            showExpiryDate: false,
            showDepositFromItems: false,
            showConfirmUpdate: false,
            showConfirmTerminate: false,
            showTerminateResult: false,
            isTerminateSuccess: false,
            amount: (props.info && props.info.detail) ? props.info.detail.amount : 0,
            remarks: (props.info && props.info.detail) ? props.info.detail.remarks : '',
            depositDate,
            frequency,
            expiry,
            eddas: [],
            isExipred: false
        }
    }

    static getDerivedStateFromProps(props, state) {
        let { info, isExpired, eddas } = state;

        if (props.eddas.resultCode === 1) {
            eddas = props.eddas.resultData.edda_relation;
        }

        if (info && info.detail && (info.detail.transt === 'Invalid' || info.detail.transt === 'Finastate')) {
            isExpired = true;
        }

        return {
            isExpired,
            eddas
        }
    }

    render() {
        const { isExpired, info, isTerminateSuccess, eddas, depositDate, frequency, expiry, showTerminateResult, showConfirmTerminate, showConfirmUpdate, showDepositFromItems, showFrequency, showExpiryDate, showDepositDate, amount, remarks } = this.state;

        return (
            <div className="deposit">
                <CardReview>
                    <DepositFromReceive data={info}></DepositFromReceive>
                </CardReview>
                <div className="deposit-row">
                    <CardReview>
                        <DepositAmount amount={amount} onChangeAmount={this.onChangeAmount}></DepositAmount>
                    </CardReview>
                </div>
                {this.renderAutoDeposit()}
                <div className="deposit-row">
                    <TextField
                        propValue={{
                            placeHolder: `${intl.get('remarks')} (${intl.get('optional')})`,
                            value: remarks
                        }}
                        stateName={'remarks'}
                        setCurrentInputData={this.onChangeMark.bind(this)}>
                    </TextField>
                </div>
                <div>
                    {isExpired && <button className="ai-btn-primary" onClick={this.onReactive}>{intl.get("reactive")}</button>}
                    {!isExpired && <div className="ai-btn-primary" onClick={() => this.setState({ showConfirmUpdate: !showConfirmUpdate })}>{intl.get("up_date")}</div>}
                    {!isExpired && <div className="ai-btn-tripple" onClick={() => this.setState({ showConfirmTerminate: !showConfirmTerminate })}>{intl.get("cancel")}</div>}                </div>
                {
                    showConfirmUpdate &&
                    <PopOver isDialog={true} disClose={true} visible={showConfirmUpdate}
                        onShow={() => this.setState({ showConfirmUpdate: !showConfirmUpdate })}>
                        <DialogConfirmUpdateAutoDeposit
                            onUpdate={this.onUpdateAutoDeposit}
                            onCancel={() => this.setState({ showConfirmUpdate: !showConfirmUpdate })}>
                        </DialogConfirmUpdateAutoDeposit>
                    </PopOver>
                }
                {
                    showDepositFromItems &&
                    <PopOver title={intl.get('deposit_from')} titleDone={intl.get('done')} visible={showDepositFromItems}
                        onShow={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}
                        onDone={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}>
                        <DepositFromItems data={eddas}></DepositFromItems>
                    </PopOver>
                }
                {
                    showDepositDate &&
                    <PopOver title={intl.get('set_start_date')} titleDone={intl.get('done')} visible={showDepositDate}
                        onShow={() => this.setState({ showDepositDate: !this.state.showDepositDate })}
                        onDone={() => this.setState({ showDepositDate: !this.state.showDepositDate })}>
                        <DatePicker date={depositDate} onSelectDate={this.onSelectDate}></DatePicker>
                    </PopOver>
                }
                {
                    showFrequency &&
                    <PopOver title={intl.get('deposit_frequency')} titleDone={intl.get('done')} visible={showFrequency}
                        onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
                        onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
                        <FrequencyPicker isSeDDA={true}
                            max={12}
                            data={frequency}
                            onSelectFrequency={this.onSelectFrequency}></FrequencyPicker>
                    </PopOver>
                }
                {
                    showExpiryDate &&
                    <PopOver title={intl.get('set_end_date')} titleDone={intl.get('done')} visible={showExpiryDate}
                        onShow={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}
                        onDone={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}>
                        <ExpiryDatePicker expiry={expiry} onSelectExpiryDate={this.onSelectExpiryDate}></ExpiryDatePicker>
                    </PopOver>
                }
                {
                    showConfirmTerminate &&
                    <PopOver isDialog={true} disClose={true} visible={showConfirmTerminate}
                        onShow={() => this.setState({ showConfirmTerminate: !showConfirmTerminate })}>
                        <ConfirmTerminate
                            onTerminate={this.onTerminateDeposit}
                            onCancel={() => this.setState({ showConfirmTerminate: !showConfirmTerminate })}>
                        </ConfirmTerminate>
                    </PopOver>
                }
                {
                    showTerminateResult &&
                    <PopOver isDialog={true} disClose={true} visible={showTerminateResult}
                        onShow={() => this.setState({ showTerminateResult: !showTerminateResult })}>
                        <TerminateResult
                            isSuccess={isTerminateSuccess}
                            onOkay={() => { window.location.href = 'bank-auto-deposit.html' }}></TerminateResult>
                    </PopOver>
                }
            </div>
        )
    }

    renderAutoDeposit = () => {
        const { showDepositDate, depositDate, frequency, expiry } = this.state;
        let expiryDate = expiry && ((expiry.key === 'ondate' && expiry.value) ? ((typeof expiry.value === 'string') ? expiry.value : expiry.value.Format('yyyy/MM/dd')) : expiry.value);
        if (expiry.key === 'never') {
            expiryDate = intl.get('no_end_date');
        }
        return (
            <React.Fragment>
                <div className="deposit-row">
                    <SelectCalendar title={intl.get('start_date')} value={depositDate}
                        onSelect={() => this.setState({ showDepositDate: !showDepositDate })}>
                    </SelectCalendar>
                </div>
                <div className="deposit-row">
                    <SelectFrequency title={intl.get('deposit_frequent')} value={frequency.label}
                        onSelect={() => this.setState({ showFrequency: true, title: 'Frequency' })}>
                    </SelectFrequency>
                </div>
                {
                    frequency.key !== 'specialdate' &&
                    <div className="deposit-row">
                        <SelectField title={intl.get('end_date')}
                            value={expiryDate}
                            onSelect={() => this.setState({ showExpiryDate: true, title: '' })}>
                        </SelectField>
                    </div>
                }
            </React.Fragment>
        )
    }

    /**
     * 查询有效的SeDDA信息
     */
    componentDidMount() {
        this.props.doQueryEddaAction({ signtp: 'deposit', eddaStu: 'Effective' }, res => { })
    }

    onShowDepositAccount = () => {
        this.setState({ showDepositFromItems: !this.state.showDepositFromItems })
    }

    onChangeAmount = (amount) => {
        this.setState({ amount });
    }

    onChangeMark = (pn, json) => {
        if (json.value.split('').length > 40) {
            return;
        }

        this.setState({ remarks: json.value })
    }

    onSelectFrequency = (item) => {
        this.setState({ showFrequency: false, frequency: item })
    }

    onSelectDate = (date) => {
        this.setState({ depositDate: date });
    }

    onSelectExpiryDate = (expiry) => {
        this.setState({ expiry })
    }

    /**
     * 终止入金流程 （即时交易）
     * 01 才去轮询结果
     * 
     * Option 1: 00 - 转账成功
     * Option 2: 01 - 初始化
     * Option 3: 02 - 失败
     * Option 4: 03 - 过风控返回
     */
    onTerminateDeposit = () => {
        const { info } = this.state;
        this.props.doTerminateAppointDepositAction({ resvid: info.detail.resvid }, res => {
            if (res.resultCode === 1 && res.resultData.transt === '00') {
                this.setState({ showConfirmTerminate: false, showTerminateResult: true, isTerminateSuccess: true });
            } else if (res.resultCode === 1 && res.resultData.transt === '02') {
                this.setState({ showConfirmTerminate: false, showTerminateResult: true, isTerminateSuccess: false });
            } else if (res.resultCode === 1 && res.resultData.transt === '01') {
                this.onQueryFPSCenter(res);
            } else if (res.resultCode === 0 && res.errorData) {
                Toast.show(res.errorData.msg);
            }
        })
    }

    /**
     * TODO：
     * 由于即时存款入金是核心即时进行的操作，所以此处的轮询插结果是没有必要的。
     * 但是，业务接口是保留了次状态（01），所以此处的轮询操作是暂时保留的。
     * 后续如果产品或者业务确认不需要01状态，那么此处轮询可以优化删除掉；
     */
    onQueryFPSCenter = (res, count) => {
        if (count > 3) {
            return;
        }

        this.props.doQueryTransferResultAction({
            inchdt: res.resultData.chnldt,
            inchsq: res.resultData.chnlsq
        }, resp => {
            const { resultCode, resultData } = resp;
            if (resultCode === 0) {
                Toast.show(resp.errorData.msg);
                return;
            }
            //// 轮询状态(2秒一循环)
            if (resultData.addrtranst === 'sendSuc' || resultData.addrtranst === 'initial') {
                setTimeout(() => { this.onQueryFPSCenter(res, ++count); }, 2000);
            } else {
                this.setState({ showTerminateResult: true, isTerminateSuccess: true });
            }
        })
    }

    /**
     * 确认进行更新操作才进入到下一个页面
     */
    onUpdateAutoDeposit = () => {
        const { showConfirmUpdate, amount, frequency, depositDate, expiry, remarks, info } = this.state;

        this.setState({ showConfirmUpdate: !showConfirmUpdate }, () => {
            hashHistory.push({
                pathname: 'auto-deposit-review',
                state: {
                    from: info.from,
                    receive: info.receive,
                    detail: {
                        amount,
                        depositDate,
                        frequency,
                        expiry,
                        remarks,
                        resvid: info.detail.resvid
                    }
                }
            })
        })
    }

    /**
     * 过期SeDDA重新激活进入预览界面
     */
    onReactive = () => {
        const { amount, frequency, depositDate, expiry, remarks, info } = this.state;

        hashHistory.push({
            pathname: 'auto-deposit-review',
            state: {
                from: info.from,
                receive: info.receive,
                detail: {
                    amount,
                    depositDate,
                    frequency,
                    expiry,
                    remarks,
                    resvid: info.detail.resvid
                }
            }
        })
    }
}

export default connect(function (state) {
    return {
        eddas: state.doQueryEddaReducer
    }
}, { doQueryEddaAction, doQueryTransferResultAction, doTerminateAppointDepositAction, doQuerySignEDDAResultAction })(AutoDepositFragment);