import React from 'react';
import intl from 'react-intl-universal'

export default class TerminateResult extends React.Component {
    state = {
        isSuccess: false
    }

    static getDerivedStateFromProps(props) {
        return {
            isSuccess: props.isSuccess
        }
    }

    render() {
        const { isSuccess } = this.state;
        return (
            <div className="dialog-small-value">
                <img alt="" src={require('assets/imgs/close-account/close-account.png')} />
                <div className="dialog-small-value-tip">
                    {isSuccess && <div style={{ color: '#848484' }}>{intl.get('auto_deposit_has')}</div>}
                    {!isSuccess && <div style={{ color: '#848484' }}>{intl.get('auto_deposit_terminate_has')}</div>}
                    {!isSuccess && <div style={{ color: '#848484' }}>{intl.get('failed_please_try_again_later')}</div>}
                </div>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-primary" onClick={() => this.props.onOkay()}>{intl.get('done')}</li>
                </ul>
            </div>
        )
    }
}