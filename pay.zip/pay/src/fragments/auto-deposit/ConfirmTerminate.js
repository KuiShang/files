import React from 'react';
import intl from 'react-intl-universal'
import imgClose from 'assets/imgs/close-account/close-account@2x.png';

export default class AutoDeposit extends React.Component {
    render() {
        return (
            <div className="dialog-small-value">
                <img alt="" src={imgClose} />
                <div className="dialog-small-value-tip">
                    <div style={{ color: '#848484' }}>{intl.get('scheduled_direct_deposit_tip_1')} </div>
                    <div style={{ color: '#848484' }}>{intl.get('scheduled_direct_deposit_tip_2')}</div>
                </div>
                <p>{intl.get('scheduled_direct_deposit_note')}</p>
                <ul className="dialog-small-value-actions">
                    <li className="ai-btn-minor" onClick={() => this.props.onTerminate()}>{intl.get('yes')}</li>
                    <li className="ai-btn-tripple" onClick={() => { this.props.onCancel && this.props.onCancel() }}>{intl.get('no')}</li>
                </ul>
            </div>
        )
    }
}