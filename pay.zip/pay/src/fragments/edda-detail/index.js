import React from 'react';
import intl from 'react-intl-universal';
import CardReview from 'components/card-review';
import DepositAmount from 'components/deposit-amount';
import DepositFrom from 'components/deposit-from';
import DepositFromReceive from 'components/deposit-from-receive'
import TextField from 'components/text-field';
import './index.scss';

export default class EDDADetailFragment extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            isNew: props.isNew
        }
    }

    static getDerivedStateFromProps(props) {
        return {
            isNew: props.isNew
        }
    }

    render() {
        const { isNew } = this.state;

        return (
            <div className="edda-new">
                {
                    isNew &&
                    <div className="edda-new-row">
                        <DepositFrom></DepositFrom>
                    </div>
                }
                {
                    !isNew &&
                    <div className="edda-new-row">
                        <CardReview>
                            <DepositFromReceive></DepositFromReceive>
                        </CardReview>
                    </div>
                }
                <div className="edda-new-row">
                    <CardReview>
                        <DepositAmount></DepositAmount>
                    </CardReview>
                </div>
                <div className="edda-new-row">
                    <TextField propValue={{ placeHolder: intl.get('start_date') }}></TextField>
                </div>
                <div className="edda-new-row">
                    <TextField
                        propValue={{ placeHolder: intl.get('frequency') }}
                        rightIconObj={{
                            iconUrl: require('assets/imgs/pulldown/pulldown-small.png'),
                            handleClick: this.setIconClick.bind(this)
                        }}></TextField>
                </div>
                <div className="edda-new-row">
                    <TextField
                        propValue={{ placeHolder: intl.get('end_date') }}
                        rightIconObj={{
                            iconUrl: require('assets/imgs/calendar/calendar@3x.svg'),
                            handleClick: this.setIconClick.bind(this)
                        }}></TextField>
                </div>
                <div className="edda-new-row">
                    <TextField propValue={{ placeHolder: `${intl.get('remarks')} (${intl.get('optional')})` }}></TextField>
                </div>
                <div className="edda-new-row" style={{ textAlign: 'center' }}>
                    {isNew && <div disabled={true} className="ai-btn-primary">{intl.get('continue')}</div>}
                    {
                        !isNew &&
                        <React.Fragment>
                            <div className="ai-btn-primary">{intl.get('up_date')}</div>
                            <div className="ai-btn-edit-primary">{intl.get('terMinate')}</div>
                        </React.Fragment>
                    }
                </div>
            </div>
        )
    }

    setIconClick = () => {

    }
}