import React from 'react';
import FilterSearch from 'components/filter-search';
import ListIndexed from 'components/list-indexed';
import { country } from './data';
import './index.scss';

export default class DialingCodeFragment extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: country
        }
    }

    render() {
        return (
            <div className="dialling-code">
                <div className="dialling-code-search">
                    <FilterSearch placeholder="Dialling Code/ Keywords" onChange={e => this.onChange(e)}></FilterSearch>
                </div>
                <ListIndexed data={this.state.data}></ListIndexed>
            </div>
        )
    }

    onChange = (e) => {
        const option = e.target.value;
        const results = country.filter((item, index) => {
            if (item.indexOf(option) >= 0) {
                return item;
            }

            return null;
        })

        this.setState({ data: results })
    }
}