import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardSwitch from 'components/card-switch';
import CardDeposit from 'components/card-deposit';
import { doQueryAppointTransferDepositRecordsAction } from 'redux/actions/common';
import { doQueryEddaAction } from 'redux/actions/edda';
import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';
import './index.scss';
import imgTip from 'assets/imgs/edda/edda.svg';

/**
 * Option 2: SeDDA
 */
class SeDDAFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            account: props.account,
            noSeDDABankAccounts: false,
            data: props.data,
            checkind: 0,
            seddas: []
        }
    }

    /**
     * Option 0: Enable 启用
     * Option 1: Invalid 失效
     * Option 2: Pending 处理中
     * Option 3: Finastate 彻底失效
     */
    static getDerivedStateFromProps(props, state) {
        let { seddas } = state;
        seddas = [];
        if (props.seddasResult && props.seddasResult.resultCode === 1) {
            seddas = props.seddasResult.resultData.result.filter(item => {
                if (state.checkind === 0 && (item.transt === 'Enable' || item.transt === 'Pending')) {
                    return item;
                } else if (state.checkind === 1 && (item.transt === 'Invalid' || item.transt === 'Finastate')) {
                    return item;
                }
            })
        }

        return {
            seddas
        }
    }

    render() {
        const { noSeDDABankAccounts } = this.state;

        return (
            <div className="edda">
                {noSeDDABankAccounts && this.renderNoSeDDABankAccounts()}
                {!noSeDDABankAccounts && this.renderSeDDABankAccounts()}
            </div>
        )
    }

    renderItems = () => {
        const { seddas, checkind } = this.state;

        if (!seddas || seddas.length <= 0) {
            return (
                <div className="edda-con-no">
                    <img alt="" src={require('assets/imgs/info/info@2x.png')} />
                    <div>{checkind === 0 ? intl.get('no_active_direct_debit_instruction') : intl.get('no_inactive_direct_debit_instruction')}</div>
                </div>
            )
        }

        return seddas.map((item, index) => {
            return <CardDeposit key={`${checkind === 0 ? 'AU' : 'EX'}-${item.resvid}`} data={item} onEdit={() => this.onEditDetail(item)}></CardDeposit>
        })
    }

    /**
     * 无主动付款授权记录
     * Option 1: SeDDA
     */
    renderNoSeDDABankAccounts = () => {
        SDK.setTopStatusBar({ title: intl.get('direct_deposit') });

        return (
            <div className="edda-no-items">
                <img alt="" src={imgTip} />
                <div className="edda-no-items-title">{intl.get('direct_deposit')}</div>
                <div className="edda-no-items-con">
                    <span>
                        <label>{intl.get('direct_deposit_collect_tips')}</label>
                    </span>
                    <span>
                        <label>{intl.get('direct_deposit_under_hkma')}</label>
                    </span>
                </div>
                <div className="ai-btn-primary" onClick={this.onSetupSeDDABankAccount}>{intl.get('set_up_immediate')}</div>
            </div>
        )
    }

    renderSeDDABankAccounts = () => {
        const { checkind } = this.state;
        SDK.setTopStatusBar({ title: intl.get('scheduled_direct_deposit') });

        return (
            <React.Fragment>
                <div className="edda-switch">
                    <CardSwitch
                        options={[intl.get('active'), intl.get('expired')]}
                        checkind={checkind}
                        onSwitch={this.onSwitch}>
                    </CardSwitch>
                </div>
                <div className="edda-con">
                    {this.renderItems()}
                </div>
                <div className='edda-actions'>
                    <div className="ai-btn-edit" style={{ margin: '23px 0 17px 0' }} onClick={this.onSeeLinkedBankAccount}>{intl.get('see_linked_bank_account')}</div>
                    <div className="ai-btn-primary" onClick={this.onSetupNewAutoDeposit}>{intl.get('sedda_schedule_deposit')}</div>
                </div>
            </React.Fragment>
        )
    }

    /**
     * SeDDA-deposit 的入口查询
     * Step 1: 查询是否有SeDDA授权账户
     */
    componentDidMount() {
        //// 查询SeDDA授权签约信息
        //// Step 1: 如果有授权信息则获取定时存款记录
        //// Step 2: 如果没有授权信息则进入账户绑定流程
        this.props.doQueryEddaAction({ signtp: 'deposit' }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.edda_relation && resultData.edda_relation.length > 0) {

                //// 查询定时存款记录
                this.props.doQueryAppointTransferDepositRecordsAction({ funcno: 'deposit' })
            } else {
                this.setState({ noSeDDABankAccounts: true })
            }
        })
    }

    onSwitch = (e) => {
        this.setState({ checkind: e })
    }

    /**
     * SeDDA授权账户列表页面
     */
    onSeeLinkedBankAccount = () => {
        window.location.href = '/pay/linked-bank.html';
    }

    /**
     * 进入SeDDA定时存款/入金签约流程
     */
    onSetupNewAutoDeposit = () => {
        hashHistory.push({
            pathname: '/new-auto-deposit',
            state: {}
        })
    }

    /**
     * 进入SeDDA银行账户绑定流程
     */
    onSetupSeDDABankAccount = () => {
        const { account } = this.state;

        hashHistory.push({
            pathname: '/deposit-account', state: {
                from: {
                    accountName: '',
                    accountNo: '',
                    type: 'BBAN',
                    bankCode: ''
                },
                receive: {
                    accountName: account.acct_name,
                    accountNo: account.acct_no,
                    idNo: '',
                    phone: '',
                    type: 'BBAN',
                }
            }
        })
    }

    onGetFrequency = (prd) => {
        const temp = frequency.filter(item => {
            return item.value === prd;
        })

        return temp.length > 0 ? temp[0] : frequency[0];
    }

    /**
     * Option 2: SeDDA跳转到New/Edit Auto Deposit
     */
    onEditDetail = (item) => {
        const { signtp, todate } = item;
        const frequency = this.onGetFrequency(item.resvpd);
        const expiry = {
            key: (todate === '') ? 'never' : (signtp === 'number' ? 'repeat' : 'ondate'),
            value: (signtp === 'number') ? todate : ((signtp === 'time' && todate === '') ? 'Never' : todate.formatDate())
        }

        hashHistory.push({
            pathname: '/auto-deposit',
            state: {
                from: {
                    accountName: item.otacna,
                    accountNo: item.otacct,
                    bankName: item.otbkna,
                    bankNo: item.otacct,
                    bankCode: item.otbkno
                },
                receive: {
                    accountName: item.inacna,
                    accountNo: item.inacct,
                    bankName: item.inbkna,
                    bankNo: item.inacct,
                    bankCode: item.inbkno
                },
                detail: {
                    amount: item.insamt,
                    depositDate: item.fmdate,
                    frequency,
                    expiry,
                    remarks: item.ustrd,
                    transt: item.transt,
                    resvid: item.resvid
                }
            }
        })
    }
}

const frequency = [
    { key: 'specialdate', label: 'on_a_specific_date', value: 'specialdate' },
    { key: 'daily', label: ("once_a_day"), value: 'daily' },
    { key: 'weekly', label: ("once_a_week"), value: 'weekly' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'biweekly' },
    { key: 'monthly', label: ("once_a_month"), value: 'monthly' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'quarterly' },
]

export default connect(function (state) {
    return {
        seddasResult: state.doQueryAppointTransferDepositRecordsReucer
    }
}, { doQueryEddaAction, doQueryAppointTransferDepositRecordsAction })(SeDDAFragment);