import React from 'react';
import { connect } from 'react-redux';
import PopOver from 'components/pop-over';
import CardSent from 'components/card-sent';
import TransactionDetail from 'components/transaction-detail';
import CollapseDetail from 'components/collapse-detail';
import DatePicker from 'components/date-picker';
import SmallTransferLimit from './SmallTransferLimit';
import { doQueryTransferResultAction, doQuerySmallTransferLimitAction } from 'redux/actions/transfer';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import imgSuccess from 'assets/imgs/success/success.svg';
import imgFailed from 'assets/imgs/error/error.png';
import imgPending from 'assets/imgs/pending/pending.png';
import './index.scss';

class ResultFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            params: props.params,
            isFetching: true,
            isFirstShow: true,
            isNeedShowSmall: false,
            isSchedule: props.params.type === 0 ? false : true,
            showDetail: false,
            showSmall: false,
            showCalendar: false,
            detail: null
        }
    }

    static getDerivedStateFromProps(props, state) {
        let { detail, isNeedShowSmall } = state;

        if (props.result.resultCode === 1) {
            detail = props.result.resultData;
        }
        if (props.result.resultCode === 1 && props.smallTransferLimit.resultCode === 1) {
            if ((props.result.resultData.ctpurp === '2' || props.result.resultData.ctpurp === '3') && props.smallTransferLimit.resultData.limit_value === 0) {
                isNeedShowSmall = true;
            } else if (props.result.resultData.ctpurp === '1') {
                isNeedShowSmall = true;
            }
        }

        return {
            detail,
            isNeedShowSmall
        }
    }

    /**
     * 交易状态
     * Option 1: 00 - 转账成功
     * Option 2: 01 - 初始化
     * Option 3: 02 - 失败
     * Option 4: 03 - 过风控返回
     * Option 5: 04 - 发送支付渠道成功
     * 
     * 请求数据完毕关闭原生Loading窗口
     */
    render() {
        const { params, detail, isFetching } = this.state;

        //// No parameters.
        if (!params || !params.chnldt || !params.chnlsq || !params.qytype) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        //// No result data.
        if (!detail) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        //// Fetching result data...
        if (isFetching) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        SDK.showNativeLoading(false);

        if (detail.transt === '00') {
            return this.renderSuccess();
        } else if (detail.transt === '02') {
            return this.renderFailed();
        } else {
            return this.renderPending();
        }
    }

    renderSuccess = () => {
        const { isFirstShow, showDetail, showSmall, showCalendar, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgSuccess} />
                    <div className="result-status-tip">
                        <span>{intl.get('transfer_complete')}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get("transfer_details")}
                        amount={detail.instdAmt}
                        alias={detail.crdNm}
                        proxyNo={detail.crdAcctId}>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? 'Show less' : 'Show More'}`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <TransactionDetail isSchedule={true} detail={detail}></TransactionDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={() => this.onDone()}>{intl.get('ok')}</button>
                    <button className="ai-btn-minor" onClick={this.onMakeAnother}>{intl.get("make_another_transfer")}</button>
                </div>
                {
                    (showSmall && isFirstShow) &&
                    <PopOver isDialog={true} visible={(showSmall && isFirstShow)}
                        onShow={() => this.setState({ showSmall: !this.state.showSmall, isFirstShow: false })}>
                        <SmallTransferLimit
                            onSetupSmallTransfer={this.onSetupSmallTransfer}
                            onNotNow={() => this.setState({ showSmall: !this.state.showSmall, isFirstShow: false })}>
                        </SmallTransferLimit>
                    </PopOver>
                }
                {
                    showCalendar &&
                    <PopOver title={intl.get('Start Date')} titleDone={intl.get('done')} visible={showCalendar}
                        onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
                        onDone={(obj) => { console.info('done action', obj) }}>
                        <DatePicker onSelectDate={(e) => { console.info(e) }}></DatePicker>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * TODO: 确定是否需要Done按钮
     *
     */
    renderFailed = () => {
        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgFailed} />
                    <div className="result-status-tip">
                        <span>{intl.get('transfer_result_failed_top')}</span>
                        <span>{intl.get('transfer_result_failed_bottom')}</span>
                    </div>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onMakeAnother}>{intl.get('try_again')}</button>

                    {/* <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onMakeAnother}>Done</button> */}

                </div>
            </div>
        )
    }

    renderPending = () => {
        const { isFirstShow, showDetail, showSmall, showCalendar, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgPending} />
                    <div className="result-status-tip">
                        <span>{intl.get('transaction_pending')}</span>
                        <span>{intl.get('transaction_pending_tips')}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get("pending")}
                        amount={detail.instdAmt}
                        alias={detail.crdNm}
                        proxyNo={detail.crdAcctId}>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? intl.get('hide_more') : intl.get('show_more')}`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <TransactionDetail isSchedule={true} detail={detail}></TransactionDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onDone}>{intl.get('ok')}</button>
                    <button className="ai-btn-minor" onClick={this.onMakeAnother}>{intl.get("make_another_transfer")}</button>
                </div>
                {
                    (showSmall && isFirstShow) &&
                    <PopOver isDialog={true} visible={(showSmall && isFirstShow)}
                        onShow={() => this.setState({ showSmall: !this.state.showSmall, isFirstShow: !this.state.isFirstShow })}>
                        <SmallTransferLimit
                            onSetupSmallTransfer={this.onSetupSmallTransfer}
                            onNotNow={() => this.setState({ showSmall: !this.state.showSmall, isFirstShow: !this.state.isFirstShow })}>
                        </SmallTransferLimit>
                    </PopOver>
                }
                {
                    showCalendar &&
                    <PopOver title={intl.get("start_date")} titleDone={intl.get("done")} visible={showCalendar}
                        onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
                        onDone={(obj) => { console.info('done action', obj) }}>
                        <DatePicker onSelectDate={(e) => { console.info(e) }}></DatePicker>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * 页面加载原生Loading界面
     * 
     * Step 1: 根据的是风控的交易流水去查询的交易结果
     * Step 2: 查询用户的小额限额是否为0
     */
    componentDidMount() {
        SDK.showNativeLoading(true);
        const { params } = this.state;

        this.onCheckResult(params, 1);

        this.props.doQuerySmallTransferLimitAction({});

        SDK.setTitleRight({
            show: 1,
            iconUrl: require('assets/imgs/share/Share.png')
        }, () => {
            const { detail } = this.state;

            SDK.buildSharePic({
                accountType: '',
                accountName: detail.crdNm,
                accountFromType: '',
                accountNum: detail.dbtAcctId,
                accountPhone: detail.crdAcctId,
                transferCode: detail.chnlcd || '',
                transferTime: detail.trandt || '',
                status: this.onCheckStatus(detail.transt),
                remarks: detail.ustrd,
                amount: thousandBitSeparator(keep2DecimalFull(detail.instdAmt || 0))
            }, res => {
                SDK.shareBySDK(res);
            })
        });
    }

    onCheckResult = (params, count) => {
        if (count > 3) {
            this.setState({ isFetching: false })
            return;
        }

        this.props.doQueryTransferResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
            qytype: params.qytype
        }, res => {
            //// SDK.showNativeLoading(false);

            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.transt === '00') {
                this.setState({ isFetching: false })
            } else if (resultCode === 1 && (resultData.transt === '02')) {
                this.setState({ isFetching: false })
            } else {
                setTimeout(() => { this.onCheckResult(params, ++count) }, 2000)
            }
        })
    }

    /**
     * Option 1: 判断该笔转账是不是小额交易
     * Option 2: 判断账户小额限额是否为0
     */
    onDone = () => {
        if (this.state.isNeedShowSmall && this.state.isFirstShow) {
            this.setState({ showSmall: true })
        } else {
            SDK.closeWebView();
            //// window.location.href = "transfer.html"
        }
    }

    onMakeAnother = () => {
        window.location.href = "transfer.html"
    }
    /**
     * 跳转到设置日转账限额页面
     */
    onSetupSmallTransfer = () => {
        const returnUrl = window.location.href;
        // window.location.href = `${window.location.origin}/pay/transfer-settings.html#/SetLimit?type=2&returnUrl${returnUrl}`;
        const url = `${window.location.origin}/pay/transfer-settings.html#/SetLimit?type=2&returnUrl=`
        // "Recipient's Bank"
        SDK.goNativeWebview(url, (res) => {
            // 关闭WEBVIEW的回调
        });
    }

    /**
     * 交易状态
     * Option 1: 00 - 转账成功
     * Option 2: 01 - 初始化
     * Option 3: 02 - 失败
     * Option 4: 03 - 过风控返回
     * Option 5: 04 - 发送支付渠道成功
     */
    onCheckStatus = (code) => {
        const status = [
            { key: '00', value: '转账成功' },
            { key: '01', value: '初始化' },
            { key: '02', value: '失败' },
            { key: '03', value: '过风控返回' },
            { key: '04', value: '发送支付渠道成功' },
        ]

        const temp = status.filter(item => {
            return item.key === code;
        })

        return (temp && temp.length > 0) ? temp[0].value : '';
    }
}

function mapStateFromProps(state) {
    return {
        result: state.doQueryTransferResultReducer,
        smallTransferLimit: state.doQuerySmallTransferLimitReducer
    }
}

export default connect(mapStateFromProps, { doQueryTransferResultAction, doQuerySmallTransferLimitAction })(ResultFragment)