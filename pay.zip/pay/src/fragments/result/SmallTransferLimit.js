import React from 'react';
import intl from 'react-intl-universal';
import imgSuccess from 'assets/imgs/result/transfer-success.svg';

export default class SmallTransferLimit extends React.Component {
    render() {
        return (
            <div className="dialog-small-value">
                <img alt="" src={imgSuccess} />
                {/* <div>Setup Daily Transfer Limit</div> */}
                <div className="dialog-small-value-tip">
                    {/* <div style={{ color: '#848484' }}>Set up Small-Value for </div>
                    <div style={{ color: '#848484' }}>faster processing</div> */}
                    <div>{intl.get('small_value_transfer')}</div>
                </div>
                <ul className="dialog-small-value-actions">
                    <li style={{ color: '#008ecc' }} onClick={this.onSetupSmallTransfer}>{intl.get('activate_now')}</li>
                    <li onClick={this.onNotNow}>{intl.get('do_it_later')}</li>
                </ul>
            </div>
        )
    }

    onSetupSmallTransfer = () => {
        this.props.onSetupSmallTransfer && this.props.onSetupSmallTransfer();
    }

    onNotNow = () => {
        this.props.onNotNow && this.props.onNotNow();
    }
}