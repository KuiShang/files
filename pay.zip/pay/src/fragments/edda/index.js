import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardSwitch from 'components/card-switch';
import CardEDDA from 'components/card-edda';
import { doQueryEddaAction } from 'redux/actions/edda';
import { doQueryTransferLimitAction } from 'redux/actions/transfer';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import './index.scss';
import imgTip from 'assets/imgs/edda/edda.svg';

/**
 * Option 1: eDDA
 */
class EDDAFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isLoading: false,
            account: props.account,
            data: props.data,
            checkind: 0,
            hasTabs: false,
            eddas: [],
            limit_value: 0,
        }

        SDK.setTopStatusBar({ title: intl.get("payment_authorization") });
    }

    /**
     * Option 0: 激活状态 bindsuc/unbindfail/changesuc/changefail/suspfail 
     * Option 1: 过期状态 bindfail/unbindsuc/suspsuc
     * Option 2: 签约状态 binding
     * Option 3: 中间状态 unbinding/changing/susping
     */
    static getDerivedStateFromProps(props, state) {
        let { isLoading, eddas, hasTabs, limit_value } = state;
        eddas = [];
        if (props.eddaResult.resultCode === 1) {
            eddas = props.eddaResult.resultData.edda_relation.filter(item => {
                if (state.checkind === 0 && (item.eddaStatus === 'bindsuc' || item.eddaStatus === 'unbindfail' ||
                    item.eddaStatus === 'changesuc' || item.eddaStatus === 'changefail' || item.eddaStatus === 'suspfail' ||
                    item.eddaStatus === 'binding' || item.eddaStatus === 'changing' || item.eddaStatus === 'unbinding')) {
                    return item;
                } else if (state.checkind === 1 && (item.eddaStatus === 'bindfail' || item.eddaStatus === 'unbindsuc' || item.eddaStatus === 'suspsuc')) {
                    return item;
                }
            })

            if (props.eddaResult.resultData.edda_relation.length > 0) {
                hasTabs = true;
            } else {
                hasTabs = false;
            }
        }

        if (props.limit && props.limit.resultCode === 1) {
            limit_value = props.limit.resultData.limit_value;
        }

        if (props.eddaResult.isLoading || props.transferLimit.isLoading) {
            isLoading = true;
        } else {
            isLoading = false;
        }

        return {
            isLoading,
            eddas,
            hasTabs,
            limit_value
        }
    }

    render() {
        const { isLoading, hasTabs, checkind, eddas } = this.state;

        if (isLoading) {
            return null;
        }

        return (
            <div className="edda">
                {(eddas && eddas.length <= 0 && !hasTabs) && this.renderNoItems()}
                {(eddas && hasTabs) &&
                    <React.Fragment>
                        <div className="edda-switch">
                            <CardSwitch
                                options={[intl.get("active"), intl.get("expired")]}
                                checkind={checkind}
                                onSwitch={this.onSwitch}>
                            </CardSwitch>
                        </div>
                        <div className="edda-con">
                            {this.renderItems()}
                        </div>
                        <div className='edda-actions'>
                            <div className="ai-btn-primary" onClick={this.onSetupEDDA}>{intl.get("set_up_direct_debit")}</div>
                        </div>
                    </React.Fragment>
                }
            </div>
        )
    }

    renderItems = () => {
        const { eddas, checkind } = this.state;
        if (eddas && eddas.length <= 0) {
            return (
                <div className="edda-con-no">
                    <img alt="" src={require('assets/imgs/info/info@2x.png')} />
                    <div>{checkind === 0 ? intl.get('no_active_direct_debit') : intl.get('no_expired_direct_debit')}</div>
                </div>
            );
        }

        return eddas.map((item, index) => {
            return <CardEDDA key={`${checkind === 0 ? 'AU' : 'EX'}-${item.resdid}`} data={item} onEdit={() => this.onEditDetail(item)}></CardEDDA>
        })
    }

    /**
     * 无主动付款授权记录
     * Option 1: SeDDA
     * Option 2: eDDA
     */
    renderNoItems = () => {
        return (
            <div className="edda-no-items">
                <img alt="" src={imgTip} />
                <div className="edda-no-items-title">{intl.get("set_auto_direct_debit")}</div>
                <div className="edda-no-items-con-e">
                    <span>{intl.get("pay_authorised_merchant_auto")}</span>
                </div>
                <div className="ai-btn-primary" onClick={this.onSetupEDDA}>{intl.get("set_up_direct_debit")}</div>
            </div>
        )
    }

    /**
     * EDDA-merchant 的入口查询
     */
    componentDidMount() {
        const { account } = this.state;

        //// 查询eDDA授权签约信息
        this.props.doQueryEddaAction({ signtp: 'merchant' })

        //// 获取转账限额
        //// 转账限额小于等于0则弹出需要设置转账限额弹框
        this.props.doQueryTransferLimitAction({
            acct_type: account.acct_type,
            acct_no: account.acct_no,
        }, res => {
            if (res.resultCode === 1) {
                this.setState({ limit_value: res.resultData.limit_value })
            }
        });
    }

    onSwitch = (e) => {
        this.setState({ checkind: e })
    }

    /**
     * 进入商户eDDA签约流程
     */
    onSetupEDDA = () => {
        hashHistory.push({ pathname: '/authorization', state: {} })
    }

    onGetFrequency = (prd) => {
        const temp = frequencies.filter(item => {
            return item.value === prd;
        })

        return temp.length > 0 ? temp[0] : frequencies[0];
    }

    /**
     * Option 1: eDDA跳转到设置账号信息
     */
    onEditDetail = (detail) => {
        const { account, limit_value } = this.state;
        const frequency = this.onGetFrequency(detail.prd)
        const { endtp, endnum, toDt } = detail;

        let expiry = {
            key: (endtp === 'number') ? 'repeat' : ((endtp === 'time' && toDt === '') ? 'never' : 'ondate'),
            value: (endtp === 'number') ? endnum : ((endtp === 'time' && toDt === '') ? 'Never' : toDt)
        }

        if (expiry.key === 'ondate') {
            expiry.value = new Date(toDt);
        }

        hashHistory.push({
            pathname: '/instructions', state: {
                isEdit: true,
                mndtId: detail.mndtId,
                from: {
                    alias: account.acct_name,
                    number: account.acct_no,
                    limit_value
                },
                merchant: {
                    alias: detail.crdNm,
                    cdtrRef: detail.cdtrRef,
                    custnm: detail.crdNm, //贷记名称
                    proxId: detail.crdAcctId, //贷记账号
                    proxTp: detail.crdAcctCd, //贷记账号类型
                    partcd: detail.crdMmbId, //贷记银行代码
                    // cdtrRef: detail.cdtrRef, // 商户账号
                    // custnm: detail.custnm, // 商户名称（英文）
                    ctdpnm: detail.ctdpnm, // 脱敏商户名称（英文）
                    chinnm: detail.chinnm, // 商户名称（中文）
                    chdpnm: detail.chdpnm, // 脱敏商户名称（英文）
                    // proxId: detail.proxId, // 商户FPS账户号
                    // proxTp: detail.proxTp, // 商户FPS账户类型
                    partcd: detail.partcd, // 商户银行代码
                    cusId: detail.cusId, // 商户银行账号
                    cusTp: detail.cusTp, //商户类型
                },
                detail: {
                    mndtId: detail.mndtId,
                    amount: detail.maxAmt,
                    frequency,
                    expiry,
                    remarks: detail.ustrd,
                    eddaStatus: detail.eddaStatus
                }
            }
        })
    }
}

const frequencies = [
    { key: 'daily', label: ('once_every_day'), value: 'DAIL' },
    { key: 'weekly', label: ('once_every_week'), value: 'WEEK' },
    { key: 'biweekly', label: ("once_every_2_weeks"), value: 'FRTN' },
    { key: 'monthly', label: ('once_every_month'), value: 'MNTH' },
    { key: 'quarterly', label: ("once_a_quarter"), value: 'QURT' },
]

export default connect(function (state) {
    return {
        eddaResult: state.doQueryEddaReducer,
        transferLimit: state.doQueryTransferLimitReducer
    }
}, { doQueryEddaAction, doQueryTransferLimitAction })(EDDAFragment);