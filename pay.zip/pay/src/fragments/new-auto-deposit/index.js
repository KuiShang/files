import React from 'react';
import { hashHistory } from 'react-router';
import { connect } from 'react-redux';
import CardReview from 'components/card-review';
import DepositFrom from 'components/deposit-from';
import DepositFromItems from 'components/deposit-from-items';
import DepositAmount from 'components/deposit-amount';
import TextField from 'components/text-field';
import SelectCalendar from 'components/select-calendar';
import SelectFrequency from 'components/select-frequency';
import SelectField from 'components/select-field';
import PopOver from 'components/pop-over';
import DialogSeDDAPendingTip from 'components/dialog-sedda-pending-tip';
import Toast from 'components/toast';
import DatePicker from 'components/date-picker';
import ExpiryDatePicker from 'components/expiry-date-picker';
import FrequencyPicker from 'components/frequency-picker';
import intl from 'react-intl-universal';
import { doQueryEddaAction } from 'redux/actions/edda';
import './index.scss';

class NewAutoDepositFragment extends React.Component {
    constructor(props) {
        super(props);

        const now = new Date();
        const nowT1 = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
        this.state = {
            account: props.account,
            showDepositDate: false,
            showFrequency: false,
            showExpiryDate: false,
            showDepositFromItems: false,
            showSeDDAPendingTip: false,
            amount: 0,
            remarks: '',
            depositAccount: null,
            depositDate: nowT1,
            frequency: {
                key: 'monthly', label: 'once_every_month', value: 'monthly'
            },
            expiry: {
                key: 'never', value: 'Never'
            },
            eddas: [],

            beforeIndex: 0,
        }
    }

    static getDerivedStateFromProps(props) {
        if (props.eddas.resultCode === 1) {
            return {
                eddas: props.eddas.resultData.edda_relation
            }
        }
    }

    render() {
        const { eddas, depositAccount, depositDate, frequency, expiry, showSeDDAPendingTip, showDepositFromItems, showFrequency, showExpiryDate, showDepositDate, amount, remarks } = this.state;

        return (
            <div className="deposit">
                <div className="deposit-row">
                    <DepositFrom data={depositAccount} onShowDepositAccount={this.onShowDepositAccount}></DepositFrom>
                </div>
                <div className="deposit-row">
                    <CardReview>
                        <DepositAmount amount={amount} onChangeAmount={this.onChangeAmount}>
                        </DepositAmount>
                    </CardReview>
                </div>
                {this.renderAutoDeposit()}
                <div className="deposit-row">
                    <TextField
                        propValue={{
                            placeHolder: `${intl.get('remarks')}(${intl.get('optional')})`,
                            value: remarks
                        }}
                        stateName={'remarks'}
                        setCurrentInputData={this.onChangeMark.bind(this)}>
                    </TextField>
                </div>
                <div>
                    <div disabled={(depositAccount && depositAccount.eddaStatus !== "binding") ? false : true} className="ai-btn-primary" onClick={this.onReview}>{intl.get('continue')}</div>
                </div>
                {
                    showDepositFromItems &&
                    <PopOver title={intl.get('deposit_from')} titleDone={intl.get('done')} visible={showDepositFromItems}
                        onShow={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}
                        onDone={() => this.setState({ showDepositFromItems: !this.state.showDepositFromItems })}>
                        <DepositFromItems data={eddas} checkedItem={depositAccount} onSelectDepositAccount={this.onSelectDepositAccount} onNewBankAccount={this.onNewBankAccount}></DepositFromItems>
                    </PopOver>
                }
                {
                    showDepositDate &&
                    <PopOver title={intl.get('set_start_date')} titleDone={intl.get('done')} visible={showDepositDate}
                        onShow={() => this.setState({ showDepositDate: !this.state.showDepositDate })}
                        onDone={() => this.setState({ showDepositDate: !this.state.showDepositDate })}>
                        <DatePicker date={depositDate} onSelectDate={this.onSelectDate}></DatePicker>
                    </PopOver>
                }
                {
                    showFrequency &&
                    <PopOver title={intl.get('deposit_frequency')} titleDone={intl.get('done')} visible={showFrequency}
                        onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
                        onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
                        <FrequencyPicker
                            isSeDDA={true}
                            max={12}
                            data={frequency}
                            onSelectFrequency={this.onSelectFrequency}>
                        </FrequencyPicker>
                    </PopOver>
                }
                {
                    showExpiryDate &&
                    <PopOver title={intl.get('set_end_date')} titleDone={intl.get('done')} visible={showExpiryDate}
                        onShow={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}
                        onDone={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}>
                        <ExpiryDatePicker expiry={expiry} onSelectExpiryDate={this.onSelectExpiryDate}></ExpiryDatePicker>
                    </PopOver>
                }
                {
                    showSeDDAPendingTip &&
                    <PopOver isDialog={true} visible={showSeDDAPendingTip}
                        onShow={() => this.setState({ showSeDDAPendingTip: !showSeDDAPendingTip })}>
                        <DialogSeDDAPendingTip onOkay={() => this.onReview()}>
                        </DialogSeDDAPendingTip>
                    </PopOver>
                }
            </div>
        )
    }

    renderAutoDeposit = () => {
        const { showDepositDate, frequency, depositDate, expiry } = this.state;
        let expiryValue = expiry && ((expiry.key === 'ondate' && expiry.value) ? expiry.value.Format('yyyy/MM/dd') : expiry.value);
        if (expiry && expiry.key === 'never') {
            expiryValue = intl.get('no_end_date');
        } else if (expiry && expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiry.value} ${intl.get('times')}`
        }

        return (
            <React.Fragment>
                <div className="deposit-row">
                    <SelectCalendar title={intl.get('start_date')} value={depositDate}
                        onSelect={() => this.setState({ showDepositDate: !showDepositDate })}>
                    </SelectCalendar>
                </div>
                <div className="deposit-row">
                    <SelectFrequency title={intl.get('deposit_frequent')} value={frequency.label}
                        onSelect={() => this.setState({ showFrequency: true, title: intl.get('deposit_frequent') })}>
                    </SelectFrequency>
                </div>
                {
                    frequency.key !== 'specialdate' &&
                    <div className="deposit-row">
                        <SelectField title={intl.get('end_date')}
                            value={expiryValue}
                            onSelect={() => this.setState({ showExpiryDate: true, title: '' })}>
                        </SelectField>
                    </div>
                }
            </React.Fragment>
        )
    }

    /**
     * 查询有效的SEDDA信息
     */
    componentDidMount() {
        this.props.doQueryEddaAction({ signtp: "deposit", eddaStu: 'Effective' }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && resultData.edda_relation && resultData.edda_relation.length > 0) {
                this.setState({ depositAccount: resultData.edda_relation[0] })
            }
        })
    }

    onSwitch = (checkind) => {
        this.setState({ checkind })
    }

    onShowDepositAccount = () => {
        this.setState({ showDepositFromItems: !this.state.showDepositFromItems })
    }

    onChangeAmount = (amount) => {
        this.setState({ amount });
    }

    onChangeMark = (pn, json) => {
        if (json.value.split('').length > 50) {
            return;
        }

        this.setState({ remarks: json.value })
    }

    onSelectDepositAccount = (item, currentIndex) => {
        let eddas = this.state.eddas;

        eddas.map((item, index) => {
            if (index === currentIndex) {
                item.checked = true;
            } else if (index !== currentIndex) {
                item.checked = false
            }
        })

        this.setState({
            depositAccount: item,
            eddas: eddas
        })
    }

    onSelectFrequency = (item) => {
        this.setState({ showFrequency: false, frequency: item })
    }

    onSelectDate = (date) => {
        this.setState({ depositDate: date });
    }

    onSelectExpiryDate = (expiry) => {
        this.setState({ expiry })
    }

    onNewBankAccount = () => {
        hashHistory.push({ pathname: 'deposit-account', state: {} })
    }

    onReview = () => {
        const { account, amount, depositAccount, depositDate, frequency, expiry, remarks } = this.state;

        if (depositAccount.eddaStatus === "binding") {
            Toast.show('签约中不可转账')
            return;
        }

        const now = new Date();
        if (depositDate <= now) {
            Toast.show('开始日期必须大于等于T+1')
            return;
        }

        if (depositAccount && depositAccount.eddaStatus !== 'bindsuc' && !this.state.showSeDDAPendingTip) {
            this.setState({ showSeDDAPendingTip: true });
            return;
        }

        if (amount <= 0 || amount === '') {
            Toast.show('金额必须大于0');
            return;
        }

        hashHistory.push({
            pathname: 'new-auto-deposit-review',
            state: {
                from: {
                    accountName: depositAccount.dbtNm,
                    accountNo: '',
                    bankName: depositAccount.dbtMmbNa,
                    bankNo: depositAccount.dbtAcctId,
                    bankCode: depositAccount.dbtMmbId,
                    dbtAcctCd: (depositAccount && depositAccount.dbtAcctCd),
                    ...depositAccount
                },
                receive: {
                    accountName: account.acct_name,
                    accountNo: account.acct_no,
                },
                pay: {
                    amount,
                    depositDate,
                    frequency,
                    expiry,
                    remarks
                }
            }
        })
    }
}

export default connect(function (state) {
    return {
        eddas: state.doQueryEddaReducer
    }
}, { doQueryEddaAction })(NewAutoDepositFragment);