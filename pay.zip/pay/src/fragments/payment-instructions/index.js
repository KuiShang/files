import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardSwitch from 'components/card-switch';
import PaymentInstructionsTo from 'components/payment-instructions-to';
import TextField from 'components/text-field';
import SelectCalendar from 'components/select-calendar';
import SelectFrequency from 'components/select-frequency';
import SelectField from 'components/select-field';
import PopOver from 'components/pop-over';
import DatePicker from 'components/date-picker';
import FrequencyPicker from 'components/frequency-picker';
import ExpiryDatePicker from 'components/expiry-date-picker';
import Toast from 'components/toast';
import { doQueryPlanTransferAction } from 'redux/actions/transfer';
import * as SDK from 'utils/SDKUtil';
import * as Constants from 'utils/ConstantsUtil';
import intl from 'react-intl-universal';
import './index.scss';

async function doGetTransferInfo() {
    return await SDK.getCache(Constants.TRANSFER_INFO, 0);
}

class PaymentInstructionsFragment extends React.Component {
    constructor(props) {
        super(props);

        let info = props.info ? props.info : {
            from: {
                accountNo: '',
                balance: 0,
                limit_value: 0
            },
            to: {
                alias: '',
                number: '',
                isDefaultBank: true,
                bankDes: '',
                bankCode: ''
            }
        }

        SDK.getCache(Constants.TRANSFER_INFO, 0, res => {
            //alert('production' + JSON.stringify(res))
        });

        const cacheInfo = doGetTransferInfo();

        const now = new Date();
        const nowT1 = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
        const amount = (info && info.pay && info.pay.amount) ? info.pay.amount : 0;
        const mark = (info && info.pay && info.pay.remarks) ? info.pay.remarks : "";
        const isNow = (info && info.pay && info.pay.isNow) ? info.pay.isNow : 0;
        const frequency = (info && info.pay && info.pay.frequency) ? info.pay.frequency : {
            key: 'specialdate',
            label: 'on_a_specific_date',
            value: 'specialdate'
        }
        const startDate = (info && info.pay && info.pay.startDate) ? info.pay.startDate : nowT1;
        const endDate = (info && info.pay && info.pay.endDate) ? info.pay.endDate : nowT1;
        let isEdit = false, expiry = { key: 'never', value: 'Never' };

        if (info) {
            isEdit = info.from.isEdit;

            if (isEdit && info.pay) {
                expiry = info.pay.expiry;
            }
        }

        this.state = {
            isEdit,
            info,
            curIndex: 0,
            showFrequency: false,
            showCalendar: false,
            showExpiryDate: false,
            showEndDate: false,
            title: '',
            checkind: isNow === 0 ? 0 : 1,
            frequency,
            amount: amount,
            mark: mark,
            type: 0,
            startDate: startDate,
            endDate: endDate,
            expiry
        }
    }

    static getDerivedStateFromProps(props, state) {
        return {
            showEndDate: (state.frequency.key !== 'specialdate') ? true : false
        };
    }

    render() {
        const { info, amount, checkind, curIndex, title, frequency, type, expiry, startDate, endDate, showFrequency, showCalendar, showEndDate, showExpiryDate } = this.state;
        let expiryValue = expiry.value;
        if (expiry && expiry.key === 'ondate') {
            expiryValue = expiry.value.Format('yyyy/MM/dd');
        } else if (expiry && expiry.key === 'repeat') {
            expiryValue = `${intl.get('repeat')} ${expiry.value} ${intl.get('time')}`;
        } else if (expiry && expiry.key === 'never') {
            expiryValue = intl.get('no_end_date');
        }

        return (
            <div className="payment-instructions">
                <PaymentInstructionsTo info={info} amount={amount} onChangeAmount={this.onChangeAmount}></PaymentInstructionsTo>
                <div className="payment-instructions-transfer">
                    <CardSwitch
                        title={intl.get('when_to_transfer')}
                        options={[intl.get('now'), intl.get('later')]}
                        checkind={checkind}
                        onSwitch={this.onSwitch}>
                    </CardSwitch>
                </div>
                {
                    (checkind === 1) &&
                    (
                        <React.Fragment>
                            <div className="payment-instructions-schedule">
                                <SelectFrequency title={intl.get('frequency')} value={frequency.label} onSelect={() => this.setState({ showFrequency: true, title: 'Frequency' })}></SelectFrequency>
                            </div>
                            {
                                curIndex !== 2 &&
                                <div className="payment-instructions-mark">
                                    <SelectCalendar title={intl.get('start_date')} value={startDate} onSelect={() => this.onShowDatePicker(0)}></SelectCalendar>
                                </div>
                            }
                            {
                                (curIndex !== 2 && showEndDate) &&
                                <div className="payment-instructions-mark">
                                    <SelectField
                                        title={intl.get('end_date')}
                                        value={expiryValue}
                                        onSelect={() => this.setState({ showExpiryDate: !showExpiryDate })}>
                                    </SelectField>
                                </div>
                            }
                        </React.Fragment>
                    )
                }
                <div className="payment-instructions-mark">
                    <TextField
                        propValue={{ placeHolder: intl.get("remarks_optional"), value: this.state.mark }}
                        stateName={'mark'}
                        setCurrentInputData={this.onChangeMark.bind(this)}>
                    </TextField>
                </div>
                {
                    checkind === 1 &&
                    <div className="payment-instructions-info">
                        {intl.get("avoid_potential_fees_keeping_sufficient_funds")}
                    </div>
                }
                <div className="payment-instructions-actions">
                    <button className="ai-btn-primary" onClick={this.onPreview}>{intl.get("transfer_continue")}</button>
                </div>
                {
                    showCalendar &&
                    <PopOver title={intl.get('set_start_date')} visible={showCalendar} titleDone={intl.get('done')}
                        onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
                        onDone={() => this.setState({ showCalendar: !this.state.showCalendar })}>
                        <DatePicker date={(type === 0 ? startDate : endDate)} onSelectDate={this.onSelectDate}></DatePicker>
                    </PopOver>
                }
                {
                    showFrequency &&
                    <PopOver title={intl.get('set_frequency')} visible={showFrequency}
                        onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
                        onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
                        <FrequencyPicker isTransfer={true} data={frequency} onSelectFrequency={this.onSelectFrequency}></FrequencyPicker>
                    </PopOver>
                }
                {
                    showExpiryDate &&
                    <PopOver visible={showExpiryDate}
                        title={intl.get('set_end_date')}
                        titleDone={intl.get('done')}
                        onShow={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}
                        onDone={() => this.setState({ showExpiryDate: !this.state.showExpiryDate })}>
                        <ExpiryDatePicker
                            max={12}
                            expiry={expiry}
                            onSelectExpiryDate={this.onSelectExpiryDate}>
                        </ExpiryDatePicker>
                    </PopOver>
                }
            </div>
        )
    }

    onSwitch = (e) => {
        this.setState({ checkind: e })
    }

    /**
     * 跳转到预览界面
     * Option 1: 即时转账直接跳转到预览界面；
     * Option 2: 预约转账先要查询预约转账的单子是否小于10笔。大于10就TOAST提醒用户；小于10跳转到预览界面；
     */
    onPreview = () => {
        const { frequency, checkind, amount, startDate, endDate, expiry, info } = this.state;

        //// 转账金额必须大于0
        if (amount <= 0) {
            Toast.show('转账金额必须大于0')
            return
        }

        //// 转账金额必须小于余额
        if (amount > info.from.balance) {
            Toast.show('转账金额必须小于余额')
            return
        }

        //// 转账金额必须小于日限额
        if (amount > info.from.limit_value) {
            Toast.show('转账金额必须小于日限额')
            return
        }

        //// 预约转账开始日期必须大于等于T+1
        //// 预约转账结束日期必须大于开始日期
        if (checkind === 1) {
            const now = new Date();
            if (startDate <= now) {
                Toast.show('开始日期必须大于等于T+1')
                return;
            }

            if (frequency.key !== 'specialdate' && expiry.key === 'ondate' && expiry.value < startDate) {
                Toast.show('结束日期必须大于等于开始日期')
                return;
            }
        }

        if (checkind !== 0) {
            this.props.doQueryPlanTransferAction({ funcno: 'withdraw' }, res => {
                if (res.resultCode === 1) {
                    // if (res.resultData.count >= 10) {
                    //     Toast.show('预约转账单已经达到10笔');
                    //     return;
                    // }

                    this.onNavigateReview();
                } else {
                    Toast.show(res.errorData.msg)
                }
            })
        } else {
            this.onNavigateReview();
        }
    }

    /**
     * 跳转到预览界面
     */
    onNavigateReview = () => {
        const { info, checkind, amount, mark, frequency, startDate, endDate, expiry } = this.state;

        const obj = {
            from: {
                ...info.from,
                accountNo: info.from.accountNo,
                accountName: info.from.accountName,
                balance: info.from.balance,
                limit_value: info.from.limit_value
            },
            to: {
                ...info.to,
                payeeName: info.to.payeeName,
                bankAccountNo: info.to.bankAccountNo,
                transferType: info.to.transferType,
                alias: info.to.alias,
                number: info.to.number,
                accountDes: '',
                isDefaultBank: info.to.isDefaultBank,
                bankCode: info.to.bankCode,
                bankDes: info.to.bankDes,
                otherBank: info.to.otherBank || null
            },
            pay: {
                amount: amount,
                isNow: checkind,
                frequency: frequency,
                startDate: startDate,
                endDate: endDate,
                remarks: mark,
                expiry
            },
            selectRecipient: info.selectRecipient,
            bankAccount: info.bankAccount,
            mobile: info.mobile,
            email: info.email,
            fps: info.fps
        }

        SDK.setCache(Constants.TRANSFER_INFO, obj, 2);

        hashHistory.push({
            pathname: '/review',
            state: obj
        });
    }

    /**
     * 修改金额数
     */
    onChangeAmount = (amount) => {
        this.setState({ amount })
    }

    /**
     * 转账附言最多40个字符
     */
    onChangeMark = (pn, json) => {
        if (json.value.split('').length > 40) {
            return;
        }

        this.setState({ mark: json.value })
    }

    onSelectDate = (date) => {
        const { type } = this.state;
        if (type === 0) {
            this.setState({ startDate: date });
        } else if (type === 1) {
            this.setState({ endDate: date });
        }
    }

    onCheckSchedule = (e) => {
        this.setState({ curIndex: e })
    }

    onSelectFrequency = (item) => {
        this.setState({ showFrequency: false, frequency: item })
    }

    onShowDatePicker = (type) => {
        this.setState({ showCalendar: true, title: type === 0 ? intl.get('start_date') : intl.get('end_date'), type: type });
    }

    onSelectExpiryDate = (expiry) => {
        this.setState({ expiry });
    }
}

export default connect(function (state) {
    return null
}, { doQueryPlanTransferAction })(PaymentInstructionsFragment);