import React from 'react';
import { connect } from 'react-redux';
import FilterSearch from 'components/filter-search';
import List from 'components/list';
import ItemBankCode from 'components/item-bank-code';
import { doQueryBanksAction, doSelectRecipientBankAction } from 'redux/actions/common';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import './index.scss';

class BankCodeFragment extends React.Component {
    state = {
        data: {
            popular_banks_list: [],
            info: []
        }
    }

    render() {
        const { data } = this.state;

        return (
            <div className="bank-code">
                <div style={{ margin: '26px 20px' }}>
                    <FilterSearch placeholder={intl.get('search')} onChange={e => this.onChange(e)}></FilterSearch>
                </div>
                <div className="ai-item-indexed">{intl.get('popular_list')}</div>
                <div className='bank-code-list'>
                    <List>
                        {
                            data && data.popular_banks_list.map((item, index) => {
                                return <ItemBankCode key={`PBL_${item.bank_code}_${index}`} data={item} onSelect={() => this.onSelect(item)}></ItemBankCode>
                            })
                        }
                    </List>
                </div>
                <div className="ai-item-indexed">{intl.get('more')}</div>
                <div className='bank-code-list'>
                    <List>
                        {
                            data && data.info.map((item, index) => {
                                return <ItemBankCode key={`IN_${item.bank_code}_${index}`} data={item} onSelect={() => this.onSelect(item)}></ItemBankCode>
                            })
                        }
                    </List>
                </div>
            </div>
        )
    }

    /**
     * 查询银行列表时，需要设置参数:币种(ccy_code 硬编码 HKD),是否允许绑定(isBind  0-否 1-是 签约时需要设置为1)
     * 除了签约送1，其他情况不送（为null）
     * URL中含有ref=tran，证明是从转账中打开的列表；
     */
    componentDidMount() {
        let isBind = null;
        if (window.location.search.indexOf("ref=tran") < 0) {
            isBind = 1;
        }

        this.props.doQueryBanksAction({ ccy_code: 'HKD', isBind }, res => {
            if (res.resultCode === 1) {
                this.setState({ data: res.resultData });
            }
        });
    }

    onChange = (e) => {
        const { banks } = this.props;
        const option = e.target.value;
        const popular = banks.resultData.popular_banks_list.filter((item) => {
            if ((item.bank_code.indexOf(option) >= 0) || (item.bank_en_name.indexOf(option) >= 0)) {
                return item;
            }

            return null;
        })

        const common = banks.resultData.info.filter((item) => {
            if ((item.bank_code.indexOf(option) >= 0) || (item.bank_en_name.indexOf(option) >= 0)) {
                return item;
            }

            return null;
        })

        this.setState({
            data: {
                popular_banks_list: popular,
                info: common
            }
        })
    }

    onSelect = (item) => {
        SDK.closeNativeWebview(item);
    }
}

function mapStateFromProps(state) {
    return {
        banks: state.doQueryBanksReducer
    }
}

export default connect(mapStateFromProps, { doQueryBanksAction, doSelectRecipientBankAction })(BankCodeFragment)