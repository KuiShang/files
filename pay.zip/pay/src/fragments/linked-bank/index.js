import React from 'react';
import { connect } from 'react-redux';
import intl from 'react-intl-universal';
import List from 'components/list';
import PopOver from 'components/pop-over';
import DialogConfirmTerminate from 'components/dialog-confirm-terminate';
import Toast from 'components/toast';
import * as Mask from 'utils/MaskUtil'
import Item from './Item';
import { doGetAccountInfo3014Action } from 'redux/actions/account';
import { doTerminateEDDAAction, doQuerySignEDDAResultAction, doQueryEddaAction } from 'redux/actions/edda';
import './index.scss';

class LinkedBankFragment extends React.Component {
    state = {
        showTerminate: false,
        showTerminateResult: false,
        mobile: '',
        email: '',
        eddas: [],
        curAccount: null,
        isSuccess: false,
        isPending: false
    }

    static getDerivedStateFromProps(props, state) {
        let { eddas, mobile, email } = state;
        if (props.eddas.resultCode === 1 && props.eddas.resultData && props.eddas.resultData.edda_relation.length > 0) {
            eddas = props.eddas.resultData.edda_relation;
        }

        if (props.accountInfo.resultCode === 1 && props.accountInfo.resultData && props.accountInfo.resultData.list03) {
            const contacts = props.accountInfo.resultData.list03;
            contacts && contacts.forEach(obj => {
                if (obj.contact_method.indexOf('010') >= 0) {
                    email = Mask.maskEmail(obj.contact_content)
                } else if (obj.contact_method.indexOf('002') >= 0) {
                    mobile = `${obj.int_phone_area_code} ${Mask.maskMobile(obj.contact_content)}`;
                }
            })
        }

        return {
            eddas,
            email,
            mobile
        }
    }

    render() {
        const { showTerminate, showTerminateResult, mobile, email, isSuccess, isPending } = this.state;
        const linkMessage = intl.get("following_are_the_linked_accounts");
        const newLinkMessage = linkMessage.replace(/\{mobile\}/, mobile).replace(/\{email\}/, email);
        return (
            <div className="linked-bank">
                <div className="linked-bank-title">
                    {/* Here is the summary of authorized accounts under this {mobile} {email ? `and ${email}` : ''} */}
                    {newLinkMessage}
                </div>
                <List>
                    {this.renderItems()}
                </List>
                {
                    showTerminate &&
                    <PopOver isDialog={true} disClose={true} visible={showTerminate}
                        onShow={() => this.setState({ showTerminate: !showTerminate })}>
                        <DialogConfirmTerminate
                            isResult={false}
                            onTerminate={() => this.onTerminate()}
                            onCancel={() => this.setState({ showTerminate: !showTerminate })}>
                        </DialogConfirmTerminate>
                    </PopOver>
                }
                {
                    showTerminateResult &&
                    <PopOver isDialog={true} disClose={true} visible={showTerminateResult}
                        onShow={() => this.setState({ showTerminateResult: !showTerminateResult })}>
                        <DialogConfirmTerminate
                            isResult={true}
                            isSuccess={isSuccess}
                            isPending={isPending}
                            onOkay={() => window.location.href = '/pay/linked-bank.html'}>
                        </DialogConfirmTerminate>
                    </PopOver>
                }
            </div>
        )
    }

    /**
     * 激活 bindsuc/unbindfail/changesuc/changefail/suspfail（可以终止，可以修改，可以做即时定时）
     * 过期 bindfail/unbindsuc/suspsuc(已经终止，除查询不能做任何交易)
     * 签约中 binding(不能终止，不能修改，可以做即时，定时)
     * 中间状态 unbinding/changing/susping(除查询外,不能做任何相关交易，)
     * 彻底失效 finastate(180天后的状态，不能做任何相关交易，此时app已经查不到此状态)
     */
    renderItems = () => {
        const { eddas } = this.state;
        const temp = eddas.filter(item => {
            return (item.eddaStatus !== 'bindfail' && item.eddaStatus !== 'unbindsuc' &&
                item.eddaStatus !== 'suspsuc' && item.eddaStatus !== 'finastate')
        })

        return temp.map((item, index) => {
            return <Item key={index} data={item} onShowTerminate={() => this.onShowTerminate(item)}></Item>
        })
    }

    componentDidMount() {
        this.props.doGetAccountInfo3014Action({});

        this.props.doQueryEddaAction({ signtp: 'deposit' });
    }

    onShowTerminate = (data) => {
        this.setState({ showTerminate: !this.state.showTerminate, curAccount: data })
    }

    /**
     * Step 1: 终止操作，返回的是流水和以下四种状态
     * 
     * Option 1 sendSuc, initial 则进行轮询；
     * Option 2 sendFail，代表发送失败，直接默认交易失败(交易失败)
     * Option 3 tranSuc，代表交易成功（交易成功）
     * Option 4 tranFail，receipt  代表交易失败（交易失败）
     * 
     * Step 2: 如果是上述第一种情况，需要论询查询结果的接口；如果是其他三种情况，怎直接展示相应结果；
     * 结果值同上，但是如果轮询3次还是sendSuc那么展示给用户的状态应该为pending
     *（也有可能用户收到成功或者失败，因为轮询是有时间限制的，可能在此期间没有查到相应结果）
     */
    onTerminate = () => {
        const { curAccount } = this.state;

        this.props.doTerminateEDDAAction({ mndtId: curAccount.mndtId }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && (resultData.transt === 'initial' || resultData.transt === 'sendSuc')) {
                this.onQuerySignEDDAResult(res, 1);
            } else if (resultCode === 1 && resultData.transt === 'tranSuc') {
                this.setState({ showTerminate: false, showTerminateResult: true, isSuccess: true })
            } else if (resultCode === 1 && (resultData.transt === 'sendFail' || resultData.transt === 'tranFail' || resultData.transt === 'receipt')) {
                this.setState({ showTerminate: false, showTerminateResult: true, isSuccess: false })
            } else if (resultCode === 0) {
                Toast.show(res.errorData.msg);
            }
        })
    }

    onQuerySignEDDAResult = (params, count) => {
        if (count > 3) {
            this.setState({ showTerminate: false, showTerminateResult: true, isSuccess: false, isPending: true })
            return;
        }

        this.props.doQuerySignEDDAResultAction({
            inchdt: params.resultData.chnldt,
            inchsq: params.resultData.chnlsq,
        }, res => {
            const { resultCode, resultData } = res;
            if (resultCode === 1 && (resultData.eddatranst === 'initial' || resultData.eddatranst === 'sendSuc')) {
                setTimeout(() => { this.onQuerySignEDDAResult(params, count++); }, 2000);
            } else if (resultCode === 1 && (resultData.eddatranst === 'sendFail' || resultData.eddatranst === 'tranFail' || resultData.eddatranst === 'receipt')) {
                this.setState({ showTerminate: false, showTerminateResult: true, isSuccess: false })
            } else if (resultCode === 1 && resultData.eddatranst === 'tranSuc') {
                this.setState({ showTerminate: false, showTerminateResult: true, isSuccess: true })
            } else if (resultCode === 0) {
                Toast.show(res.errorData.msg);
            }
        })
    }
}

export default connect(function (state) {
    return {
        accountInfo: state.doGetAccountInfo3014Reducer,
        eddas: state.doQueryEddaReducer
    }
}, { doGetAccountInfo3014Action, doQueryEddaAction, doQuerySignEDDAResultAction, doTerminateEDDAAction })(LinkedBankFragment)