import React from 'react';
import intl from 'react-intl-universal';
import * as Mask from 'utils/MaskUtil';

export default class Item extends React.Component {
    state = {
        showStatus: true,
        data: this.props.data
    }

    static getDerivedStateFromProps(props) {
        return {
            showStatus: props.showStatus,
            data: props.data
        }
    }

    /**
     * Option 0: 激活状态 bindsuc/unbindfail/changesuc/changefail/suspfail
     * Option 1: 过期状态 bindfail/unbindsuc/suspsuc
     * Option 2: 签约状态 binding
     * 
     * 2019.6.17 修改状态
     * 激活 bindsuc/unbindfail/changesuc/changefail/suspfail（可以终止，可以修改，可以做即时定时）
     * 过期 bindfail/unbindsuc/suspsuc(已经终止，除查询不能做任何交易)
     * 签约中 binding(不能终止，不能修改，可以做即时，定时)
     * 中间状态 unbinding/changing/susping(除查询外,不能做任何相关交易，)
     * 彻底失效 finastate(180天后的状态，不能做任何相关交易，此时app已经查不到此状态)
     */
    render() {
        const { showStatus, data } = this.state;

        return (
            <div className="linked-bank-item">
                <div className="linked-bank-item-left">
                    {/* <div className="linked-bank-item-icon"></div> */}
                    <img alt="" src={require('assets/imgs/common/bank.svg')} />
                    <div style={{ width: 210 }}>
                        <div>{(data && data.dbtMmbNa) || ''}</div>
                        <div>{(data && Mask.maskName(data.dbtNm))}</div>
                        {
                            (data && data.eddaStatus === 'binding') &&
                            <div className="linked-bank-item-status">{intl.get('linked_bank_pending_authorisation')}</div>
                        }
                    </div>
                </div>
                {
                    (data && (data.eddaStatus === 'bindsuc' || data.eddaStatus === 'unbindfail'
                        || data.eddaStatus === 'changesuc' || data.eddaStatus === 'changefail'
                        || data.eddaStatus === 'suspfail')) &&
                    <div className="linked-bank-item-action" style={{ width: 35 }} onClick={this.onTerminate}>{intl.get('unlink')}</div>
                }
                {
                    (data && (data.eddaStatus === 'unbinding' || data.eddaStatus === 'changing' || data.eddaStatus === 'susping')) &&
                    <div className="linked-bank-item-action" style={{ color: '#484848',width: 35 }}>{intl.get('unlinking')}</div>
                }
            </div>
        )
    }

    onTerminate = () => {
        this.props.onShowTerminate && this.props.onShowTerminate()
    }
}