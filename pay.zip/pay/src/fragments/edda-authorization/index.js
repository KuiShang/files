import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import MerchantSelect from 'components/merchant-select'
import TextField from 'components/text-field';
import Toast from 'components/toast';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import { doQueryTransferPayerAction, doQueryTransferLimitAction } from 'redux/actions/transfer';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import './index.scss';


class EDDAAuthorizationFragment extends React.Component {
    state = {
        account: this.props.account,
        amount: '',
        accountNo: '',
        referenceNumber: '',
        merchant: null,
        limit_value: 0,
    }

    static getDerivedStateFromProps(props, state) {
        let { amount, accountNo, limit_value } = state;
        if (props.transferPayer.resultCode === 1) {
            amount = thousandBitSeparator(keep2DecimalFull(props.transferPayer.resultData.conv_amt_sum || 0));
            accountNo = props.transferPayer.resultData.acct_no;
        }

        if (props.limit.resultCode === 1) {
            limit_value = props.limit.resultData.limit_value;
        }

        return {
            amount,
            accountNo,
            limit_value
        }
    }

    render() {
        const { amount, accountNo, referenceNumber, merchant } = this.state;
        return (
            <div className="edda-authorization">
                <div className="edda-authorization-title">{intl.get("from")}</div>
                <CardReview>
                    <div className="edda-authorization-from">
                        <div className="edda-authorization-from-sub">{intl.get("livi_savings_account")}</div>
                        <div className="edda-authorization-from-money">
                            {amount}
                            <span>HKD</span>
                        </div>
                        <div className="edda-authorization-from-balance">{accountNo}</div>
                    </div>
                </CardReview>
                <div className="edda-authorization-title">{intl.get("to")}</div>
                <MerchantSelect merchant={merchant} onSelectMerchant={this.onSelectMerchant}></MerchantSelect>
                <div style={{ margin: '16px 0 32px 0' }}>
                    <TextField
                        requireInputMessage='Reference Number can not be empty'
                        propValue={{
                            hasRequiredMessage: true,
                            requireInputMessage: '',
                            regExp: /^[a-zA-z0-9]{8,16}$/,
                            regExpMessgae: '',
                            value: referenceNumber,
                            isPass: false,
                            placeHolder: intl.get("reference_number")
                        }}
                        stateName={'referenceNumber'}
                        setCurrentInputData={this.onHandleReferenceNumber.bind(this)}>
                    </TextField>
                </div>
                <div className="ai-btn-primary" onClick={this.onContinue}>{intl.get("continue")}</div>
            </div>
        )
    }

    componentDidMount() {
        const { account } = this.state;

        //// 获取转账限额
        //// 转账限额小于等于0则弹出需要设置转账限额弹框
        this.props.doQueryTransferLimitAction({
            acct_type: account.acct_type,
            acct_no: account.acct_no,
        }, res => {
            if (res.resultCode === 1) {
                this.setState({ limit_value: res.resultData.limit_value })
            }
        });

        //// 获取转账账户余额信息
        this.props.doQueryTransferPayerAction({
            acct_no: account.acct_no
        })
    }

    /**
     * 选择商户号
     */
    onSelectMerchant = () => {
        const url = `${window.location.origin}/pay/merchant.html`;

        SDK.goNativeWebview(url, (res) => {
            if (res.code === 1) {
                this.setState({ merchant: res.data.outData })
            }
        });
    }

    onHandleReferenceNumber = (pn, json) => {
        // 增加限制35位字符
        let value = json.value;
        if (value.length >= 35) {
            value = value.substr(0, 35);
        }
        this.setState({ referenceNumber: value })
    }

    onContinue = () => {
        let { account, merchant, referenceNumber, limit_value } = this.state;
        if (!merchant) {
            Toast.show('请选择商户！');
            return;
        } else if (!referenceNumber) {
            Toast.show('请输入商户参考号！');
            return;
        }

        hashHistory.push({
            pathname: "/instructions", state: {
                from: {
                    alias: account.acct_name,
                    number: account.acct_no,
                    limit_value
                },
                merchant: {
                    cdtrRef: referenceNumber,
                    alias: merchant.custnm,
                    number: merchant.proxId,
                    ...merchant
                }
            }
        })
    }
}

function mapStateToProps(state) {
    return {
        limit: state.doQueryTransferLimitReducer,
        transferPayer: state.doQueryTransferPayerReducer
    }
}

export default connect(mapStateToProps, { doQueryTransferPayerAction, doQueryTransferLimitAction })(EDDAAuthorizationFragment);