import React from 'react';
import { connect } from 'react-redux';
import intl from 'react-intl-universal';
import CardSent from 'components/card-sent';
import EDDAAuthorizationDetail from 'components/edda-authorization-detail';
import CollapseDetail from 'components/collapse-detail';
import Toast from 'components/toast';
import { doQuerySignEDDAResultAction } from 'redux/actions/edda';
import imgSuccess from 'assets/imgs/success/success.svg';
import imgFailed from 'assets/imgs/error/error.png';
import imgPending from 'assets/imgs/pending/pending.png';
import './index.scss';

class EDDAResultFragment extends React.Component {
    state = {
        showDetail: false,
        isSchedule: false,
        detail: null,
        params: this.props.params,
    }

    static getDerivedStateFromProps(props, state) {
        let { detail } = state;
        if (props.result && props.result.resultCode === 1) {
            detail = props.result.resultData;
        }

        return {
            detail
        }
    }

    render() {
        const { params, detail } = this.state;

        //// No parameters.
        if (!params || !params.chnldt || !params.chnlsq) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        //// No result data.
        if (!detail) {
            return <div style={{ width: '100%', textAlign: 'center' }}></div>
        }

        if (detail.eddatranst === 'tranSuc') {
            return this.renderSuccess();
        } else if (detail.eddatranst === 'sendSuc' || detail.eddatranst === 'initial') {
            return this.renderPending();
        } else {
            return this.renderFailed();
        }
    }

    renderSuccess = () => {
        const { showDetail, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgSuccess} />
                    <div className="result-status-tip">
                        <span>{intl.get("auto_debit_ready")} </span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get("debit_limit")}
                        // des={`(${intl.get("from_livi_savings_account")}) (${detail.dbtAcctId})`}
                        des={`${intl.get("from_livi_savings_account")}`}
                        amount={detail.maxAmt}
                        alias=''
                        proxyNo=''>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? intl.get("hide_more") : intl.get("show_more")}`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <EDDAAuthorizationDetail isSchedule={true} detail={detail}></EDDAAuthorizationDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={() => { window.location.href = 'edda.html' }}>{intl.get('back_to_home')}</button>
                </div>
            </div>
        )
    }

    renderFailed = () => {
        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgFailed} />
                    <div className="result-status-tip">
                        <span>{intl.get("debit_set_up_failed")}</span>
                        <span>{intl.get("please_try_again_later")}</span>
                    </div>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={this.onDoAuthorizeAgain}>{intl.get("try_again_once")}</button>
                </div>
            </div>
        )
    }

    renderPending = () => {
        const { showDetail, detail } = this.state;

        return (
            <div className="result">
                <div className="result-status">
                    <img alt="" src={imgPending} />
                    <div className="result-status-tip">
                        <span>{intl.get("debit_set_up_processed")}</span>
                    </div>
                </div>
                <div className="result-summary">
                    <CardSent
                        title={intl.get("debit_limit")}
                        // des={`(${intl.get("from_livi_savings_account")}) (${detail.dbtAcctId})`}
                        des={`${intl.get("from_livi_savings_account")}`}
                        amount={detail.maxAmt}
                        alias=''
                        proxyNo=''>
                    </CardSent>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <CollapseDetail title={`${showDetail ? intl.get("hide_more") : intl.get("show_more")}`} onCollapse={() => this.setState({ showDetail: !showDetail })}></CollapseDetail>
                </div>
                <div style={{ display: `${showDetail ? "" : "none"}` }}>
                    <EDDAAuthorizationDetail isSchedule={true} detail={detail}></EDDAAuthorizationDetail>
                </div>
                <div className="result-actions">
                    <button className="ai-btn-primary" style={{ margin: '0 0 16px 0' }} onClick={() => { window.location.href = 'edda.html' }}>{intl.get("done")}</button>
                </div>
            </div>
        )
    }

    componentDidMount() {
        const { params } = this.state;
        this.onCheckResult(params, 1);
    }

    /**
     * Option 1 成功：tranSuc
     * Option 2 失败：initial，sendFail，receipt，tranFail
     * Option 3 pending:sendSuc
     * 
     * Option 1 成功: tranSuc 
     * Option 2 失败：sendFail, receipt, tranFail
     * Option 3 pending:initial, sendSuc
     */
    onCheckResult = (params, count) => {
        if (count > 3) {
            //// SDK.showNativeLoading(false);
            this.setState({ isFetching: false });
            return;
        }

        this.props.doQuerySignEDDAResultAction({
            inchdt: params.chnldt,
            inchsq: params.chnlsq,
        }, res => {
            const { resultCode, resultData, errorData } = res;
            if (resultCode === 1 && resultData.transt === 'tranSuc') {
                this.setState({ isFetching: false })
            } else if (resultCode === 0 && errorData) {
                Toast.show(errorData.msg);
                this.setState({ isFetching: false })
            } else if (resultCode === 1 && (resultData.transt === 'initial' || resultData.transt === 'sendSuc')) {
                setTimeout(() => { this.onCheckResult(params, ++count) }, 2000)
            }
        })
    }

    onDoAuthorizeAgain = () => {
        window.location.href = `${window.location.origin}/pay/edda.html`;
    }
}

function mapStateFromProps(state) {
    return {
        result: state.doQuerySignEDDAResultReducer
    }
}

export default connect(mapStateFromProps, { doQuerySignEDDAResultAction })(EDDAResultFragment)