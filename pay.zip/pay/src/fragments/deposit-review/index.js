import React from 'react';
import { connect } from 'react-redux';
import { hashHistory } from 'react-router';
import CardReview from 'components/card-review';
import DepositFromReceive from 'components/deposit-from-receive';
import TextLabel from 'components/text-label';
import Toast from 'components/toast';
import intl from 'react-intl-universal';
import { doTransferWithPassRiskAction } from 'redux/actions/common';
import { doCreateNewAppointDepositAction, doCreateNewImmedDepositAction } from 'redux/actions/deposit';
import * as SDK from 'utils/SDKUtil';
import './index.scss';

class DepositReviewFragment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            info: props.info
        }

        SDK.setTitleRight({ show: 0 });
    }

    render() {
        const { info } = this.state;

        if (!info || !info.pay) {
            return null;
        }

        const { isNow, amount, startDate, frequency, expiry, remarks } = info.pay;

        let expiryVal = expiry.key === 'ondate' ? expiry.value.Format('yyyy/MM/dd') : expiry.value;
        if (expiry.key === 'never') {
            expiryVal = intl.get('no_end_date');
        } else if (expiry.key === 'repeat') {
            expiryVal = `${intl.get('repeat')} ${expiry.value} ${intl.get('times')}`
        }

        return (
            <div className="deposit-review">
                <CardReview>
                    <DepositFromReceive data={info}></DepositFromReceive>
                    <span className="deposit-review-space"></span>
                    <div>
                        <TextLabel label={intl.get('deposit_amount_every')} value={`${amount} HKD`}></TextLabel>
                    </div>
                    {
                        (isNow === 1) &&
                        <React.Fragment>
                            <div>
                                <TextLabel label={intl.get('start_date')} value={startDate && startDate.Format('yyyyMMdd')}></TextLabel>
                            </div>
                            <div>
                                <TextLabel label={intl.get('frequency')} value={frequency && intl.get(frequency.label)}></TextLabel>
                            </div>
                            {
                                frequency.key !== 'specialdate' &&
                                <div>
                                    <TextLabel label={intl.get('end_date')} value={expiryVal}></TextLabel>
                                </div>
                            }
                        </React.Fragment>
                    }
                    <div>
                        <TextLabel label={`${intl.get('remark')}`} value={remarks}></TextLabel>
                    </div>
                </CardReview>
                <div className="deposit-review-action">
                    <div className="ai-btn-primary" onClick={this.onSetupDeposit}>{intl.get('confirm')}</div>
                </div>
            </div>
        )
    }

    onSetupDeposit = () => {
        this.onCheckRisk(this.state.info);
    }

    /**
     * 即时/定时入金过风控
     * 
     * Option 1: 即时入金
     * Option 2: 预约入金
     * 
     */
    onCheckRisk = (obj) => {
        if (obj.pay.isNow === 0) {
            this.props.doCreateNewImmedDepositAction({
                ctgyPurp: 'DDOTHR', // 类别目的
                instdAmt: obj.pay.amount, //交易金额
                instdCcy: 'HKD',
                dbtNm: obj.from.accountName, // 借记名称
                dbtAcctId: obj.from.bankNo, // 借记账户ID
                dbtBankCode: obj.from.bankCode, // 借方银行代码
                dbtAcctCd: obj.from.dbtAcctCd, // 借记账户类型
                crdNm: obj.receive.accountName, // 贷记名称
                crdAcctId: obj.receive.accountNo, // 贷记账户ID
                crdAcctCd: 'BBAN', // 贷记账户类型
            }, res => {
                this.onNativeVerify(res, 0);
            })
        } else {
            this.props.doCreateNewAppointDepositAction({
                signtp: 'timing',
                dbtMmbId: obj.from.bankCode, // 借记银行代码
                dbtNm: obj.from.accountName, // 借记名称
                dbtAcctId: obj.from.bankNo, // 借记账号
                dbtAcctcd: obj.from.dbtAcctCd, // 借记类型
                crdMmbId: obj.receive.bankCode, // 贷记银行代码
                crdNm: obj.receive.accountName, // 贷记名称
                crdAcctId: obj.receive.accountNo, // 贷记账号
                crdAcctcd: 'BBAN',
                stadat: (obj.pay.startDate && obj.pay.startDate.Format('yyyyMMdd')),
                endtp: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'repeat' ? 'number' : 'time')),
                enddat: (obj.pay.frequency.key === 'specialdate' ? '' : (obj.pay.expiry.key === 'ondate' ? obj.pay.expiry.value.Format('yyyyMMdd') : (obj.pay.expiry.key === 'never' ? '' : `${obj.pay.expiry.value}`))),
                instdAmt: obj.pay.amount,
                instdCcy: 'HKD',
                period: obj.pay.frequency.value,
                ustrd: obj.pay.remarks
            }, res => {
                this.onNativeVerify(res, 1);
            })
        }
    }

    /**
     * 根据过风控提示的核身方式进行校验，调用原生核身方式
     */
    onNativeVerify = (res, type) => {
        if (res.resultCode === 0 && res.resultData && res.resultData.body) {
            const goNativeData = res.resultData.body.actionData;
            this.goNativeCheck(goNativeData, (natRes) => {
                (natRes && natRes.outData && natRes.outData.businessNo) && this.onCheckRiskResult(res, natRes.outData.businessNo, type);
            });
        } else if (res.resultCode === 0 && res.errorData) {
            Toast.show(res.errorData.msg)
        }
    }

    /**
     * 将风控结果提交即时/定时入金
     */
    onCheckRiskResult = (obj, businessNo, type) => {
        this.props.doTransferWithPassRiskAction({
            bizInfo: {
                trandt: obj.resultData.trandt,
                transq: obj.resultData.transq,
                busino: obj.resultData.busino,
            },
            securityResultData: {
                businessNo: businessNo,
            },
        }, res => {
            if (res.resultCode === 0) {
                Toast.show(res.errorData.msg);
            } else {
                hashHistory.push({
                    pathname: 'result',
                    state: {
                        chnldt: res.resultData.chnldt,
                        chnlsq: res.resultData.chnlsq,
                        type
                    }
                })
            }
        });
    }

    async goNativeCheck(goNativeData, cb) {
        const nativeRes = await SDK.goNativeAction(goNativeData);
        cb && cb(nativeRes)
    }
}

export default connect(function (state) {
    return null;
}, { doTransferWithPassRiskAction, doCreateNewAppointDepositAction, doCreateNewImmedDepositAction })(DepositReviewFragment)