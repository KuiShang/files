import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, hashHistory, Link } from 'react-router';
import createSagaMiddleware from 'redux-saga'
import { applyMiddleware, createStore, compose } from 'redux'
import { Provider } from 'react-redux';
import * as serviceWorker from 'serviceWorker';
import VConsole from 'vconsole';


// 引入样式&工具包
import 'assets/css/main.scss';
import 'utils/InitialUtil';
import keybord from './SetLimit/demoKeyBord';
import * as SDK from 'utils/SDKUtil';

// 页面组件
import Recipients from './Recipients/Recipients';
import mobile from './Recipients/mobile'
import email from './Recipients/email'
import fpsId from './Recipients/fpsId'
import accountNumber from './Recipients/accountNumber'
import result from './Recipients/result'
import add from './Recipients/add'
import SetLimit from './SetLimit/SetLimit';
import Recurring from './recurring/recurring';
import RecurringEdit from './recurring/edit';
import RecurringResult from './recurring/result';
import SetLimitSesult from './SetLimit/result';
import Home from './Home/Home';
import ErrorBoundary from './error/errorBoundary';
import Loading from './loading/loading';
import resultError from './SetLimit/resultError';

import rootSaga from './redux/saga'
import reducer from './redux/reducers'

// 国际化语言模块
import intl from 'react-intl-universal';
import enHK from './i18n/en_HK.js';
import zhCN from './i18n/zh_CN.js';
import zhHK from './i18n/zh_HK.js';
import debugI18n from './i18n/debug_i18n.js'

// mock数据
if (process.env.NODE_ENV === 'development') {
    require('./mock') 
}

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const sagaMiddleware = createSagaMiddleware()
const store = createStore(reducer, /* preloadedState, */ composeEnhancers(applyMiddleware(sagaMiddleware)
));
sagaMiddleware.run(rootSaga);

window.localeLanguage = 'en-HK';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;
const debugI18nEnv = platformInfo.debugI18n || false;
// ********* 设置环境变量 *********
// 获取当前Native的
(isJDAPP == true && debugI18nEnv) ?  window.localeLanguage = 'debug-i18n' : getAppLang();
if (debugI18nEnv) {
    var vConsole = new VConsole();
}


async function getAppLang() {
    if (isJDAPP) {
      const ret = await SDK.getCommonInfo();
      if (!!ret.language) {
        window.localeLanguage = ret.language;
      }
    }
}
getAppLang();
export default class App extends React.Component {
	constructor(props) {
		super(props)
		this.state = {
			initDone: false
		}
	}

	componentDidMount() {
		this.loadLocales()
	}

	loadLocales() {
        intl.init({
        currentLocale: window.localeLanguage, 
        locales: {
                    "en-HK": enHK,
                    "zh-CN": zhCN,
                    "zh-HK": zhHK,
                    "debug-i18n": debugI18n
                }
        })
        .then(() => {
            this.setState({initDone: true});
        });
    }

  render() {
		return (
			this.state.initDone && 
			<Provider store={store}>
            <ErrorBoundary>
                <Loading></Loading>
                <Router history={hashHistory}>
                    <Route path={'/'} components={Test}></Route>
                    <Route path={'/Recipients'} components={Recipients}></Route>
                    <Route path={'/Recipients/mobile'} components={mobile}></Route>
                    <Route path={'/Recipients/accountNumber'} components={accountNumber}></Route>
                    <Route path={'/Recipients/email'} components={email}></Route>
                    <Route path={'/Recipients/fpsId'} components={fpsId}></Route>
                    <Route path={'/Recipients/result'} components={result}></Route>
                    <Route path={'/Recipients/add'} components={add}></Route>
                    <Route path={'/SetLimit'} components={SetLimit}></Route>
                    <Route path={'/Recurring'} components={Recurring}></Route>
                    <Route path={'/Recurring/edit'} components={RecurringEdit}></Route>
                    <Route path={'/Recurring/result'} components={RecurringResult}></Route>
                    <Route path={'/SetLimit/result'} components={SetLimitSesult}></Route>
                    <Route path={'/TransferSetting'} components={Home}></Route>
                    <Route path={'/SetLimit/resultError'} components={resultError}></Route>
                    {/* react键盘demo */}
                    <Route path={'/keybord'} components={keybord}></Route>
                </Router>
            </ErrorBoundary>
        </Provider>
		)
	}
}

function Test() {
    return (
        <div>
            <Link to="/TransferSetting">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go transfer-setting 列表页</div>
            </Link>
            <Link to="/Recipients">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go Recipients 常用收款人</div>
            </Link>
            <Link to="/Recurring/">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go recurring 定时传出</div>
            </Link>
            <Link to="/SetLimit">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go 设置限额(每日和小额)</div>
            </Link>
            <Link to="/SetLimit/result">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go 限额 结果页</div>
            </Link>
            <Link to="/keybord">
                <div style={{ margin: '10px', height: '40px', textAlign: 'center', background: 'gray', color: '#fff', lineHeight: '40px', fontSize: '20px' }}
                >go 键盘</div>
            </Link>
        </div>
    )
}
