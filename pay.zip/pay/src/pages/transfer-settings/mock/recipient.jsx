export default function recipient(mock) {
    // 添加收款人
    mock.onPost('/cocgw/adpyfo').reply(200, {
        "resultCode": 1,
        "resultMsg": "success",
        "resultData": {
        }
    })
    // 删除收款人
    mock.onPost('/cocgw/delpyfo').reply(200, {
        "resultCode": 1,
        "resultMsg": "success",
        "resultData": {
        }
    })

    // 获取收款人列表
    var flag = true
    mock.onPost('/cocgw/qrpyfo').reply(() => {
        if (flag) {
            flag =false
            return [200, {
                "resultCode": 1,
                "resultMsg": "success",
                "resultData": {
                    name_list: [
                        {
                            payeno: '123123',
                            custno: '321312',
                            pyname: 'dd333',
                            pyform: 'dynastary',
                            rmname: 'more better more faster',
                            pyacct: '11115544z@q.com',
                            inactp: 'EMAL',
                            pybank: '8899',
                            banknm: 'ICBC'
                        },
                        {
                            payeno: '123123',
                            custno: '321312',
                            pyname: 'fff',
                            pyform: 'dynastary',
                            rmname: 'more better more faster',
                            pyacct: '1111123123',
                            inactp: 'BBAN',
                            pybank: '8899',
                            banknm: 'ICBC'
                        },
                        {
                            payeno: '123123',
                            custno: '321312',
                            pyname: 'fff',
                            pyform: 'dynastary',
                            rmname: 'more better more faster',
                            pyacct: '1111123123',
                            inactp: 'SVID',
                            pybank: '8899',
                            banknm: 'ICBC'
                        }
                      
                    ]
                }
            }]
        } else {
            flag =true
            return [200, {
                "resultCode": 1,
                "resultMsg": "success",
                "resultData": {
                    name_list: [
                        {
                            payeno: '123123',
                            custno: '321312',
                            pyname: 'dd',
                            pyform: 'kkk',
                            rmname: 'more better more faster',
                            pyacct: '5544z@q.com',
                            inactp: 'EMAL',
                            pybank: '8899',
                            banknm: 'ICBC'
                        },
                        {
                            payeno: '123123',
                            custno: '321312',
                            pyname: 'fff',
                            pyform: 'dynastary',
                            rmname: 'more better more faster',
                            pyacct: '1111123123',
                            inactp: 'BBAN',
                            pybank: '8899',
                            banknm: 'ICBC'
                        }
                      
                    ]
                }
            }]
        }

    })
    // 更新收款人
    mock.onPost('/cocgw/uppyfo').reply(200, {
        "resultCode": 1,
        "resultMsg": "success",
        "resultData": {
        }
    })
}