export default function coupon(mock) {


  // 预约转账列表
  // mock.onPost('/enqtranset').reply(200, {
  //   "resultCode": 1,
  //   "resultMsg": "success",
  //   "resultData": {
  //     set_list: [
  //       {
  //         prosta: '1',
  //         pmtTpInfPrtry: 'SKIP_PYE_VRF',
  //         ctgyPurp: 'CXBSNS',
  //         instdAmt: '100',
  //         instdCcy: 'HKD',
  //         dbtNm: 'tom',
  //         dbtPrtId: '9527',
  //         dbtPrtIssr: '1',
  //         dbtPrtMobNb: '138xxxx12554',
  //         dbtPrtEmailAdr: 'nevers@jd.com',
  //         dbtAcctId: '189045123',
  //         dbtAcctCd: 'BBAN',
  //         crdNm: 'lili',
  //         crdPrtId: '3306',
  //         crdPrtIssr: 'nothing',
  //         crdPrtMobNb: '1801125846',
  //         crdPrtEmailAdr: 'react@jd.com',
  //         crdAcctId: '8080',
  //         crdAcctCd: 'EMAL',
  //         crdBankCode: 'ICBC',
  //         dbtAddress: 'beijing',
  //         crdCorrBank: 'china bank',
  //         chrgDetail: 'SHA',
  //         ustrd: 'dont not used',
  //         stadat: '57964826',
  //         enddat: '74167258',
  //         period: 'weekly',
  //         tranSetSeq: '7834659245'
  //       },
  //       {
  //         prosta: '1',
  //         pmtTpInfPrtry: 'SKIP_PYE_VRF',
  //         ctgyPurp: 'CXBSNS',
  //         instdAmt: '100',
  //         instdCcy: 'HKD',
  //         dbtNm: 'jack',
  //         dbtPrtId: '9527',
  //         dbtPrtIssr: '1',
  //         dbtPrtMobNb: '138xxxx12554',
  //         dbtPrtEmailAdr: 'nevers@jd.com',
  //         dbtAcctId: '189045123',
  //         dbtAcctCd: 'BBAN',
  //         crdNm: 'lili',
  //         crdPrtId: '3306',
  //         crdPrtIssr: 'nothing',
  //         crdPrtMobNb: '1801125846',
  //         crdPrtEmailAdr: 'react@jd.com',
  //         crdAcctId: '8080',
  //         crdAcctCd: 'EMAL',
  //         crdBankCode: 'ICBC',
  //         dbtAddress: 'beijing',
  //         crdCorrBank: 'china bank',
  //         chrgDetail: 'SHA',
  //         ustrd: 'dont not used',
  //         stadat: '57964826',
  //         enddat: '74167258',
  //         period: 'weekly',
  //         tranSetSeq: '7834659245'
  //       },
  //       {
  //         prosta: '0',
  //         pmtTpInfPrtry: 'SKIP_PYE_VRF',
  //         ctgyPurp: 'CXBSNS',
  //         instdAmt: '100',
  //         instdCcy: 'HKD',
  //         dbtNm: 'lucy',
  //         dbtPrtId: '9527',
  //         dbtPrtIssr: '1',
  //         dbtPrtMobNb: '138xxxx12554',
  //         dbtPrtEmailAdr: 'nevers@jd.com',
  //         dbtAcctId: '189045123',
  //         dbtAcctCd: 'BBAN',
  //         crdNm: 'lili',
  //         crdPrtId: '3306',
  //         crdPrtIssr: 'nothing',
  //         crdPrtMobNb: '1801125846',
  //         crdPrtEmailAdr: 'react@jd.com',
  //         crdAcctId: '8080',
  //         crdAcctCd: 'EMAL',
  //         crdBankCode: 'ICBC',
  //         dbtAddress: 'beijing',
  //         crdCorrBank: 'china bank',
  //         chrgDetail: 'SHA',
  //         ustrd: 'dont not used',
  //         stadat: '57964826',
  //         enddat: '74167258',
  //         period: 'weekly',
  //         tranSetSeq: '7834659245'
  //       }
  //     ]
  //   }
  // })
  mock.onPost('/cocgw/4401').reply(200, {
    "resultData": {
      "list01": [{
        "close_acct_remark": "",
        "acct_oth_name": "ZhangSan",
        "joint_acct_ind": "N",
        "data_version": 2,
        "acct_type": "E01",
        "close_acct_branch": "",
        "acct_branch_name": "xxx Branch",
        "acct_status": "1",
        "cust_type": "1",
        "cust_no": "100000004111",
        "open_acct_seq": "2019040502580000000000046",
        "acct_name": "å¼ ä¸",
        "sigl_sub_acct_ind": "N",
        "sigl_prod_acct_ind": "N",
        "correlation_voch_ind": "N",
        "close_acct_seq": "",
        "kyc_status": "P",
        "acct_branch": "1234",
        "open_acct_date": "20190405",
        "sigl_ccy_acct_ind": "N",
        "kyc_status_date": "20190405",
        "open_acct_voch_ind": "0",
        "ref_voch_level": "1",
        "external_acct_no": "0258000015048",
        "acct_no": "0258000015048",
        "acct_limit_status": "0",
        "withdrawal_cond": "N",
        "close_acct_date": "",
        "acct_date": "20190405",
        "open_acct_branch": "1234",
        "card_relationship_ind": "N"
      }]
    },
    "resultCode": 1
  })
  // 查询限额
  mock.onPost('/cocgw/4213').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
      "max_limit_value": 200000000.00,
      "min_limit_value": 1.00,
      "limit_ccy": "HKD",
      "limit_value": 5000.00,
      "used_limit": 0,
      "limit_no": "LIMIT001",
      "limit_reset_cycle": "D"
    }
  })
  // 设置转账
  mock.onPost('/setDayLimit').reply(200, {
    "resultCode": 1,
    "resultMsg": "success",
    "resultData": {
    }
  })
   /*
   * 获取协议标题、版本
   * 请求头:
   *   Content-Type:application/json
   *   simpleDeviceInfo:{"language":"zh-CN"}
   * 请求体:
   *   {"agreementNo":"AGM_REG"}
   */
  mock.onPost('/saser/agreement/queryAgreementInfo').reply(200,
    {
      "resultCode": 1,
      "resultData": {
        "agreementNo": "AGM_REG",
        "agreementVersion": "001",
        "languageType": "zh-CN",
        "agreementName": "注册协议20190411",
        "agreementContent": null
      },
      "errorData": null
    }
  )
  /**
   * 查询转账限额
   * /cocgw/4213
   */
  mock.onPost('/cocgw/4213').reply(200,
    {
      "resultCode": 1,
      "resultData": {
        "max_limit_value": 200000000.00,
        "min_limit_value": 0.00,
        "limit_ccy": "HKD",
        "limit_value": 200000000.00,
        "used_limit": 0,
        "limit_reset_cycle": "D"
      },
      "errorData": null
    }
  )

  /**
   * 设置转账限额
   * /channal/4214
   */
  mock.onPost('/cocgw/4214').reply(200,
    {
      "resultCode": 1,
      "resultData": {
       
      },
      "errorData": null
    }
  )
  /**
   * 转账设置列表页面
   * 入参 
   *  客户号 custno
   * 出参
   *  recurPay 是否设置定时转出 string 1是，0否 包括生效的和一定时间内失效的  用来第三项判断定时转出入口展示与否
   *  linkBank 是否存在签约信息 string 1是，0否 用来判断展示 第六项 绑定他行账户
   */
  mock.onPost('/cocgw/transferset').reply(200,
    {
      "resultCode": 1,
      "resultData": {
        recurPay: '1',
        linkBank: '1'
      },
      "errorData": null
    }
  )
  /**
   * 查询小额限额
   * /cocgw/4213
   */
  mock.onPost('/cocgw/enqadtf').reply(200,
    {
      "resultData": {
        "islmsm": "0",
        "rangeVal": "10000.00",
        "maxTranamValue": "10000.00",
        "minTranamValue": "1000.00"
      },
      "resultCode": 1
    }
  )
  /**
   * 设置限额
   */
  mock.onPost('cocow/initadtf').reply(200,
    {
      "resultData": {
        "busino": "2019051600000000078",
        "body": {
          "entranceNo": "0b0a17b9-df22-4d3f-88dd-6dd57a09a14c",
          "actionData": {
            "address": "/safecenter/main",
            "params": {
              "country": "",
              "custNo": "100000004111",
              "realType": "0",
              "entranceNo": "0b0a17b9-df22-4d3f-88dd-6dd57a09a14c",
              "mobileNumber": "13135311153",
              "sysSource": "PAY",
              "needCrossToApp": {},
              "iDCountry": "",
              "requestSource": "APP_NORMAL",
              "otpType": 0,
              "userId": "0020001164"
            },
            "type": "native"
          }
        },
        "trandt": "20190516",
        "transq": "2019051631000098500000000164"
      },
      "resultCode": 0,
      "actionData": {
        "address": "/safecenter/main",
        "params": {
          "country": "",
          "custNo": "100000004111",
          "realType": "0",
          "entranceNo": "0b0a17b9-df22-4d3f-88dd-6dd57a09a14c",
          "mobileNumber": "13135311153",
          "sysSource": "PAY",
          "needCrossToApp": {},
          "iDCountry": "",
          "requestSource": "APP_NORMAL",
          "otpType": 0,
          "userId": "0020001164"
        },
        "type": "native"
      }
    } 
    )

  /**
   * 查询transfer-setting 聚合接口
   */
  mock.onPost('/cocgw/transferset').reply(200,
    {
      "resultCode": 1,
      "resultData":{
        "linkBank":0,
        "recurPay":0
      },
      "errorData": null
    }
  )


}

