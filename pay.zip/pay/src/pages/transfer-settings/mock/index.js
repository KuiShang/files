import transferSetting from './transferSetting'
import recurring from './recurring'
import recipient from './recipient'

var axios = require('axios')

var MockAdapter = require('axios-mock-adapter')

var mock = new MockAdapter(axios, {
    delayResponse: 1000
})

transferSetting(mock)
recurring(mock)
recipient(mock)