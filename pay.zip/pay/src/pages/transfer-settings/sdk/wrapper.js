var img_my_account_add = require('./My_acc Add@2x.png')
var img_sortlist = require('./Sortlist@2x.png')
/*
* 获取系统信息
* getSysType(str)
* */
export function getSysType(str) {
    var ua = navigator.userAgent.toLowerCase();
    var isIOS = ua.indexOf('ipad') > -1 || ua.indexOf('iphone') > -1 || false;
    var isAndroid = ua.indexOf('android') > -1 || false;
    // var isJdApp = ua.indexOf('ijr') > -1 || false;
    var isJdApp = ua.indexOf('t1w') > -1 || false;
    var result = {
        isIOS: isIOS,
        isAndroid: isAndroid,
        isJdApp: isJdApp
    }
    return str ? result[str] : result;
}

const platformInfo = getSysType()
const isJDAPP = platformInfo.isJdApp
const isAndroid = platformInfo.isAndroid
const isIOS = platformInfo.isIOS

let platformEnv = ''
function getPlatformEnv() {
    if (platformEnv) {
        return platformEnv
    }
    return new Promise(reslove => {
        window.wallet.platform.env(data => {
            platformEnv = data.data
            return reslove(data.data)
        })
    })
}

async function checkMethod(methodName, cb) {
    if (!isJDAPP) {
        return false
    }
    return new Promise(async reslove => {
        let platformEnv = await getPlatformEnv()
        console.info('platformEnv', platformEnv)
        const methods = platformEnv.methods
        const onEvents = platformEnv.onEvents
        const onRoutes = platformEnv.onRoutes
        if (methods.includes(methodName) || onEvents.includes(methodName) || onRoutes.includes(methodName)) {
            reslove(true)
        } else {
            // do something
            console.error('方法不存在:', methodName)
            reslove(false)
        }
    })
}

/**
 * 设置标题
 * @param {} obj 
 */
export async function setTitle(obj) {
    // if (!isJDAPP) {
    //     return false
    // }
    const default_obj = {
        title: 'VB',
        titleColor: '#000000',
        titleBackgroundColor: '#eeeeee',
        subTitleName: '子标题',
        subTitleColor: '#333333'
    }
    console.info('settitle')
    let ret = Object.assign(default_obj, obj)
    const flag = await checkMethod('setTitle')
    if (flag) {
        return window.wallet.platform.setTitle(ret)
    }
    return false
}

/**
 * 设置标题右面的
 * @param {} obj 
 */
export async function setTitleRight(obj, cb) {
    // if (!isJDAPP) {
    //     return false
    // }
    const flag = await checkMethod('onTitleBusiness')
    if (flag) {
        window.wallet.platform.onTitleBusiness(obj, cb);
    }
    return false
}

/**
 * 获取公共信息
 * @param {*} obj 
 */
export async function getCommonInfo() {
    // if (!isJDAPP) {
    //   return false
    // }
    const ret = await checkMethod('getCommonInfo')
    if (ret) {
        return new Promise(reslove => {
            window.wallet.platform.getCommonInfo(data => reslove(data.data))
        })
    }
}

/**
 * 根据输入的手机号获取通讯录列表
 * @param {*} obj 
 */
export async function getPhonesByNumber(num) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('getPhonesByNumber')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.getPhonesByNumber({
                inputdata: num
            }, data => reslove(data.data))
        })
    }
    return false
}

/**
 * 调用获取通讯录列表 获得一个手机号
 */
export async function goContactRes() {
    // if (!isJDAPP) {
    //   return false
    // }

    const flag = await checkMethod('goContactRes')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.goContactRes(data => reslove(data.data))
        })
    }
    return false
}

/**
 *  跳转到原生
 */
export async function goNativeAction(obj) {
    if (!isJDAPP) {
        return false
    }

    const flag = await checkMethod('goNativeAction');
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.goNativeAction(obj, data => reslove(data.data))
        })
    }
    return false
}

/**
 *  跳转到原生 -余额交易详情
 *  0 //交易记录
    1 //收钱列表记录
    2 //生活缴费记录
    3 //转账交易记录
    4 //余额交易记录
 */
export function goNativeActionTransDetail() {
    const json = {
        type: 'native',
        address: '/trade/transaction',
        params: {
            transactionType: 4
        }
    }
    return goNativeAction(json)
}

/**
 *  跳转到原生 -綁卡
 */
export function goNativeActionAddCard() {
    const json = {
        "type": "native",
        // "address": "/bank/management"  
        "address": "/cardCenter/requestPreBind"
    }

    return goNativeAction(json)
}

/**
 *  跳转到原生 -原声自定义的通讯录
 */
export function goNativeCustomContact() {
    const json = {
        "type": "native",
        "address": "/contact/book",
        params: {
            transactionType: 3
        }
    }
    return goNativeAction(json)
}

/**
 * 关闭webview
 */
export async function closeWebView() {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('close')
    if (flag) {
        return window.wallet.platform.close()
    }
    return false
}

/**
 * 监听返回键，这回接管系统事件，系统会取消默认操作，
 */
export async function onBackPress(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackPress')
    if (flag) {
        return window.wallet.platform.onBackPress(() => {
            cancleOnBackPress()
            cb()
        })
    }
    return false
}

/**
 * webview切到后台监听
 */
export async function onBackground(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackground')
    if (flag) {
        return window.wallet.platform.onBackground(() => {
            cb()
        })
    }
    return false
}

/**
 * webview回到前台监听
 */
export async function onForeground(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onForeground')
    if (flag) {
        return window.wallet.platform.onForeground(() => {
            cb()
        })
    }
    return false
}

/**
 * 取消监听返回键
 */
export async function cancleOnBackPress() {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackPress')
    if (flag) {
        console.info('取消了回退监听')
        return window.wallet.platform.onBackPress()
    }
    return false
}

/**
 * 跳转到原生 -收银台便利店支付方式页面
 * @param {交易号} orderNum 
 */
export function goNativeQrRechange(orderNum) {
    const json = {
        type: 'native',
        address: '/qr/recharge',
        params: {
            orderNum
        }
    }

    return goNativeAction(json)
}

/**
 *  跳转到原生 -关闭当前webwiew并发送结果
 */
export async function closeWebViewAndSendResult(json = { resultCode: 1 }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('close')
    if (flag) {
        return window.wallet.platform.close(json)
    }
    return false
}

/**
 * 跳转到原生主页
 */
export function goNativeMain() {
    const json = {
        type: 'native',
        address: '/main/main'
    }
    return goNativeAction(json)
}

/**
 * 原生页面事件埋点
 */
export async function buriedPoint(buriedPointJSON = { pageName: '', eventId: '', map: {} }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 3,
        ...buriedPointJSON
    }
    console.info('default_obj:', default_obj)
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 原生页面进入埋点
 */
export async function buriedPointEntry(buriedPointJSON = { pageName: '' }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 1,
        map: {},
        ...buriedPointJSON
    }
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 原生页面likai埋点
 */
export async function buriedPointLeave(buriedPointJSON = { pageName: '' }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 2,
        map: {},
        ...buriedPointJSON
    }
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 生成条形码
 */
export async function setBarCode(obj, cb) {
    // if (!isJDAPP) {
    //     return false
    // }
    const flag = await checkMethod('getScanCode')
    if (flag) {
        window.wallet.platform.getScanCode(obj, cb);
    }
    return false
}

/**
 * 跳转到原生优惠券二维码
 */
export async function goNativeQrCoupon(couponId, merchantId) {
    const json = {
        type: 'native',
        address: '/qr/coupon',
        params: {
            couponId,
            merchantId
        }
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生我的优惠券列表
 */
export function goNativeCouponList() {
    const json = {
        type: 'native',
        address: '/coupon/listpage'
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生的其他app
 */
export function goOtherNativeAPP(scheme) {
    const json = {
        type: 'native',
        address: '/main/scheme',
        params: {
            scheme
        }
    }
    return goNativeAction(json)
}

/**
 * 检测一款app是否安装
 */
export async function checkInstallApps(scheme) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('checkInstallApps')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.checkInstallApps(scheme, data => {
                console.info('结果：：：', data)
                reslove(data.data)
            })
        })
    }
    return false
}

/**
 * 检测一款kplus是否安装
 */
export function checkInstallKplus() {
    // if (!isJDAPP) {
    //   return false
    // }
    let json = ''
    if (isAndroid) {
        json = {
            packages: ['com.kasikorn.retail.mbanking.wap']
        }
    } else if (isIOS) {
        json = {
            scheme: ['kbank.kplus://']
        }
    }
    return new Promise(reslove => {
        return checkInstallApps(json).then(ret => {
            let dat = 0
            if (isAndroid) {
                if (json.packages[0] === ret[0]) {
                    dat = 1
                } else {
                    dat = 0
                }
                reslove(dat)
            } else if (isIOS) {
                if (json.scheme[0] === ret[0]) {
                    dat = 1
                } else {
                    dat = 0
                }
                reslove(dat)
            }
        })
    })
}

/**
 * 跳转到原生的kyc
 */
export function goNativeKYC(params) {
    const json = {
        type: 'native',
        address: '/kyc/main'
    }
    if (params && typeof params === 'object') {
        json.params = params;
    }
    return goNativeAction(json)
}

/**
 * reload页面
 */
export async function reloadPage(obj, cb) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('reload')
    if (flag) {
        window.wallet.platform.reload(obj, cb);
    }
    return false
}

/**
 * 跳转到原生的QRCode页面
 */
export function goNativeQRCode() {
    const json = {
        type: 'native',
        address: '/qr/point'
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生的unbindMsg
 */
export function goNativeThe1Bind() {
    const json = {
        type: 'native',
        address: '/account/bindThe1'
    }
    return goNativeAction(json)
}

/**
 * 埋点 目前支持 //channelType 1:Channel_FireBase;//channelType 2:Channel_AF;//channelType 3:Channel_FaceBook;//没有实现
 * 
    mList: [
    {
    channelType:1,
    eventId:'dsdsd',
    map:{
      test:'dsdsds',
      test2:'dsdsds'
    }
    },


    {
    channelType:2,
    eventId:'dsdsd',
    map:{
      test:'dsdsds',
      test2:'dsdsds'
    }
    }
      ]

 */
export async function buriedPointCore(mList) {
    // if (!isJDAPP) {
    //   return false
    // }
    const da = { mList }
    const flag = await checkMethod('buriedPointCore')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.buriedPointCore(da, data => {
                reslove(data.data)
            })
        })
    }
    return false
}

/**
 * 原生的ajax请求
 */
export async function request(data, cb) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('request')
    if (flag) {
        return window.wallet.platform.request(data, cb)
    }
    return false
}

/**
 * 原生的有没有 ajax请求
 */
export function checkHasAppRequest() {
    return checkMethod('request')
}

/**
 * 获取title方法
 */
export async function getTitleName() {

    const flag = await checkMethod('getTitleName')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.getTitleName('', data => reslove(data.data))
        })
    }
    return false
}

/**
 * 弹出原生选择国家号码窗口
 */
export async function goCountryCode(callback) {
    const json = {
        type: 'native',
        address: '/public/selectCountryCode',
        params: {
            title: 'TEST'
        }
    }
    const flag = await checkMethod('getTitleName')
    if (flag) {
        window.wallet.platform.goNativeAction(json, function (resp) {
            callback && callback(resp);
        });
    }

    return false
    //return goNativeAction(json)
}

/**
 * 调用原生WEBVIEW
 */
export async function goNativeWebview(url, callback) {
    var json = {
        type: 'native',
        address: '/webview/web',
        params: {
            url: url
        }
    };

    // const flag = await checkMethod('goNativeWebview')
    // if (flag) {
        window.wallet.platform.goNativeAction(json, (res) => {
            callback && callback(res);
        });
    // }

   
}

/**
 * 关闭WEBVIEW回调函数
 * @param {*} item 
 */
export function closeNativeWebview(item) {
    var param = {
        resultCode: 1,
        result: item
    };

    window.wallet.platform.close(param);
}

/**
 * 弹出原生通讯录选择电话
 * @param {*} callback 
 */
export async function goNativePhoneList(callback) {

    // const flag = await checkMethod('goContactRes')
   //  if (flag) {
        window.wallet.platform.goContactRes((res) => {
            callback && callback(res);
        })
   //  }
    return false
    
}

/**
 * 获取用户信息
 * @param {*} callback 
 */
export function getUserInfo(callback) {
    if (!isJDAPP) {
        return false
    }
    window.wallet.platform.getUserAccount(function (res) {
        callback && callback(res);
    });
}

/**
 * 保存数据
 * @param {*} key 
 * @param {*} value 
 * @param {*} mode 0是当前webview，内存;1是全局（需要重启APP）;2持久化到加密区 
 */
export function setCache(key, value, mode, callback) {
    if (!key || !value) {
        return false;
    }

    const json = {
        key: key,
        value: value,
        cacheMode: mode ? mode : 0
    };

    window.wallet.platform.putCache(json, function (resp) {
        callback && callback(resp);
    });
}

/**
 * 获取数据
 * @param {*} key 
 * @param {*} mode 
 * @param {*} callback 
 */
export function getCache(key, mode, callback) {
    if (!key) {
        return false;
    }

    const json = {
        key: key,
        cacheMode: mode ? mode : 0
    };

    window.wallet.platform.getCache(json, function (resp) {
        callback && callback(resp);
    });
}

/**
 * 删除数据
 */
export function removeCache(key, mode, callback) {
    if (!key) {
        return false;
    }

    const json = {
        key: key,
        cacheMode: mode ? mode : 0
    };

    window.wallet.platform.removeCache(json, function (resp) {
        callback && callback(resp);
    });
}



export async function setHeaderWithImg(cb ) {
    var param = {
        left:{
        iconUrl: img_my_account_add,
        show: 1
        },

        right:{
            iconUrl: img_sortlist,
        show: 1,
        }

    };
    if (!isJDAPP) {
        return false
    }
    // const flag = await checkMethod('onTitleBusiness2')
    // if (flag) {
            window.wallet.platform.onTitleBusiness2(param, cb)
    // }

    return false
}

export async function setHeaderWithImgHide( ) {
    var param = {
        left:{
        iconUrl: img_my_account_add,
        show: 0
        },

        right:{
            iconUrl: img_sortlist,
        show: 0,
        }

    };
    if (!isJDAPP) {
        return false
    }
    // const flag = await checkMethod('onTitleBusiness2')
    // if (flag) {
            window.wallet.platform.onTitleBusiness2(param, function(){})
    // }

    return false
}

/**
 * 调用原生全屏Loading效果
 */
export function showNativeLoading(show) {
    var json = {
        title: 'loading...',
        backColor: '#00000000',
        textColor: '#FFFFFF',
        isShow: show ? 1 : 0
    };
    console.info(JSON.stringify(json));
    window.wallet.platform.showDialogLoading(json);
}
