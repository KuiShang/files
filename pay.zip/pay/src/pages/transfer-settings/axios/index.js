/*eslint-disable*/
import axios from 'axios'
// 全局超时时间
axios.defaults.timeout = 3000
axios.defaults.baseURL = ''
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
// axios.defaults.headers.common['Authorization'] = 'AUTH_TOKEN';
if (process.env.NODE_ENV !== 'production') {
  axios.defaults.headers.common['ticket'] = '3091a120-3a04-450c-8c16-23ccf5a578ae';
  axios.defaults.headers.common['uuid'] = new Date().getTime().toString();
  // axios.defaults.headers.common['cust_no'] = '10024825096';
  axios.defaults.headers.common['simpleDeviceInfo'] = JSON.stringify({"language":"zh-CN"});
  // axios.defaults.headers.common['userId'] = 'UserId1';
  // axios.defaults.headers.common['custNo'] = '100000002801';
  
  // axios.defaults.headers.common['ticket'] = 'd66e1ead-c270-4b6b-8ec4-9bd054c7f73f';
  // axios.defaults.headers.common.deviceInfo = JSON.stringify({"deviceModel":"OS105","deviceType":"APP","language":"en_US"});
}
// 添加请求拦截器
axios.interceptors.request.use((config) => {
  if (config.method == 'get') {
    config.data = true
    config.headers['Content-Type'] = 'application/json'
  }
  // Vue.$indicator.open({
  //   text: 'Loading...',
  //   spinnerType: 'fading-circle'
  // })
  // 在发送请求之前做些什么
  if (config.method === 'post') {
    console.info(`入参${config.url} :`, config.method, config.data)
  } else {
    console.info(`入参${config.url} :`, config.method, config.params)
  }
  // config.url = `/api${config.url}`
  return config
}, (error) => {
  // 对请求错误做些什么
  console.info('request error', error)
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  // console.info(JSON.stringify(response))
  // 对响应数据做点什么
  if (response.status !== 200) {
  }
  console.info(`返回${response.config.url} :`, response.data)
  
  return response
}, function (error) {
  // 对响应错误做点什么
  console.info('error', error.response)
  return error
})
export default axios
