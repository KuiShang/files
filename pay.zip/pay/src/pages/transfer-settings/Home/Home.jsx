import React from 'react';
import './Home.scss';
import { Link } from 'react-router';
import { queryTransfersetInfo, qrpayee } from 'pages/transfer-settings/api';
import { connect } from 'react-redux';
import intl from 'react-intl-universal';
import * as SDK from '../sdk/wrapper';


class Home extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			renderStatus: false,
			baseDomain: '',
			transferSetList: {
				recurPay: '0',
				linkBank: '0'
			}
		}
	}

	componentWillMount() {
		// 设置标题
		SDK.setTitle({
			title: intl.get('09D.01.001-1'),
		});
		this.initData();

		this.props.fetchMedda({
			custno: '123',
			funcno: 'withdraw'
		})
	}

	render() {
		return (
			this.state.renderStatus &&
			<div className="TransferSetting-home">
				<header className="choice-fqa">
					<article>
						<ul>
							<li onClick={() => this.goNativeFps()} className="clearFix" key={1}>
							{/* pfs注册入口 */}
								<section>
									<p>{ intl.get('09D.01.001-2') }</p>
									<i>
										<img src={require('./next@2x.png')} alt=" " />
									</i>
								</section>
							</li>
							<li onClick={() => this.goRecipients()} className="clearFix">
								<section>
									<p>{ intl.get('09D.01.001-3') }</p>
									<i>
										<img src={require('./next@2x.png')} alt=" " />
									</i>
								</section>
							</li>
							{
								this.state.transferSetList.recurPay === '1' &&
								// 预约转账管理入口
								<Link to={{ pathname: '/Recurring', state: { type: 1 } }} key={3}>
									<li className="clearFix">
										<section>
											<p>{ intl.get('09D.01.001-4') }</p>
											<i>
												<img src={require('./next@2x.png')} alt=" " />
											</i>
										</section>
									</li>
								</Link>
							}
						</ul>
					</article>
					<article>
						<ul>
							<li onClick={() => this.goAuthorizedDirectDebit()} className="clearFix">
							{/* sedda 主扣款入口 */}
								<section>
									<p>{ intl.get('09D.01.001-5') }</p>
									<i>
										<img src={require('./next@2x.png')} alt=" " />
									</i>
								</section>
							</li>
							<li onClick={() => this.goEdda()} className="clearFix">
								<section>
									<p>{ intl.get('09D.01.001-6') }</p>
									<i>
										<img src={require('./next@2x.png')} alt=" " />
									</i>
								</section>
							</li>
							{
								this.state.transferSetList.linkBank === '1' &&
								<li
									onClick={() => this.goLinkBank()}
									className="clearFix">
									<section>
										<p>{ intl.get('09D.01.001-7') }</p>
										<i>
											<img src={require('./next@2x.png')} alt=" " />
										</i>
									</section>
								</li>
							}
						</ul>
					</article>
					<article>
						<ul>
							<li className="clearFix">
								<Link className="clearFix" to={{ pathname: '/SetLimit', query: { type: 1 } }} key={7}>
									<section>
										<p>{ intl.get('09D.01.001-9') }</p>
										<i>
											<img src={require('./next@2x.png')} alt=" " />
										</i>
									</section>
								</Link>
							</li>
							<li className="clearFix">
								<Link className="clearFix" to={{ pathname: '/SetLimit', query: { type: 2 } }} key={8}>
									<section>
										<p>{ intl.get('07.05.007-2-1') }</p>
										<i>
											<img src={require('./next@2x.png')} alt=" " />
										</i>
									</section>
								</Link>
							</li>
						</ul>
					</article>
				</header>
			</div>
		)
	}
	goNativeFps() {
		window.location.href = `${window.location.origin}/fefps/index.html`;
	}
	// 跳转常用收款人
	async goRecipients() {
		const payees = this.props.stateData.payees
		// 根据api决定跳转常用收款人哪个页面
		if (payees.length === 0) {
			// 新增收款人
			this.props.router.push({ pathname: '/Recipients/add' })
		} else {
			// 已有收款人
			this.props.router.push({ pathname: '/Recipients' })
		}
	}
	async goAuthorizedDirectDebit() {
		window.location.href = window.location.href = `${window.location.origin}/pay/edda.html#/`;
		// 根据api决定跳转常用水电煤哪个页面
	}
	async goEdda() {
		window.location.href = `${window.location.origin}/pay/bank-auto-deposit.html#/`;
		// 根据api决定跳转 edda 哪个页面 auto-deposit
		// alert(`根据api决定跳转 edda 哪个页面`);
		// const res = await queryTransfersetInfo();
	}
	async goLinkBank() {
		window.location.href = `${window.location.origin}/pay/linked-bank.html#/`;
	}
	async initData() {
		// custno
		const res = await queryTransfersetInfo(
			{
				bizInfo: {

				}
			}
		);

		if (res.data.resultCode === 1) {
			console.info(res)
			console.info(` ---------- tranfer-setting list ----------`);
			this.setState({
				renderStatus: true,
				transferSetList: res.data.resultData
			})
		}
	}
}
const mapStateToProps = (state) => ({
	stateData: state.recipient
})

const mapDispatchToProps = (dispatch) => ({
	fetchMedda: (payload) => {
		dispatch({
			payload,
			type: 'REQUEST_PAYEE'
		})
	}
})
export default connect(
	mapStateToProps,
	mapDispatchToProps
)(Home)
