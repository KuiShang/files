import recipient from './recipient/en'
import recurring from './recurring/en'
const en_HK = {
	// transfer setting
	"09D.01.001-1": 'Transfers',
	"09D.01.001-2": 'FPS',
	"09D.01.001-3": 'Friend List',
	"09D.01.001-4": 'Scheduled Transfers',
	"09D.01.001-5": 'Direct Debit',
	"09D.01.001-6": 'Direct Deposit',
	"09D.01.001-7": 'Linked Bank Accounts',
	"09D.01.001-8": 'Small-Value Transfer Limit',
	"09D.01.001-9": 'Daily Transfer Limit',
	...recipient,
	...recurring,
	// set-limit
	"09D.01.009-2": 'Set daily limit:',
	"09D.01.003-2": 'Set Daily Small-Value Tranfer Limit:',
	"09D.01.003A-3-1": '超过最大值(待提供)',
	"09D.01.003A-3-2": '超过最小值(待提供)',
	"09D.01.003-3": 'Important Notice',
	"09D.01.003-4-1": "1. You can make Small-value Transfer(s) with a total amount of no more than the Small-value Transfer Limit number of times of transactions",
	"09D.01.003-4-2": "2. The Small-value Transfer Limit is up to HKD10,000 per day and cannot be higher than the Transfer Limit",
	"09D.01.003-4-3": "3. When you adjust the Transfer Limit to an amount less than the Small-value Transfer Limit, the Small-value will be simultaneously reduced to the same amount. ",
	"09D.01.003-5": 'I have read, understood and agreed',
	"09D.01.003-6": 'Confirm',
	'09D.01.003A-4-1': 'Max: ',
	'09D.01.003A-4-2': ' HKD',
	'Payment Reactivated': 'Payment Reactivated',
	'07.05.007-2-1': 'Daily Transfer Limit',
	'07.05.007-2-2': 'Daily Small-Value Transfer Limit',
	'07.05.007-3': 'Done!',
	"09D.01.003-1": 'Daily Transfer Limit',
	"09D.01.009-1": 'Small-Value Tranfer',
	"09D.01.008-1": "Confirmation",
	"09D.01.008-4": "OK",
	"07.01.021.02": 'No internet connection, please try again'
}
export default en_HK;   