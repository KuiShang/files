import React from 'react';
import './FilterRecipient.scss'
import tick from '../img/tick.svg';

import intl from 'react-intl-universal'

export default class FilterRecipient extends React.Component {
  state = {
    filterList: [
        {
          title: intl.get('Show All'),
          value: 0
        },
        {
          title: intl.get('Mobile Number'),
          value: 1
        },
        {
          title: intl.get('Bank Account Number'),
          value: 2
        },
        {
          title: intl.get('Email'),
          value: 3
        },
        {
          title: intl.get('FPS ID'),
          value: 4
        }
      ],
      value: [...this.props.currentValue] || []
  }
  click = (idx) => {
    const value = this.state.filterList[idx].value 
    let valueArr = this.state.value
    if (this.state.value.includes(value)) {
      // 要删除某一个选项
      if (valueArr.length > 1) {
        // 保证最少数组有一项
        valueArr.splice(valueArr.findIndex(item => item === value), 1)
      }
    } else {
      // 要添加一个选项
      if (value === 0) {
        // 选中全部时候  清空数组
        valueArr = [0]
      } else {
        // 选中其他的时候判断里面如果包含0 要去掉
        if (valueArr.includes(0)) {
          valueArr.splice(valueArr.findIndex(item => item === 0), 1)
        }
        valueArr = [value, ...valueArr]
        
      }
    }
  
    this.setState({
      value: valueArr
    }, () => {
      
    })
    this.props.onChange({value: valueArr})
  }
  render() {
    const valueArr = this.state.value || []
    return <ul className="recipient-filter-container">
      {
        
        this.state.filterList.map((item, idx) => (
          <li key={item.title} className="item" onClick={e => this.click(idx)}>
            <p className={` ${valueArr.indexOf(item.value) !== -1 ? 'txt-tick-actived' : ''}`} >{item.title}</p>
            <img src={tick} alt="" className={`tick ${valueArr.indexOf(item.value)!== -1  ? 'tick-actived' : ''}`}/>
          </li>
        ))
      }
    </ul>
  }

}

