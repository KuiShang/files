import React from 'react';
import CardSwitch from 'components/card-switch';
import ClickItem from 'components/click-item/ClickItem';
import intl from 'react-intl-universal';
import classnames from 'classnames';
import './selectBank.scss'


export default class mobile extends React.Component {
  constructor() {
    super()
    this.state = {
      activeFirst: true
    }
  }
  tabClick = (c) => {
    console.info(c)
    this.setState({
      activeFirst: c ===  true
    })
  }
  render() {
    const animaClass = classnames('height120', 'animat',  {
      'height0': this.state.activeFirst
    })
    return (
      <div className="select-bank">
        <CardSwitch title={ intl.get("send_to_recipient") } options={['default bank', 'other bank']} onSwitch={(c) => this.tabClick(c)}></CardSwitch>
        <p className="height32"></p>
        <div className={animaClass}>
          <ClickItem></ClickItem>
        </div>
      </div>
    )
  }
}