import React from 'react';
import intl from 'react-intl-universal'
import { connect } from 'react-redux'
import FilterSearch from 'commonComponents/filter-search';
import ContactColor from 'commonComponents/contact-color';
import PopOver from 'commonComponents/pop-over';
import Toast from 'components/toast';
import FilterRecipient from './module/FilterRecipient'
import './Recipients.scss'
import * as SDK from '../sdk/wrapper';
import  { stopBodyScroll }  from '../util';
// const PopOver = React.lazy(() => import('components/pop-over'))

class Recipients extends React.Component {
  state = {
    showFilterFlag: false,
    currentFilter: [0],
    currentFilterTxt: '',
  }

  add = () => {
    if (this.props.payees && this.props.payees.name_list.length >= 30) {
      Toast.info('at most 30')
      return
    }
    this.props.router.push(`${this.props.route.path}/add`)
  }
  showFilter = () => {
    this.setState({
      showFilterFlag: true
    })
    stopBodyScroll(true)
  }
  closePop = () => {
    this.setState({
      showFilterFlag: false
    })
    stopBodyScroll(false)
  }
  donPop = (idxArr) => {
    if (!idxArr) {
      this.closePop()
      return
    }
    this.setState({
      currentFilter: [...idxArr.value]
    }, () => {
      this.closePop()
    })
  }
   componentDidMount() { 
    SDK.setTitle({
      title: intl.get('Saved Contacts'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })


    SDK.buriedPointEntry({
      pageName: 'COIPS_REGDREC_START'
    })



    SDK.setHeaderWithImg((ret) => {
      if (ret.data.outData === 'right') {
        this.showFilter()
      } else if (ret.data.outData === 'left') {
        this.add()
      }
    })
    this.props.fetchPayee({
    })
    // SDK.onBackPress(() => {
    //   const queryfrom = this.props.location.query.from.add
    //   if (queryfrom === 'add') {
    //     this.props.router.push()
    //   } else {
    //     this.props.router.go(-1)
    //   }
    // });
    
  }
  componentWillUnmount() {
    SDK.setHeaderWithImgHide()
    SDK.buriedPointLeave({
      pageName: 'COIPS_REGDREC_START'
    });
  }
  onChange = (e) => {
    const filter = e.target.value;

    this.setState({
      currentFilterTxt: filter
    })
  }
  onFilterFecipientChange= (e) => {
      console.info(e)
  }
  onSelectRecipient = (obj) => {
    console.info(obj)
    this.props.setCurrentPayee(obj)
    if (obj.inactp === 'BBAN') {
      this.props.router.push(`${this.props.route.path}/accountNumber`)
    } else if (obj.inactp === 'MOBN') {
      this.props.router.push(`${this.props.route.path}/mobile`)
    } else if (obj.inactp === 'EMAL') {
      this.props.router.push(`${this.props.route.path}/email`)
    } else if (obj.inactp === 'SVID') {
      this.props.router.push(`${this.props.route.path}/fpsId`)
    } else {
      Toast.info('wrong inactp :' + obj.inactp, 1)
    }
  }
  addFilter = (data) => {
    let filter = this.state.currentFilterTxt
    var tmparr = data.name_list || []
    let retArr = []
    let arr = tmparr.filter(item => {
      if (item.pyform.indexOf(filter) >= 0 || item.pyacct.indexOf(filter) >= 0 || item.banknm.indexOf(filter) > 0) {
        return item;
      } else {
        return null;
      }
    })
    if (this.state.currentFilter.includes(0)) {
      retArr = arr
    } 
    
    if (this.state.currentFilter.includes(1)) {// Mobile Number
      let moarr = arr.filter(item => {
        if (item.inactp === 'MOBN') {
          return item;
        } else {
          return null;
        }
      })

      retArr.push(...moarr)
    }
    if (this.state.currentFilter.includes(2)) { // Bank Account Number
      let moarr = arr.filter(item => {
        if (item.inactp === 'BBAN') {
          return item;
        } else {
          return null;
        }
      })

      retArr.push(...moarr)
    } 
    if (this.state.currentFilter.includes(3)) {// Email
      let moarr = arr.filter(item => {
        if (item.inactp === 'EMAL') {
          return item;
        } else {
          return null;
        }
      })

      retArr.push(...moarr)
    } 
    if (this.state.currentFilter.includes(4)) {// FPS ID
      let moarr = arr.filter(item => {
        if (item.inactp === 'SVID') {
          return item;
        } else {
          return null;
        }
      })

      retArr.push(...moarr)
    }
    return {
      name_list: retArr
    }


  }
  render() {
    return (
      <div className="trans-set-recip">
        {/* <button onClick={this.add}>go fps add</button>
        <p></p>
        <button onClick={this.showFilter}>recipients filter</button> */}
        <div className="search-container">
          <FilterSearch placeholder={ intl.get('Search')} onChange={e => this.onChange(e)}></FilterSearch>
        </div>
        <ContactColor data={this.addFilter(this.props.payees)} onSelectItem={obj => this.onSelectRecipient(obj)} ></ContactColor>
        {this.state.showFilterFlag &&
          <PopOver titleDone={intl.get('Done')} visible={this.state.showFilterFlag}
            onShow={this.closePop}
            onDone={this.donPop}>
            <FilterRecipient onChange={this.onFilterFecipientChange} currentValue={this.state.currentFilter}></FilterRecipient>
          </PopOver>
        }

      </div>
    )
  }
}
const mapStateToProps = (state) => ({
  payees: state.recipient.payees,
  currentPayee: state.recipient.currentPayee,
  custno: state.recipient.custno
})

const mapDispatchToProps = (dispatch) => ({
  fetchPayee: (payload) => {
    dispatch({
      payload,
      type: 'REQUEST_PAYEE'
    })
  },
  setCurrentPayee: (payload) => {
    dispatch({
      payload,
      type: 'SET_CURRENT_PAYEE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Recipients)