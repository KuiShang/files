import React from 'react';
import CardTo from 'commonComponents/card-to';
import { connect } from 'react-redux'
import './add.scss'
// import TextFieldContact from 'components/text-field-contact';
import CardToMobile from 'commonComponents/card-to-mobile';
import SelectBank from './module/selectBank';
import CardToBankAccount from 'commonComponents/card-to-bank-account';
import Button from 'commonComponents/button/button';
import TextField from 'commonComponents/text-field';
import * as SDK from 'utils/SDKUtil';
import Hint from 'components/modal-hint';
import PopOver from 'components/pop-over';
import intl from 'react-intl-universal'
import PhonePicker from 'components/phone-picker';
const INACTP_TYPE = ['MOBN', 'BBAN', 'EMAL', 'SVID']
class Add extends React.Component {
  constructor() {
    super()
    this.state = {
      currentTab: 1,
      showHint: false,
      inviteCodeJSON: {
        value: '',
        isPass: true,
        placeHolder: intl.get('Contact display name'),
        hasRequiredMessage: true,
        regExpMessgae: '只能1-60字符',
      },
      inviteCodeJSON2: {
        value: '',
        isPass: true,
        placeHolder:  intl.get('Email'),
        hasRequiredMessage: true,
        regExpMessgae: "error email",
      },
      inviteCodeJSON3: {
        value: '',
        isPass: true,
        placeHolder: intl.get('FPS ID'),
        hasRequiredMessage: true,
        regExpMessgae: "只能长度是七位的数字",
      },
      pyacct: '',
      // 选手机号
      country: '+852',
      showPhone: false,
      phone: null,
      mobile: '',
      showTips: false,
      disabled: false,
      selectRecipient: null,
      bankAccount: null,
      showHint: false,
      pyname: '',
      pybank: '',
      banknm: '',
      btnok_name: false,
      btnok_mobile: false,
      btnok_account: false,
      btnok_email: false,
      btnok_fps: false,
      btnok_fullName: false,
      Lock: true,
    }
  }

  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Add My Contact'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_ADDREC'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_ADDREC'
    });
  }


  btnClick = () => {
    if (this.state.inviteCodeJSON.value.trim().length === 0) {
      return
    }

    let pyacct = ''
    let additionalData = {}
    if (this.state.currentTab === 1) {
      pyacct = this.state.country + '-' + this.state.mobile
    } else if (this.state.currentTab === 2) {
      pyacct = this.state.pyacct
      additionalData = {
        pyname: this.state.pyname,
        pybank: this.state.pybank,
        banknm: this.state.banknm
      }
    } else if (this.state.currentTab === 3) {
      pyacct = this.state.inviteCodeJSON2.value
    } else if (this.state.currentTab === 4) {
      pyacct = this.state.inviteCodeJSON3.value
    }
    const data = {
      // custno: this.props.custno,
      pyform: this.state.inviteCodeJSON.value,
      inactp: INACTP_TYPE[this.state.currentTab - 1],
      pyacct: pyacct,
      ...additionalData
    }
    this.props.addPayee(data)
  }
  cancel = () => {
    this.props.router.push('/Recipients')
  }
  onChecked = (index) => {
    console.info(index)
    this.setState({
      currentTab: index
    })
  }
  /**
* 修改手机号
*/
  onChangeMobile = (mobile) => {
    let show = false;
    if (mobile.split("").length >= 7) {
      show = true;
    }
    this.setState({ mobile });
  }

  /**
     * 选择手机号
     */
  onSelectMobile = () => {

    console.info('onSelectMobile')
    SDK.goNativePhoneList((res) => {
      console.info(res)

      if (res.code === 1) {
        const phone = res.data.outData.phone;
        if (phone.length > 1) {
          this.setState({ phone, showPhone: true })

        } else if (phone.length === 1) {
          this.setState({ mobile: phone[0].value.replace(/\s+/g, "") })
          this.ifmobileok(phone[0].value.replace(/\s+/g, "") )
        }
      }
    })
  }
  // 判断当前手机号是否能通过
  ifmobileok = (value) => {
    if (this.state.country === '+852') {
      if (/^[4-9]/.test(value)) {
        this.setState({ btnok_mobile: true })
      } else {
        this.setState({ btnok_mobile: false })
      }
    } else if (this.state.country === '+86') {
      if (/^[1]/.test(value)) {
        this.setState({ btnok_mobile: true })
      } else {
        this.setState({ btnok_mobile: false })
      }
    }
  }
  onPickPhone = (item) => {
    this.setState({ mobile: item.value, showPhone: false })
    this.ifmobileok(item.value)
  }

  /**
  * 选择手机号国家码
  */
 onSelectCountryCode = () => {
  SDK.goCountryCode(res => {
    this.setState({ country: (res.data.outData.mobilePrefix) })
    const value = this.state.mobile
    if (res.data.outData.mobilePrefix == '+852') {
     
      if (/^[4-9]/.test(value)) {
        this.setState({btnok_mobile: true})
      } else {
        this.setState({btnok_mobile: false})
      }

    } else if (res.data.outData.mobilePrefix == '+86') {
      if (/^[1]/.test(value)) {
        this.setState({btnok_mobile: true})
      } else {
        this.setState({btnok_mobile: false})
      }
    }
  });

}
  regExpName = (val, flag=true) => {
    // 只能包含字符、数字和下划线
    const nameReg =/^[\S]{1,60}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_name: false,
        Lock: flag
      })
      return false
    } else {
      this.setState({
        btnok_name: true
      })
    }
    return true
  }
  onMobileStates = (status) => {
    this.setState({
      btnok_mobile: status
    })
  }
  onAccountStates = (status) => {
    this.setState({
      btnok_account: status
    })
  }
  regExpEmail = (val) => {
    // 验证Email地址
    const nameReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_email: false
      })
      return false
    } else {
      this.setState({
        btnok_email: true
      })
    }
    return true
  }
  regExpFps = (val) => {
    // 只能包含字符、数字和下划线
    const nameReg = /^\d{7}$/
    console.info( val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_fps: false
      })
      return false
    } else {
      this.setState({
        btnok_fps: true
      })
    }
    return true
  }
  /**
   * 选择银行
   */
  onSelectBank = () => {
    console.info('selectbank')
    const url = `http://${window.location.host}/pay/bank-code.html?ref=tran`;
    // "Recipient's Bank"
    SDK.goNativeWebview(url, (res) => {
      if (res.code === 1) {
        this.setState({
          pybank: res.data.outData.bank_code,
          banknm: res.data.outData.bank_en_name
        })

      }
    });
  }

  getCurrent() {
    const { fps, country, mobile, showPhone, showHint, phone, showTips, showBanks, showContinue, disabled, selectRecipient, bankAccount, transferPayer, payees, curType } = this.state;

    let tem = ''
    if (this.state.currentTab === 1) {
      tem = (
        <>
          <p className="height10"></p>
          {/* <TextFieldContact  mobile={this.state.pyacct} onHandleContact={this.onHandleContact}></TextFieldContact> */}
          <CardToMobile
            country={country}
            mobile={mobile}
            showTips={showTips}
            disabled={disabled}
            selectRecipient={selectRecipient}
            showBanks={showBanks}
            onSelectCountryCode={this.onSelectCountryCode}
            onSelectMobile={this.onSelectMobile}
            onChangeMobile={this.onChangeMobile}
            onMobileStates = {this.onMobileStates}
          >
          </CardToMobile>

          <p className="height16"></p>
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_mobile)} onClick={this.btnClick}>{intl.get('Save')}</Button>
          <div className="cancel" onClick={this.cancel}>{intl.get('Cancel')}</div>
          {
            showPhone &&
            <PopOver title={intl.get('mobile_number')} visible={showPhone} onShow={() => this.setState({ showPhone: !showPhone })}>
              <PhonePicker data={phone} onSelect={(item) => this.onPickPhone(item)}></PhonePicker>
            </PopOver>
          }
        </>
      )
    } else if (this.state.currentTab === 2) {
      tem = (
        <>
          <CardToBankAccount onHint={() => this.setState({ showHint: !showHint })}
            onHandleAccountFullName={this.onHandleAccountFullName}
            onChangeAccountNum={this.onChangeAccountNum}
            onSelectBank={this.onSelectBank}
            onAccountStates = {this.onAccountStates}
            pybank={this.state.pybank}
            banknm={this.state.banknm}
            pyname={this.state.pyname}
          ></CardToBankAccount>
          <p className="height32"></p>
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_account && this.state.btnok_fullName )} onClick={this.btnClick}>{intl.get('Save')}</Button>
          <div className="cancel" onClick={this.cancel}>{intl.get('Cancel')}</div>
        </>
      )
    } else if (this.state.currentTab === 3) {
      tem = (
        <div className="aa">
          <TextField
            propValue={this.state.inviteCodeJSON2}
            stateName={'inviteCodeJSON2'}
            regExpFn={this.regExpEmail}
            requireInputMessage='can not be empty'
            setCurrentInputData={this.setCurrentInputData.bind(this)}
          ></TextField>
          <p className="height16"></p>
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_email)} onClick={this.btnClick}>{intl.get('Save')}</Button>
          <div className="cancel" onClick={this.cancel}>{intl.get('Cancel')}</div>
        </div>
      )
    } else if (this.state.currentTab === 4) {
      tem = (
        <div className="bbb">

          <TextField
            requireInputMessage='can not be empty'
            regExpFn={this.regExpFps}
            propValue={this.state.inviteCodeJSON3}
            stateName={'inviteCodeJSON3'}
            setCurrentInputData={this.setCurrentInputData.bind(this)}
          ></TextField>
          <p className="height16"></p>
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_fps)} onClick={this.btnClick}>{intl.get('Save')}</Button>
          <div className="cancel" onClick={this.cancel}>{intl.get('Cancel')}</div>
        </div>
      )
    }
    return tem
  }

  onHandleAccountFullName = (name) => {

    this.setState({
      pyname: name
    })
    const nameReg =/^[\S]{1,60}$/
    if (!name || !nameReg.test(name)) {
      this.setState({
        btnok_fullName: false
      })
      return false
    } else {
      this.setState({
        btnok_fullName: true
      })
    }


  }
  onChangeAccountNum = (pyacct) => {
    console.info('onChangeAccountNum')
    this.setState({
      pyacct: pyacct
    })
  }
  onHandleContact = (e) => {
    this.setState({
      pyacct: e
    })
  }
  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    let data = Object.assign({}, this.state[properyName], json);
    this.setState({
      [properyName]: data
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }
  render() {
    const { showHint } = this.state
    return (
      <div className="trans-set-recip-add">
        <div>
          <TextField
            regExpFn={this.regExpName}
            requireInputMessage='can not be empty'
            propValue={this.state.inviteCodeJSON}
            stateName={'inviteCodeJSON'}
            setCurrentInputData={this.setCurrentInputData.bind(this)}
          ></TextField>
        </div>
        { ((!this.state.btnok_name) && ((this.state.country === '+852' && this.state.mobile.length === 8) || (this.state.country === '+86'&& this.state.mobile.length === 11)) && (this.state.Lock)) ? <div className='error_tip'>{'can not be empty'}</div> : null}
        <CardTo title={intl.get('Add Contact with')} hideRecent={true} checkedIndex={this.state.currentTab} onChecked={index => this.onChecked(index)}></CardTo>
        {this.getCurrent()}
        {
          showHint &&
          <PopOver title={intl.get('Tips')} visible={showHint} onShow={() => this.setState({ showHint: !this.state.showHint })} >
            <Hint></Hint>
          </PopOver>
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  // custno: state.recipient.custno,
  chnlcd: state.recipient.chnlcd,
})

const mapDispatchToProps = (dispatch) => ({
  // 添加联系人
  addPayee: (payload) => {
    dispatch({
      payload,
      type: 'ADD_PAYEE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Add)