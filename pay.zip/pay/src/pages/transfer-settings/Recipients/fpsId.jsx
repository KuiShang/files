        import React from 'react';
import Button from 'commonComponents/button/button';
import TextField from 'commonComponents/text-field';
import PopOver from 'components/pop-over';
import { connect } from 'react-redux'
import DeleteModule from '../../../commonComponents/deleteModule/deleteModule';
import './fpsId.scss'
import * as SDK from 'utils/SDKUtil';

import intl from 'react-intl-universal'

class FpsId extends React.Component {
  state = {
    inviteCodeJSON: {
      value: this.props.currentPayee.pyform,
      isPass: true,
      placeHolder: intl.get('Contacts Nickname'),
      hasRequiredMessage: true,
      regExpMessgae: "只能中英文，数字，下划线，减号",
    },
    inviteCodeJSON2: {
      value: this.props.currentPayee.pyacct,
      isPass: true,
      placeHolder: intl.get('FPS ID'),
      hasRequiredMessage: true,
      regExpMessgae: "只能长度是七位的数字",
    },
    showHint: false,
    btnok_name: true,
    btnok_fps: true
  }
  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Change Contacts Info'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    
    SDK.buriedPointEntry({
      pageName: 'COIPS_EDITREC_FPS'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_EDITREC_FPS'
    });
  }
  btnClick = () => {
    const data = {
      ...this.props.currentPayee,
      pyform: this.state.inviteCodeJSON.value,
      pyacct: this.state.inviteCodeJSON2.value
    }
    this.props.updatePayee(data)
    // this.props.router.push('/Recipients/result')
  }
  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    let data = Object.assign({}, this.state[properyName], json);
    this.setState({
      [properyName]: data
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }
  removeRecipent = () => {
    const data = {
      payeno: this.props.currentPayee.payeno
    }
    this.props.deleteCurrentPayee(data)
  }
  doneFn = () => {
    this.props.setDeleteModuleState(false)
   //  this.props.router.push('/Recipients')
   window.history.go(-1)
  }
  regExpName = (val) => {
    // 只能包含字符、数字和下划线
    const nameReg =/^[\S]{1,60}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_name: false
      })
      return false
    } else {
      this.setState({
        btnok_name: true
      })
    }
    return true
  }
  regExpFps = (val) => {
    // 只能包含字符、数字和下划线
      // 只能包含字符、数字和下划线
      const nameReg = /^\d{7}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_fps: false
      })
      return false
    } else {
      this.setState({
        btnok_fps: true
      })
    }
    return true
  }
  render() {
    const { showHint } = this.state;
    return (
      <div className="transf-set-recip-fps-id">
        <TextField
          propValue={this.state.inviteCodeJSON}
          stateName={'inviteCodeJSON'}
          regExpFn={this.regExpName}
          requireInputMessage='can not be empty'
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <p className="height16"></p>
        <TextField
          propValue={this.state.inviteCodeJSON2}
          stateName={'inviteCodeJSON2'}
          requireInputMessage='can not be empty'
          regExpFn={this.regExpFps}
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <p className="height32"></p>
        <div className="btn-wraper">
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_fps)} onClick={this.btnClick}>{intl.get('Save Changes')}</Button>
        </div>
        <div className="remove-recipient" onClick={() => this.props.setDeleteModuleState(true)}>{intl.get('Remove')}</div>
        {this.props.showDeleteDialog &&
          <PopOver visible={this.props.showDeleteDialog} isDialog={true}
            onShow={() => this.props.setDeleteModuleState(false)}>
            <DeleteModule doneFn={this.doneFn} deleteFn={this.removeRecipent}></DeleteModule>
          </PopOver>
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  currentPayee: state.recipient.currentPayee,
  showDeleteDialog: state.recipient.showDeleteDialog
})

const mapDispatchToProps = (dispatch) => ({
  // 更新联系人
  updatePayee: (payload) => {
    dispatch({
      payload,
      type: 'UPDATE_PAYEE'
    })
  },
  // 删除联系人
  deleteCurrentPayee: (payload) => {
    dispatch({
      payload,
      type: 'DELETE_CURRENT_PAYEE'
    })
  },
  // 联系人弹窗展示与隐藏
  setDeleteModuleState: (payload) => {
    dispatch({
      payload,
      type: 'SET_DELETE_MODULE_STATE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(FpsId)