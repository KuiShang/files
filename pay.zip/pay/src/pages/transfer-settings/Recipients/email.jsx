import React from 'react';
import intl from 'react-intl-universal'
import Button from 'commonComponents/button/button';
import TextField from 'commonComponents/text-field';
import { connect } from 'react-redux'
import DeleteModule from '../../../commonComponents/deleteModule/deleteModule';
import PopOver from 'components/pop-over';
import './email.scss'

import * as SDK from 'utils/SDKUtil';


class Email extends React.Component {
  state = {
    inviteCodeJSON: {
      // value: 'Dhun158u',
      value: this.props.currentPayee.pyform,
      isPass: true,
      placeHolder: intl.get('Contacts Nickname'),
      hasRequiredMessage: true,
      regExpMessgae: "只能中英文，数字，下划线，减号"
    },
    inviteCodeJSON2: {
      // value: 'Dhun158u',
      value: this.props.currentPayee.pyacct,
      isPass: true,
      placeHolder: intl.get('Email'),
      hasRequiredMessage: true,
      regExpMessgae: "error email"
    },
    btnok_name: true,
    btnok_email: true
  }

  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Change Contacts Info'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_EDITREC_EMAIL'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_EDITREC_EMAIL'
    });
  }


  regExpName = (val) => {
    // 只能包含字符、数字和下划线
    const nameReg =/^[\S]{1,60}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_name: false
      })
      return false
    } else {
      this.setState({
        btnok_name: true
      })
    }
    return true
  }
  regExpEmail = (val) => {
    // 验证Email地址
    const nameReg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_email: false
      })
      return false
    } else {
      this.setState({
        btnok_email: true
      })
    }
    return true
  }
  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    let data = Object.assign({}, this.state[properyName], json);
    this.setState({
      [properyName]: data
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }
  btnClick = () => {
    const data = {
      ...this.props.currentPayee,
      pyform: this.state.inviteCodeJSON.value,
      pyacct: this.state.inviteCodeJSON2.value
    }
    this.props.updatePayee(data)
    // this.props.router.push('/Recipients/result')
  }
  removeRecipent = () => {
    const data = {
      payeno: this.props.currentPayee.payeno
    }
    this.props.deleteCurrentPayee(data)
  }
  doneFn = () => {
    this.props.setDeleteModuleState(false)
    // this.props.router.push('/Recipients')
    window.history.go(-1)
  }
  render() {
    return (
      <div className="setting-email">
        <TextField
          regExpFn={this.regExpName}
          requireInputMessage='can not be empty'
          propValue={this.state.inviteCodeJSON}
          stateName={'inviteCodeJSON'}
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <p className="height16"></p>
        <TextField
          regExpFn={this.regExpEmail}
          requireInputMessage='can not be empty'
          propValue={this.state.inviteCodeJSON2}
          stateName={'inviteCodeJSON2'}
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <p className="height32"></p>
        <Button type="primary"  disabled={!(this.state.btnok_name && this.state.btnok_email)} onClick={this.btnClick}>{intl.get('Save Changes')}</Button>
        <div className="remove-recipient" onClick={() => this.props.setDeleteModuleState(true)}>{intl.get('Remove')}</div>
        {this.props.showDeleteDialog &&
          <PopOver visible={this.props.showDeleteDialog} isDialog={true}
            onShow={() => this.props.setDeleteModuleState(false)}>
            <DeleteModule doneFn={this.doneFn} deleteFn={this.removeRecipent}></DeleteModule>
          </PopOver>
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  currentPayee: state.recipient.currentPayee,
  showDeleteDialog: state.recipient.showDeleteDialog
})

const mapDispatchToProps = (dispatch) => ({
  // 更新联系人
  updatePayee: (payload) => {
    dispatch({
      payload,
      type: 'UPDATE_PAYEE'
    })
  },
  // 删除联系人
  deleteCurrentPayee: (payload) => {
    dispatch({
      payload,
      type: 'DELETE_CURRENT_PAYEE'
    })
  },
  // 联系人弹窗展示与隐藏
  setDeleteModuleState: (payload) => {
    dispatch({
      payload,
      type: 'SET_DELETE_MODULE_STATE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Email)