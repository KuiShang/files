import React from 'react';
import { connect } from 'react-redux'

import intl from 'react-intl-universal'

import CardToMobile from '../../../commonComponents/card-to-mobile';

import Button from 'commonComponents/button/button';
import TextField from 'commonComponents/text-field';
import DeleteModule from '../../../commonComponents/deleteModule/deleteModule';
import PopOver from 'components/pop-over';
import './mobile.scss'
import PhonePicker from 'components/phone-picker';
import * as SDK from 'utils/SDKUtil';
class mobile extends React.Component {
  state = {
    inviteCodeJSON: {
      // value: 'Dhun158u',
      value: this.props.currentPayee.pyform,
      isPass: true,
      placeHolder: intl.get('Contacts Nickname'),
      hasRequiredMessage: true,
      regExpMessgae: "只能中英文，数字，下划线，减号"
    },

    // 选手机号
    country: '',
    showPhone: false,
    phone: null,
    mobile: '',
    showTips: false,
    disabled: false,
    selectRecipient: null,
    bankAccount: null,
    btnok_name: true,
    btnok_mobile: true
  }
  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Change Contacts Info'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    
    this.getPhoneWithoutAreaCode()
    SDK.buriedPointEntry({
      pageName: 'COIPS_EDITREC_MOBILE'
    })

  }

  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_EDITREC_MOBILE'
    });
  }
  getPhoneWithoutAreaCode = () => {
    const all = this.props.currentPayee.pyacct
    if (!all) {
      console.warn('没有数据')
      return
    }
    const arr = all.split('-')
    this.setState({
      country: arr[0],
      mobile: arr[1]
    })
  }
  btnClick = () => {
    const data = {
      ...this.props.currentPayee,
      pyform: this.state.inviteCodeJSON.value,
      pyacct: this.state.country + '-' + this.state.mobile
    }
    this.props.updatePayee(data)
    // this.props.router.push('/Recipients/result')
  }
  removeRecipent = () => {
    const data = {
      payeno: this.props.currentPayee.payeno
    }
    this.props.deleteCurrentPayee(data)
  }
  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    let data = Object.assign({}, this.state[properyName], json);
    this.setState({
      [properyName]: data
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }

  doneFn = () => {
    this.props.setDeleteModuleState(false)
    // this.props.router.push('/Recipients')
    window.history.go(-1)
  }
  /**
  * 选择手机号国家码
  */
  onSelectCountryCode = () => {
    SDK.goCountryCode(res => {
      this.setState({ country: (res.data.outData.mobilePrefix) })
      const value = this.state.mobile
      if (res.data.outData.mobilePrefix == '+852') {
       
        if (/^[4-9]/.test(value)) {
          this.setState({btnok_mobile: true})
        } else {
          this.setState({btnok_mobile: false})
        }

      } else if (res.data.outData.mobilePrefix == '+86') {
        if (/^[1]/.test(value)) {
          this.setState({btnok_mobile: true})
        } else {
          this.setState({btnok_mobile: false})
        }
      }
    });
  
  }
  /**
     * 选择手机号
     */
  onSelectMobile = () => {
    SDK.goNativePhoneList((res) => {
      console.info('res手机号', res)
      // if (res.code === 1) {
      //   const phone = res.data.outData.phone
      //   this.setState({ mobile: phone })
      // }


      if (res.code === 1) {
        const phone = res.data.outData.phone;
        if (phone.length > 1) {
          this.setState({ phone, showPhone: true })

        } else if (phone.length === 1) {
          this.setState({ mobile: phone[0].value.replace(/\s+/g, "") })
          this.ifmobileok(phone[0].value.replace(/\s+/g, ""))
        }
      }


    })
  }

    // 判断当前手机号是否能通过
    ifmobileok = (value) => {
      if (this.state.country === '+852') {
        if (/^[4-9]/.test(value)) {
          this.setState({ btnok_mobile: true })
        } else {
          this.setState({ btnok_mobile: false })
        }
      } else if (this.state.country === '+86') {
        if (/^[1]/.test(value)) {
          this.setState({ btnok_mobile: true })
        } else {
          this.setState({ btnok_mobile: false })
        }
      }
    }
  onPickPhone = (item) => {
    this.setState({ mobile: item.value, showPhone: false })
    this.ifmobileok(item.value)
  }
  /**
  * 修改手机号
  */
  onChangeMobile = (mobile) => {
    this.setState({  mobile });
  }
  regExpName = (val) => {
    // 只能包含字符、数字和下划线
    const nameReg =/^[\S]{1,60}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_name: false
      })
      return false
    } else {
      this.setState({
        btnok_name: true
      })
    }
    return true
  }
  onMobileStates = (status) => {
    this.setState({
      btnok_mobile: status
    })
  }


  render() {
    const { fps, country, mobile, showPhone, showTips, phone, disabled, selectRecipient, bankAccount, transferPayer, payees, curType } = this.state;

    return (
      <div className="transf-set-recip-mobile">
        <TextField
          regExpFn={this.regExpName}
          requireInputMessage='can not be empty'
          propValue={this.state.inviteCodeJSON}
          stateName={'inviteCodeJSON'}
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <p className="height16"></p>
        <CardToMobile
          country={country}
          mobile={mobile}
          showTips={showTips}
          disabled={disabled}
          selectRecipient={selectRecipient}
          bankAccount={bankAccount}
          onSelectCountryCode={this.onSelectCountryCode}
          onSelectMobile={this.onSelectMobile}
          onChangeMobile={this.onChangeMobile}
          onMobileStates = {this.onMobileStates}
        >
        </CardToMobile>

        <p className="height32"></p>
        <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_mobile)} onClick={this.btnClick}>{intl.get('Save Changes')}</Button>
        <div className="remove-recipient" onClick={() => this.props.setDeleteModuleState(true)}>{intl.get('Remove')}</div>

        {this.props.showDeleteDialog &&
          <PopOver visible={this.props.showDeleteDialog} isDialog={true}
            onShow={() => this.props.setDeleteModuleState(false)}>
            <DeleteModule doneFn={this.doneFn} deleteFn={this.removeRecipent}></DeleteModule>
          </PopOver>
        }
        {
          showPhone &&
          <PopOver title={intl.get('mobile_number')} visible={showPhone} onShow={() => this.setState({ showPhone: !showPhone })}>
            <PhonePicker data={phone} onSelect={(item) => this.onPickPhone(item)}></PhonePicker>
          </PopOver>
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  currentPayee: state.recipient.currentPayee,
  showDeleteDialog: state.recipient.showDeleteDialog
})

const mapDispatchToProps = (dispatch) => ({
  // 更新联系人
  updatePayee: (payload) => {
    dispatch({
      payload,
      type: 'UPDATE_PAYEE'
    })
  },
  // 删除联系人
  deleteCurrentPayee: (payload) => {
    dispatch({
      payload,
      type: 'DELETE_CURRENT_PAYEE'
    })
  },
  // 联系人弹窗展示与隐藏
  setDeleteModuleState: (payload) => {
    dispatch({
      payload,
      type: 'SET_DELETE_MODULE_STATE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(mobile)