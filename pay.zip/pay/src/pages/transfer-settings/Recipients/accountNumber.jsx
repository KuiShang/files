import React from 'react';
import intl from 'react-intl-universal'
import TextField from 'commonComponents/text-field';
import CardToBankAccount from '../../../commonComponents/card-to-bank-account';
import Button from 'commonComponents/button/button';

import { connect } from 'react-redux'
import DeleteModule from '../../../commonComponents/deleteModule/deleteModule';
import PopOver from 'components/pop-over';
import Hint from 'components/modal-hint';
import * as SDK from 'utils/SDKUtil';
import './accountNumber.scss'
class AccountNumber extends React.Component {
  state = {
    showHint: false,
    inviteCodeJSON: {
      // value: 'Dhun158u',
      value: this.props.currentPayee.pyform,
      isPass: true,
      hasRequiredMessage: true,
      regExpMessgae: "只能中英文，数字，下划线，减号",
      placeHolder: intl.get('Contacts Nickname')
    },
    pybank: this.props.currentPayee.pybank,
    banknm: this.props.currentPayee.banknm,
    pyname: this.props.currentPayee.pyname,
    pyacct: this.props.currentPayee.pyacct,
    btnok_name: true,
    btnok_account: true,
    btnok_fullName: true
  }

  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Change Contacts Info'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_EDITREC_ACC'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_EDITREC_ACC'
    });
  }

  btnClick = () => {
    console.info(123)
    const data = {
      ...this.props.currentPayee,
      pyform: this.state.inviteCodeJSON.value,
      pyacct: this.state.pyacct,
      pyname: this.state.pyname,
      pybank: this.state.pybank,
      banknm: this.state.banknm
    }
    this.props.updatePayee(data)
    // this.props.router.push('/Recipients/result')
  }
  removeRecipent = () => {
    const data = {
      payeno: this.props.currentPayee.payeno
    }
    this.props.deleteCurrentPayee(data)
  }
  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    let data = Object.assign({}, this.state[properyName], json);
    this.setState({
      [properyName]: data
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }
  doneFn = () => {
    this.props.setDeleteModuleState(false)
    // this.props.router.push('/Recipients')
    window.history.go(-1)
  }
  onHandleAccountFullName = (name) => {
    


    this.setState({
      pyname: name
    })


    const nameReg =/^[\S]{1,60}$/
    if (!name || !nameReg.test(name)) {
      this.setState({
        btnok_fullName: false
      })
      return false
    } else {
      this.setState({
        btnok_fullName: true
      })
    }

  }
  onChangeAccountNum = (pyacct) => {
    console.info('onChangeAccountNum', pyacct)
    this.setState({
      pyacct: pyacct
    })
  }
  /**
   * 选择银行
   */
  onSelectBank = () => {
    console.info('onSelectBank')
    const url = `http://${window.location.host}/pay/bank-code.html`;
    // "Recipient's Bank"
    SDK.goNativeWebview(url, (res) => {
      console.info('onSelectBank ret :', res)
      if (res.code === 1) {
        this.setState({
          pybank: res.data.outData.bank_code,
          banknm: res.data.outData.bank_en_name
        })
      }
    });
  }
  regExpName = (val) => {
    // 只能包含字符、数字和下划线
    const nameReg =/^[\S]{1,60}$/
    console.info(val)
    if (!val || !nameReg.test(val)) {
      this.setState({
        btnok_name: false
      })
      return false
    } else {
      this.setState({
        btnok_name: true
      })
    }
    return true
  }
  onAccountStates = (status) => {
    this.setState({
      btnok_account: status
    })
  }
  render() {
    const { showHint } = this.state
    return (
      <div className="transf-set-recip-account-number">
        <TextField
          propValue={this.state.inviteCodeJSON}
          stateName={'inviteCodeJSON'}
          regExpFn={this.regExpName}
          requireInputMessage='can not be empty'
          setCurrentInputData={this.setCurrentInputData.bind(this)}
        ></TextField>
        <CardToBankAccount onHint={() => this.setState({ showHint: !showHint })}
          pyacct={this.state.pyacct}

          pybank={this.state.pybank}
          banknm={this.state.banknm}

          pyname={this.state.pyname}
          onSelectBank={this.onSelectBank}
          onHandleAccountFullName={this.onHandleAccountFullName}
          onChangeAccountNum={this.onChangeAccountNum}
          onAccountStates = {this.onAccountStates}
        ></CardToBankAccount>
        <div className="height32"></div>
        <div className="btn-wraper">
          <Button type="primary" disabled={!(this.state.btnok_name && this.state.btnok_account && this.state.btnok_fullName)} onClick={this.btnClick}>{intl.get('Save Changes')}</Button>
        </div>
        <div className="remove-recipient" onClick={() => this.props.setDeleteModuleState(true)}>{intl.get('Remove')}</div>
        {this.props.showDeleteDialog &&
          <PopOver visible={this.props.showDeleteDialog} isDialog={true}
            onShow={() => this.props.setDeleteModuleState(false)}>
            <DeleteModule doneFn={this.doneFn} deleteFn={this.removeRecipent}></DeleteModule>
          </PopOver>
        }
        {
          showHint &&
          <PopOver title="Hint" visible={showHint} onShow={() => this.setState({ showHint: !this.state.showHint })} >
            <Hint></Hint>
          </PopOver>
        }
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  currentPayee: state.recipient.currentPayee,
  showDeleteDialog: state.recipient.showDeleteDialog
})

const mapDispatchToProps = (dispatch) => ({
  updatePayee: (payload) => {
    dispatch({
      payload,
      type: 'UPDATE_PAYEE'
    })
  },
  deleteCurrentPayee: (payload) => {
    dispatch({
      payload,
      type: 'DELETE_CURRENT_PAYEE'
    })
  },
  // 联系人弹窗展示与隐藏
  setDeleteModuleState: (payload) => {
    dispatch({
      payload,
      type: 'SET_DELETE_MODULE_STATE'
    })
  }
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AccountNumber)

