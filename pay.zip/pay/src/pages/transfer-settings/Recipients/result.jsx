import React from 'react';
import Button from 'commonComponents/button/button';
import './result.scss'
import success from './img/success.svg';

import intl from 'react-intl-universal'

import * as SDK from 'utils/SDKUtil';


export default class mobile extends React.Component {
  btnClick = () => {
    // const url = `http://${window.location.host}/pay/transfer.html`;
    // window.location.href = url
    window.history.go(-1)
  }

  componentDidMount() {
    SDK.setTitle({
      title: '',
      mHeaderTitle: {
        showEnd: 0,
        showBack: 0
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_EDITREC_RESULT'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_EDITREC_RESULT'
    });
  }


  render() {
    return (
      <div className="recipients-update-result">
        <img src={success} alt="" className="img"/>
        <p className="Title-here-title-her">{intl.get('Contacts Info Has Been Updated')}</p>
        <Button type="primary" onClick={this.btnClick}> {intl.get('Done')} </Button>
      </div>
    )
  }
}