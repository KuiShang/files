import React from 'react';
import Button from 'commonComponents/button/button';
import './result.scss'
import success from './img/success@3x.png';
import * as SDK from '../sdk/wrapper';

import intl from 'react-intl-universal'

export default class mobile extends React.Component {
  back = () => {
    this.props.router.push('/Recurring')
  }

  componentDidMount() {
    SDK.setTitle({
      title: '',
      mHeaderTitle: {
        showEnd: 1,
        showBack: 0
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_REC_PAY_INS_SUC'
    })

  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_REC_PAY_INS_SUC'
    });
  }

  render() {
    return (
      <div className="recipients-update-result">
        <img src={success} alt="" className="img"/>
        <p className="Title-here-title-her"> {intl.get('Your Transfer Details Has Been Updated')}</p>
        <Button type="primary" onClick={this.back}>{intl.get('Done')} </Button>
      </div>
    )
  }
}