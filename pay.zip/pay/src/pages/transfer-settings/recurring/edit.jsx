import React from 'react';
import Button from 'commonComponents/button/button';
import SelectEndType from 'commonComponents/SelectEndType';
import CardReview from 'components/card-review';
import ReviewFromTo from '../../../commonComponents/review-from-to';
import intl from 'react-intl-universal'
import SelectFrequency from 'commonComponents/select-frequency';
import TextField from 'commonComponents/text-field';
import FrequencyPicker from 'commonComponents/frequency-picker';
import { connect } from 'react-redux'
import PopOver from 'components/pop-over';
import DatePicker from 'commonComponents/date-picker';
import DeleteModule from 'commonComponents/deleteModule/deleteModule';
import Toast from 'components/toast';

import * as SDK from '../sdk/wrapper';
import * as Util from '../../../utils/SDKUtil'
import './edit.scss'

const NEVER = 'NEVER'
const ONDATE = 'ONDATE'
const REPEAT = 'REPEAT'

class Edit extends React.Component {
  state = {
    inviteCodeJSON: {
      // value: 'Dhun158u',
      value: '',
      isPass: true,
      placeHolder: '',
      regExpMessgae: ''
    },
    currentObj: {},
    frequency: '',
    startDate: new Date(),
    endDate: new Date(),
    mark: '',
    showFrequency: false,
    title: '',
    showCalendar: false,
    showEndDate: false,
    showSelectEndType: false,
    type: 0,
    endType: '',
    endTimes: 0,
    btnok: true,
    money_ipt_value: (this.props.recurring[this.props.currentEditIndex] || {}).insamt,
    inputSelection: '',
    errorType: null,
    lock: false
  }
  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Transfer Details'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })


    const self = this
    SDK.getUserInfo((res) => {
      if (res.code === 1 && res.data) {
        self.props.queryDayLimit({
          "limit_no": 'LIMIT001',
          "acct_type": 'E01',
          "acct_no": res.data[0].acct_no
        })
      }
    })
    const currentObj = this.props.recurring[this.props.currentEditIndex] || {}
    // 比较 开始和结束时间是否大于 t+1
    let startTime = this.getDateWithLine(currentObj.fmdate).getTime()
    let currentTime = this.getDay(1)
    if (startTime <= currentTime) {
      startTime = currentTime
    }
    startTime = new Date(startTime).Format("yyyyMMdd")



    let endType = ''
    if (currentObj.signtp === 'time' && currentObj.todate == '') {
      endType = NEVER
    } else if (currentObj.signtp === 'time' && currentObj.todate != '') {
      endType = ONDATE
    } else if (currentObj.signtp === 'number') {
      endType = REPEAT
    }
    let endTimes, endDate
    if (currentObj.todate.length === 8) {
      endTimes = 5
      endDate = currentObj.todate
      let endTime = this.getDateWithLine(currentObj.todate).getTime()
      if (endTime <= currentTime) {
        endTime = currentTime
        endDate = new Date(this.getDay(1)).Format("yyyyMMdd")
      }

    } else {
      endTimes = currentObj.todate || 5
      endDate = new Date(this.getDay(1)).Format("yyyyMMdd")
    }


    this.setState({
      currentObj: currentObj,
      inviteCodeJSON: {
        value: (this.props.recurring[this.props.currentEditIndex] || {}).insamt,
        isPass: true,
        placeHolder: intl.get('Amount'),
        regExpMessgae: 'Exceeding quota'
      },
      frequency: currentObj.resvpd,
      startDate: startTime,
      endDate: endDate,
      mark: currentObj.ustrd,
      showEndDate: currentObj.resvpd !== 'specialdate' ? true : false,
      endType: endType,
      endTimes: endTimes,
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_REC_PAY_INS'
    })
  }
  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_REC_PAY_INS'
    });
  }

  // 获取相对于今天的某一天， 传入1 表示明天， 传入-1 表示昨天  以此类推
  getDay(num) {
    var today = new Date();
    var nowTime = today.getTime();
    var ms = 24 * 3600 * 1000 * num;
    today.setTime(parseInt(nowTime + ms));
    var oYear = today.getFullYear();
    var oMoth = (today.getMonth() + 1).toString();
    if (oMoth.length <= 1) oMoth = '0' + oMoth;
    var oDay = today.getDate().toString();
    if (oDay.length <= 1) oDay = '0' + oDay;
    return new Date(oYear + '-' + oMoth + '-' + oDay).getTime()
  }
  compareValue = (val) => {
    console.info(val)
    if (val > this.props.rangeVal) {
      this.setState({
        btnok: false
      })
      return false
    }
    return true
  }
  btnClick = () => {
    let endtp, enddat = '';
    if (this.state.frequency === 'specialdate') {
      endtp = ''
      enddat = ''
    } else {
      if (this.state.endType === NEVER) {
        endtp = 'time'
        enddat = ''
      } else if (this.state.endType === ONDATE) {
        endtp = 'time'
        enddat = this.state.endDate
      } else if (this.state.endType === REPEAT) {
        endtp = 'number'
        enddat = this.state.endTimes
      }
    }
    this.props.updatemedda({
      stadat: this.state.startDate,
      endtp: endtp,
      enddat: String(enddat),
      instdCcy: this.state.currentObj.insccy,
      resvid: this.state.currentObj.resvid,
      instdAmt: Number(this.state.money_ipt_value),
      period: this.state.frequency,
      ustrd: this.state.mark

    }, () => {
      if (this.props.location.query.expired === 'false') {
        console.info(this.props)
        this.props.router.push('/Recurring/result')
      } else {
        this.props.router.replace('/Recurring?type=reactivate')
      }
    })

  }
  /**
   * 转账附言最多40个字符
   */
  onChangeMark = (pn, json) => {
    if (json.value.split('').length > 40) {
      return;
    }

    this.setState({ mark: json.value })
  }
  removeRecipent = () => {
    // const currentObj = this.props.recurring[this.props.currentEditIndex]
    this.props.cancelmedda({
      resvid: this.state.currentObj.resvid,
    }, (ret) =>  {
      console.log(ret)
      setTimeout(() => {
      Toast.showNetError(intl.get("show_net_error"));
        
      }, 10);
      
    });
  }
  showRemoveRecipent = () => {
    this.setState({
      showDeleteDialog: true
    })
  }
  hideRemoveRecipent = () => {
    this.setState({
      showDeleteDialog: false
    })
  }
  doneFn = () => {
    // Util.forbidLeftBackPress(false);
    console.info(123)
  }

  getPassState(...args) {
    let hasErrorInput = args.find((item) => item.isPass === false);
    if (!hasErrorInput) {
      this.setState({
        submitPass: true
      });
    } else {
      this.setState({
        submitPass: false
      });
    }
  }
  showSelectEndType = (type) => {
    this.setState({
      showSelectEndType: true, title: `${type === 0 ?  intl.get('Start Date')  : intl.get('End Date')  }`, type: type
    })
  }
  onShowDatePicker = (type) => {
    this.setState({ showCalendar: true, title: `${type === 0 ? intl.get('Start Date')  : intl.get('End Date') } `, type: type });
  }
  onSelectDate = (date) => {
    console.info(date)
    let str = date.Format("yyyyMMdd")

    const { type } = this.state;
    if (type === 0) {
      this.setState({ startDate: str });
    } else if (type === 1) {
      this.setState({ endDate: str });
    }
  }
  onSelectNum = (num) => {
    console.info('num', num)
    this.setState({
      endTimes: num
    })
  }
  setCurrentInputData(properyName, json, needCheck = true) {
    const jsonValue = this.checkJsonValue(json)
    let data = Object.assign({}, this.state[properyName], jsonValue);
    let btnok = true
    if (json.value == 0 || json.value == '') {
      btnok = false
    }
    if (Number(json.value) > Number(this.props.rangeVal)) {
      btnok = false
    }

    this.setState({
      [properyName]: data,
      btnok
    }, () => {
      if (needCheck) {
        this.getPassState()
      }
    })
  }
  componentDidUpdate(prevProps,preval) {
    const { money_ipt_value } = preval;
    const { inputSelection } = this;
    if (inputSelection) {
      // 在 didUpdate 时根据情况恢复光标的位置
      // 如果光标的位置小于值的长度，那么可以判定属于中间编辑的情况
      // 此时恢复光标的位置
      if (inputSelection.start < String(money_ipt_value).length) {
        const input = this.input;
        input.selectionStart = inputSelection.start;
        input.selectionEnd = inputSelection.end;
        this.inputSelection = null;
      }
    }
}

  handle_moneyipt_Change = (event) => {
    if (this.input) {
      this.inputSelection = {
        start: this.input.selectionStart,
        end: this.input.selectionEnd,
      };
    }

    let val = event.target.value
    if (val.charAt(0) === '.') {
      return 
    }
    val = val.replace(/[^\d.]/g, '') //清除“数字”和“.”以外的字符
    val = val.replace(/\.{2,}/g, '.') //只保留第一个. 清除多余的 连续两个
    val = val.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.') //只保留第一个. 清除多余的 非连续两个
    val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3') //只能输入两个小数
    if(val.indexOf('.')< 0 && val != ''){ //以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
      val = parseFloat(val)
    }
    console.info(val)
    setTimeout(() => {
      this.setState({money_ipt_value: val});
    })
   if ( val > this.props.rangeVal ) {
      this.setState({
        btnok: false,
        lock: true,
        errorType: 0,
      })
    } else if ( val == '' || val == 0) {
      this.setState({
        btnok: false,
        lock: true,
        errorType: 1,
      })
    } else {
      this.setState({
        btnok: true,
        lock: false
      })
    }
  }
  checkJsonValue = (json) => {
    let val = json.value
    if (val === '.') {
      val = ''
    }
    val = val.replace(/[^\d.]/g, '') //清除“数字”和“.”以外的字符
    val = val.replace(/\.{2,}/g, '.') //只保留第一个. 清除多余的 连续两个
    val = val.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.') //只保留第一个. 清除多余的 非连续两个
    val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3') //只能输入两个小数
    json.value = val
    return json
  }
  onSelectEndTypeItem = (type) => {
    console.info(type)
    this.setState({
      endType: type
    })
  }
  getEndDateTxt() {
    const { endDate, endTimes, endType } = this.state
    if (endType === NEVER) {
      return intl.get('No End Date')
    } else if (endType === ONDATE) {
      return this.getDateWithLine(endDate).toLocaleDateString('zh-CN')

    } else if (endType === REPEAT) {
      return intl.get('Repeat') + endTimes + intl.get('time') 
    } else {
      this.setState({
        endType: NEVER
      })
      return intl.get('No End Date')
    }
  }

  onSelectFrequency = (item) => {
    this.setState({ showFrequency: false, frequency: item.key, showEndDate: item.key !== 'specialdate' ? true : false })
  }
  getDateWithLine = (str) => {
    if (str && str.length === 8) {
      let year = str.slice(0, 4)
      let monuth = str.slice(4, 6)
      let dat = str.slice(6, 8)
      return new Date(year + '-' + monuth + '-' + dat)
    } else {
      return str
    }

  }
  handleInputFn = (value) => {
    console.info(value)
  }

  render() {
    const { frequency, startDate, endDate, endTimes, showFrequency, title, showCalendar, showEndDate, type, showSelectEndType } = this.state;
    return (
      <div className="trans-set-recurring-edit">

        <CardReview>
          <ReviewFromTo editable={false} initData={this.state.currentObj}></ReviewFromTo>
        </CardReview>
        <div className="magt24">
          <CardReview>
            <div className="money-ipt-left-container">
              {/* <div className="money-ipt-left">
                <TextField
                  propValue={this.state.inviteCodeJSON}
                  stateName={'inviteCodeJSON'}
                  regExpFn={this.compareValue}
                  borderbotom = {true}
                  setCurrentInputData={this.setCurrentInputData.bind(this)}
                ></TextField>
              </div> */}
              <p>{intl.get('Amount')}</p>
              <div className="money-right-ipt-hkd-container">
                <input className="money-right-ipt-hkd"    ref={(c) => { this.input = c; }} value={this.state.money_ipt_value} onChange={e => this.handle_moneyipt_Change(e)}/>
                <span className="money-right-hkd">HKD</span>
              </div>
              {this.state.lock ? <div className='errorText'>{(()=>{
                switch (this.state.errorType) {
                  case 0:
                    return intl.get('insuficient_balance')
                  case 1:
                    return 'can not be empty'
                  default:
                    return null
                }
              })()}</div> : null}
            </div>
          </CardReview>
        </div>

        <p className='Frequency-title'>{intl.get('Frequency')}</p>
        <div className="payment-instructions-schedule">
          <SelectFrequency title={intl.get('Frequency Limit')} datakey={frequency} onSelect={() => this.setState({ showFrequency: true,   })}></SelectFrequency>
        </div>
        <div className="payment-instructions-mark">
          <SelectFrequency title= {intl.get('Start Date')} datakey={this.getDateWithLine(startDate).toLocaleDateString('zh-CN')} onSelect={() => this.onShowDatePicker(0)}></SelectFrequency>
        </div>
        {
          showEndDate &&
          <div className="payment-instructions-mark">
            <SelectFrequency title={ intl.get('End Date')} datakey={this.getEndDateTxt()} onSelect={() => this.showSelectEndType(1)}></SelectFrequency>
          </div>

        }

        <div className="payment-instructions-mark">
          <TextField
            propValue={{ placeHolder:  intl.get('Remarks (Optional)'), value: this.state.mark }}
            stateName={'mark'}
            setCurrentInputData={this.onChangeMark.bind(this)}>
          </TextField>
        </div>

        <p className="height32"></p>
        <Button type="primary" disabled={!this.state.btnok} onClick={this.btnClick}>{this.props.location.query.expired !== 'true' ? intl.get('Confirm') : intl.get('Reactivate')}</Button>
        {

        }
        {
          this.props.location.query.expired !== 'true' && <div className="remove-recipient" onClick={() => { this.props.setDeleteModuleState(true); Util.forbidLeftBackPress(true); }}>{intl.get('Stop making this payment')}</div>
        }

       




        {
          showCalendar &&
          <PopOver title={title} visible={showCalendar} titleDone={intl.get('Done')}
            onShow={() => this.setState({ showCalendar: !this.state.showCalendar })}
            onDone={() => this.setState({ showCalendar: !this.state.showCalendar })}>
            <DatePicker date={(type === 0 ? new Date(this.getDateWithLine(startDate)) : new Date(this.getDateWithLine(endDate)))} onSelectDate={this.onSelectDate}></DatePicker>
          </PopOver>
        }
        {
          showFrequency &&
          <PopOver title= {intl.get('Frequency')} visible={showFrequency}
            onShow={() => this.setState({ showFrequency: !this.state.showFrequency })}
            onDone={() => this.setState({ showFrequency: !this.state.showFrequency })}>
            <FrequencyPicker isTransfer={true} data={frequency} onSelectFrequency={this.onSelectFrequency}></FrequencyPicker>
          </PopOver>
        }

        {
          showSelectEndType &&
          <PopOver title={intl.get('SET End Date')} titleDone={intl.get('Done')}  visible={showSelectEndType}
            onShow={() => this.setState({ showSelectEndType: !this.state.showSelectEndType })}
            onDone={() => this.setState({ showSelectEndType: !this.state.showSelectEndType })}>
            <SelectEndType
              checked={this.state.endType}
              date={new Date(this.getDateWithLine(endDate))}
              currentTimes={endTimes}
              onSelectEndTypeItem={this.onSelectEndTypeItem}
              onSelectNum={this.onSelectNum}
              onSelectDate={this.onSelectDate}>
            </SelectEndType>
          </PopOver>
        }

        {this.props.showDeleteDialog &&
          <PopOver visible={this.props.showDeleteDialog} isDialog={true}
            onShow={() => { this.props.setDeleteModuleState(false); Util.forbidLeftBackPress(false); }}>
            <DeleteModule 
            content={ intl.get('Are you sure you want to terminate this scheduled Transfer?') } 
            doneFn={this.doneFn} 
            showcancelBtn = {true}
            cancelBtnClick = {() => { this.props.setDeleteModuleState(false); Util.forbidLeftBackPress(false); }}
            deleteFn={this.removeRecipent}/>
          </PopOver>
        }



      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  recurring: state.recurring.recurring.result,
  rangeVal: state.recurring.rangeVal,
  currentEditIndex: state.recurring.currentEditIndex,
  custno: state.recipient.custno,
  showDeleteDialog: state.recipient.showDeleteDialog
})

const mapDispatchToProps = (dispatch) => ({
  fetchMedda: (payload) => {
    dispatch({
      payload,
      type: 'REQUEST_MEDDA'
    })
  },
  cancelmedda: (payload, cb) => {
    dispatch({
      payload,
      cb,
      type: 'DELETE_MEDDA'
    })
  },
  updatemedda: (payload, cb) => {
    dispatch({
      payload,
      cb,
      type: 'UPDATE_MEDDA'
    })
  },
  // 联系人弹窗展示与隐藏
  setDeleteModuleState: (payload) => {
    dispatch({
      payload,
      type: 'SET_DELETE_MODULE_STATE'
    })
  },
  queryDayLimit: (payload) => {
    dispatch({
      payload,
      type: 'QUERY_DAY_LIMIT'
    })
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Edit)