import React from 'react';
import CardSwitch from 'commonComponents/card-switch';
import classnames from 'classnames';
import Toast from 'components/toast';
import { connect } from 'react-redux'

import intl from 'react-intl-universal'

import './recurring.scss'
import * as SDK from 'utils/SDKUtil';
import defaultInfo from './img/info.svg';

class Recurring extends React.Component {
  constructor() {
    super()
    this.state = {
      activeFirst: true,
      currentShowDetailIdx: null
    }
  }


  componentWillUnmount() {
    SDK.buriedPointLeave({
      pageName: 'COIPS_REC_PAY'
    });
  }


  componentDidMount() {
    SDK.setTitle({
      title: intl.get('Scheduled Transfers'),
      mHeaderTitle: {
        showEnd: 0,
        showBack: 1
      }
    })
    

 
    this.props.fetchMedda({
      funcno: 'withdraw'
    }, () => {
    if (this.props.location.query.type === 'cancel') {
        Toast.info(intl.get('payment_terminated'), 1)
      } else if (this.props.location.query.type === 'reactivate') {
        Toast.info(intl.get('payment_reactivated'), 1)
        
      }
    })

    SDK.buriedPointEntry({
      pageName: 'COIPS_REC_PAY'
    })


  }
  tabClick = (c) => {
    console.info(c)
    this.setState({
      activeFirst: c === true
    })
  }
  static defaultProps = {
    progressList: [1, 2],
    expiredList: [1]
  }
  seeDetail(idx) {
    console.info(idx)
    if (idx === this.state.currentShowDetailIdx) {
      idx = null
    }
    this.setState({
      currentShowDetailIdx: idx
    })
  }
  edit(idx, type) {
    console.info(idx)
    let str = ''
    if (type === 1) {
      str = 'false'
    } else {
      str = 'true'
    }
    this.props.setCurrentEditIndex(idx)
    this.props.router.push(`/Recurring/edit?expired=${str}`)
  }
  getEndDateOrTimes = (str, type) => {
    // 按次
    if (type === 'number') {
      return str
    }
    if (type === 'time') {
      if (str === '') {
        return intl.get('No End Date')
      } else {
        return this.getDateWithLine(str)
      }
    }
  }
  getDateWithLine = (str) => {
    let year = str.slice(0, 4)
    let monuth = str.slice(4, 6)
    let dat = str.slice(6, 8)
    return year + '/' + monuth + '/' + dat
  }
  getFrequencyStr = (key) => {
    const r = {
      specialdate:  intl.get('Specific Date'),
      daily:  intl.get('Once a Day'),
      weekly:  intl.get('Once a Week'),
      biweekly:  intl.get('Once Every 2 Weeks'),
      monthly:  intl.get('Once a Month'),
      quarterly:  intl.get('Once a Quarter'),
      yearly:   intl.get('Once a Year'),
    }
    return r[key] ? r[key] : key
  }


 thousandBitSeparator (num, cent, isThousand) {
  if(Number(num) < 0){
      return 0;
    }
    if(num){
      num = num.toString().replace(/\$|\,/g,'');
      if(''==num || isNaN(num)){return 'Not a Number ! ';}
      var sign = num.indexOf("-")> 0 ? '-' : '';
      var cents = num.indexOf(".")> 0 ? num.substr(num.indexOf(".")) : '';
      cents = cents.length>1 ? cents : '' ;
      num = num.indexOf(".")>0 ? num.substring(0,(num.indexOf("."))) : num ;
      if('' == cents){ if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}
      else{if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}
      for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
          num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
      }
      return (sign + num + cents);    
    }else{
      return num;
    }
  }


  render() {
    const animaClass = classnames('card-container', 'animat', {
      'hide': !this.state.activeFirst
    })
    const animaClass2 = classnames('card-container', 'animat', {
      'hide': this.state.activeFirst
    })
    
    return (
      <div className="recurring">
        <CardSwitch title="" options={[intl.get('Active'), intl.get('Inactive')]} onSwitch={(c) => this.tabClick(c)}></CardSwitch>
        <ul className={animaClass}>
          {this.props.recurring.map((item, idx) => (
            (item.transt === 'Enable' || item.transt === 'Pending') && <li className="item-container" key={idx}>
              <div className="item">
                <div className="item-left">
                  <div className="avator">{String(item.inacna).substring(0, 1).toUpperCase()}</div>
                  <div className="item-left-txt">
                    <p className="name">
                      {item.inacna} 
                      </p>
                    <p className="name2">

                    <span>
                      {item.inactp === 'SVID' ? 'FPS ID - ' : ''} 
                      </span>
                      <span>
                      {item.inacct} 
                        </span>
                      </p>
                    <p className="name3">{item.inbkna}</p>
                  </div>
                </div>
                <div className="edit" onClick={e => this.edit(idx, 1)}>{intl.get('Change')}</div>
              </div>
              <p className="txt-title">{intl.get('Payment Amount (Per Transaction)')}</p>
              <p className="txt"> {this.thousandBitSeparator(Number(item.insamt).toFixed(2))} {item.insccy}</p>
              <p className="txt-title">{intl.get('Frequency')}</p>
              <p className="txt"> {this.getFrequencyStr(item.resvpd)}</p>
              <div className={`more-detail ${this.state.currentShowDetailIdx === idx ? '' : 'height0'}`}>
                <p className="txt-title">{intl.get('Start Date')}</p>
                <p className="txt">{this.getDateWithLine(item.fmdate)}</p>
                {
                  item.resvpd !== 'specialdate' &&
                  <>
                    <p className="txt-title">{intl.get('End Date')}</p>
                    <p className="txt">{this.getEndDateOrTimes(item.todate, item.signtp)}</p>
                  </>
                }


                <p className="txt-title">{intl.get('Status')}</p>
                <p className="txt">{item.transt}</p>
                <p className="txt-title">{intl.get('Remarks')}</p>
                <p className="txt">{item.ustrd}</p>
              </div>
              <p className="seeDetail" onClick={e => this.seeDetail(idx, e)}>
                {
                  this.state.currentShowDetailIdx === idx ? intl.get('Hide Details') : intl.get('View Details')
                }
              </p>
            </li>
          ))}
          {
            this.props.recurring.filter((item, idx) => item.transt === 'Enable' || item.transt === 'Pending').length === 0 && 
            <div className="default-schedule-wrapper">
              <img src={defaultInfo} alt=""/>
              <p>{intl.get('No scheduled transfers')}</p>
            </div>
          }
        </ul>
        <ul className={animaClass2}>
          {this.props.recurring.map((item, index) => (
            item.transt === 'Invalid' && <li className="item-container" key={index}>
              <div className="item">
                <div className="item-left">
                <div className="avator">{String(item.inacna).substring(0, 1).toUpperCase()}</div>
                  <div className="item-left-txt">
                    <p className="name">{item.inacna} </p>
                    <p className="name2">

                    <span>
                      {item.inactp === 'SVID' ? 'FPS ID - ' : ''} 
                      </span>
                      <span>
                      {item.inacct} 
                        </span>
                    </p>
                    <p className="name3">{item.inbkna}</p>
                  </div>
                </div>
                <div className="edit" onClick={e => this.edit(index, 2)}>{intl.get('Change')}</div>
              </div>
              <p className="txt-title">{intl.get('Payment Amount (Per Transaction)')}</p>
              <p className="txt"> {this.thousandBitSeparator(Number(item.insamt).toFixed(2))} {item.insccy}</p>
              <p className="txt-title">{intl.get('Frequency')}</p>
              <p className="txt"> {this.getFrequencyStr(item.resvpd)}</p>
              <div className={`more-detail ${this.state.currentShowDetailIdx === index ? '' : 'height0'}`}>
                <p className="txt-title">{intl.get('Start Date')}</p>
                <p className="txt">{this.getDateWithLine(item.fmdate)}</p>
                {
                  item.resvpd !== 'specialdate' &&
                  <>
                    <p className="txt-title">{intl.get('End Date')}</p>
                    <p className="txt">{this.getEndDateOrTimes(item.todate, item.signtp)}</p>
                  </>
                }


                <p className="txt-title">{intl.get('Status')}</p>
                <p className="txt">{item.transt}</p>
                <p className="txt-title">{intl.get('Remarks')}</p>
                <p className="txt">{item.ustrd}</p>
              </div>
              <p className="seeDetail" onClick={e => this.seeDetail(index, e)}>
                {
                  this.state.currentShowDetailIdx === index ? intl.get('Hide Details') : intl.get('View Details')
                }
              </p>
            </li>
          ))}
          {
            this.props.recurring.filter((item, idx) => item.transt === 'Invalid').length === 0 && 
            <div className="default-schedule-wrapper">
              <img src={defaultInfo} alt=""/>
              <p>{intl.get('No inactive scheduled transfers')}</p>
            </div>
          }
        </ul>

      </div>
    )
  }
}


const mapStateToProps = (state) => ({
  recurring: state.recurring.recurring.result,
  custno: state.recipient.custno
})

const mapDispatchToProps = (dispatch) => ({
  fetchMedda: (payload, cb) => {
    dispatch({
      payload,
      cb,
      type: 'REQUEST_MEDDA'
    })
  },
  cancelmedda: (payload) => {
    dispatch({
      payload,
      type: 'REQUEST_MEDDA'
    })
  },
  setCurrentEditIndex: (payload) => {
    dispatch({
      payload,
      type: 'SET_CURRENT_EDIT_INDEX'
    })
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Recurring)