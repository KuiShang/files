import axios from '../axios';
import * as SDK from 'utils/SDKUtil';
import { Base64 } from 'js-base64';

const TYPES = {
  GET: 'GET',
  POST: 'POST'
}
// 是否完成判断当前使用哪个fetch， 默认为假，在初始化完成之后为真
let initFinish = false;
// 是否使用客户端request开关， true:表示使用客户端发送请求    false：表示使用h5请求
const safeFlag = true;
// 判断是否跳转去原生的登录
let isGOLogin = false;

/**
 * h5 ajax请求
 * @param {*} types 
 * @param {*} url 
 * @param {*} data 
 */
function fetchAxiox(types, url, data) {
  axios.defaults.headers.common['uuid'] = new Date().getTime();
  data = Object.assign(data, {
    deviceInfo: window.$DeviceInfo
  })
  if (types === TYPES.GET) {
    return axios.get(url, {
      params: data
    })
  } else if (types === TYPES.POST) {
    return axios.post(url, data)
  }
  console.error('没有添加这种类型', types)
  return false
}
/**
 * 原生http request请求
 * @param {*} types 1- post  2- get
 * @param {*} url 
 * @param {*} data 
 */
function fetchApp(types, url, data) {
  let type = 1
  if (types === TYPES.GET) {
    type = 2
  } else {
    type = 1
  }
  // const urlAll = window.location.origin + url
  const urlAll = 'http://appgw.livibank.com' + url;////window.location.origin + url
  data = Object.assign(data, {
    deviceInfo: window.$DeviceInfo
  })
  const json = {
    url: urlAll,
    httpType: type,
    parameters: JSON.stringify(data),
    postMediaType: 'application/json',
    headerParameters: {
      t1w: 't1w',
      'Accept-Language': window.$DeviceInfo.language
    }
  }
  console.info('request请求数据: ', json)
  return new Promise((reslove, reject) => {
    SDK.request(json, (ret) => {
      console.info('原声app成功的ret', ret)
      console.info('Base64.decode', Base64.decode)
      if (ret.code !== 1) {
        console.info('客户端返回0， 替换成h5 ajax 再次发送个请求', Base64.decode)
        return fetchAxiox(types, url, data).then(d => reslove(d))
      }
      const retResloved = JSON.parse(Base64.decode(ret.data))
      console.info('原声app成功的ret 解析后：', retResloved)
      if (retResloved.status === 200) {
        retResloved.data = JSON.parse(retResloved.data)
        retResloved.data.resultCode = Number(retResloved.data.resultCode);
        console.info('最终解析完成的结果：', retResloved)
        if (retResloved.data.resultCode !== 1 && retResloved.data.actionData && retResloved.data.actionData.address.indexOf('login') >= 0 && !isGOLogin) {
          isGOLogin = true
          SDK.goNativeAction(retResloved.data.actionData, res => {
            isGOLogin = false;
            window.location.href = window.location.href;
          })
        }
        reslove(retResloved)
      } else if (retResloved.status.toString().match(/^50/)) {
        reject(retResloved)
      } else if (retResloved.status.toString().match(/^40/)) {
        reject(retResloved)
      } else {
        reject(retResloved)
      }
      return ''
    })
  })
  // window.wallet.platform.request(json, su, er)
}

let fetch = async function d(a, b, c) {
  if (!initFinish) {
    const hasRequest = await SDK.checkHasAppRequest()
    if (safeFlag && hasRequest) {
      fetch = fetchApp
    } else {
      fetch = fetchAxiox
    }
    return fetch(a, b, c)
  }
  return fetch(a, b, c)
}

async function switchFetch() {
  const hasRequest = await SDK.checkHasAppRequest()
  console.info(`hasRequest: ${hasRequest} + safeFlag: ${safeFlag}`)
  if (safeFlag && hasRequest) {
    fetch = fetchApp
  } else {
    fetch = fetchAxiox
  }
  initFinish = true
  return fetch
}
switchFetch()

console.info('当前的fetch：', fetch)

// 添加收款人
export function addpayee(data) {
  return fetch(TYPES.POST, '/cocgw/adpyfo', data)
}
// 删除收款人
export function delpayee(data) {
  return fetch(TYPES.POST, '/cocgw/delpyfo', data)
}

// 获取收款人
export function qrpayee(data) {
  return fetch(TYPES.POST, '/cocgw/qrpyfo', data)
}

// 修改收款人
export function uppayee(data) {
  return fetch(TYPES.POST, '/cocgw/uppyfo', data)
}

// 查询每日转账限额
export function queryDayLimit(data) {
  return fetch(TYPES.POST, '/cocgw/4213', data)
}

// 设置每日转账限额
export function setDayLimit(data) {
  // return fetch(TYPES.POST, '/cocgw/4214', data)
  return fetch(TYPES.POST, '/cocgw/custdeptlimit', data)
}

// 获取协议标题、版本
export function queryAgreementInfo(data) {
  return fetch(TYPES.POST, '/saser/agreement/queryAgreementInfo', data)
}

// 获取 转账设置列表信息
export function queryTransfersetInfo(data) {
  return fetch(TYPES.POST, '/cocgw/transferset', data)
}

// 查询小额限额
export function querySmallLimit(data) {
  return fetch(TYPES.POST, '/cocgw/enqadtf', data)
}

// 开通小额限额
export function setSmallLimitNew(data) {
  return fetch(TYPES.POST, '/cocgw/initadtf', data)
}

// 修改小额限额
export function setSmallLimitUpdate(data) {
  return fetch(TYPES.POST, '/cocgw/amendadtf', data)
}

// 定时转账查询
export function qrmedda(data) {
  return fetch(TYPES.POST, '/cocgw/qrmedda', data)
}

// 删除转账查询
export function cancelmedda(data) {
  return fetch(TYPES.POST, '/cocgw/cancelmedda', data)
}

// 更新转账查询
export function amendmedda(data) {
  return fetch(TYPES.POST, '/cocgw/amendmedda', data)
}

// qryrisk
export function queryRiskResult(data) {
  return fetch(TYPES.POST, '/cocgw/qryrisk', data)
}
// 获取开户状态
export function getStatus(data) {
  return fetch(TYPES.POST, '/cocgw/4401', data)
}
