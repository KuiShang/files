import React from 'react';
import Button from 'commonComponents/button/button';
import warning from './img/warning@3x.png';
import intl from 'react-intl-universal'
export default class resultError extends React.Component {
  render() {
    return (
      <div className="recipients-update-result">
        <img src={warning} alt="" className="img"/>
        <p className="Title-here-title-her">Opps.. Error Wording</p>
        <Button className="transfer-settings-button" onClick={this.goAgainHandle} type="primary">Try Again</Button>
      </div>
    )
  }

	/**
	 * 跳转到主页 关闭webview
	 */
	goAgainHandle() {
		window.history.go(-1);
	}
}
