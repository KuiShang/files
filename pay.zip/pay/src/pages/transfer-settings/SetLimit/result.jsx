import React from 'react';
import Button from 'commonComponents/button/button';
import './result.scss'
import success from './img/success@3x.png';
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil';
import * as SDK from 'utils/SDKUtil';
import { queryDayLimit, querySmallLimit, getStatus } from 'pages/transfer-settings/api';
import intl from 'react-intl-universal'
export default class mobile extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			renderStatus: false,
			limitType: null,
			rangeVal: 0,
			accMsg: null, //获取到的账户信息
			titleType: ''
		}
	}
	componentWillMount() {
		const limitType = (this.props.location.state && this.props.location.state.type) || 0;
		this.setState({ limitType: limitType })
		if (limitType === 1) {
			// 设置标题
			SDK.setTitle({
				title: intl.get('09D.01.003-1')
			});
			// 每日限额
			this.getAccMsg(1);
			this.setState({ titleType: intl.get('07.05.007-2-1') })
		} else {
			SDK.setTitle({
				title: intl.get('09D.01.009-1')
			});
			// 小额转账
			this.getAccMsg(2);
			this.setState({ titleType: intl.get('07.05.007-2-2') })
		}
		// 注册页面离开埋点监听
		this.buriedPointLeave();
		// 上报页面进入埋点
		SDK.buriedPointEntry({
			pageName: 'COIPS_TRNSLMT_RESULT'
		});
	}

	render() {
		return (
			this.state.renderStatus &&
			<div className="recipients-update-result">
				<img src={success} alt="" className="img" />
				<p className="Title-here-title-her">{intl.get('07.05.007-3')}</p>
				<section className="rectangle">
					<h6>{this.state.titleType}</h6>
					<p>{thousandBitSeparator(keep2DecimalFull(this.state.rangeVal))}<span>HKD</span></p>
				</section>
				<Button className="transfer-settings-button" onClick={this.goHomeHandle} type="primary">{intl.get('09D.01.008-4')}</Button>
			</div>
		)
	}

	async initData(type) {
		const limitType = type || 0;
		if (limitType === 0) return;
		if (this.state.limitType == 1) {
			// 单日
			var queryDayLimitAjax = queryDayLimit(
				{
					"bizInfo": {
						"limit_no": 'LIMIT001',
						"acct_type": 'E01',
						"acct_no": this.state.accMsg.list01[0].acct_no
					}
				}
			);
		} else {
			var queryDayLimitAjax = querySmallLimit(
				{
					"bizInfo": {
						"acctno": this.state.accMsg.list01[0].acct_no
					}
				}
			);
		}

		Promise.all([queryDayLimitAjax]).then((dat) => {
			const limitRes = dat[0];
			if (limitRes.data.resultCode === 1) {
				if (this.state.limitType == 1) {
					var rangeVal = limitRes.data.resultData.limit_value;
				} else {
					var rangeVal = limitRes.data.resultData.rangeVal;
				}
				console.info(limitRes)
				this.setState({
					rangeVal: rangeVal,
					renderStatus: true
				})
			} else {
				alert('接口请求错误');
			}
		})
	}
	/**
	 * 跳转到主页 关闭webview
	 */
	goHomeHandle() {
		SDK.closeWebView();
	}
	/**
	 * 获取账户信息 接口 目前是从服务端接口获取的
	 */
	async getAccMsg(isPerDay) {
		const res = await getStatus({
			"bizInfo": {
				"acct_status": ''
			}
		});
		console.info('-------------getStatus 获取账户信息 -------------')
		if (res.data.resultCode === 1) {
			console.info(res.data.resultData)
			this.setState({
				accMsg: res.data.resultData
			})
			this.initData(isPerDay);
		} else {
			alert('获取获取账户信息失败');
		}
	}
	/**
	 * 页面离开埋点上报
	 */
	buriedPointLeave() {
		const buriedPointKey = 'COIPS_TRNSLMT_RESULT';
		SDK.onForeground(() => {
			SDK.buriedPointLeave({
				pageName: buriedPointKey
			})
		});
		// SDK.onBackPress(() => {
		// 	SDK.buriedPointLeave({
		// 		pageName: buriedPointKey
		// 	})
		// });
	}
}