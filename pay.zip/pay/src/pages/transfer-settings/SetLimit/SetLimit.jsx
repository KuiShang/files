import React from 'react'
import './SetLimit.scss'
import Checkbox from 'components/checkbox'
import { thousandBitSeparator, keep2DecimalFull } from 'utils/NumUtil'
import { queryDayLimit, setDayLimit, queryAgreementInfo, querySmallLimit, setSmallLimitNew, setSmallLimitUpdate, queryRiskResult, getStatus } from 'pages/transfer-settings/api';
import { Base64 } from 'js-base64';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import Toast from 'components/toast';

class SetLimit extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			showProtocolName: '',
			jumpParams: {},
			limitType: null,
			limitTitle: '',
			rangeVal: 1000,
			keybordMaxVal: 9999999999999,
			renderStatus: false, // 展示页面的标志位
			dis: true,
			disAmount: false, // 金额校验
			accMsg: null,
			sliderData: {
				maxValue: 200000000,
				minValue: 1,
				step: 100,
				rangeVal: 1000,
				firstValue: 1000,
			},
			quertResultParams: {},
			returnUrl: '',
			isPerDay: true,
			isCallKeyBord: false,
			tipsAmountMin: false,
			tipsAmountMax: false,
			buriedPointKey: 'COIPS_TRNSLMT_PD',
			network: true
		}
	}
	componentWillMount() {
		const limitType = this.props.location.query ? this.props.location.query.type : 0;
		/**
		 * isPerDay 
		 * @type {Boolean} 
		 * 1 {Boolean} 每日限额 - 查询核心谢军接口
		 * 2 {Booble}  小额转账设置 - 查询张俊磊支付接口
		 */
		const isPerDay = this.props.location.query.type == 1 ? true : false;
		const returnUrl = this.props.location.query.returnUrl || '';
		this.setState({
			returnUrl: returnUrl,
			isPerDay: isPerDay,
			limitType: limitType
		});
		if (isPerDay) {
			// 设置标题 每日
			SDK.setTitle({
				title: intl.get('09D.01.003-1'),
			});
			this.setState({ limitTitle: intl.get('09D.01.009-2') });
			this.getAccMsg(isPerDay);

		} else {
			// 设置标题 小额
			SDK.setTitle({
				title: intl.get('09D.01.009-1'),
			});
			this.setState({ limitTitle: intl.get('09D.01.003-2'), buriedPointKey: 'COIPS_TRNSLMT_SPD' });
			this.getAccMsg(isPerDay);
		}

		const buriedPointKey = this.state.buriedPointKey;
		// 注册页面离开埋点监听
		this.buriedPointLeave();
		// 上报页面进入埋点
		SDK.buriedPointEntry({
			pageName: buriedPointKey
		})
	}
	/**
	 * 页面销毁钩子
	 */
	componentWillUnmount() {
		// 页面卸载时 上报埋点
		const buriedPointKey = this.state.buriedPointKey;
		SDK.buriedPointLeave({
			pageName: buriedPointKey
		})
	}
	/**
	 * 获取账户信息 接口 目前是从服务端接口获取的
	 */
	async getAccMsg(isPerDay) {
		const res = await getStatus({
			"bizInfo": {
				"acct_status": ''
			}
		});
		console.info('-------------getStatus 获取账户信息 -------------')
		if (res.data.resultCode === 1) {
			console.info(res.data.resultData)
			this.setState({
				accMsg: res.data.resultData
			})
			isPerDay === true ? this.initData(1) : this.initData(2);
		} else {
			alert('获取获取账户信息失败');
		}
	}
	/**
	 * 渲染模板
	 */
	render() {
		return (
			this.state.renderStatus &&
			<div className="setlimit-container">
				<section className="limit-num">
					{/* 输入款模块 */}
					<h5>{this.state.limitTitle}</h5>
					<div className="slider-choice-value">
						<input
							value={this.state.rangeVal}
							onChange={(e) => { this.handleChange(e) }}
							onFocus={() => this.inputFocusHandle()}
							onBlur={() => this.inputBlurHandle()}
						/>
						<span> HKD </span>
					</div>
					<div className="slider">
						<p className={`err-tips-amount-max tips ${this.state.tipsAmountMax === true ? '' : 'hidden'}`}>
							{intl.get('09D.01.003A-3-1')}
							{thousandBitSeparator(this.state.sliderData.maxValue)}
						</p>
						<p className={`err-tips-amount-small tips ${this.state.tipsAmountMin === true ? '' : 'hidden'}`}>
							{intl.get('09D.01.003A-3-2')}
							{thousandBitSeparator(this.state.sliderData.minValue)}
						</p>
						<p>
							<label> {intl.get('09D.01.003A-4-1')}</label>
							{this.state.renderStatus && thousandBitSeparator(keep2DecimalFull(this.state.sliderData.maxValue))}
							<label> {intl.get('09D.01.003A-4-2')}</label>
						</p>
					</div>
				</section>
				<section className="limit-desc">
					<h6>{intl.get('09D.01.003-3')}</h6>
					<p>
						{intl.get('09D.01.003-4-1')}
					</p>
					<p>
						{intl.get('09D.01.003-4-2')}
					</p>
					<p>
						{intl.get('09D.01.003-4-3')}
					</p>
				</section>
				<section className="protocol-submit">
					<section className="clearFix">
						<label className="check-box fl">
							<Checkbox checked={this.state.dis} onChecked={(e) => {
								this.setState({ dis: !this.state.dis })
							}}></Checkbox>
						</label>
						<p className="fl">
							{intl.get('09D.01.003-5')}
							<span onClick={() => { this.goProtocol() }}> {this.state.showProtocolName} </span>
						</p>
					</section>
					<b className={(this.state.dis === false || this.state.disAmount === true) ? "dis" : ""} onClick={this.handleClick.bind(this)}>
						{intl.get('09D.01.003-6')}
					</b>
				</section>
			</div>
		)
	}
	onChange(val) {
		this.setState({ rangeVal: val })
	}
	handleChange = (e) => {
		const value = e.target.value;
		const valueReg = /^[0-9]*\.{0,1}\d{0,2}$/;
		if (valueReg.test(value)) {
			this.setState({ rangeVal: value })
		}
		console.info('value' + value)
		console.info(typeof (value));
		console.info('minValue' + this.state.sliderData.minValue)
		console.info(typeof (this.state.sliderData.minValue));
		if (Number(value) < Number(this.state.sliderData.minValue)) {
			this.setState({ tipsAmountMin: true, disAmount: false, tipsAmountMax: false });
		} else if (Number(value) > Number(this.state.sliderData.maxValue)) {
			this.setState({ tipsAmountMax: true, disAmount: true, tipsAmountMin: false });
		} else if (Number(this.state.sliderData.maxValue) >= Number(value) && Number(value) >= Number(this.state.sliderData.minValue)) {
			this.setState({ tipsAmountMin: false, tipsAmountMax: false, disAmount: false });
		}
	}
	/**
	 * 初始化数据 Init
	 * @param {} type 
	 */
	async initData(type) {
		console.info('--------initData---------');
		console.info(type);
		const limitType = type || 0;
		if (limitType === 0) return;
		if (limitType === 1) {
			// 单日
			var queryDayLimitAjax = queryDayLimit(
				{
					"bizInfo": {
						"limit_no": 'LIMIT001',
						"acct_type": 'E01',
						"acct_no": this.state.accMsg.list01[0].acct_no
					}
				}
			);
		} else {
			var queryDayLimitAjax = querySmallLimit({
				"bizInfo": {
					"acctno": this.state.accMsg.list01[0].acct_no
				}
			}
			);
		}
		Promise.all([queryAgreementInfo({ "agreementNo": "SmallValueTransfer_003", "languageType": window.localeLanguage }), queryDayLimitAjax]).then((dat) => {
			// Promise.all([queryDayLimitAjax]).then( (dat) => {
			console.info('----------- setlimit Query ----------- ')
			console.info(dat[0]);
			console.info('----------- setlimit Query ----------- ')
			console.info(dat[1]);
			const protocolRes = dat[0];
			const limitRes = dat[1];
			if (protocolRes.data.resultCode === 1 && limitRes.data.resultCode === 1) {
				// if (limitRes.data.resultCode === 1) {
				const showProtocolName = protocolRes.data.resultData.agreementName;
				let limitData = Object.assign(this.state.sliderData, limitRes.data.resultData);
				if (limitType === 1) {
					limitData.maxValue = limitData.max_limit_value;
					limitData.minValue = limitData.min_limit_value;
					limitData.rangeVal = limitData.limit_value;
					limitData.firstValue = limitData.limit_value;
				} else {
					limitData.maxValue = limitData.maxTranamValue;
					limitData.minValue = limitData.minTranamValue;
					limitData.rangeVal = limitData.rangeVal;
					limitData.firstValue = limitData.rangeVal;
				}
				/**    
				 * 判断限额
				 */
				if (limitData.rangeVal < limitData.minValue) {
					this.setState({ tipsAmountMin: true, disAmount: true, tipsAmountMax: false });
				} else if (limitData.rangeVal > limitData.maxValue) {
					this.setState({ tipsAmountMax: true, disAmount: true, tipsAmountMin: false });
				} else if (limitData.maxValue >= limitData.rangeVal && limitData.rangeVal >= limitData.minValue) {
					this.setState({ tipsAmountMin: false, tipsAmountMax: false, disAmount: false });
				}

				this.setState({
					sliderData: limitData,
					renderStatus: true,
					rangeVal: limitData.rangeVal,
					showProtocolName: showProtocolName,
					jumpParams: protocolRes.data.resultData
				})
			} else {
				alert('接口请求错误');
			}
		})
	}
	/**
	 * 点击设置限额提交
	 */
	async handleClick() {
		const networkres = await SDK.checkNetwork();

		try {
			console.info('---------- networkres -----------');
			console.info(networkres);
			let network = networkres.code == 1 && networkres.data && networkres.data.connected;
			!network && Toast.showNetError(intl.get('07.01.021.02'));
			if(!network) {
				return false;
			}
		} catch (error) {
			
		}
		
		let { limitType, rangeVal } = this.state;
		rangeVal = Number( String(this.state.rangeVal).replace(/(,)/g, "") );

		if (!this.state.dis || this.state.disAmount) return;
		if (limitType == 1) {
			// 每日限额接口 新增和修改是一个
			var setLimitAjax = setDayLimit({
				"bizInfo": {
					"limit_value": rangeVal,
					"ccy_code": "HKD",
					"limit_no": 'LIMIT001',
					"acct_type": 'E01',
					"acct_no": this.state.accMsg.list01[0].acct_no
				}
			})
		} else {
			// 小额转账接口提交
			if (this.state.sliderData.islmsm === '0') {
				// 开通
				var setLimitAjax = setSmallLimitNew(
					{
						"bizInfo": {
							"custna": this.state.accMsg.list01[0].acct_oth_name,
							"amlmtp": 0,
							"amlmvl": rangeVal || 0,
							"crcycd": "HKD",
							"remark": '',
							"acctno": this.state.accMsg.list01[0].acct_no
						}
					}
				)
			} else {
				// 新增
				var setLimitAjax = setSmallLimitUpdate(
					{
						"bizInfo": {
							"custna": this.state.accMsg.list01[0].acct_oth_name,
							"amlmtp": 0,
							"amlmvl": rangeVal || 0,
							"crcycd": "HKD",
							"remark": '',
							"acctno": this.state.accMsg.list01[0].acct_no
						}
					}
				)
			}
		}
		
		SDK.showNativeLoading(true);
		new Promise((resolve, reject) => {
			SDK.request((ret)=>{
				alert(ret.code);
				if(reject.code === -2){
					Toast.showNetError(intl.get('07.01.021.02'));
					return;
				}
			})
			// alert(reject.code);
			// if(reject.code === -2){
			// 	Toast.showNetError('No internet connection, please try again');
			// 	return;
			// }
			SDK.showNativeLoading(true);

			const res = setLimitAjax;
			resolve(res);
		}).then((r) => {
			SDK.showNativeLoading(false);
			console.info('设置限额返回的核身中心数据')
			console.info(r);
			// 因为action里面有值所以resultCode 为0
			if (r.data.resultCode === 0) {
				if (r.data.resultData && r.data.resultData.body) {
					// 核心中心返回加验证场景
					// 存下 服务到端返回的值， 这个接口要用
					this.setState({ quertResultParams: r.data.resultData });
					// 拿到服务端的数据跳转到原生的合身中心 actiondata
					const goNativeData = r.data.resultData.body.actionData;
					this.goNativeCheck(goNativeData, (nativeRes) => {
						// 请求服务端结果需要的参数
						console.info('这是js桥安全中心返回来数据');
						console.info(nativeRes)
						// native返回的code码
						if (nativeRes.status === 1) {
							// 请求服务端查询结果
							this.queryRiskData(nativeRes.outData.businessNo);
						}
					});
				} else {
					// 错误信息提示
					Toast.show(r.data.errorData.msg);
				}
			} else {
				if (r.data.resultData) {
					// 不需要加验
					this.setState({ quertResultParams: r.data.resultData });
					this.queryRiskData({});
				} else {
					Toast.show('Sys Error 999');
				}

			}
		})
	}
	/**
	 * 
	 * @param {调用原生Native传的参数ActionData} goNativeData 
	 * @param {回调参数} cb 
	 */
	async goNativeCheck(goNativeData, cb) {
		const nativeRes = await SDK.goNativeAction(goNativeData);
		cb && cb(nativeRes)
	}
	/**
	 * 查询结果接口
	 */
	queryRiskData(businessNo = {}) {
		new Promise((resolve, reject) => {
			const res = queryRiskResult(
				{
					"bizInfo": {
						"busino": this.state.quertResultParams.busino,
						"trandt": this.state.quertResultParams.trandt,
						"transq": this.state.quertResultParams.transq,
					},
					"securityResultData": {
						"businessNo": businessNo,
					}
				}
			);
			resolve(res);
		}).then((r) => {
			console.info('模拟安全中心通过')
			const limitType = this.state.limitType;
			console.info(r);
			if (r.data.resultCode === 1) {
				this.props.router.push({ pathname: '/SetLimit/result', state: { type: limitType, returnUrl: this.state.returnUrl } })
			} else {
				this.props.router.push({ pathname: '/SetLimit/resultError', state: { type: limitType, returnUrl: this.state.returnUrl } })
			}
		})
	}
	/**
	 * 查看协议 详情
	 */
	goProtocol() {
		// const params = this.state.jumpParams;
		// const b = Base64.encode(`No=${params.agreementNo}&Ver=${params.agreementVersion}&type=1`);
		// 产品何彦给了编号和版本
		const b = Base64.encode(`No=SmallValueTransfer_003&Ver=20190821_1.0&type=1`);
		window.location.href = `${window.location.origin}/public/protocol.html#/detailProtocol?${b}`;
	}

	/**
	 * js键盘输入回调
	 */
	inputAmout(amount) {
		amount = amount + '';
		amount = amount == '' ? '0' : amount;
		// 判断输入金额是否大于13位
		if (!!amount) {
			amount = amount.length > 12 ? amount.substr(0, 12) : amount;
		}
		// this.refs.keybord.ks.value = amount
		this.setState({
			rangeVal: amount,
			keybordMaxVal: amount
		});
		// this.refs.keybord.setState({
		// 	value: amount
		// });
		if (amount < this.state.sliderData.minValue) {
			this.setState({ tipsAmountMin: true, disAmount: true, tipsAmountMax: false });
		} else if (amount > this.state.sliderData.maxValue) {
			this.setState({ tipsAmountMax: true, disAmount: true, tipsAmountMin: false });
		} else if (this.state.sliderData.maxValue >= amount && amount >= this.state.sliderData.minValue) {
			this.setState({ tipsAmountMin: false, tipsAmountMax: false, disAmount: false });
		}
	}
	/**
	 * 页面离开埋点上报
	 */
	buriedPointLeave() {
		const buriedPointKey = this.state.buriedPointKey;
		SDK.onForeground(() => {
			SDK.buriedPointLeave({
				pageName: buriedPointKey
			})
		});
		// SDK.onBackPress(() => {
		// 	SDK.buriedPointLeave({
		// 		pageName: buriedPointKey
		// 	})
		// });
	}
	/**
	 * 金额输入框的聚焦回调
	 */
	inputFocusHandle() {
		let { rangeVal } = this.state;
		try {
			rangeVal = rangeVal.replace(/(,)/g, "");
			this.setState({ rangeVal: rangeVal });
			Number(rangeVal) === 0 && this.setState({ rangeVal: '' });
		} catch (error) {

		}
	}
	/**
	 * 金融输入框失焦回调
	 */
	inputBlurHandle() {
		const { rangeVal } = this.state;
		const newrangeVal = thousandBitSeparator(Number(rangeVal).toFixed(2));
		this.setState({ rangeVal: newrangeVal })
	}

	/**
	 * 千位分隔符
	 * @param {*} num 
	 * @param {*} cent 
	 * @param {*} isThousand 
	 */
	thousandBitSeparator(num, cent, isThousand) {
		if (Number(num) < 0) {
			return 0;
		}
		if (num) {
			num = num.toString().replace(/\$|\,/g, '');
			if ('' == num || isNaN(num)) { return 'Not a Number ! '; }
			var sign = num.indexOf("-") > 0 ? '-' : '';
			var cents = num.indexOf(".") > 0 ? num.substr(num.indexOf(".")) : '';
			cents = cents.length > 1 ? cents : '';
			num = num.indexOf(".") > 0 ? num.substring(0, (num.indexOf("."))) : num;
			if ('' == cents) { if (num.length > 1 && '0' == num.substr(0, 1)) { return 'Not a Number ! '; } }
			else { if (num.length > 1 && '0' == num.substr(0, 1)) { return 'Not a Number ! '; } }
			for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
				num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
			}
			return (sign + num + cents);
		} else {
			return num;
		}
	}
}

export default SetLimit;