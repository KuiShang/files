import { call, put, takeEvery } from 'redux-saga/effects'
import { qrmedda, cancelmedda, amendmedda, queryDayLimit } from 'pages/transfer-settings/api';
import { hashHistory } from 'react-router';
import { queryRiskResult } from 'pages/transfer-settings/api';
import * as SDK from 'utils/SDKUtil';


/** -------------------请求定时转账列表----------------*/
function* yieldQrmedda(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
        ...payload.payload
    }
  }
  const ret = yield call(qrmedda, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  yield put({ type: 'RECEIVE_MEDDA', medda: ret.data.resultData })
  payload.cb && payload.cb()
}

export function* watchYieldQrmedda() {
  yield takeEvery('REQUEST_MEDDA', yieldQrmedda)
}

/** ------------------请求定时转账列表----------------*/


/** -------------------删除定时转账----------------*/
function* yieldCancelmedda(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
        ...payload.payload
    }
  }
  const ret = yield call(cancelmedda, tempdata)
  
  yield put({ type: 'SET_DELETE_MODULE_STATE', payload: false })
  if (ret && ret.data && ret.data.resultCode === 1 ) {
    hashHistory.push('/Recurring?type=cancel')
  } else {
    payload.cb && payload.cb(ret)
  }
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  yield put({ type: 'CANCEL_MEDDA', medda: ret && ret.data && ret.data.resultData })
}

export function* watchYieldCancelmedda() {
  yield takeEvery('DELETE_MEDDA', yieldCancelmedda)
}


/** ------------------删除定时转账----------------*/


/** -------------------更新定时转账----------------*/
function* yieldUpdatemedda(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
        ...payload.payload
    }
  }
  const r = yield call(amendmedda, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })

  let quertResultParams = {}
  if (r.data.resultCode === 0 && r.data.resultData && r.data.resultData.body) {
    // 存下 服务到端返回的值， 这个接口要用
    quertResultParams = r.data.resultData
    // 拿到服务端的数据跳转到原生的合身中心 actiondata
    const goNativeData = r.data.resultData.body.actionData;
    goNativeCheck(goNativeData, (nativeRes) => {
      // 请求服务端结果需要的参数
      console.info('这是js桥安全中心返回来数据' + nativeRes)
      quertResultParams.businessNo = nativeRes.outData.businessNo
      // 请求服务端查询结果
      queryRiskData(quertResultParams, res => {
        if (res.data.resultCode === 1) {
          payload.cb && payload.cb()
          // hashHistory.push('/Recurring/result')
        } else {
           // 错误
           alert('server error!')
        }
      });
    });
  } else if (r.data.resultCode === 1) {
    payload.cb && payload.cb()
    // hashHistory.push('/Recurring/result')
  }else {
    // 错误
    r.data.errorData && alert(r.data.errorData.msg)
  }
  
  // yield put({ type: 'UPDATE_MEDDA', medda: ret.data.resultData })
}


async function goNativeCheck(goNativeData, cb) {
  const nativeRes = await SDK.goNativeAction(goNativeData);
  cb && cb(nativeRes)
}

async function queryRiskData(quertResultParams, cb) {
  const params = {
    "bizInfo": {
      "busino": quertResultParams.busino,
      "trandt": quertResultParams.trandt,
      "transq": quertResultParams.transq,
    },
    "securityResultData": {
      "businessNo": quertResultParams.businessNo,
    }
  }
  // 请求服务端 查询最终结果
  const res = await queryRiskResult(params);
  cb && cb(res)
  console.info('res', res)

}

export function* watchYieldUpdatemedda() {
  yield takeEvery('UPDATE_MEDDA', yieldUpdatemedda)
}

/** ------------------更新定时转账----------------*/


/** -------------------查询定时转账限额----------------*/
function* yieldQueryDayLimit(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
        ...payload.payload
    }
  }
  const ret = yield call(queryDayLimit, tempdata)
  
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })

  const rangeVal = ret.data.resultData.limit_value
  
  yield put({ type: 'SAVE_DAY_LIMIT', rangeVal: rangeVal })

}

export function* watchYieldQueryDayLimit() {
  yield takeEvery('QUERY_DAY_LIMIT', yieldQueryDayLimit)
}

/** ------------------查询定时转账限额----------------*/