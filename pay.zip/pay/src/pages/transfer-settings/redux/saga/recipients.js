import { hashHistory } from 'react-router';
import { call, put, takeEvery } from 'redux-saga/effects'
import { qrpayee, uppayee, delpayee, addpayee } from 'pages/transfer-settings/api';
import { queryRiskResult } from 'pages/transfer-settings/api';
import * as SDK from 'utils/SDKUtil';

/** -------------------请求收款人列表----------------*/
function* yieldQrpayee(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
      ...payload.payload
    },
    deviceInfo: {
      "deviceModel": "iPhone8",
      "imei": "11111",
      "macAddress": "123123",
      "os": "Android",
      "uuid": Date.now() + ''
    }
  }
  const ret = yield call(qrpayee, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  console.info('----', ret)
  if (ret.data.resultCode === '0') {
    if (ret.data.errorData.code === 'APPGW_BS_0002') {
      const aa = yield call(() => {
        return SDK.goNativeAction(ret.data.actionData)
      })
      console.info(aa)
      yieldQrpayee(payload)
      return
    }
  }
  yield put({ type: 'RECEIVE_PAYEE', payees: ret.data.resultData })
}

export function* watchYieldQrpayee() {
  yield takeEvery('REQUEST_PAYEE', yieldQrpayee)
}

/** ------------------请求收款人列表----------------*/



/** ------------------更新收款人----------------*/
function* yieldUppayee(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
      ...payload.payload
    },
    deviceInfo: {
      "deviceModel": "iPhone8",
      "imei": "11111",
      "macAddress": "123123",
      "os": "Android",
      "uuid": Date.now() + ''
    }
  }
  const r = yield call(uppayee, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  let quertResultParams = {}
  if (r.data.resultCode === 0 && r.data.resultData && r.data.resultData.body) {
    // 存下 服务到端返回的值， 这个接口要用
    quertResultParams = r.data.resultData
    // 拿到服务端的数据跳转到原生的合身中心 actiondata
    const goNativeData = r.data.resultData.body.actionData;
    goNativeCheck(goNativeData, (nativeRes) => {
      // 请求服务端结果需要的参数
      console.info('这是js桥安全中心返回来数据' + nativeRes)
      quertResultParams.businessNo = nativeRes.outData.businessNo
      // 请求服务端查询结果
      queryRiskData(quertResultParams, res => {
        if (res.data.resultCode === 1) {
          hashHistory.replace('/Recipients/result')
        } else {
          hashHistory.replace('/Recipients/result')
        }
      });
    });
  } else if (r.data.resultCode === 1) {
    hashHistory.replace('/Recipients/result')
  }else {
    // 错误
    r.data.errorData && alert(r.data.errorData.msg)
  }
  
}

export function* watchYieldUppayee() {
  yield takeEvery('UPDATE_PAYEE', yieldUppayee)
}
/** ------------------更新收款人-------------*/

/** ------------------删除收款人----------------*/
function* yieldDelpayee(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
      ...payload.payload
    },
    deviceInfo: {
      "deviceModel": "iPhone8",
      "imei": "11111",
      "macAddress": "123123",
      "os": "Android",
      "uuid": Date.now() + ''
    }
  }
  yield call(delpayee, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  yield put({ type: 'DELETE_MODULE_DONE', payload: true })
  // hashHistory.push('/Recipients/result')
}

export function* watchYieldDelpayee() {
  yield takeEvery('DELETE_CURRENT_PAYEE', yieldDelpayee)
}
/** ------------------删除收款人-------------*/


/** ------------------添加收款人----------------*/
function* yieldAddpayee(payload) {
  yield put({ type: 'CHANGE_FETCHING', isFetching: true })
  let tempdata = {
    bizInfo: {
      ...payload.payload
    },
    deviceInfo: {
      "deviceModel": "iPhone8",
      "imei": "11111",
      "macAddress": "123123",
      "os": "Android",
      "uuid": Date.now() + ''
    }
  }
  console.info(hashHistory)
  const r = yield call(addpayee, tempdata)
  yield put({ type: 'CHANGE_FETCHING', isFetching: false })
  let quertResultParams = {}
  if (r.data.resultCode === 1) {
    hashHistory.replace('/Recipients/result')
  } else if (r.data.resultCode === 0 && r.data.resultData && r.data.resultData.body) {
    // 存下 服务到端返回的值， 这个接口要用
    quertResultParams = r.data.resultData
    // 拿到服务端的数据跳转到原生的合身中心 actiondata
    const goNativeData = r.data.resultData.body.actionData;
    goNativeCheck(goNativeData, (nativeRes) => {
      // 请求服务端结果需要的参数
      console.info('这是js桥安全中心返回来数据' + nativeRes)
      // 请求服务端查询结果
      quertResultParams.businessNo = nativeRes.outData.businessNo

      queryRiskData(quertResultParams, (res) => {
        if (res.data.resultCode === 1) {
          hashHistory.replace('/Recipients/result')
        } else {
          hashHistory.replace('/Recipients/result')
        }
      });
    });
  } else {
    // 错误
    alert(r.data.errorData.msg)
  }
}

async function goNativeCheck(goNativeData, cb) {
  const nativeRes = await SDK.goNativeAction(goNativeData);
  cb && cb(nativeRes)
}

async function queryRiskData(quertResultParams, cb) {
  const params = {
    "bizInfo": {
      "busino": quertResultParams.busino,
      "trandt": quertResultParams.trandt,
      "transq": quertResultParams.transq,
    },
    "securityResultData": {
      "businessNo": quertResultParams.businessNo,
    }
  }
  // 请求服务端 查询最终结果
  const res = await queryRiskResult(params);
  cb && cb(res)
  console.info('res', res)



}

export function* watchYieldAddpayee() {
  yield takeEvery('ADD_PAYEE', yieldAddpayee)
}
/** ------------------添加收款人-------------*/


