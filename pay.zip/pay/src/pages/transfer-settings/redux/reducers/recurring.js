const defaultState = {
    recurring: {
        result: [],
        count: 0,
        
    }, // 预约列表
    currentEditIndex: 0,
    custno: '10024825096',// 客户号
    chnlcd: 'kkkk渠道类型', // 渠道类型
    showDeleteDialog: false, // 删除联系人弹窗展示
    deleteDone: false, // 删除联系人弹窗 删除完成状态
    rangeVal: 11 // 最大日转账限额
}
const recurring = (state = defaultState, action) => {
  switch (action.type) {
    // 存储收款人列表
    case 'RECEIVE_MEDDA':
    return {...state,  recurring: action.medda}
    case 'SET_CURRENT_EDIT_INDEX':
    return {...state,  currentEditIndex: action.payload}
    case 'SAVE_DAY_LIMIT':
      return {...state,  rangeVal: action.rangeVal}
    default:
      return state
  }
}
export default recurring
