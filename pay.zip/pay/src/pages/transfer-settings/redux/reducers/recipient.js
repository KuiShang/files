const defaultState = {
    payees: [], // 收款人列表
    currentPayee: {}, // 当前修改的收款人
    custno: '10024825096',// 客户号
    chnlcd: 'kkkk渠道类型', // 渠道类型
    showDeleteDialog: false, // 删除联系人弹窗展示
    deleteDone: false // 删除联系人弹窗 删除完成状态
}
const recipient = (state = defaultState, action) => {
  switch (action.type) {
    // 存储收款人列表
    case 'RECEIVE_PAYEE':
    return {...state,  payees: action.payees}
    case 'SET_CURRENT_PAYEE':
    return {...state,  currentPayee: action.payload}
    // 联系人弹窗展示与隐藏
    case 'SET_DELETE_MODULE_STATE':
    return {...state,  showDeleteDialog: action.payload, deleteDone: false}
    // 联系人弹窗完成状态
    case 'DELETE_MODULE_DONE':
    return {...state,  deleteDone: action.payload}
    default:
      return state
  }
}
export default recipient
