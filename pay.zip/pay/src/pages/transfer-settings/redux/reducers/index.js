import { combineReducers } from 'redux'
import recipient from './recipient'
import recurring from './recurring'
import { ENAMETOOLONG } from 'constants';


const defaultCommonState = {
    isFetching: false,
    language: 'EN',
}
const common = (state = defaultCommonState, action) => {
  switch (action.type) {
    case 'CHANGE_FETCHING':
    return {...state,  isFetching: action.isFetching}
    default:
      return state
  }
}


const reducer = combineReducers({
    recipient,
    recurring,
    common
})
export default reducer
