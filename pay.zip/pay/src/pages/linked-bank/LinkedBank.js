import React from 'react';
import LinkedBankFragment from 'fragments/linked-bank';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();

export default class LinkedBank extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            account: null
        }

    }

    render() {
        if (!this.state.account) {
            return <div style={{ textAlign: 'center', margin: '20px 0' }}>loading...</div>
        }

        return (
            <LinkedBankFragment account={this.state.account}></LinkedBankFragment>
        )
    }

    loadLocales() {
        intl.init({
            currentLocale: localeLanguage, // TODO: determine locale here
            locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK
            }
        }).then(() => {
            this.setState({ initDone: true });
        });
    }

    componentDidMount() {
        this.loadLocales();
        
        SDK.setTopStatusBar({ title: intl.get('linked_bank_accounts') });

        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_oth_name,
                        acct_type: res.data[0].acct_type
                    }
                })
            }
        })
    }
}