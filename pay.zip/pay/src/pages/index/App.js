import React from 'react';

export default class App extends React.Component {
    render() {
        return (
            <div>
                <a href="transfer.html">Transfer.html</a><br />
                <a href="linked-bank.html">Linked Bank.html</a><br />
                <a href="edda.html">eDDA.html</a><br />
                <a href="bank-auto-deposit.html">SeDDA.html</a><br />
                <a href="deposit.html">Deposit.html</a><br />
                <a href="transfer-settings.html">transfer-settings.html</a><br />
                <a href="transfer-settings.html#/SetLimit?type=1">Daily Transfer Limit</a><br />
                <a href="transfer-settings.html#/SetLimit?type=2">Daily Small-Value Transfer Limit</a><br />
            </div>
        )
    }
}