import React from 'react';
import PaymentInstructionsFragment from 'fragments/payment-instructions';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class Instructions extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: intl.get('transfer_instruction') });
    }

    render() {
        return (
            <div>
                <PaymentInstructionsFragment info={this.state.info}></PaymentInstructionsFragment>
            </div>
        )
    }
}