import React from 'react';
import SendMoneyFragment from 'fragments/send-money';
// import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';

export default class Transfer extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            account: null,
            info
        }
    }

    render() {
        const { account, info } = this.state;
        if (!account) {
            return <div style={{ textAlign: 'center', margin: '20px 0' }}>loading...</div>;
        }

        return (
            <SendMoneyFragment account={this.state.account} info={info} onShowContinue={(e) => this.setState({ showContinue: e })} onCheckType={this.onCheckType}></SendMoneyFragment>
        )
    }

    componentDidMount() {
        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_oth_name,
                        acct_type: res.data[0].acct_type
                    }
                })
            }
        })
    }
}