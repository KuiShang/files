import React from 'react';
import ReviewFragment from 'fragments/review';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class Review extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: intl.get('review_details') });
    }

    render() {
        return (
            <ReviewFragment info={this.state.info}></ReviewFragment>
        )
    }
}