import React from 'react';
import * as SDK from 'utils/SDKUtil';
import MerchantFragment from 'fragments/merchant';
import intl from 'react-intl-universal';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();
        
async function loadLocales(){
    intl.init({
        currentLocale: localeLanguage, // TODO: determine locale here
        locales: {
            "en-HK": enHK,
            "zh-CN": zhCN,
            "zh-HK": zhHK
        }
    })
}

export default class Merchant extends React.Component {
    render() {
        return (
            <MerchantFragment></MerchantFragment>
        )
    }

    componentDidMount() {
        loadLocales();
        SDK.setTopStatusBar({ title: intl.get('merchant') });
    }
}