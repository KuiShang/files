import React from 'react';
import EDDAReviewFragment from 'fragments/edda-review';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class Review extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: intl.get("review") });
    }

    render() {
        console.info(this.state.info);
        return (
            <EDDAReviewFragment info={this.state.info}></EDDAReviewFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get('review') });
    }
}