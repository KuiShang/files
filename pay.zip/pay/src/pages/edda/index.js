import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import * as serviceWorker from 'serviceWorker';
import * as SDK from 'utils/SDKUtil';
import 'utils/InitialUtil';
import 'assets/css/main.scss';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

/**
 * Step 1: 异步获取公共DeviceInfo信息；
 */
async function initAppData() { 
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        window.$DeviceInfo = ret
    } else {
        window.$DeviceInfo = {
            androidUuid: 'AndroidUuid',
            appChannel: 'AppChannel',
            appVersion: 'AppVersion'
        }
    };

    ReactDOM.render(<App></App>, document.getElementById('root'));
}

initAppData();
serviceWorker.unregister();