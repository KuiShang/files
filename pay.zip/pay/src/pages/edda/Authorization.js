import React from 'react';
import Waiting from 'components/waiting';
import EDDAAuthorizationFragment from 'fragments/edda-authorization';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class Authorization extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            account: null
        }

    }

    render() {
        if (!this.state.account) {
            return <Waiting></Waiting>;
        }

        return (
            <EDDAAuthorizationFragment account={this.state.account}></EDDAAuthorizationFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get("payment_authorization") });

        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_name,
                        acct_type: res.data[0].acct_type
                    }
                });
            }
        })
    }
}