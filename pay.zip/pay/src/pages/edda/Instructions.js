import React from 'react';
import EDDAInstructionsFragment from 'fragments/edda-instructions';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class Instructions extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            info
        }
    }

    render() {
        return (
            <EDDAInstructionsFragment info={this.state.info}></EDDAInstructionsFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get("payment_authorization") });
    }
}