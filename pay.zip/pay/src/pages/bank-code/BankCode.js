import React from 'react';
import BankCodeFragment from 'fragments/bank-code';
import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();

export default class BankCode extends React.Component {
    constructor(props) {
        super(props);
        this.loadLocales();   
        if (window.location.search.indexOf("ref=tran") >= 0) {
            SDK.setTopStatusBar({ title: intl.get('recipient_bank') });
        } else {
            SDK.setTopStatusBar({ title: intl.get('bank_code') });
        }
    }

    render() {
        return (
            <BankCodeFragment></BankCodeFragment>
        )
    }

    componentDidMount() {
        this.loadLocales()
        if (window.location.search.indexOf("ref=tran") >= 0) {
            SDK.setTopStatusBar({ title: intl.get('recipient_bank') });
        } else {
            SDK.setTopStatusBar({ title: intl.get('bank_code') });
        }
    }

    loadLocales() {
        intl.init({
            currentLocale: localeLanguage, // TODO: determine locale here
            locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK
            }
        }).then(() => {
            this.setState({ initDone: true });
        });
    }
}