import React from 'react';
import EDDAResultFragment from 'fragments/edda-result';
import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();

export default class App extends React.Component {
    constructor(props) {
        super(props);

        const params = this.props.location.query || null;
        this.state = {
            params
        }
    }

    loadLocales() {
        intl.init({
            currentLocale: localeLanguage, // TODO: determine locale here
            locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK
            }
        }).then(() => {
            this.setState({ initDone: true });
        });
    }

    render() {
        if (!this.state.params) {
            return (
                <div></div>
            )
        }

        return (
            <EDDAResultFragment params={this.state.params}></EDDAResultFragment>
        )
    }

    componentDidMount() {
        this.loadLocales()
        SDK.setTopStatusBar({ title: intl.get('confirmation') });
    }
}