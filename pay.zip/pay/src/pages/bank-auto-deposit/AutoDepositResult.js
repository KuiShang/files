import React from 'react';
import AutoDepositResultFragment from 'fragments/auto-deposit-result';
import * as SDK from 'utils/SDKUtil';

export default class AutoDepositResult extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: '' });
    }

    render() {
        return (
            <AutoDepositResultFragment params={this.state.info}></AutoDepositResultFragment>
        )
    }
}