import React from 'react';
import { Router, Route, hashHistory } from 'react-router';
import { Provider } from 'react-redux';
import store from 'redux/store';
import BankAutoDeposit from './BankAutoDeposit';
import NewAutoDeposit from './NewAutoDeposit';
import AutoDeposit from './AutoDeposit';
import AutoDepositReview from './AutoDepositReview';
import AutoDepositResult from './AutoDepositResult';
import NewAutoDepositReview from './NewAutoDepositReview';
import NewAutoDepositResult from './NewAutoDepositResult';
import AuthorizeDepositAccount from './AuthorizeDepositAccount';
import AuthorizeDepositAccountReview from './AuthorizeDepositAccountReview';
import AuthorizeDepositAccountResult from './AuthorizeDepositAccountResult';
import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();

export default class App extends React.Component {
    componentDidMount() {
        this.loadLocales()
    }

    loadLocales() {
        intl.init({
            currentLocale: localeLanguage, // TODO: determine locale here
            locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK
            }
        }).then(() => {
            this.setState({ initDone: true });
        });
    }

    render() {
        return (
            <Provider store={store}>
                <Router history={hashHistory}>
                    <Route path={'/'} components={BankAutoDeposit}></Route>
                    <Route path={'/auto-deposit'} components={AutoDeposit}></Route>
                    <Route path={'/auto-deposit-review'} components={AutoDepositReview}></Route>
                    <Route path={'/auto-deposit-result'} components={AutoDepositResult}></Route>
                    <Route path={'/new-auto-deposit'} components={NewAutoDeposit}></Route>
                    <Route path={'/new-auto-deposit-review'} components={NewAutoDepositReview}></Route>
                    <Route path={'/new-auto-deposit-result'} components={NewAutoDepositResult}></Route>
                    <Route path={'/deposit-account'} components={AuthorizeDepositAccount}></Route>
                    <Route path={'/deposit-account-review'} components={AuthorizeDepositAccountReview}></Route>
                    <Route path={'/deposit-account-result'} components={AuthorizeDepositAccountResult}></Route>
                </Router>
            </Provider>
        )
    }
}