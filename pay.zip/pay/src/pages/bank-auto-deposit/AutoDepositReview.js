import React from 'react';
import AutoDepositReviewFragment from 'fragments/auto-deposit-review';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class AutoDepositReview extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;
        this.state = {
            info
        }

        SDK.setTitleRight({ show: 0 });
        SDK.setTopStatusBar({ title: intl.get('review') });
    }

    render() {
        return (
            <AutoDepositReviewFragment info={this.state.info}></AutoDepositReviewFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get('review') });
    }
}