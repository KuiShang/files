import React from 'react';
import AuthorizeDepositAccountReviewFragment from 'fragments/authorize-deposit-account-review';

export default class Review extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info
        }
    }

    render() {
        return (
            <AuthorizeDepositAccountReviewFragment info={this.state.info}></AuthorizeDepositAccountReviewFragment>
        )
    }
}