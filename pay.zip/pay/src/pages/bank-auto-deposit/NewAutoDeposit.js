import React from 'react';
import NewAutoDepositFragment from 'fragments/new-auto-deposit'
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class NewAutoDeposit extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            account: null
        }

    }

    render() {
        if (!this.state.account) {
            return <div style={{ textAlign: 'center', margin: '20px 0' }}>loading...</div>;
        }

        return (
            <NewAutoDepositFragment account={this.state.account}></NewAutoDepositFragment>
        )
    }

    componentDidMount() {
        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_oth_name,
                        acct_type: res.data[0].acct_type
                    }
                })
            }
        })
        SDK.setTopStatusBar({ title: intl.get('new_auto_deposit') });
    }
}