import React from 'react';
import NewAutoDepositResultFragment from 'fragments/new-auto-deposit-result';
import * as SDK from 'utils/SDKUtil';

export default class NewAutoDepositReview extends React.Component {
    constructor(props) {
        super(props);

        const params = props.location ? props.location.state : null;

        this.state = {
            params,
            isSuccess: (params && params.isSuccess) || true,
            isPending: (params && params.isPending) || false,
            isFailed: (params && params.isFailed) || false
        }
    }

    render() {
        const { isSuccess, isPending, isFailed } = this.state;

        return (
            <NewAutoDepositResultFragment params={this.state.params} isSuccess={isSuccess} isPending={isPending} isFailed={isFailed}>
            </NewAutoDepositResultFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: '' });
    }
}