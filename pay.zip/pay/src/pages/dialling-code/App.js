import React from 'react';
import DiallingCodeFragment from 'fragments/dialling-code';

export default class DiallingCode extends React.Component {
    render() {
        return (
            <DiallingCodeFragment></DiallingCodeFragment>
        )
    }
}