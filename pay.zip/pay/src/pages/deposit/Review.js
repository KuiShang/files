import React from 'react';
import DepositReviewFragment from 'fragments/deposit-review';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';


export default class Review extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: 'Review' });
    }

    render() {
        return (
            <DepositReviewFragment info={this.state.info}></DepositReviewFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get('review') });
    }
}