import React from 'react';
import AuthorizeDepositAccountResultFragment from 'fragments/authorize-deposit-account-result';
import * as SDK from 'utils/SDKUtil';

export default class AccountResult extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info
        }

        SDK.setTopStatusBar({ title: '' });
    }

    render() {
        return (
            <AuthorizeDepositAccountResultFragment info={this.state.info}></AuthorizeDepositAccountResultFragment>
        )
    }
}