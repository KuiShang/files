import React from 'react';
import DepositResultFragment from 'fragments/deposit-result';

export default class Result extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info
        }
    }

    render() {
        return (
            <DepositResultFragment params={this.state.info}></DepositResultFragment>
        )
    }
}