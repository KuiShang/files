import React from 'react';
import { Router, Route, hashHistory } from 'react-router';
import { Provider } from 'react-redux';
import store from 'redux/store';
import Instruction from './Instruction';
import Review from './Review';
import Result from './Result';
import AuthorizeDepositAccount from './AuthorizeDepositAccount';
import AuthorizeDepositAccountReview from './AuthorizeDepositAccountReview';
import AuthorizeDepositAccountResult from './AuthorizeDepositAccountResult';
import intl from 'react-intl-universal';
import * as SDK from 'utils/SDKUtil';
import enHK from 'i18n/en_HK.js';
import zhCN from 'i18n/zh_CN.js';
import zhHK from 'i18n/zh_HK.js';

const platformInfo = SDK.getSysType();
const isJDAPP = platformInfo.isJdApp;

let localeLanguage = 'en-HK';
async function getAppLang() {
    if (isJDAPP) {
        const ret = await SDK.getCommonInfo()
        if (!!ret.language) {
            localeLanguage = ret.language;
        }
    }
}
getAppLang();

export default class Deposit extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            account: null
        }
    }

    loadLocales() {
        intl.init({
            currentLocale: localeLanguage, // TODO: determine locale here
            locales: {
                "en-HK": enHK,
                "zh-CN": zhCN,
                "zh-HK": zhHK
            }
        }).then(() => {
            this.setState({ initDone: true });
        });
    }

    render() {
        return (
            <Provider store={store}>
                <Router history={hashHistory}>
                    <Route path={'/'} components={Instruction}></Route>
                    <Route path={'/review'} components={Review}></Route>
                    <Route path={'/result'} components={Result}></Route>
                    <Route path={'/deposit-account'} components={AuthorizeDepositAccount}></Route>
                    <Route path={'/deposit-account-review'} components={AuthorizeDepositAccountReview}></Route>
                    <Route path={'/deposit-account-result'} components={AuthorizeDepositAccountResult}></Route>
                </Router>
            </Provider>
        )
    }

    componentDidMount() {
        this.loadLocales()
        SDK.setTopStatusBar({ title: intl.get('direct_deposit') });
        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_oth_name,
                        acct_type: res.data[0].acct_type
                    }
                })
            }
        })
    }
}