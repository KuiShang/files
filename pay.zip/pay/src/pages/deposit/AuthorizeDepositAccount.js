import React from 'react';
import AuthorizeDepositAccountFragment from 'fragments/authorize-deposit-account';
import * as SDK from 'utils/SDKUtil';
import intl from 'react-intl-universal';

export default class DepositAccount extends React.Component {
    constructor(props) {
        super(props);

        const info = props.location ? props.location.state : null;

        this.state = {
            info,
            account: null
        }
    }

    render() {
        if (!this.state.account) {
            return null;
        }

        return (
            <AuthorizeDepositAccountFragment account={this.state.account} info={this.state.info}></AuthorizeDepositAccountFragment>
        )
    }

    componentDidMount() {
        SDK.setTopStatusBar({ title: intl.get("set_direct_deposit") });
        SDK.getUserInfo((res) => {
            if (res.code === 1 && res.data) {
                this.setState({
                    account: {
                        acct_no: res.data[0].acct_no,
                        acct_name: res.data[0].acct_oth_name,
                        acct_type: res.data[0].acct_type
                    }
                })
            }
        })
    }
}