import axios from './AxiosUtil';
import intl from 'react-intl-universal';
import * as SDK from './SDKUtil';
import { Base64 } from 'js-base64';
import Toast from 'components/toast';

const FetchUtil = {};

function uuid(len, radix) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = [], i;
    radix = radix || chars.length;

    if (len) {
        // Compact form
        for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
    } else {
        // rfc4122, version 4 form
        var r;

        // rfc4122 requires these characters
        uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
        uuid[14] = '4';

        // Fill in random data. At i==19 set the high bits of clock sequence as
        // per rfc4122, sec. 4.1.5
        for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
                r = 0 | Math.random() * 16;
                uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
            }
        }
    }

    return uuid.join('');
}

const TYPES = {
    GET: 'GET',
    POST: 'POST'
}

let initFinish = false; // 是否完成判断当前使用哪个fetch， 默认为假，在初始化完成之后为真
const safeFlag = true; // 是否使用客户端request开关， true:表示使用客户端发送请求    false：表示使用h5请求

/**
 * 原生Fetch发起API请求
 * @param {*} types 
 * @param {*} url 
 * @param {*} params 
 */
function fetchApi(types, url, params) {
    let temp = [];
    if (params !== undefined) {
        Object.keys(params).forEach(key => temp.push(key + '=' + params[key]))
    }

    const data = Object.assign({}, { "bizInfo": params }, {
        "deviceInfo": {
            "appChannel": "App发布不同的渠道有不通的值:google,appStore",
            "appUniqueCode": "App发布的技术版本号",
            "appVersion": "App版本号，给用户看的",
            "appsFlyerUID": "一个第三方的SDK生成的ID，此SDK可以监控google和Facebook等投放效果",
            "brand": "手机品牌，如Xiaomi、Apple",
            "clientName": "客户端类型:APP,PC_Web,M_Web",
            "deviceModel": "手机型号如MI 8、iPhone8",
            "deviceType": "客户端类型:Mobile,PC",
            "eid": "设备指纹SDK生成的设备唯一ID，理论上是不应该变化",
            "googleAdvertisingID": "App内嵌了google的SDK，此SDK生成的google广告id",
            "idfa": "苹果自带的广告唯一标识",
            "idfv": "苹果自带的硬件唯一标识，不太准，手机重置时会改变",
            "imei": "通信唯一识别码",
            "ip": "客户端ip",
            "language": "App内设置的语言编码英语(香港)：002；简体中文：001;繁体中文：003",
            "location": "手机经度=值#手机纬度=值#百度SDK获取的经度=值#百度SDK获取纬度=值#google的SDK获取的经度=值#google的SDK获取纬度=值",
            "macAddress": "手机mac地址",
            "networkType": "手机网络环境:3G,4G,null",
            "openType": "硬件是否支持指纹识别，值为1或0",
            "os": "手机操作系统，枚举值有：Android；iOS",
            "osVersion": "手机操作系统版本，如9",
            "pushId": "google消息推送时的key",
            "simCard": "手机通讯卡的id",
            "uuid": "App自己生成的设备唯一ID",
            "webVersionCode": "App内置浏览器的技术版本"
        }
    })

    return new Promise(function (resolve, reject) {
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8',
                'uuid': uuid(32, 6),
                //'custNo': '100000002801',
                'custNo': '100000000702'
            },
            body: JSON.stringify(data),
        }).then((response) => {
            if (response.ok) {
                return response.json();
            } else {
                reject({ ok: false, status: response.status, msg: response.statusText })
            }
        }).then((response) => {
            resolve(response);
        }).catch((err) => {
            reject({ status: -1 });
        })
    })
}

function fetchAxiox(types, url, data) {
    axios.defaults.headers.common['uuid'] = new Date().getTime();

    data = Object.assign({}, { "bizInfo": data }, {
        "deviceInfo": {
            "appChannel": "App发布不同的渠道有不通的值:google,appStore",
            "appUniqueCode": "App发布的技术版本号",
            "appVersion": "App版本号，给用户看的",
            "appsFlyerUID": "一个第三方的SDK生成的ID，此SDK可以监控google和Facebook等投放效果",
            "brand": "手机品牌，如Xiaomi、Apple",
            "clientName": "客户端类型:APP,PC_Web,M_Web",
            "deviceModel": "手机型号如MI 8、iPhone8",
            "deviceType": "客户端类型:Mobile,PC",
            "eid": "设备指纹SDK生成的设备唯一ID，理论上是不应该变化",
            "googleAdvertisingID": "App内嵌了google的SDK，此SDK生成的google广告id",
            "idfa": "苹果自带的广告唯一标识",
            "idfv": "苹果自带的硬件唯一标识，不太准，手机重置时会改变",
            "imei": "通信唯一识别码",
            "ip": "客户端ip",
            "language": "App内设置的语言编码英语(香港)：002；简体中文：001;繁体中文：003",
            "location": "手机经度=值#手机纬度=值#百度SDK获取的经度=值#百度SDK获取纬度=值#google的SDK获取的经度=值#google的SDK获取纬度=值",
            "macAddress": "手机mac地址",
            "networkType": "手机网络环境:3G,4G,null",
            "openType": "硬件是否支持指纹识别，值为1或0",
            "os": "手机操作系统，枚举值有：Android；iOS",
            "osVersion": "手机操作系统版本，如9",
            "pushId": "google消息推送时的key",
            "simCard": "手机通讯卡的id",
            "uuid": "App自己生成的设备唯一ID",
            "webVersionCode": "App内置浏览器的技术版本"
        }
    })

    if (types === TYPES.GET || types === 2) {
        return axios.get(url, {
            params: data
        })
    } else if (types === TYPES.POST || types === 1) {
        return new Promise(function (resolve, reject) {
            axios.post(url, data).then(res => {
                resolve(res.data);
            }).catch((err) => {
                reject(err)
            })
        })
    }

    return false
}

/**
 * 原生APP发起API请求
 * type: 1- post  2- get
 */
function fetchApp(types, url, data) {
    let type = 1
    if (types === TYPES.GET) {
        type = 2
    } else {
        type = 1
    }
    const urlAll = 'http://appgw.livibank.com' + url;////window.location.origin + url

    //// Option 1: 如果含有bizInfo属性
    //// Option 2: 如果不含有bizInfo属性
    if (data.bizInfo) {
        data = Object.assign({}, data, { deviceInfo: window.$DeviceInfo })
    }
    else {
        data = Object.assign({},
            { bizInfo: data },
            { deviceInfo: window.$DeviceInfo }
        )
    }

    const json = {
        url: urlAll,
        httpType: type,
        parameters: JSON.stringify(data),
        postMediaType: 'application/json',
        headerParameters: {
            ///simpleDeviceInfo: JSON.stringify({ "language": 'zh-CN' }),
            ///custNo: '100000000702',
            ///uuid: new Date().getTime(),
        }
    }

    return new Promise((reslove, reject) => {
        SDK.request(json, (ret) => {
            if (ret.code === -2) {
                Toast.showNetError(intl.get("show_net_error"));
                return;
            }
            const retResloved = JSON.parse(Base64.decode(ret.data))
            console.info('原声app成功的ret 解析后：', retResloved)

            let strObj = ''
            let str = ''
            strObj = {
                k50: intl.get("show_net_error"),
                k40: 'System error'
            }

            //// reResloved.data 为最终解析后服务器端返回的结果
            if (retResloved.status === 200) {
                retResloved.data = JSON.parse(retResloved.data)
                retResloved.data.resultCode = Number(retResloved.data.resultCode)

                //// Toast.show(JSON.stringify(retResloved.data), 500)
                //// 此处只是用于处理登录的情况
                if (retResloved.data.resultCode !== 1 && retResloved.data.actionData && retResloved.data.actionData.address.indexOf('login') >= 0) {
                    /////Toast.show('shit js bridge');
                    SDK.goNativeAction(retResloved.data.actionData, res => {
                        window.location.href = window.location.href;
                    })
                }
                reslove(retResloved.data)
            } else if (retResloved.status.toString().match(/^50/)) {
                str = strObj.k50;
                reject(retResloved)
            } else if (retResloved.status.toString().match(/^40/)) {
                str = strObj.k40;
                reject(retResloved)
            } else {
                str = strObj.k40;
                reject(retResloved)
            }
            return ''
        })
    })
}

let fetch = async function d(a, b, c) {
    if (!initFinish) {
        const hasRequest = await SDK.checkHasAppRequest()
        if (safeFlag && hasRequest) {
            fetch = fetchApp
        } else {
            fetch = fetchAxiox
        }
        return fetch(a, b, c)
    }
    return fetch(a, b, c)
}

async function switchFetch() {
    const hasRequest = await SDK.checkHasAppRequest()
    console.info(`hasRequest: ${hasRequest} + safeFlag: ${safeFlag}`)
    if (safeFlag && hasRequest) {
        fetch = fetchApp
    } else {
        fetch = fetchAxiox
    }
    initFinish = true
    return fetch
}

switchFetch();

FetchUtil.postBK = function (url, params, headers) {
    let temp = [];
    if (params !== undefined) {
        Object.keys(params).forEach(key => temp.push(key + '=' + params[key]))
    }

    const data = Object.assign({}, { "bizInfo": params }, {
        "deviceInfo": {
            "appChannel": "App发布不同的渠道有不通的值:google,appStore",
            "appUniqueCode": "App发布的技术版本号",
            "appVersion": "App版本号，给用户看的",
            "appsFlyerUID": "一个第三方的SDK生成的ID，此SDK可以监控google和Facebook等投放效果",
            "brand": "手机品牌，如Xiaomi、Apple",
            "clientName": "客户端类型:APP,PC_Web,M_Web",
            "deviceModel": "手机型号如MI 8、iPhone8",
            "deviceType": "客户端类型:Mobile,PC",
            "eid": "设备指纹SDK生成的设备唯一ID，理论上是不应该变化",
            "googleAdvertisingID": "App内嵌了google的SDK，此SDK生成的google广告id",
            "idfa": "苹果自带的广告唯一标识",
            "idfv": "苹果自带的硬件唯一标识，不太准，手机重置时会改变",
            "imei": "通信唯一识别码",
            "ip": "客户端ip",
            "language": "App内设置的语言编码英语(香港)：002；简体中文：001;繁体中文：003",
            "location": "手机经度=值#手机纬度=值#百度SDK获取的经度=值#百度SDK获取纬度=值#google的SDK获取的经度=值#google的SDK获取纬度=值",
            "macAddress": "手机mac地址",
            "networkType": "手机网络环境:3G,4G,null",
            "openType": "硬件是否支持指纹识别，值为1或0",
            "os": "手机操作系统，枚举值有：Android；iOS",
            "osVersion": "手机操作系统版本，如9",
            "pushId": "google消息推送时的key",
            "simCard": "手机通讯卡的id",
            "uuid": "App自己生成的设备唯一ID",
            "webVersionCode": "App内置浏览器的技术版本"
        }
    })

    return new Promise(function (resolve, reject) {
        fetch(url, {
            method: 'POST',
            headers: Object.assign({}, headers, {
                'Content-Type': 'application/json;charset=UTF-8',
                'uuid': uuid(32, 6),
                //'custNo': '100000002801',
                'custNo': '100000000702'
            }),
            body: JSON.stringify(data),
        }).then((response) => {
            if (response.ok) {
                return response.json();
            } else {
                reject({ ok: false, status: response.status, msg: response.statusText })
            }
        }).then((response) => {
            resolve(response);
        }).catch((err) => {
            reject({ status: -1 });
        })
    })
}

FetchUtil.post = function (url, data) {
    return fetch(1, url, data);
}

export default FetchUtil;