const ASTERISK = '*';
const AT = '@';
const EMPTY_STRING = "";
const BLANK_SPACE = " ";

/**
 * 手机号脱敏
 * 倒数第4-6位打*
 *
 * @param str
 * @return
 */
export function maskMobile(str) {
    if (str == null) {
        return null;
    } else {
        let len = str.length;
        if (len >= 6) {
            let sb = `${str.substring(0, len - 6)}${asterisk(3)}${str.substring(len - 3)}`;
            return sb;
        } else if (len == 5) {
            return asterisk(2) + str.substring(2);
        } else if (len == 4) {
            return asterisk(1) + str.substring(1);
        } else {
            return str;
        }
    }
}

/**
 * email地址脱敏
 * 设@前字数为n,
 * n大于5位时，展示字符为开始的3位，后续使用*进行替代后续。
 * n小于等于5位时，展示前面的n/2下取整位，后续的字母打*
 *
 * @param str
 * @return
 */
export function maskEmail(str) {
    let atIndex = -1;
    if (str == null || (atIndex = str.lastIndexOf(AT)) <= 0) {
        return str;
    }
    if (atIndex > 5) {
        let sb = `${str.substring(0, 3)}${asterisk(atIndex - 3)}${str.substring(atIndex)}`;
        return sb;
    } else {
        let displayWidth = (atIndex) >> 1;
        let sb = `${str.substring(0, displayWidth)}${asterisk(atIndex - displayWidth)}${str.substring(atIndex)}`;
        return sb;
    }
}

export function maskName(name) {
    if (!name || name === '') {
        return "";
    }
    name = name.trim();
    //首字母是中文按照中文名字处理 否则按照英文名字处理
    const reg = new RegExp("^[\\u4e00-\\u9fa5]$");
    if (reg.test(name.substring(0, 1))) {
        return maskChinseName(name);
    }
    return maskEnglishName(name);
}

/**
 * 中文名字脱敏
 * 只展示最后一个中文文字，其它字符都使用*替代
 *
 * @param str
 * @return
 */
function maskChinseName(str) {
    let len = 0;
    if (str === null || (len = str.length) === 0) {
        return str;
    } else if (len == 1) {
        return asterisk(1);
    } else {
        let sb = `${asterisk(len - 1)}${str.charAt(len - 1)}`;
        return sb;
    }
}

/**
 * 英文名字脱敏
 * 单词之间的间隔通过空格符区分,第一个单词全展示，后续单词展示首字母，该单词的其它字母使用*进行替代，如果后续单词只有一个字符直接用*替代；
 * 若只有一个单词（L展示成*，Leo展示成L** 以此类推）
 *
 * @param temp
 * @return
 */

function maskEnglishName(temp) {
    if (temp === null || (temp = temp.trim()).length === 0) {
        return temp;
    }
	let b = ''
    let nameArr = temp.split(' ');
    if(nameArr.length === 1){
        let words = nameArr[0]
        if(words.length === 1){
            return asterisk(1)
        }
        return words.charAt(0) + asterisk(words.length - 1)
    }else{
        let arr = nameArr.slice(1);
	    for(var i = 0; i < arr.length; i++){
		    b += (BLANK_SPACE + arr[i].charAt(0) + asterisk(arr[i].length - 1))
        }
	    return nameArr[0] + b
    }
}
// function maskEnglishName(temp) {
//     if (temp === null || (temp = temp.trim()).length === 0) {
//         return temp;
//     }

//     let split = temp.split("\\s+");
//     let sb = '';
//     if (split.length === 1) {
//         const word = split[0];
//         if (word.length == 1) {
//             sb += (asterisk(1));
//         } else {
//             sb += `${word.charAt(0)}${asterisk(word.length - 1)}`;
//         }
//         return sb;
//     } else {
//         for (let i = 0; i < split.length; i++) {
//             const word = split[i];
//             if (i === 0) {
//                 sb = `${word}${BLANK_SPACE}`;
//             } else {
//                 if (word.length === 1) {
//                     sb = `${asterisk(1)}${BLANK_SPACE}`;
//                 } else {
//                     sb = `${word.charAt(0)}${asterisk(word.length - 1)}${BLANK_SPACE}`;
//                 }
//             }
//         }
//         return sb.substring(0, sb.length - 1);
//     }
// }

/**
 * 生成定长的星号
 *
 * @param n 长度
 * @return
 */
function asterisk(n) {
    if (n <= 0) {
        return EMPTY_STRING;
    } else {
        let sb = '';
        for (let i = 0; i < n; i++) {
            sb += ASTERISK;
        }

        return sb;
    }
}
