/**
 * 
 * 千位分隔符
 * @returns 
 */
export function thousandBitSeparator(num) {
	let res = num.toString().replace(/\d+/, function (n) {
		return n.replace(/(\d)(?=(\d{3})+$)/g, function ($1) {
			return $1 + ",";
		});
	})
	return res;
}

/**
 * 
 * 保留两位小数
 * @returns 
 */
export function keep2DecimalFull(x) {
	let f_x = parseFloat(x);
	if (isNaN(f_x)) {
		return false;
	}
	f_x = Math.round(x * 100) / 100;
	let s_x = f_x.toString();
	let pos_decimal = s_x.indexOf('.');
	if (pos_decimal < 0) {
		pos_decimal = s_x.length;
		s_x += '.';
	}
	while (s_x.length <= pos_decimal + 2) {
		s_x += '0';
	}
	return s_x;
}

/*
* 获取系统信息
* getSysType(str)
* */
export function getSysType(str) {
	var ua = navigator.userAgent.toLowerCase();
	var isIOS = ua.indexOf('ipad') > -1 || ua.indexOf('iphone') > -1 || false;
	var isAndroid = ua.indexOf('android') > -1 || false;
	// var isJdApp = ua.indexOf('ijr') > -1 || false;
	var isJdApp = ua.indexOf('t1w') > -1 || false;
	var result = {
		isIOS: isIOS,
		isAndroid: isAndroid,
		isJdApp: isJdApp
	}
	return str ? result[str] : result;
}