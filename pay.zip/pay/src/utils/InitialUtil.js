/**
 * 页面初始化时进行
 * 1: 类型的方法扩展
 */

Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

/**
 * 将数据库日期字符串转化为日期格式
 */
String.prototype.formatDate = function () {
    const year = this.substr(0, 4);
    let month = this.substr(4, 2);
    if (month.substr(0, 1) === '0') {
        month = parseInt(month.substr(1, 1)) - 1;
    } else {
        month = parseInt(month) - 1;
    }
    const day = this.substr(6, 2);
    return new Date(year, month, day);
}

/**
 * 替换除数字、字母外其他字符
 */
String.prototype.isOnlyNumChar = function () {
    return this.replace(/[\W]/g, '');
}

/**
 * 替换中文
 */
String.prototype.isNotChinese = function () {
    return this.replace(/[\u4e00-\u9fa5]/g, '');
    //return this.replace(/[/u0391-/uFFE5]/gi, '');
}

/**
 * 替换除英文外所有字符
 */
String.prototype.isOnlyEnglish = function () {
    return this.replace(/[^a-zA-Z]/g, '');
}

/**
 * 替换除数字之外的所有字符
 */
String.prototype.isOnlyNumber = function () {
    return this.replace(/\D/g, '');
}

/**
* 只能输入数字以及两位有效小数
*/
String.prototype.isOnlyNumWithTwoDecimal = function () {
    let amount = this.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    amount = this.replace(/^\./g, ""); // 验证第一个字符是数字
    amount = this.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    amount = this.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    amount = this.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); // 只能输入两个小数
    return amount;
}

function formatNum(amount) {
    amount = amount.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    amount = amount.replace(/^\./g, ""); // 验证第一个字符是数字
    amount = amount.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    amount = amount.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    amount = amount.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); // 只能输入两个小数
    return amount;
}