/*eslint-disable*/
import axios from 'axios'

axios.defaults.timeout = 3000
axios.defaults.baseURL = ''
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

if (process.env.NODE_ENV !== 'production') {
  axios.defaults.headers.common['uuid'] = new Date().getTime();;
  axios.defaults.headers.common['simpleDeviceInfo'] = JSON.stringify({ "language": "zh-CN" });
  axios.defaults.headers.common['custNo'] = '100000000702';
}

/**
 * 请求拦截器
 */
axios.interceptors.request.use((config) => {
  if (config.method == 'get') {
    config.data = true
    config.headers['Content-Type'] = 'application/json'
  }
  // Vue.$indicator.open({
  //   text: 'Loading...',
  //   spinnerType: 'fading-circle'
  // })
  // 在发送请求之前做些什么
  if (config.method === 'post') {
    console.info(`入参${config.url} :`, config.method, config.data)
  } else {
    console.info(`入参${config.url} :`, config.method, config.params)
  }
  // config.url = `/api${config.url}`
  return config
}, (error) => {
  console.info('request error', error)
  return Promise.reject(error)
})

/**
 * 响应拦截器
 */
axios.interceptors.response.use(function (response) {
  // console.info(JSON.stringify(response))
  // 对响应数据做点什么
  if (response.status !== 200) {
  }
  console.info(`返回${response.config.url} :`, response.data)

  return response
}, function (error) {
  // 对响应错误做点什么
  console.info('error', error.response)
  return Promise.reject(error)
})
export default axios
