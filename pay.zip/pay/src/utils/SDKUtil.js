/*
* 获取系统信息
* getSysType(str)
* */
export function getSysType(str) {
    var ua = navigator.userAgent.toLowerCase();
    var isIOS = ua.indexOf('ipad') > -1 || ua.indexOf('iphone') > -1 || false;
    var isAndroid = ua.indexOf('android') > -1 || false;
    // var isJdApp = ua.indexOf('ijr') > -1 || false;
    if (isAndroid) {
      var debugI18n = ua.indexOf('language_debug') > -1 || false;
    } else if(isIOS) {
      var debugI18n = ua.indexOf('language_debug=1') > -1 || false;
    } else {
      var debugI18n = false;
    }
    var isJdApp = ua.indexOf('t1w') > -1 || false;
    var result = {
        isIOS: isIOS,
        isAndroid: isAndroid,
        isJdApp: isJdApp,
        debugI18n: debugI18n
    }
    return str ? result[str] : result;
}

const platformInfo = getSysType()
const isJDAPP = platformInfo.isJdApp
const isAndroid = platformInfo.isAndroid
const isIOS = platformInfo.isIOS

let platformEnv = ''
function getPlatformEnv() {
    if (platformEnv) {
        return platformEnv
    }
    return new Promise(reslove => {
        window.wallet.platform.env(data => {
            platformEnv = data.data
            return reslove(data.data)
        })
    })
}

async function checkMethod(methodName, cb) {
    if (!isJDAPP) {
        return false
    }
    return new Promise(async reslove => {
        let platformEnv = await getPlatformEnv()
        console.info('platformEnv', platformEnv)
        const methods = platformEnv.methods
        const onEvents = platformEnv.onEvents
        const onRoutes = platformEnv.onRoutes
        if (methods.includes(methodName) || onEvents.includes(methodName) || onRoutes.includes(methodName)) {
            reslove(true)
        } else {
            // do something
            console.error('方法不存在:', methodName)
            reslove(false)
        }
    })
}

/**
 * 设置标题
 * @param {} obj 
 */
export async function setTitle(obj) {
    // if (!isJDAPP) {
    //     return false
    // }
    const default_obj = {
        title: 'Wallet',
        titleColor: '#000000',
        titleBackgroundColor: '#eeeeee',
        subTitleName: '子标题',
        subTitleColor: '#333333'
    }
    console.info('settitle')
    let ret = Object.assign(default_obj, obj)
    const flag = await checkMethod('setTitle')
    if (flag) {
        return window.wallet.platform.setTitle(ret)
    }
    return false
}

/**
 * 设置标题右面的
 * @param {} obj 
 */
export async function setTitleRight(obj, cb) {
    // if (!isJDAPP) {
    //     return false
    // }
    const flag = await checkMethod('onTitleBusiness')
    if (flag) {
        window.wallet.platform.onTitleBusiness(obj, cb);
    }
    return false
}

/**
 * 获取公共信息
 * @param {*} obj 
 */
export async function getCommonInfo() {
    // if (!isJDAPP) {
    //   return false
    // }
    const ret = await checkMethod('getCommonInfo')
    if (ret) {
        return new Promise(reslove => {
            window.wallet.platform.getCommonInfo(data => reslove(data.data))
        })
    }
}

/**
 * 根据输入的手机号获取通讯录列表
 * @param {*} obj 
 */
export async function getPhonesByNumber(num) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('getPhonesByNumber')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.getPhonesByNumber({
                inputdata: num
            }, data => reslove(data.data))
        })
    }
    return false
}

/**
 * 调用获取通讯录列表 获得一个手机号
 */
export async function goContactRes() {
    // if (!isJDAPP) {
    //   return false
    // }

    const flag = await checkMethod('goContactRes')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.goContactRes(data => reslove(data.data))
        })
    }
    return false
}

/**
 *  跳转到原生
 */
export async function goNativeAction(obj) {
    if (!isJDAPP) {
        return false
    }
    const flag = await checkMethod('goNativeAction');
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.goNativeAction(obj, data => reslove(data.data))
        })
    }
    return false
}

/**
 *  跳转到原生 -余额交易详情
 *  0 //交易记录
    1 //收钱列表记录
    2 //生活缴费记录
    3 //转账交易记录
    4 //余额交易记录
 */
export function goNativeActionTransDetail() {
    const json = {
        type: 'native',
        address: '/trade/transaction',
        params: {
            transactionType: 4
        }
    }
    return goNativeAction(json)
}

/**
 *  跳转到原生 -綁卡
 */
export function goNativeActionAddCard() {
    const json = {
        "type": "native",
        // "address": "/bank/management"  
        "address": "/cardCenter/requestPreBind"
    }

    return goNativeAction(json)
}

/**
 *  跳转到原生 -原声自定义的通讯录
 */
export function goNativeCustomContact() {
    const json = {
        "type": "native",
        "address": "/contact/book",
        params: {
            transactionType: 3
        }
    }
    return goNativeAction(json)
}

/**
 * 关闭webview
 */
export async function closeWebView() {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('close')
    if (flag) {
        return window.wallet.platform.close()
    }
    return false
}

/**
 * 监听返回键，这回接管系统事件，系统会取消默认操作，
 */
export async function onBackPress(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackPress');
    if (flag) {
        return window.wallet.platform.onBackPress(() => {
            cancleOnBackPress()
            cb()
        })
    }
    return false
}

/**
 * webview切到后台监听
 */
export async function onBackground(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackground')
    if (flag) {
        return window.wallet.platform.onBackground(() => {
            cb()
        })
    }
    return false
}

/**
 * webview回到前台监听
 */
export async function onForeground(cb = () => { }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onForeground')
    if (flag) {
        return window.wallet.platform.onForeground(() => {
            cb()
        })
    }
    return false
}

/**
 * 取消监听返回键
 */
export async function cancleOnBackPress() {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('onBackPress')
    if (flag) {
        console.info('取消了回退监听')
        return window.wallet.platform.onBackPress()
    }
    return false
}

/**
 * 跳转到原生 -收银台便利店支付方式页面
 * @param {交易号} orderNum 
 */
export function goNativeQrRechange(orderNum) {
    const json = {
        type: 'native',
        address: '/qr/recharge',
        params: {
            orderNum
        }
    }

    return goNativeAction(json)
}

/**
 *  跳转到原生 -关闭当前webwiew并发送结果
 */
export async function closeWebViewAndSendResult(json = { resultCode: 1 }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('close')
    if (flag) {
        return window.wallet.platform.close(json)
    }
    return false
}

/**
 * 跳转到原生主页
 */
export function goNativeMain() {
    const json = {
        type: 'native',
        address: '/main/main'
    }
    return goNativeAction(json)
}

/**
 * 原生页面事件埋点
 */
export async function buriedPoint(buriedPointJSON = { pageName: '', eventId: '', map: {} }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 3,
        ...buriedPointJSON
    }
    console.info('default_obj:', default_obj)
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 原生页面进入埋点
 */
export async function buriedPointEntry(buriedPointJSON = { pageName: '' }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 1,
        map: {},
        ...buriedPointJSON
    }
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 原生页面likai埋点
 */
export async function buriedPointLeave(buriedPointJSON = { pageName: '' }) {
    // if (!isJDAPP) {
    //   return false
    // }
    const default_obj = {
        mode: 1,
        actionType: 2,
        map: {},
        ...buriedPointJSON
    }
    const flag = await checkMethod('buriedPoint')
    if (flag) {
        return window.wallet.platform.buriedPoint(default_obj);
    }
    return false
}

/**
 * 生成条形码
 */
export async function setBarCode(obj, cb) {
    // if (!isJDAPP) {
    //     return false
    // }
    const flag = await checkMethod('getScanCode')
    if (flag) {
        window.wallet.platform.getScanCode(obj, cb);
    }
    return false
}

/**
 * 跳转到原生优惠券二维码
 */
export async function goNativeQrCoupon(couponId, merchantId) {
    const json = {
        type: 'native',
        address: '/qr/coupon',
        params: {
            couponId,
            merchantId
        }
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生我的优惠券列表
 */
export function goNativeCouponList() {
    const json = {
        type: 'native',
        address: '/coupon/listpage'
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生的其他app
 */
export function goOtherNativeAPP(scheme) {
    const json = {
        type: 'native',
        address: '/main/scheme',
        params: {
            scheme
        }
    }
    return goNativeAction(json)
}

/**
 * 检测一款app是否安装
 */
export async function checkInstallApps(scheme) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('checkInstallApps')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.checkInstallApps(scheme, data => {
                console.info('结果：：：', data)
                reslove(data.data)
            })
        })
    }
    return false
}

/**
 * 检测一款kplus是否安装
 */
export function checkInstallKplus() {
    // if (!isJDAPP) {
    //   return false
    // }
    let json = ''
    if (isAndroid) {
        json = {
            packages: ['com.kasikorn.retail.mbanking.wap']
        }
    } else if (isIOS) {
        json = {
            scheme: ['kbank.kplus://']
        }
    }
    return new Promise(reslove => {
        return checkInstallApps(json).then(ret => {
            let dat = 0
            if (isAndroid) {
                if (json.packages[0] === ret[0]) {
                    dat = 1
                } else {
                    dat = 0
                }
                reslove(dat)
            } else if (isIOS) {
                if (json.scheme[0] === ret[0]) {
                    dat = 1
                } else {
                    dat = 0
                }
                reslove(dat)
            }
        })
    })
}

/**
 * 跳转到原生的kyc
 */
export function goNativeKYC(params) {
    const json = {
        type: 'native',
        address: '/kyc/main'
    }
    if (params && typeof params === 'object') {
        json.params = params;
    }
    return goNativeAction(json)
}

/**
 * reload页面
 */
export async function reloadPage(obj, cb) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('reload')
    if (flag) {
        window.wallet.platform.reload(obj, cb);
    }
    return false
}

/**
 * 跳转到原生的QRCode页面
 */
export function goNativeQRCode() {
    const json = {
        type: 'native',
        address: '/qr/point'
    }
    return goNativeAction(json)
}

/**
 * 跳转到原生的unbindMsg
 */
export function goNativeThe1Bind() {
    const json = {
        type: 'native',
        address: '/account/bindThe1'
    }
    return goNativeAction(json)
}

/**
 * 埋点 目前支持 //channelType 1:Channel_FireBase;//channelType 2:Channel_AF;//channelType 3:Channel_FaceBook;//没有实现
 * 
    mList: [
    {
    channelType:1,
    eventId:'dsdsd',
    map:{
      test:'dsdsds',
      test2:'dsdsds'
    }
    },


    {
    channelType:2,
    eventId:'dsdsd',
    map:{
      test:'dsdsds',
      test2:'dsdsds'
    }
    }
      ]

 */
export async function buriedPointCore(mList) {
    // if (!isJDAPP) {
    //   return false
    // }
    const da = { mList }
    const flag = await checkMethod('buriedPointCore')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.buriedPointCore(da, data => {
                reslove(data.data)
            })
        })
    }
    return false
}

/**
 * 原生的ajax请求
 */
export async function request(data, cb) {
    // if (!isJDAPP) {
    //   return false
    // }
    const flag = await checkMethod('request')
    if (flag) {
        return window.wallet.platform.request(data, cb)
    }
    return false
}

/**
 * 原生的有没有 ajax请求
 */
export function checkHasAppRequest() {
    return checkMethod('request')
}

/**
 * 获取title方法
 */
export async function getTitleName() {

    const flag = await checkMethod('getTitleName')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.getTitleName('', data => reslove(data.data))
        })
    }
    return false
}

/**
 * 弹出原生选择国家号码窗口
 */
export function goCountryCode(callback) {
    const json = {
        type: 'native',
        address: '/public/selectCountryCode',
        params: {
            title: 'TEST'
        }
    }

    window.wallet.platform.goNativeAction(json, function (resp) {
        callback && callback(resp);
    });

    //return goNativeAction(json)
}

/**
 * 调用原生WEBVIEW
 */
export function goNativeWebview(url, callback) {
    var json = {
        type: 'native',
        address: '/webview/web',
        params: {
            url: url
        }
    };
    if (url.indexOf('transfer-settings.html') !== -1) {
        url = decodeURIComponent(url);
    }
    window.wallet.platform.goNativeAction(json, (res) => {
        callback && callback(res);
    });
}

/**
 * 关闭WEBVIEW回调函数
 * @param {*} item 
 */
export function closeNativeWebview(item) {
    var param = {
        resultCode: 1,
        result: item
    };

    window.wallet.platform.close(param);
}

/**
 * 弹出原生通讯录选择电话
 * @param {*} callback 
 */
export function goNativePhoneList(callback) {
    window.wallet.platform.goContactResForAllInfo((res) => {
        console.info(JSON.stringify(res))
        callback && callback(res);
    })
}

/**
 * 获取用户信息
 * @param {*} callback 
 */
export function getUserInfo(callback) {
    window.wallet.platform.getUserAccount(function (res) {
        callback && callback(res);
    });
}

/**
 * 保存数据
 * @param {*} key 
 * @param {*} value 
 * @param {*} mode 0是当前webview，内存;1是全局（需要重启APP）;2持久化到加密区 
 */
export function setCache(key, value, mode, callback) {
    if (!key || !value) {
        return false;
    }

    const json = {
        key: key,
        value: value,
        cacheMode: mode ? mode : 0
    };

    window.wallet.platform.putCache(json, function (resp) {
        callback && callback(resp);
    });
}

/**
 * 获取数据
 * @param {*} key 
 * @param {*} mode 
 * @param {*} callback 
 */
export function getCache(key, mode, callback) {
    if (!key) {
        return false;
    }

    const json = {
        key: key,
        cacheMode: mode ? mode : 0
    };

    // return new Promise(resolove => {
    //     window.wallet.platform.getCache(json, res => {alert(JSON.stringify(res));
    //         resolove(res)
    //     });
    // })

    window.wallet.platform.getCache(json, res => {
        callback && callback(res);
    });
}

/**
 * 删除数据
 */
export function removeCache(key, mode, callback) {
    if (!key) {
        return false;
    }

    const json = {
        key: key,
        cacheMode: mode ? mode : 0
    };

    window.wallet.platform.removeCache(json, function (resp) {
        callback && callback(resp);
    });
}

/**
 * 显示/隐藏顶部状态栏
 * @param {*} show 
 */
export function showTopStatusBar(show) {
    window.wallet.platform.setTitle({
        mHeaderTitle: {
            showHead: show || 0
        }
    }, false)
}

export function setTopStatusBar(obj) {
    if (!obj) {
        return;
    }
    window.wallet.platform.setTitle(obj, false)
}

/**
 * 设置顶部右侧图片点击事件
 */
export function setTopRightMenu() {
    window.wallet.platform.setMenu({
        menus: [{
            menuTitle: '菜单1',
            menuAction: function () {

            },
            menuImage: 'http://172.25.47.49/hybrid/demo/imgs/app-icon.png'
        }]
    }, function (resp) {

    });
}

export async function setHeaderWithImg(key, mode, callback) {
    var param = {

        left: {
            iconUrl: 'http://img0.imgtn.bdimg.com/it/u=1675008401,2896528661&fm=26&gp=0.jpg',
            show: 1
        },

        right: {
            text: '你好',
            show: 1,
            textSize: 18,
            textColor: '#00ffff'
        }

    };
    const flag = await checkMethod('onTitleBusiness2')
    if (flag) {
        return new Promise(reslove => {
            window.wallet.platform.onTitleBusiness2(param, data => {
                reslove(data.data)
            })
        })
    }

    return false
}
/**
 * 调用原生安全键盘
 */
export function callNativekeyboard() {
    const IsNumberChaos = 0;//是不是混乱的
    const IsOnlyNumberKeyboard = 1;//只是数字类型
    const isAddPoint = 0;//加小数点
    const ismi = 0;
    window.myEdit.onClick4Js(IsNumberChaos, IsOnlyNumberKeyboard, isAddPoint, ismi, null);
}

/**
 * 调用原生全屏Loading效果
 */
export function showNativeLoading(show) {
    var json = {
        title: 'loading...',
        backColor: '#00000000',
        textColor: '#FFFFFF',
        isShow: show ? 1 : 0
    };
    console.info(JSON.stringify(json));
    window.wallet.platform.showDialogLoading(json);
}

/**
 * 生成截屏
 */
export function buildSharePic(payInfo, callback) {
    const json = {
        payInfo
    }

    window.wallet.platform.getVBPayResImage(json, function (resp) {
        const result = resp.data;
        callback && typeof callback === 'function' && callback(result);
    });
}

/**
 * 原生分享
 */
export function shareBySDK(imageData) {
    return window.wallet.platform.shareBySDK({
        channelList: [1, 2, 3, 4, 5],
        type: 'image',
        imageBase64: imageData
    });
}

/**
 * 禁用、启用左上角回退按钮
 * @param {*} forbid 
 */
export function forbidLeftBackPress(forbid) {
    if (forbid) {
        window.wallet.platform.onBackPressPrehandle(function (resp) { });
    } else {
        window.wallet.platform.onBackPressPrehandle(null);
    }
}

/**
 * 敏感信息脱敏
 * @param {*} type 
 * @param {*} value 
 */
export function maskInfo(params) {
    return new Promise(resolve => {
        window.wallet.platform.mask(params, (res) => {
            resolve(res.data);
        });
    });
}
/**
 * 桥方法的注释
 *
 * checkNetwork:
 * 检查网络
 *
 */
export function checkNetwork() {
    return new Promise(resolve => {
        window.wallet.platform.checkNetwork((res) => {
            resolve(res);
        });
    });
}
/**
 * 桥方法的注释
 *
 * setTitle:
 * 控制中间显示的TITLE
 *
 * onTitleBusiness:
 * 只能控制右侧自定义
 *
 * 左侧 onBackPress
 * 控制回退按钮的事件
 */

