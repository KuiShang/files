const proxy = require('http-proxy-middleware')

module.exports = function (app) {
  // app.use(proxy('/cocgw', { target: 'http://192.168.0.69:19022/' }));
  // 设置限额——长亮 走的本地配置host 172.25.49.166 appgw.livibank.com
  app.use(proxy('/cocgw', { target: 'http://appgw.livibank.com', changeOrigin: true }));
  // 协议相关——王慧慧
  // app.use(proxy('/saser', { target: 'http://10.13.144.190:8080', changeOrigin: true }))
  // app.use(proxy('/saser', { target: 'http://10.13.144.202:8080', changeOrigin: true }));
  // app.use(proxy('/saser', { target: 'http://appgw.livibank.com', changeOrigin: true }));
  //app.use(proxy('/saser', { target: 'http://appgw.livibank.com', changeOrigin: true }));
}