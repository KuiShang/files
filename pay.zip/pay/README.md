# VB Pay (Trasfer/Trasfer Settings)
===============================

TODO: 功能优化(2019/5/30)
1: 整体打包脚本优化，添加打包进度，提高打包速度；
2: 对于代码中Warning的修改；
3: 将eDDA/SeDDA逻辑进行拆分，二者将不在一起进行逻辑编写；
4: 如果采用的是PNG图片，需要TINY一次；

ZIP Package' Name: vb_fe_pay-20190711T0001


============================ 2019.8.7 ============================
1: IOS字体问题；
2: Android 底部Pay改为 Transfer;
4: iOS/ Android Contact List 修改为 My Mobile Contacts;
3: Recent 搜索框改为Search；
5: Transfer Instructions 时候 Scheduled fo Later 修改为 Later;
6: Transfer Review VB Saving Account 修改为 livi Saving Account;
7: Transfer Account No ----  Branch Code + Account No 修改为 Account Number
8: Hint 全修改为 Tips;
9: Tranfser Review 标题 从Review Details 修改为 Review;
10: 确认取消转账，Confirm 修改为 Yes， Cancel 修改为 No；
11: Loading 全局效果太差；
12: Transfer Result 结果页的 Payment Details 修改 Transfer Details
13: 分享出去的转账结果页图片，（第一行）Scan to Download livi!  （第二行）Enjoy life, join livi! 
14: jay 图片

